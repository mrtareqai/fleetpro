/**
 * Token Refresh API Endpoint
 *
 * POST /api/auth/refresh
 *
 * Refreshes an expired access token using a valid refresh token.
 *
 * Request Body:
 * {
 *   refresh_token: string
 * }
 *
 * Response:
 * {
 *   access_token: string,
 *   refresh_token: string
 * }
 */

import { type NextRequest, NextResponse } from "next/server"
import { verifyToken, generateToken, generateRefreshToken } from "@/lib/security/jwt"
import { getUserPermissions } from "@/lib/permissions"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { refresh_token } = body

    if (!refresh_token) {
      return NextResponse.json({ error: "Refresh token is required" }, { status: 400 })
    }

    // Verify refresh token
    const decoded = await verifyToken(refresh_token)

    // Get updated permissions
    const permissions = await getUserPermissions(decoded.userId)

    // Generate new tokens
    const tokenPayload = {
      userId: decoded.userId,
      role: decoded.role,
      permissions: permissions.permissions,
      companyId: decoded.companyId,
    }

    const newAccessToken = await generateToken(tokenPayload)
    const newRefreshToken = await generateRefreshToken(tokenPayload)

    return NextResponse.json({
      access_token: newAccessToken,
      refresh_token: newRefreshToken,
    })
  } catch (error) {
    console.error("[v0] Token refresh error:", error)
    return NextResponse.json({ error: "Invalid or expired refresh token" }, { status: 401 })
  }
}
