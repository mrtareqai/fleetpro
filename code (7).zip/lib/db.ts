import { neon } from "@neondatabase/serverless"

let sqlInstance: ReturnType<typeof neon> | null = null

export function getSQL() {
  if (typeof window !== "undefined") {
    // Running on client side - return null
    return null
  }

  if (!sqlInstance && process.env.DATABASE_URL) {
    sqlInstance = neon(process.env.DATABASE_URL)
  }

  return sqlInstance
}

// For backwards compatibility, export sql but it will be null on client
export const sql = typeof window === "undefined" && process.env.DATABASE_URL ? neon(process.env.DATABASE_URL) : null

// Helper to check if database is available
export function isDatabaseAvailable(): boolean {
  if (typeof window !== "undefined") {
    return false
  }
  return !!process.env.DATABASE_URL
}

// Export type for SQL query function
export type SQL = ReturnType<typeof neon> | null
