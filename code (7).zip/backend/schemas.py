"""
Pydantic schemas for request/response validation
"""

from pydantic import BaseModel, EmailStr
from datetime import date, datetime
from typing import Optional

# Vehicle schemas
class VehicleBase(BaseModel):
    manufacture_date: Optional[date] = None
    model: Optional[str] = None
    plate_number: Optional[str] = None
    base_number: Optional[str] = None
    card_number: Optional[str] = None
    expiry_date: Optional[date] = None
    status: Optional[str] = "active"
    country: Optional[str] = None

class VehicleCreate(VehicleBase):
    pass

class VehicleUpdate(VehicleBase):
    pass

class VehicleResponse(VehicleBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Driver schemas
class DriverBase(BaseModel):
    name: str
    license_number: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    status: Optional[str] = "active"

class DriverCreate(DriverBase):
    pass

class DriverUpdate(DriverBase):
    name: Optional[str] = None

class DriverResponse(DriverBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Reservation schemas
class ReservationBase(BaseModel):
    vehicle_id: Optional[int] = None
    driver_id: Optional[int] = None
    customer_name: Optional[str] = None
    pickup_date: Optional[date] = None
    return_date: Optional[date] = None
    destination: Optional[str] = None
    status: Optional[str] = "pending"

class ReservationCreate(ReservationBase):
    pass

class ReservationUpdate(ReservationBase):
    pass

class ReservationResponse(ReservationBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Ticket schemas
class TicketBase(BaseModel):
    ticket_number: str
    subject: str
    category: Optional[str] = None
    assigned_to: Optional[str] = None
    priority: Optional[str] = "medium"
    status: Optional[str] = "open"
    date_created: Optional[date] = None

class TicketCreate(TicketBase):
    pass

class TicketUpdate(BaseModel):
    subject: Optional[str] = None
    category: Optional[str] = None
    assigned_to: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None

class TicketResponse(TicketBase):
    id: int
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True

# Auth schemas
class UserLogin(BaseModel):
    username: str
    password: str

class UserRegister(BaseModel):
    username: str
    email: EmailStr
    password: str
    full_name: Optional[str] = None

class Token(BaseModel):
    access_token: str
    token_type: str

class UserResponse(BaseModel):
    id: str
    username: str
    email: str
    full_name: Optional[str] = None
    role: str

    class Config:
        from_attributes = True
