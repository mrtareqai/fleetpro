/**
 * Mock Data Configuration
 * Central configuration for mock data behavior
 */

function shouldEnableMockData(): boolean {
  if (typeof window !== "undefined") {
    // On client side, default to enabled (will be overridden by API responses)
    return true
  }
  return !process.env.NEON_DATABASE_URL
}

export const MockDataConfig = {
  // Enable/disable mock data globally
  get enabled() {
    return shouldEnableMockData()
  },

  // Data generation settings
  generation: {
    users: 50,
    vehicles: 100,
    drivers: 80,
    reservations: 200,
    movements: 500,
    tickets: 300,
    supplies: 50,
  },

  // Network simulation
  network: {
    enabled: true,
    condition: "good" as "excellent" | "good" | "fair" | "poor",
    simulateErrors: true,
    simulateTimeouts: true,
  },

  // Performance settings
  performance: {
    lazyLoading: true,
    caching: true,
    pagination: {
      enabled: true,
      defaultPageSize: 20,
    },
  },

  // Development helpers
  development: {
    logApiCalls: true,
    logDataGeneration: true,
    showNetworkStats: true,
  },

  // Data persistence
  persistence: {
    useLocalStorage: true,
    storageKey: "fleetpro_mock_data_v2",
  },
} as const

/**
 * Update configuration at runtime
 */
export function updateMockConfig(updates: Partial<typeof MockDataConfig>) {
  Object.assign(MockDataConfig, updates)
  console.log("[v0] Mock data configuration updated:", updates)
}
