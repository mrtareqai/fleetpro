# متغيرات البيئة المطلوبة - Environment Variables

## 🔧 متغيرات Neon Database (مطلوبة)

المشروع يستخدم قاعدة بيانات Neon PostgreSQL. المتغيرات التالية متوفرة من تكامل Neon:

### سلسلة الاتصال الخاصة بك

تم توفير سلسلة الاتصال التالية:

\`\`\`env
NEON_NEON_DATABASE_URL=postgresql://neondb_owner:npg_yrGIk2Awoab8@ep-icy-cloud-adpafx3r-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
\`\`\`

⚠️ **تحذير أمني**: هذه سلسلة اتصال حقيقية تحتوي على بيانات اعتماد. يجب:
1. عدم مشاركتها علناً
2. إضافتها فقط في متغيرات البيئة في Vercel
3. عدم كتابتها في الكود أو Git
4. تغيير كلمة المرور إذا تم تسريبها

### المتغيرات الأساسية (متوفرة حالياً)

\`\`\`env
# متغير الاتصال الرئيسي (المستخدم في المشروع)
NEON_DATABASE_URL=postgresql://neondb_owner:npg_yrGIk2Awoab8@ep-icy-cloud-adpafx3r-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# متغيرات إضافية من Neon
NEON_POSTGRES_URL=postgresql://user:password@host/database
NEON_POSTGRES_PRISMA_URL=postgresql://user:password@host/database?pgbouncer=true
NEON_DATABASE_URL_UNPOOLED=postgresql://user:password@host/database
NEON_POSTGRES_URL_NON_POOLING=postgresql://user:password@host/database
NEON_POSTGRES_URL_NO_SSL=postgresql://user:password@host/database?sslmode=disable
NEON_PGHOST=host.neon.tech
NEON_PGHOST_UNPOOLED=host.neon.tech
NEON_POSTGRES_USER=username
NEON_PGUSER=username
NEON_POSTGRES_PASSWORD=password
NEON_PGPASSWORD=password
NEON_POSTGRES_DATABASE=database_name
NEON_PGDATABASE=database_name
NEON_POSTGRES_HOST=host.neon.tech
NEON_NEON_PROJECT_ID=project-id-xxxx
\`\`\`

## 🔐 متغيرات الأمان (اختيارية - للإنتاج)

\`\`\`env
# JWT Secret (سيتم توليده تلقائياً إذا لم يتم تحديده)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# JWT Expiration (افتراضي: 7d)
JWT_EXPIRES_IN=7d

# Refresh Token Expiration (افتراضي: 30d)
REFRESH_TOKEN_EXPIRES_IN=30d
\`\`\`

## 📊 متغيرات Upstash (متوفرة)

\`\`\`env
# Upstash Redis (للتخزين المؤقت وتحديد المعدل)
UPSTASH-KV_KV_REST_API_URL=https://xxx.upstash.io
UPSTASH-KV_KV_REST_API_TOKEN=your-token
UPSTASH-KV_KV_REST_API_READ_ONLY_TOKEN=your-readonly-token

# Upstash Search (للبحث المتقدم)
UPSTASH-SEARCH_UPSTASH_SEARCH_REST_URL=https://xxx.upstash.io
UPSTASH-SEARCH_UPSTASH_SEARCH_REST_TOKEN=your-token

# Upstash QStash (للمهام المجدولة)
UPSTASH-QSTASH_QSTASH_URL=https://qstash.upstash.io
UPSTASH-QSTASH_QSTASH_TOKEN=your-token
\`\`\`

## 🚀 كيفية إضافة المتغيرات في Vercel

### الطريقة 1: من خلال لوحة تحكم Vercel

1. افتح مشروعك في Vercel Dashboard
2. اذهب إلى **Settings** → **Environment Variables**
3. أضف المتغيرات المطلوبة:
   - **Key**: اسم المتغير (مثل `NEON_DATABASE_URL`)
   - **Value**: قيمة المتغير
   - **Environment**: اختر `Production`, `Preview`, `Development`
4. اضغط **Save**

### الطريقة 2: من خلال Vercel CLI

\`\`\`bash
# تسجيل الدخول إلى Vercel
vercel login

# ربط المشروع
vercel link

# إضافة متغير بيئة
vercel env add NEON_DATABASE_URL production
# ثم أدخل القيمة عند الطلب

# أو إضافة من ملف
vercel env pull .env.local
\`\`\`

### الطريقة 3: من خلال v0 Interface

1. افتح **In-chat sidebar** (الشريط الجانبي)
2. اذهب إلى **Vars** (المتغيرات)
3. أضف المتغيرات المطلوبة مباشرة

## ✅ التحقق من المتغيرات

بعد إضافة المتغيرات، تحقق من أنها تعمل:

\`\`\`typescript
// في أي ملف API Route أو Server Component
console.log('Database URL exists:', !!process.env.NEON_DATABASE_URL)
\`\`\`

## 🔄 إعادة النشر

بعد إضافة المتغيرات، يجب إعادة نشر المشروع:

\`\`\`bash
vercel --prod
\`\`\`

أو من لوحة التحكم:
1. اذهب إلى **Deployments**
2. اضغط على **Redeploy** للنشر الأخير

## 📝 ملاحظات مهمة

1. **الأمان**: لا تشارك قيم المتغيرات أبداً في الكود أو Git
2. **البيئات**: استخدم قيم مختلفة للتطوير والإنتاج
3. **التحديث**: بعد تغيير المتغيرات، يجب إعادة النشر
4. **النسخ الاحتياطي**: احتفظ بنسخة آمنة من جميع المتغيرات

## 🐛 استكشاف الأخطاء

### المشكلة: "Database connection failed"

**الحل**:
1. تحقق من وجود `NEON_DATABASE_URL` في متغيرات البيئة
2. تأكد من صحة قيمة الاتصال
3. تحقق من أن قاعدة البيانات نشطة في Neon Dashboard

### المشكلة: "Environment variable not found"

**الحل**:
1. تأكد من إضافة المتغير في البيئة الصحيحة (Production/Preview/Development)
2. أعد نشر المشروع بعد إضافة المتغيرات
3. تحقق من عدم وجود أخطاء إملائية في اسم المتغير

### المشكلة: "Cannot read properties of undefined"

**الحل**:
1. تأكد من استخدام `process.env.VARIABLE_NAME` وليس `process.env['VARIABLE_NAME']`
2. تأكد من أن المتغير يبدأ بـ `NEXT_PUBLIC_` إذا كنت تستخدمه في Client Component
3. أعد تشغيل خادم التطوير بعد إضافة متغيرات جديدة
