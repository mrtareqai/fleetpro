# Rate Limiting Implementation Plan

## Executive Summary

This document provides a comprehensive implementation plan for integrating rate limiting across the FleetPro application. Rate limiting is a critical security measure that protects against brute force attacks, API abuse, and denial-of-service attempts while maintaining optimal user experience.

## Table of Contents

1. [Overview](#overview)
2. [Rate Limiting Strategies](#rate-limiting-strategies)
3. [Configuration Guidelines](#configuration-guidelines)
4. [Implementation Roadmap](#implementation-roadmap)
5. [Testing Strategy](#testing-strategy)
6. [Monitoring and Maintenance](#monitoring-and-maintenance)
7. [Production Considerations](#production-considerations)

---

## Overview

### What is Rate Limiting?

Rate limiting controls the number of requests a client can make to an API within a specified time window. It acts as a protective barrier against:

- **Brute Force Attacks**: Prevents password guessing attempts
- **API Abuse**: Limits excessive resource consumption
- **DDoS Attacks**: Mitigates denial-of-service impact
- **Data Scraping**: Prevents automated data extraction
- **Cost Control**: Reduces infrastructure costs from excessive requests

### Current Implementation Status

| Component | Status | Location |
|-----------|--------|----------|
| Core Rate Limiter | ✅ Implemented | `lib/security/rate-limit.ts` |
| Login Protection | ✅ Implemented | `app/api/auth/login/route.ts` |
| API Routes | ⚠️ Partial | Various API routes |
| Admin Routes | ❌ Not Implemented | `app/api/admin/**` |
| Public Routes | ❌ Not Implemented | Public endpoints |

### Architecture

\`\`\`
┌─────────────────────────────────────────────────────┐
│                  Client Request                      │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│            Rate Limit Middleware                     │
│  • Extract identifier (IP/User ID)                   │
│  • Check request count                               │
│  • Update counter                                    │
│  • Return 429 if exceeded                            │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│          In-Memory Store (Map)                       │
│  Key: "ip:192.168.1.1:endpoint:/api/login"          │
│  Value: { count: 3, resetTime: 1705320000 }         │
└──────────────────┬──────────────────────────────────┘
                   │
                   ▼
┌─────────────────────────────────────────────────────┐
│            Automatic Cleanup                         │
│  • Runs every 5 minutes                              │
│  • Removes expired entries                           │
└─────────────────────────────────────────────────────┘
\`\`\`

---

## Rate Limiting Strategies

### 1. Fixed Window Counter

**How it works:**
- Counts requests in fixed time windows (e.g., 1 minute)
- Resets counter at window boundary
- Simple and memory-efficient

**Pros:**
- Easy to implement
- Low memory usage
- Predictable behavior

**Cons:**
- Burst traffic at window boundaries
- Not perfectly smooth

**Use case:** General API protection

\`\`\`typescript
// Example: 100 requests per minute
const limiter = createRateLimiter({
  maxRequests: 100,
  windowMs: 60000
})
\`\`\`

### 2. Sliding Window Log

**How it works:**
- Tracks timestamp of each request
- Counts requests in sliding time window
- More accurate than fixed window

**Pros:**
- Smooth rate limiting
- No boundary burst issues
- Accurate counting

**Cons:**
- Higher memory usage
- More complex implementation

**Use case:** High-security endpoints

### 3. Token Bucket

**How it works:**
- Bucket holds tokens (requests)
- Tokens refill at constant rate
- Request consumes one token
- Allows burst traffic up to bucket size

**Pros:**
- Allows controlled bursts
- Smooth long-term rate
- Industry standard

**Cons:**
- More complex
- Requires token tracking

**Use case:** APIs with bursty traffic patterns

### Strategy Selection Matrix

| Endpoint Type | Strategy | Reason |
|---------------|----------|--------|
| Authentication | Fixed Window | Simple, effective for brute force prevention |
| Public API | Token Bucket | Allows bursts, smooth long-term rate |
| Admin API | Sliding Window | High accuracy for sensitive operations |
| File Upload | Token Bucket | Handles large request sizes |
| Search | Fixed Window | Simple, predictable |

---

## Configuration Guidelines

### Determining Rate Limits

#### Step 1: Analyze Usage Patterns

\`\`\`typescript
// Log request patterns for analysis
console.log('[v0] Request:', {
  endpoint: request.url,
  method: request.method,
  ip: getClientIp(request),
  timestamp: new Date().toISOString()
})
\`\`\`

#### Step 2: Calculate Baseline

**Formula:**
\`\`\`
Rate Limit = (Expected Peak Traffic × Safety Factor) / Time Window
\`\`\`

**Example:**
- Expected peak: 50 requests/minute
- Safety factor: 2x (for spikes)
- Rate limit: 100 requests/minute

#### Step 3: Set Conservative Initial Limits

Start with generous limits and tighten based on monitoring:

\`\`\`typescript
// Initial configuration (generous)
const initialLimits = {
  login: { maxRequests: 10, windowMs: 15 * 60 * 1000 },
  api: { maxRequests: 200, windowMs: 60 * 1000 },
  admin: { maxRequests: 50, windowMs: 60 * 1000 }
}

// After monitoring (optimized)
const optimizedLimits = {
  login: { maxRequests: 5, windowMs: 15 * 60 * 1000 },
  api: { maxRequests: 100, windowMs: 60 * 1000 },
  admin: { maxRequests: 30, windowMs: 60 * 1000 }
}
\`\`\`

### Recommended Limits by Endpoint Type

#### Authentication Endpoints

\`\`\`typescript
// Login - Strict limits to prevent brute force
export const loginRateLimiter = createRateLimiter({
  maxRequests: 5,           // 5 attempts
  windowMs: 15 * 60 * 1000, // per 15 minutes
  message: "Too many login attempts. Please try again in 15 minutes."
})

// Password reset - Very strict
export const passwordResetLimiter = createRateLimiter({
  maxRequests: 3,           // 3 attempts
  windowMs: 60 * 60 * 1000, // per hour
  message: "Too many password reset requests."
})

// Registration - Moderate limits
export const registrationLimiter = createRateLimiter({
  maxRequests: 3,           // 3 registrations
  windowMs: 60 * 60 * 1000, // per hour
  message: "Registration limit exceeded."
})
\`\`\`

#### API Endpoints

\`\`\`typescript
// General API - Moderate limits
export const apiRateLimiter = createRateLimiter({
  maxRequests: 100,         // 100 requests
  windowMs: 60 * 1000,      // per minute
  message: "API rate limit exceeded. Please slow down."
})

// Search API - Higher limits (read-heavy)
export const searchRateLimiter = createRateLimiter({
  maxRequests: 200,         // 200 requests
  windowMs: 60 * 1000,      // per minute
  message: "Search rate limit exceeded."
})

// Write operations - Lower limits
export const writeRateLimiter = createRateLimiter({
  maxRequests: 30,          // 30 requests
  windowMs: 60 * 1000,      // per minute
  message: "Write operation limit exceeded."
})
\`\`\`

#### Admin Endpoints

\`\`\`typescript
// Admin operations - Moderate limits
export const adminRateLimiter = createRateLimiter({
  maxRequests: 50,          // 50 requests
  windowMs: 60 * 1000,      // per minute
  message: "Admin API rate limit exceeded."
})

// Sensitive admin operations - Strict limits
export const sensitiveAdminLimiter = createRateLimiter({
  maxRequests: 10,          // 10 requests
  windowMs: 60 * 1000,      // per minute
  message: "Sensitive operation limit exceeded."
})
\`\`\`

#### Public Endpoints

\`\`\`typescript
// Public API - Generous limits
export const publicRateLimiter = createRateLimiter({
  maxRequests: 300,         // 300 requests
  windowMs: 60 * 1000,      // per minute
  message: "Public API rate limit exceeded."
})

// File downloads - Lower limits (bandwidth intensive)
export const downloadRateLimiter = createRateLimiter({
  maxRequests: 10,          // 10 downloads
  windowMs: 60 * 1000,      // per minute
  message: "Download limit exceeded."
})
\`\`\`

### Time Window Selection

| Window Duration | Use Case | Example |
|-----------------|----------|---------|
| 1 minute | General API calls | Read operations |
| 5 minutes | Moderate security | Search, filters |
| 15 minutes | High security | Login attempts |
| 1 hour | Very strict | Password reset, registration |
| 24 hours | Extreme limits | Account creation |

### Identifier Selection

#### IP-Based Limiting

**Pros:**
- Works for unauthenticated users
- Simple to implement
- Prevents distributed attacks

**Cons:**
- Shared IPs (NAT, proxies)
- Can block legitimate users
- Easy to bypass (VPN, proxies)

\`\`\`typescript
const ip = getClientIp(request)
const result = await limiter.check(ip)
\`\`\`

#### User-Based Limiting

**Pros:**
- Accurate per-user tracking
- Fair resource allocation
- Harder to bypass

**Cons:**
- Only works for authenticated users
- Requires user identification

\`\`\`typescript
const authResult = await requireAuth(request)
const userId = authResult.userId
const result = await limiter.check(`user:${userId}`)
\`\`\`

#### Combined Approach (Recommended)

\`\`\`typescript
// Use IP for unauthenticated, user ID for authenticated
const identifier = authResult 
  ? `user:${authResult.userId}`
  : `ip:${getClientIp(request)}`

const result = await limiter.check(identifier)
\`\`\`

---

## Implementation Roadmap

### Phase 1: Core Infrastructure (Week 1)

**Status:** ✅ Complete

- [x] Create rate limiting module
- [x] Implement in-memory store
- [x] Add automatic cleanup
- [x] Create pre-configured limiters
- [x] Implement IP extraction

### Phase 2: Authentication Protection (Week 1)

**Status:** ✅ Complete

- [x] Protect login endpoint
- [x] Protect refresh token endpoint
- [x] Add rate limit headers
- [x] Implement retry-after logic

### Phase 3: API Route Protection (Week 2)

**Status:** ⚠️ In Progress

#### 3.1 Update Security Middleware

\`\`\`typescript
// lib/security/api-auth.ts
export async function requireAuth(
  request: NextRequest,
  options: {
    checkRateLimit?: boolean
    rateLimiter?: ReturnType<typeof createRateLimiter>
  } = {}
): Promise<AuthResult | Response> {
  if (options.checkRateLimit !== false) {
    const limiter = options.rateLimiter || apiRateLimiter
    const identifier = getClientIp(request)
    const rateLimitResult = await limiter.check(identifier)
    
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: "Too many requests", retryAfter: rateLimitResult.retryAfter },
        {
          status: 429,
          headers: {
            'X-RateLimit-Limit': rateLimitResult.limit.toString(),
            'X-RateLimit-Remaining': rateLimitResult.remaining.toString(),
            'X-RateLimit-Reset': new Date(rateLimitResult.reset).toISOString(),
            'Retry-After': rateLimitResult.retryAfter?.toString() || '60'
          }
        }
      )
    }
  }
  
  // ... existing auth logic ...
}
\`\`\`

#### 3.2 Protect Driver Routes

\`\`\`typescript
// app/api/drivers/route.ts
import { requirePermission } from "@/lib/security/api-auth"
import { apiRateLimiter } from "@/lib/security/rate-limit"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "drivers.read", {
    rateLimiter: apiRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
}
\`\`\`

#### 3.3 Protect Vehicle Routes

\`\`\`typescript
// app/api/vehicles/route.ts
import { requirePermission } from "@/lib/security/api-auth"
import { apiRateLimiter } from "@/lib/security/rate-limit"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "vehicles.read", {
    rateLimiter: apiRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
}
\`\`\`

### Phase 4: Admin Route Protection (Week 2)

#### 4.1 Create Admin Rate Limiter

\`\`\`typescript
// lib/security/rate-limit.ts

export const adminRateLimiter = createRateLimiter({
  maxRequests: 50,
  windowMs: 60 * 1000,
  message: "Admin API rate limit exceeded."
})

export const sensitiveAdminLimiter = createRateLimiter({
  maxRequests: 10,
  windowMs: 60 * 1000,
  message: "Sensitive operation limit exceeded."
})
\`\`\`

#### 4.2 Protect User Management

\`\`\`typescript
// app/api/admin/users/route.ts
import { adminRateLimiter } from "@/lib/security/rate-limit"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "users.read", {
    rateLimiter: adminRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
}

export async function POST(request: NextRequest) {
  const authResult = await requirePermission(request, "users.create", {
    rateLimiter: sensitiveAdminLimiter
  })
  if (authResult instanceof Response) return authResult
  
}
\`\`\`

#### 4.3 Protect Role Management

\`\`\`typescript
// app/api/admin/roles/route.ts
import { adminRateLimiter, sensitiveAdminLimiter } from "@/lib/security/rate-limit"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "roles.read", {
    rateLimiter: adminRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
}

export async function POST(request: NextRequest) {
  const authResult = await requirePermission(request, "roles.create", {
    rateLimiter: sensitiveAdminLimiter
  })
  if (authResult instanceof Response) return authResult
  
}
\`\`\`

### Phase 5: Specialized Endpoints (Week 3)

#### 5.1 File Upload Protection

\`\`\`typescript
// app/api/upload/route.ts
import { createRateLimiter } from "@/lib/security/rate-limit"

const uploadRateLimiter = createRateLimiter({
  maxRequests: 10,
  windowMs: 60 * 1000,
  message: "Upload limit exceeded."
})

export async function POST(request: NextRequest) {
  const authResult = await requireAuth(request, {
    rateLimiter: uploadRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
  // ... upload logic ...
}
\`\`\`

#### 5.2 Search Endpoint Protection

\`\`\`typescript
// app/api/search/route.ts
import { createRateLimiter } from "@/lib/security/rate-limit"

const searchRateLimiter = createRateLimiter({
  maxRequests: 200,
  windowMs: 60 * 1000,
  message: "Search rate limit exceeded."
})

export async function GET(request: NextRequest) {
  const authResult = await requireAuth(request, {
    rateLimiter: searchRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
  // ... search logic ...
}
\`\`\`

#### 5.3 Export Endpoint Protection

\`\`\`typescript
// app/api/export/route.ts
import { createRateLimiter } from "@/lib/security/rate-limit"

const exportRateLimiter = createRateLimiter({
  maxRequests: 5,
  windowMs: 60 * 1000,
  message: "Export limit exceeded."
})

export async function POST(request: NextRequest) {
  const authResult = await requireAuth(request, {
    rateLimiter: exportRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
  // ... export logic ...
}
\`\`\`

### Phase 6: Monitoring and Optimization (Week 4)

#### 6.1 Add Logging

\`\`\`typescript
// lib/security/rate-limit.ts

export function createRateLimiter(config: RateLimitConfig) {
  return {
    async check(identifier: string): Promise<RateLimitResult> {
      const result = await checkRateLimit(identifier, config)
      
      if (!result.success) {
        console.warn('[v0] Rate limit exceeded:', {
          identifier,
          limit: result.limit,
          endpoint: config.endpoint,
          timestamp: new Date().toISOString()
        })
      }
      
      return result
    }
  }
}
\`\`\`

#### 6.2 Add Metrics Collection

\`\`\`typescript
// lib/security/rate-limit-metrics.ts

interface RateLimitMetrics {
  totalRequests: number
  blockedRequests: number
  uniqueIdentifiers: Set<string>
  endpointStats: Map<string, { allowed: number; blocked: number }>
}

const metrics: RateLimitMetrics = {
  totalRequests: 0,
  blockedRequests: 0,
  uniqueIdentifiers: new Set(),
  endpointStats: new Map()
}

export function recordRateLimitCheck(
  identifier: string,
  endpoint: string,
  allowed: boolean
) {
  metrics.totalRequests++
  metrics.uniqueIdentifiers.add(identifier)
  
  if (!allowed) {
    metrics.blockedRequests++
  }
  
  const stats = metrics.endpointStats.get(endpoint) || { allowed: 0, blocked: 0 }
  if (allowed) {
    stats.allowed++
  } else {
    stats.blocked++
  }
  metrics.endpointStats.set(endpoint, stats)
}

export function getMetrics() {
  return {
    ...metrics,
    uniqueIdentifiers: metrics.uniqueIdentifiers.size,
    blockRate: (metrics.blockedRequests / metrics.totalRequests) * 100
  }
}
\`\`\`

---

## Testing Strategy

### Unit Tests

#### Test Rate Limiter Logic

\`\`\`typescript
// __tests__/lib/security/rate-limit.test.ts

import { createRateLimiter } from '@/lib/security/rate-limit'

describe('Rate Limiter', () => {
  describe('Fixed Window', () => {
    it('should allow requests within limit', async () => {
      const limiter = createRateLimiter({
        maxRequests: 5,
        windowMs: 60000
      })
      
      // Make 5 requests
      for (let i = 0; i < 5; i++) {
        const result = await limiter.check('test-user')
        expect(result.success).toBe(true)
        expect(result.remaining).toBe(4 - i)
      }
    })
    
    it('should block requests exceeding limit', async () => {
      const limiter = createRateLimiter({
        maxRequests: 3,
        windowMs: 60000
      })
      
      // Make 3 allowed requests
      for (let i = 0; i < 3; i++) {
        await limiter.check('test-user')
      }
      
      // 4th request should be blocked
      const result = await limiter.check('test-user')
      expect(result.success).toBe(false)
      expect(result.remaining).toBe(0)
      expect(result.retryAfter).toBeGreaterThan(0)
    })
    
    it('should reset after window expires', async () => {
      const limiter = createRateLimiter({
        maxRequests: 2,
        windowMs: 100 // 100ms window for testing
      })
      
      // Use up limit
      await limiter.check('test-user')
      await limiter.check('test-user')
      
      // Should be blocked
      let result = await limiter.check('test-user')
      expect(result.success).toBe(false)
      
      // Wait for window to expire
      await new Promise(resolve => setTimeout(resolve, 150))
      
      // Should be allowed again
      result = await limiter.check('test-user')
      expect(result.success).toBe(true)
    })
    
    it('should track different identifiers separately', async () => {
      const limiter = createRateLimiter({
        maxRequests: 2,
        windowMs: 60000
      })
      
      // User 1 uses limit
      await limiter.check('user-1')
      await limiter.check('user-1')
      
      // User 1 blocked
      let result = await limiter.check('user-1')
      expect(result.success).toBe(false)
      
      // User 2 still allowed
      result = await limiter.check('user-2')
      expect(result.success).toBe(true)
    })
  })
  
  describe('Rate Limit Headers', () => {
    it('should return correct header values', async () => {
      const limiter = createRateLimiter({
        maxRequests: 10,
        windowMs: 60000
      })
      
      const result = await limiter.check('test-user')
      
      expect(result.limit).toBe(10)
      expect(result.remaining).toBe(9)
      expect(result.reset).toBeGreaterThan(Date.now())
    })
  })
  
  describe('Reset Functionality', () => {
    it('should reset rate limit for identifier', async () => {
      const limiter = createRateLimiter({
        maxRequests: 1,
        windowMs: 60000
      })
      
      // Use up limit
      await limiter.check('test-user')
      
      // Should be blocked
      let result = await limiter.check('test-user')
      expect(result.success).toBe(false)
      
      // Reset
      limiter.reset('test-user')
      
      // Should be allowed again
      result = await limiter.check('test-user')
      expect(result.success).toBe(true)
    })
  })
})
\`\`\`

#### Test IP Extraction

\`\`\`typescript
// __tests__/lib/security/rate-limit.test.ts

import { getClientIp } from '@/lib/security/rate-limit'

describe('IP Extraction', () => {
  it('should extract IP from x-real-ip header', () => {
    const request = new Request('http://localhost', {
      headers: { 'x-real-ip': '192.168.1.1' }
    })
    
    expect(getClientIp(request)).toBe('192.168.1.1')
  })
  
  it('should extract first IP from x-forwarded-for', () => {
    const request = new Request('http://localhost', {
      headers: { 'x-forwarded-for': '192.168.1.1, 10.0.0.1' }
    })
    
    expect(getClientIp(request)).toBe('192.168.1.1')
  })
  
  it('should return unknown if no IP headers', () => {
    const request = new Request('http://localhost')
    
    expect(getClientIp(request)).toBe('unknown')
  })
  
  it('should prioritize x-real-ip over x-forwarded-for', () => {
    const request = new Request('http://localhost', {
      headers: {
        'x-real-ip': '192.168.1.1',
        'x-forwarded-for': '10.0.0.1'
      }
    })
    
    expect(getClientIp(request)).toBe('192.168.1.1')
  })
})
\`\`\`

### Integration Tests

#### Test Login Rate Limiting

\`\`\`typescript
// __tests__/api/auth/login.test.ts

describe('POST /api/auth/login - Rate Limiting', () => {
  beforeEach(() => {
    // Reset rate limiter before each test
    loginRateLimiter.reset('test-ip')
  })
  
  it('should allow 5 login attempts', async () => {
    for (let i = 0; i < 5; i++) {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-real-ip': 'test-ip'
        },
        body: JSON.stringify({
          username: 'admin',
          password: 'wrong'
        })
      })
      
      expect(response.status).toBe(401) // Wrong password
    }
  })
  
  it('should block 6th login attempt', async () => {
    // Make 5 failed attempts
    for (let i = 0; i < 5; i++) {
      await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-real-ip': 'test-ip'
        },
        body: JSON.stringify({
          username: 'admin',
          password: 'wrong'
        })
      })
    }
    
    // 6th attempt should be rate limited
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-real-ip': 'test-ip'
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong'
      })
    })
    
    expect(response.status).toBe(429)
    
    const data = await response.json()
    expect(data.error).toBe('Too many login attempts')
    expect(data.retryAfter).toBeGreaterThan(0)
  })
  
  it('should return rate limit headers', async () => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-real-ip': 'test-ip'
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong'
      })
    })
    
    expect(response.headers.get('X-RateLimit-Limit')).toBe('5')
    expect(response.headers.get('X-RateLimit-Remaining')).toBe('4')
    expect(response.headers.get('X-RateLimit-Reset')).toBeDefined()
  })
  
  it('should track different IPs separately', async () => {
    // IP 1 uses up limit
    for (let i = 0; i < 5; i++) {
      await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-real-ip': 'ip-1'
        },
        body: JSON.stringify({
          username: 'admin',
          password: 'wrong'
        })
      })
    }
    
    // IP 1 should be blocked
    let response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-real-ip': 'ip-1'
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong'
      })
    })
    expect(response.status).toBe(429)
    
    // IP 2 should still be allowed
    response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-real-ip': 'ip-2'
      },
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong'
      })
    })
    expect(response.status).toBe(401) // Wrong password, not rate limited
  })
})
\`\`\`

#### Test API Rate Limiting

\`\`\`typescript
// __tests__/api/drivers.test.ts

describe('GET /api/drivers - Rate Limiting', () => {
  let authToken: string
  
  beforeAll(async () => {
    // Get auth token
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'admin',
        password: 'password123'
      })
    })
    const data = await response.json()
    authToken = data.access_token
  })
  
  it('should allow 100 requests per minute', async () => {
    for (let i = 0; i < 100; i++) {
      const response = await fetch('/api/drivers', {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'x-real-ip': 'test-ip'
        }
      })
      
      expect(response.status).toBe(200)
    }
  })
  
  it('should block 101st request', async () => {
    // Make 100 requests
    for (let i = 0; i < 100; i++) {
      await fetch('/api/drivers', {
        headers: {
          'Authorization': `Bearer ${authToken}`,
          'x-real-ip': 'test-ip-2'
        }
      })
    }
    
    // 101st should be blocked
    const response = await fetch('/api/drivers', {
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'x-real-ip': 'test-ip-2'
      }
    })
    
    expect(response.status).toBe(429)
  })
})
\`\`\`

### Manual Testing

#### Test with cURL

\`\`\`bash
# Test login rate limiting
for i in {1..6}; do
  echo "Attempt $i:"
  curl -X POST http://localhost:3000/api/auth/login \
    -H "Content-Type: application/json" \
    -H "x-real-ip: 192.168.1.100" \
    -d '{"username":"admin","password":"wrong"}' \
    -w "\nStatus: %{http_code}\n\n"
  sleep 1
done

# Expected output:
# Attempts 1-5: Status 401 (Unauthorized)
# Attempt 6: Status 429 (Too Many Requests)
\`\`\`

#### Test with Postman

1. **Setup:**
   - Create collection "Rate Limit Tests"
   - Add environment variable `base_url` = `http://localhost:3000`

2. **Test Login Rate Limit:**
   \`\`\`
   POST {{base_url}}/api/auth/login
   Headers:
     Content-Type: application/json
     x-real-ip: test-ip-{{$randomInt}}
   Body:
     {
       "username": "admin",
       "password": "wrong"
     }
   
   Tests:
     pm.test("Rate limit headers present", function() {
       pm.response.to.have.header("X-RateLimit-Limit");
       pm.response.to.have.header("X-RateLimit-Remaining");
     });
   \`\`\`

3. **Run Collection:**
   - Use Collection Runner
   - Set iterations to 10
   - Verify 6th+ requests return 429

#### Test with Browser DevTools

\`\`\`javascript
// Open browser console on login page
// Run this script to test rate limiting

async function testRateLimit() {
  const results = []
  
  for (let i = 1; i <= 6; i++) {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong'
      })
    })
    
    results.push({
      attempt: i,
      status: response.status,
      remaining: response.headers.get('X-RateLimit-Remaining'),
      retryAfter: response.headers.get('Retry-After')
    })
  }
  
  console.table(results)
}

testRateLimit()

// Expected output:
// ┌─────────┬─────────┬────────┬───────────┬────────────┐
// │ (index) │ attempt │ status │ remaining │ retryAfter │
// ├─────────┼─────────┼────────┼───────────┼────────────┤
// │    0    │    1    │  401   │    '4'    │    null    │
// │    1    │    2    │  401   │    '3'    │    null    │
// │    2    │    3    │  401   │    '2'    │    null    │
// │    3    │    4    │  401   │    '1'    │    null    │
// │    4    │    5    │  401   │    '0'    │    null    │
// │    5    │    6    │  429   │    '0'    │   '900'    │
// └─────────┴─────────┴────────┴───────────┴────────────┘
\`\`\`

### Load Testing

#### Using Apache Bench (ab)

\`\`\`bash
# Test API endpoint with 1000 requests, 10 concurrent
ab -n 1000 -c 10 \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "x-real-ip: 192.168.1.1" \
  http://localhost:3000/api/drivers

# Analyze results:
# - Requests per second
# - Failed requests (should be ~900 with limit of 100/min)
# - Response time distribution
\`\`\`

#### Using Artillery

\`\`\`yaml
# artillery-config.yml
config:
  target: "http://localhost:3000"
  phases:
    - duration: 60
      arrivalRate: 10
      name: "Sustained load"

scenarios:
  - name: "Test API rate limiting"
    flow:
      - post:
          url: "/api/auth/login"
          json:
            username: "admin"
            password: "password123"
          capture:
            - json: "$.access_token"
              as: "token"
      - get:
          url: "/api/drivers"
          headers:
            Authorization: "Bearer {{ token }}"
          expect:
            - statusCode: [200, 429]
\`\`\`

\`\`\`bash
# Run load test
artillery run artillery-config.yml

# Expected results:
# - ~100 successful requests per minute per IP
# - Remaining requests return 429
\`\`\`

---

## Monitoring and Maintenance

### Logging Strategy

#### Log Rate Limit Events

\`\`\`typescript
// lib/security/rate-limit.ts

export function createRateLimiter(config: RateLimitConfig) {
  return {
    async check(identifier: string): Promise<RateLimitResult> {
      const result = await performCheck(identifier, config)
      
      // Log blocked requests
      if (!result.success) {
        console.warn('[RATE_LIMIT] Request blocked', {
          identifier,
          limit: result.limit,
          retryAfter: result.retryAfter,
          timestamp: new Date().toISOString(),
          endpoint: config.endpoint || 'unknown'
        })
      }
      
      // Log approaching limit (80% threshold)
      if (result.remaining <= result.limit * 0.2) {
        console.info('[RATE_LIMIT] Approaching limit', {
          identifier,
          remaining: result.remaining,
          limit: result.limit
        })
      }
      
      return result
    }
  }
}
\`\`\`

#### Structured Logging

\`\`\`typescript
// lib/logger.ts

export const logger = {
  rateLimit: {
    blocked: (data: {
      identifier: string
      endpoint: string
      limit: number
      retryAfter: number
    }) => {
      console.log(JSON.stringify({
        level: 'warn',
        type: 'rate_limit_blocked',
        ...data,
        timestamp: new Date().toISOString()
      }))
    },
    
    approaching: (data: {
      identifier: string
      remaining: number
      limit: number
    }) => {
      console.log(JSON.stringify({
        level: 'info',
        type: 'rate_limit_approaching',
        ...data,
        timestamp: new Date().toISOString()
      }))
    }
  }
}
\`\`\`

### Metrics Collection

#### Track Key Metrics

\`\`\`typescript
// lib/security/rate-limit-metrics.ts

interface Metrics {
  requests: {
    total: number
    allowed: number
    blocked: number
  }
  identifiers: {
    unique: Set<string>
    blocked: Set<string>
  }
  endpoints: Map<string, {
    requests: number
    blocked: number
    avgRemaining: number
  }>
}

const metrics: Metrics = {
  requests: { total: 0, allowed: 0, blocked: 0 },
  identifiers: { unique: new Set(), blocked: new Set() },
  endpoints: new Map()
}

export function recordCheck(
  identifier: string,
  endpoint: string,
  result: RateLimitResult
) {
  // Update request counts
  metrics.requests.total++
  if (result.success) {
    metrics.requests.allowed++
  } else {
    metrics.requests.blocked++
    metrics.identifiers.blocked.add(identifier)
  }
  
  // Track unique identifiers
  metrics.identifiers.unique.add(identifier)
  
  // Update endpoint stats
  const endpointStats = metrics.endpoints.get(endpoint) || {
    requests: 0,
    blocked: 0,
    avgRemaining: 0
  }
  
  endpointStats.requests++
  if (!result.success) endpointStats.blocked++
  endpointStats.avgRemaining = 
    (endpointStats.avgRemaining * (endpointStats.requests - 1) + result.remaining) / 
    endpointStats.requests
  
  metrics.endpoints.set(endpoint, endpointStats)
}

export function getMetrics() {
  return {
    requests: metrics.requests,
    identifiers: {
      unique: metrics.identifiers.unique.size,
      blocked: metrics.identifiers.blocked.size
    },
    blockRate: (metrics.requests.blocked / metrics.requests.total * 100).toFixed(2) + '%',
    endpoints: Array.from(metrics.endpoints.entries()).map(([endpoint, stats]) => ({
      endpoint,
      ...stats,
      blockRate: (stats.blocked / stats.requests * 100).toFixed(2) + '%'
    }))
  }
}

// Expose metrics endpoint
// app/api/admin/metrics/rate-limit/route.ts
export async function GET(request: NextRequest) {
  const authResult = await requireRole(request, 'admin')
  if (authResult instanceof Response) return authResult
  
  return NextResponse.json(getMetrics())
}
\`\`\`

### Alerting

#### Set Up Alerts

\`\`\`typescript
// lib/security/rate-limit-alerts.ts

interface AlertConfig {
  blockRateThreshold: number // Percentage
  blockedIdentifiersThreshold: number
  checkInterval: number // milliseconds
}

const config: AlertConfig = {
  blockRateThreshold: 20, // Alert if >20% requests blocked
  blockedIdentifiersThreshold: 10, // Alert if >10 IPs blocked
  checkInterval: 5 * 60 * 1000 // Check every 5 minutes
}

export function startAlertMonitoring() {
  setInterval(() => {
    const metrics = getMetrics()
    
    // Check block rate
    const blockRate = parseFloat(metrics.blockRate)
    if (blockRate > config.blockRateThreshold) {
      sendAlert({
        type: 'high_block_rate',
        message: `Rate limit block rate is ${blockRate}% (threshold: ${config.blockRateThreshold}%)`,
        severity: 'warning',
        metrics
      })
    }
    
    // Check blocked identifiers
    if (metrics.identifiers.blocked > config.blockedIdentifiersThreshold) {
      sendAlert({
        type: 'many_blocked_identifiers',
        message: `${metrics.identifiers.blocked} identifiers blocked (threshold: ${config.blockedIdentifiersThreshold})`,
        severity: 'warning',
        metrics
      })
    }
  }, config.checkInterval)
}

function sendAlert(alert: {
  type: string
  message: string
  severity: 'info' | 'warning' | 'critical'
  metrics: any
}) {
  console.error('[ALERT]', alert)
  
  // TODO: Send to monitoring service (Sentry, DataDog, etc.)
  // TODO: Send email/Slack notification
}
\`\`\`

### Dashboard

#### Create Metrics Dashboard

\`\`\`typescript
// app/admin/metrics/page.tsx

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export default function MetricsDashboard() {
  const [metrics, setMetrics] = useState(null)
  
  useEffect(() => {
    const fetchMetrics = async () => {
      const response = await fetch('/api/admin/metrics/rate-limit')
      const data = await response.json()
      setMetrics(data)
    }
    
    fetchMetrics()
    const interval = setInterval(fetchMetrics, 30000) // Refresh every 30s
    
    return () => clearInterval(interval)
  }, [])
  
  if (!metrics) return <div>Loading...</div>
  
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-bold">Rate Limiting Metrics</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{metrics.requests.total}</div>
            <div className="text-sm text-muted-foreground">
              {metrics.requests.allowed} allowed, {metrics.requests.blocked} blocked
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Block Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{metrics.blockRate}</div>
            <div className="text-sm text-muted-foreground">
              of all requests
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Unique Identifiers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold">{metrics.identifiers.unique}</div>
            <div className="text-sm text-muted-foreground">
              {metrics.identifiers.blocked} blocked
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Endpoint Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <table className="w-full">
            <thead>
              <tr>
                <th className="text-left">Endpoint</th>
                <th className="text-right">Requests</th>
                <th className="text-right">Blocked</th>
                <th className="text-right">Block Rate</th>
              </tr>
            </thead>
            <tbody>
              {metrics.endpoints.map((endpoint) => (
                <tr key={endpoint.endpoint}>
                  <td>{endpoint.endpoint}</td>
                  <td className="text-right">{endpoint.requests}</td>
                  <td className="text-right">{endpoint.blocked}</td>
                  <td className="text-right">{endpoint.blockRate}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  )
}
\`\`\`

---

## Production Considerations

### Scaling to Multiple Servers

#### Problem with In-Memory Storage

\`\`\`
Server 1: User makes 5 requests → Allowed
Server 2: Same user makes 5 requests → Allowed (different memory)
Total: 10 requests (limit bypassed!)
\`\`\`

#### Solution: Distributed Storage

**Option 1: Redis (Upstash) - Recommended**

\`\`\`typescript
// lib/security/rate-limit-redis.ts

import { Redis } from '@upstash/redis'

const redis = new Redis({
  url: process.env.KV_REST_API_URL!,
  token: process.env.KV_REST_API_TOKEN!
})

export function createRedisRateLimiter(config: RateLimitConfig) {
  return {
    async check(identifier: string): Promise<RateLimitResult> {
      const key = `rate_limit:${identifier}`
      const now = Date.now()
      
      // Get current count
      const count = await redis.get<number>(key) || 0
      
      if (count >= config.maxRequests) {
        const ttl = await redis.ttl(key)
        return {
          success: false,
          limit: config.maxRequests,
          remaining: 0,
          reset: now + (ttl * 1000),
          retryAfter: ttl
        }
      }
      
      // Increment count
      await redis.incr(key)
      
      // Set expiry on first request
      if (count === 0) {
        await redis.expire(key, Math.ceil(config.windowMs / 1000))
      }
      
      return {
        success: true,
        limit: config.maxRequests,
        remaining: config.maxRequests - count - 1,
        reset: now + config.windowMs
      }
    }
  }
}
\`\`\`

**Option 2: Vercel Edge Config**

\`\`\`typescript
// lib/security/rate-limit-edge-config.ts

import { get } from '@vercel/edge-config'

export function createEdgeConfigRateLimiter(config: RateLimitConfig) {
  // Similar implementation using Edge Config
  // Note: Edge Config is read-optimized, may not be ideal for rate limiting
}
\`\`\`

**Option 3: Database (PostgreSQL)**

\`\`\`typescript
// lib/security/rate-limit-db.ts

import { sql } from '@/lib/db'

export function createDatabaseRateLimiter(config: RateLimitConfig) {
  return {
    async check(identifier: string): Promise<RateLimitResult> {
      const now = new Date()
      const windowStart = new Date(now.getTime() - config.windowMs)
      
      // Count requests in window
      const result = await sql`
        SELECT COUNT(*) as count
        FROM rate_limit_requests
        WHERE identifier = ${identifier}
          AND created_at > ${windowStart}
      `
      
      const count = parseInt(result[0].count)
      
      if (count >= config.maxRequests) {
        return {
          success: false,
          limit: config.maxRequests,
          remaining: 0,
          reset: windowStart.getTime() + config.windowMs,
          retryAfter: Math.ceil(config.windowMs / 1000)
        }
      }
      
      // Record request
      await sql`
        INSERT INTO rate_limit_requests (identifier, created_at)
        VALUES (${identifier}, ${now})
      `
      
      return {
        success: true,
        limit: config.maxRequests,
        remaining: config.maxRequests - count - 1,
        reset: windowStart.getTime() + config.windowMs
      }
    }
  }
}
\`\`\`

### Environment-Specific Configuration

\`\`\`typescript
// lib/security/rate-limit-config.ts

const isDevelopment = process.env.NODE_ENV === 'development'
const isProduction = process.env.NODE_ENV === 'production'

export const rateLimitConfig = {
  login: {
    maxRequests: isDevelopment ? 100 : 5, // Relaxed in dev
    windowMs: isDevelopment ? 60000 : 15 * 60 * 1000
  },
  api: {
    maxRequests: isDevelopment ? 1000 : 100,
    windowMs: 60000
  },
  admin: {
    maxRequests: isDevelopment ? 500 : 50,
    windowMs: 60000
  }
}

// Use environment-specific storage
export function createRateLimiter(config: RateLimitConfig) {
  if (isProduction && process.env.KV_REST_API_URL) {
    return createRedisRateLimiter(config)
  }
  
  // Fallback to in-memory for development
  return createInMemoryRateLimiter(config)
}
\`\`\`

### Security Hardening

#### IP Spoofing Protection

\`\`\`typescript
// lib/security/ip-validation.ts

export function getClientIp(request: Request): string {
  // In production behind proxy, trust x-forwarded-for
  if (process.env.TRUST_PROXY === 'true') {
    const forwarded = request.headers.get('x-forwarded-for')
    if (forwarded) {
      return forwarded.split(',')[0].trim()
    }
  }
  
  // Otherwise use x-real-ip
  const realIp = request.headers.get('x-real-ip')
  if (realIp) return realIp
  
  return 'unknown'
}
\`\`\`

#### Rate Limit Bypass Prevention

\`\`\`typescript
// Prevent bypassing rate limits by changing user agent, etc.

export function generateIdentifier(request: Request, userId?: string): string {
  if (userId) {
    // Authenticated users: use user ID
    return `user:${userId}`
  }
  
  // Unauthenticated: combine IP + User Agent for better tracking
  const ip = getClientIp(request)
  const userAgent = request.headers.get('user-agent') || 'unknown'
  const hash = createHash('sha256')
    .update(`${ip}:${userAgent}`)
    .digest('hex')
    .substring(0, 16)
  
  return `anon:${hash}`
}
\`\`\`

---

## Documentation

### API Documentation

#### Rate Limit Response Format

\`\`\`typescript
/**
 * Rate Limit Response Headers
 *
 * All API responses include rate limit information in headers:
 *
 * X-RateLimit-Limit: Maximum requests allowed in window
 * X-RateLimit-Remaining: Requests remaining in current window
 * X-RateLimit-Reset: ISO 8601 timestamp when window resets
 * Retry-After: Seconds to wait before retrying (only on 429)
 *
 * Example:
 * X-RateLimit-Limit: 100
 * X-RateLimit-Remaining: 95
 * X-RateLimit-Reset: 2025-01-15T10:30:00Z
 */
\`\`\`

#### Error Response Format

\`\`\`typescript
/**
 * 429 Too Many Requests
 *
 * Returned when rate limit is exceeded.
 *
 * Response Body:
 * {
 *   "error": "Too many requests",
 *   "message": "Please try again later",
 *   "retryAfter": 900
 * }
 *
 * Headers:
 * Retry-After: 900
 * X-RateLimit-Limit: 5
 * X-RateLimit-Remaining: 0
 * X-RateLimit-Reset: 2025-01-15T10:30:00Z
 */
\`\`\`

### Developer Guide

#### Adding Rate Limiting to New Endpoints

\`\`\`typescript
/**
 * Step-by-Step Guide: Adding Rate Limiting
 *
 * 1. Choose appropriate rate limiter:
 *    - loginRateLimiter: Authentication endpoints
 *    - apiRateLimiter: General API endpoints
 *    - adminRateLimiter: Admin endpoints
 *    - strictRateLimiter: Sensitive operations
 *    - Create custom: createRateLimiter({ ... })
 *
 * 2. Import rate limiter:
 *    import { apiRateLimiter } from '@/lib/security/rate-limit'
 *
 * 3. Add to auth middleware:
 *    const authResult = await requireAuth(request, {
 *      rateLimiter: apiRateLimiter
 *    })
 *
 * 4. Test thoroughly:
 *    - Unit tests for rate limit logic
 *    - Integration tests for API endpoint
 *    - Manual testing with multiple requests
 *
 * Example:
 */

import { type NextRequest, NextResponse } from 'next/server'
import { requireAuth } from '@/lib/security/api-auth'
import { apiRateLimiter } from '@/lib/security/rate-limit'

export async function GET(request: NextRequest) {
  // Apply rate limiting via auth middleware
  const authResult = await requireAuth(request, {
    rateLimiter: apiRateLimiter
  })
  if (authResult instanceof Response) return authResult
  
  // Your API logic here
  return NextResponse.json({ data: 'Protected data' })
}
\`\`\`

### User Documentation

#### For API Consumers

\`\`\`markdown
# Rate Limiting Guide for API Users

## Overview

The FleetPro API implements rate limiting to ensure fair usage and protect against abuse. All API endpoints are subject to rate limits.

## Rate Limits

| Endpoint Type | Limit | Window |
|---------------|-------|--------|
| Authentication | 5 requests | 15 minutes |
| General API | 100 requests | 1 minute |
| Admin API | 50 requests | 1 minute |

## Response Headers

Every API response includes rate limit information:

\`\`\`
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 2025-01-15T10:30:00Z
\`\`\`

## Handling Rate Limits

### Check Headers

Always check rate limit headers to avoid hitting limits:

\`\`\`javascript
const response = await fetch('/api/drivers')
const remaining = response.headers.get('X-RateLimit-Remaining')

if (remaining < 10) {
  console.warn('Approaching rate limit!')
}
\`\`\`

### Handle 429 Errors

When rate limited, wait before retrying:

\`\`\`javascript
const response = await fetch('/api/drivers')

if (response.status === 429) {
  const retryAfter = response.headers.get('Retry-After')
  console.log(`Rate limited. Retry after ${retryAfter} seconds`)
  
  // Wait and retry
  await new Promise(resolve => setTimeout(resolve, retryAfter * 1000))
  return fetch('/api/drivers')
}
\`\`\`

### Implement Exponential Backoff

\`\`\`javascript
async function fetchWithRetry(url, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    const response = await fetch(url)
    
    if (response.status !== 429) {
      return response
    }
    
    // Exponential backoff: 1s, 2s, 4s
    const delay = Math.pow(2, i) * 1000
    await new Promise(resolve => setTimeout(resolve, delay))
  }
  
  throw new Error('Max retries exceeded')
}
\`\`\`

## Best Practices

1. **Monitor headers**: Check X-RateLimit-Remaining
2. **Implement backoff**: Use exponential backoff for retries
3. **Cache responses**: Reduce unnecessary API calls
4. **Batch requests**: Combine multiple operations when possible
5. **Use webhooks**: For real-time updates instead of polling

## Contact

If you need higher rate limits, contact support at support@fleetpro.com
\`\`\`

---

## Checklist

### Implementation Checklist

- [ ] Core rate limiting module implemented
- [ ] Pre-configured limiters created
- [ ] IP extraction utility implemented
- [ ] Automatic cleanup configured
- [ ] Login endpoint protected
- [ ] Refresh token endpoint protected
- [ ] Driver API protected
- [ ] Vehicle API protected
- [ ] Movement API protected
- [ ] Admin user API protected
- [ ] Admin role API protected
- [ ] Rate limit headers added
- [ ] Error responses standardized
- [ ] Unit tests written
- [ ] Integration tests written
- [ ] Load tests performed
- [ ] Documentation completed
- [ ] Metrics collection implemented
- [ ] Monitoring dashboard created
- [ ] Alerting configured
- [ ] Production storage configured (Redis)
- [ ] Environment-specific config added

### Testing Checklist

- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed
- [ ] Load testing completed
- [ ] Rate limits verified for each endpoint
- [ ] Headers verified
- [ ] Error responses verified
- [ ] Different IPs tracked separately
- [ ] Window reset verified
- [ ] Cleanup verified

### Documentation Checklist

- [ ] Implementation plan documented
- [ ] API documentation updated
- [ ] Developer guide created
- [ ] User guide created
- [ ] Configuration guide created
- [ ] Testing guide created
- [ ] Troubleshooting guide created
- [ ] Production deployment guide created

---

## Conclusion

This implementation plan provides a comprehensive roadmap for integrating rate limiting across the FleetPro application. By following this plan, you will:

1. **Protect against attacks**: Prevent brute force, DDoS, and API abuse
2. **Ensure fair usage**: Distribute resources fairly among users
3. **Maintain performance**: Prevent resource exhaustion
4. **Provide visibility**: Monitor and track rate limit metrics
5. **Scale effectively**: Support growth with distributed storage

The phased approach allows for incremental implementation and testing, ensuring each component works correctly before moving to the next phase.

**Next Steps:**
1. Review and approve this plan
2. Begin Phase 3 implementation (API route protection)
3. Set up monitoring and metrics collection
4. Plan production deployment with Redis storage

**Questions or Concerns:**
Contact the development team or refer to the troubleshooting section for common issues.

---

**Document Version:** 1.0  
**Last Updated:** January 2025  
**Author:** FleetPro Security Team  
**Status:** Ready for Implementation
