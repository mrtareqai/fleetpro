type User = {
  id: string
  username: string
  email: string
  full_name: string
  role: string
  roles?: Array<{ id: number; name: string; display_name: string }>
  is_active: boolean
  created_at: string
  last_login?: string
  updated_at?: string
  created_by?: string
  updated_by?: string
}

type Role = {
  id: number
  name: string
  display_name: string
  description: string
}

type Permission = {
  id: number
  name: string
  display_name: string
  resource: string
  action: string
  description?: string
}

class MockStore {
  private users: User[] = [
    {
      id: "1",
      username: "admin",
      email: "admin@fleetpro.com",
      full_name: "Admin User",
      role: "admin",
      roles: [{ id: 2, name: "admin", display_name: "Administrator" }],
      is_active: true,
      created_at: new Date().toISOString(),
    },
    {
      id: "2",
      username: "manager",
      email: "manager@fleetpro.com",
      full_name: "Fleet Manager",
      role: "manager",
      roles: [{ id: 3, name: "fleet_manager", display_name: "Fleet Manager" }],
      is_active: true,
      created_at: new Date().toISOString(),
    },
  ]

  private roles: Role[] = [
    { id: 1, name: "super_admin", display_name: "Super Administrator", description: "Full system access" },
    { id: 2, name: "admin", display_name: "Administrator", description: "Administrative access" },
    { id: 3, name: "fleet_manager", display_name: "Fleet Manager", description: "Manage fleet operations" },
    { id: 4, name: "dispatcher", display_name: "Dispatcher", description: "Manage reservations" },
    { id: 5, name: "maintenance_staff", display_name: "Maintenance Staff", description: "Manage maintenance" },
    { id: 6, name: "viewer", display_name: "Viewer", description: "Read-only access" },
  ]

  private permissions: Permission[] = [
    // Dashboard
    { id: 1, name: "dashboard.view", display_name: "View Dashboard", resource: "dashboard", action: "view" },

    // Users
    { id: 2, name: "users.create", display_name: "Create Users", resource: "users", action: "create" },
    { id: 3, name: "users.read", display_name: "View Users", resource: "users", action: "read" },
    { id: 4, name: "users.update", display_name: "Update Users", resource: "users", action: "update" },
    { id: 5, name: "users.delete", display_name: "Delete Users", resource: "users", action: "delete" },

    // Roles
    { id: 6, name: "roles.create", display_name: "Create Roles", resource: "roles", action: "create" },
    { id: 7, name: "roles.read", display_name: "View Roles", resource: "roles", action: "read" },
    { id: 8, name: "roles.update", display_name: "Update Roles", resource: "roles", action: "update" },
    { id: 9, name: "roles.delete", display_name: "Delete Roles", resource: "roles", action: "delete" },

    // Vehicles
    { id: 10, name: "vehicles.create", display_name: "Create Vehicles", resource: "vehicles", action: "create" },
    { id: 11, name: "vehicles.read", display_name: "View Vehicles", resource: "vehicles", action: "read" },
    { id: 12, name: "vehicles.update", display_name: "Update Vehicles", resource: "vehicles", action: "update" },
    { id: 13, name: "vehicles.delete", display_name: "Delete Vehicles", resource: "vehicles", action: "delete" },

    // Drivers
    { id: 14, name: "drivers.create", display_name: "Create Drivers", resource: "drivers", action: "create" },
    { id: 15, name: "drivers.read", display_name: "View Drivers", resource: "drivers", action: "read" },
    { id: 16, name: "drivers.update", display_name: "Update Drivers", resource: "drivers", action: "update" },
    { id: 17, name: "drivers.delete", display_name: "Delete Drivers", resource: "drivers", action: "delete" },

    // Reservations
    {
      id: 18,
      name: "reservations.create",
      display_name: "Create Reservations",
      resource: "reservations",
      action: "create",
    },
    { id: 19, name: "reservations.read", display_name: "View Reservations", resource: "reservations", action: "read" },
    {
      id: 20,
      name: "reservations.update",
      display_name: "Update Reservations",
      resource: "reservations",
      action: "update",
    },
    {
      id: 21,
      name: "reservations.delete",
      display_name: "Delete Reservations",
      resource: "reservations",
      action: "delete",
    },

    // Tickets
    { id: 22, name: "tickets.create", display_name: "Create Tickets", resource: "tickets", action: "create" },
    { id: 23, name: "tickets.read", display_name: "View Tickets", resource: "tickets", action: "read" },
    { id: 24, name: "tickets.update", display_name: "Update Tickets", resource: "tickets", action: "update" },
    { id: 25, name: "tickets.delete", display_name: "Delete Tickets", resource: "tickets", action: "delete" },

    // Movements
    { id: 26, name: "movements.create", display_name: "Create Movements", resource: "movements", action: "create" },
    { id: 27, name: "movements.read", display_name: "View Movements", resource: "movements", action: "read" },
    { id: 28, name: "movements.update", display_name: "Update Movements", resource: "movements", action: "update" },
    { id: 29, name: "movements.delete", display_name: "Delete Movements", resource: "movements", action: "delete" },

    // Supplies
    { id: 30, name: "supplies.create", display_name: "Create Supplies", resource: "supplies", action: "create" },
    { id: 31, name: "supplies.read", display_name: "View Supplies", resource: "supplies", action: "read" },
    { id: 32, name: "supplies.update", display_name: "Update Supplies", resource: "supplies", action: "update" },
    { id: 33, name: "supplies.delete", display_name: "Delete Supplies", resource: "supplies", action: "delete" },

    // Reports
    { id: 34, name: "reports.read", display_name: "View Reports", resource: "reports", action: "read" },
    { id: 35, name: "reports.generate", display_name: "Generate Reports", resource: "reports", action: "generate" },
    { id: 36, name: "reports.export", display_name: "Export Reports", resource: "reports", action: "export" },

    // Transactions
    {
      id: 37,
      name: "transactions.create",
      display_name: "Create Transactions",
      resource: "transactions",
      action: "create",
    },
    { id: 38, name: "transactions.read", display_name: "View Transactions", resource: "transactions", action: "read" },
    {
      id: 39,
      name: "transactions.update",
      display_name: "Update Transactions",
      resource: "transactions",
      action: "update",
    },
    {
      id: 40,
      name: "transactions.delete",
      display_name: "Delete Transactions",
      resource: "transactions",
      action: "delete",
    },
    {
      id: 41,
      name: "transactions.approve",
      display_name: "Approve Transactions",
      resource: "transactions",
      action: "approve",
    },
    {
      id: 42,
      name: "transactions.reject",
      display_name: "Reject Transactions",
      resource: "transactions",
      action: "reject",
    },
  ]

  private rolePermissions: Map<number, number[]> = new Map([
    // Super Administrator - All permissions
    [
      1,
      [
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
      ],
    ],

    // Administrator - Most permissions except some user/role management
    [
      2,
      [
        1, 3, 4, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
        34, 35, 36, 37, 38, 39, 40, 41, 42,
      ],
    ],

    // Fleet Manager - Fleet operations
    [3, [1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36]],

    // Dispatcher - Reservations and tickets
    [4, [1, 11, 15, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 34]],

    // Maintenance Staff - Vehicles and supplies
    [5, [1, 11, 12, 15, 30, 31, 32, 33, 34]],

    // Viewer - Read-only access
    [6, [1, 11, 15, 19, 23, 27, 31, 34, 38]],
  ])

  // User operations
  getUsers(): User[] {
    return [...this.users]
  }

  getUserById(id: string): User | undefined {
    return this.users.find((u) => u.id === id)
  }

  addUser(user: Omit<User, "id" | "created_at">): User {
    const newUser: User = {
      ...user,
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
    }
    this.users.push(newUser)
    console.log("[v0] User added to store. Total users:", this.users.length)
    return newUser
  }

  updateUser(id: string, updates: Partial<User>): User | null {
    const index = this.users.findIndex((u) => u.id === id)
    if (index === -1) return null

    this.users[index] = {
      ...this.users[index],
      ...updates,
      updated_at: new Date().toISOString(),
    }
    console.log("[v0] User updated in store:", id, "New is_active:", this.users[index].is_active)
    return this.users[index]
  }

  deleteUser(id: string): boolean {
    const index = this.users.findIndex((u) => u.id === id)
    if (index === -1) return false

    this.users.splice(index, 1)
    console.log("[v0] User deleted from store. Total users:", this.users.length)
    return true
  }

  // Role operations
  getRoles(): Role[] {
    return [...this.roles]
  }

  getRoleById(id: number): Role | undefined {
    return this.roles.find((r) => r.id === id)
  }

  getRoleWithPermissions(id: number): (Role & { permissions: Permission[] }) | undefined {
    const role = this.getRoleById(id)
    if (!role) return undefined

    const permissionIds = this.rolePermissions.get(id) || []
    const permissions = permissionIds
      .map((permId) => this.permissions.find((p) => p.id === permId))
      .filter((p): p is Permission => p !== undefined)

    return {
      ...role,
      permissions,
    }
  }

  addRole(role: Omit<Role, "id">): Role {
    const newRole: Role = {
      ...role,
      id: Math.max(...this.roles.map((r) => r.id), 0) + 1,
    }
    this.roles.push(newRole)
    this.rolePermissions.set(newRole.id, [])
    console.log("[v0] Role added to store. Total roles:", this.roles.length, "New role id:", newRole.id)
    return newRole
  }

  updateRole(id: number, updates: Partial<Role>): Role | null {
    const index = this.roles.findIndex((r) => r.id === id)
    if (index === -1) return null

    this.roles[index] = { ...this.roles[index], ...updates }
    console.log("[v0] Role updated in store:", id)
    return this.roles[index]
  }

  updateRolePermissions(roleId: number, permissionIds: number[]): boolean {
    if (!this.roles.find((r) => r.id === roleId)) return false
    this.rolePermissions.set(roleId, permissionIds)
    console.log("[v0] Role permissions updated:", roleId, "Permissions:", permissionIds.length)
    return true
  }

  deleteRole(id: number): boolean {
    const index = this.roles.findIndex((r) => r.id === id)
    if (index === -1) return false

    this.roles.splice(index, 1)
    this.rolePermissions.delete(id)
    console.log("[v0] Role deleted from store. Total roles:", this.roles.length)
    return true
  }

  getPermissions(): Permission[] {
    return [...this.permissions]
  }

  getPermissionById(id: number): Permission | undefined {
    return this.permissions.find((p) => p.id === id)
  }
}

// Singleton instance
export const mockStore = new MockStore()
