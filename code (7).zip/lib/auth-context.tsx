"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { getUserPermissions, type UserPermissions } from "@/lib/permissions"

interface AuthUser {
  id: string
  username: string
  email: string
  full_name: string
  role: string
}

interface AuthContextType {
  user: AuthUser | null
  permissions: UserPermissions | null
  isLoading: boolean
  login: (user: AuthUser) => void
  logout: () => void
  hasPermission: (permission: string) => boolean
  hasAnyPermission: (permissions: string[]) => boolean
  hasRole: (role: string) => boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [permissions, setPermissions] = useState<UserPermissions | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Load user from localStorage
    const storedUser = localStorage.getItem("user")
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser)
      setUser(parsedUser)
      loadPermissions(parsedUser.id)
    } else {
      setIsLoading(false)
    }
  }, [])

  const loadPermissions = async (userId: string) => {
    try {
      const userPermissions = await getUserPermissions(userId)
      setPermissions(userPermissions)
    } catch (error) {
      console.error("[v0] Error loading permissions:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const login = (newUser: AuthUser) => {
    setUser(newUser)
    localStorage.setItem("user", JSON.stringify(newUser))
    loadPermissions(newUser.id)
  }

  const logout = () => {
    setUser(null)
    setPermissions(null)
    localStorage.removeItem("user")
    localStorage.removeItem("token")
  }

  const hasPermission = (permission: string): boolean => {
    if (!permissions) return false
    if (permissions.permissions.includes("*")) return true
    if (permissions.permissions.includes(permission)) return true

    const [resource] = permission.split(".")
    if (permissions.permissions.includes(`${resource}.*`)) return true

    return false
  }

  const hasAnyPermission = (perms: string[]): boolean => {
    return perms.some((perm) => hasPermission(perm))
  }

  const hasRole = (role: string): boolean => {
    if (!permissions) return false
    return permissions.roles.includes(role)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        permissions,
        isLoading,
        login,
        logout,
        hasPermission,
        hasAnyPermission,
        hasRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
