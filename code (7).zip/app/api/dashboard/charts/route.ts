import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "dashboard.view")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Fetching dashboard charts data...")

    const { searchParams } = new URL(request.url)
    const year = searchParams.get("year") || new Date().getFullYear().toString()
    const months = searchParams.get("months") || "12"

    if (!sql) {
      return getMockChartsData(Number(months))
    }

    const monthlyReservations = await sql`
      SELECT 
        TO_CHAR(start_date, 'Mon') as month,
        EXTRACT(MONTH FROM start_date) as month_num,
        COUNT(*) as count,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
      FROM reservations
      WHERE EXTRACT(YEAR FROM start_date) = ${year}
      GROUP BY month, month_num
      ORDER BY month_num
    `

    const fleetStatus = await sql`
      SELECT 
        status,
        COUNT(*) as count
      FROM vehicles
      GROUP BY status
    `

    const chartsData = {
      monthlyReservations: monthlyReservations.map((row) => ({
        month: row.month,
        value: Number(row.count),
        completed: Number(row.completed),
      })),
      fleetStatus: fleetStatus.map((row) => ({
        name: row.status,
        value: Number(row.count),
      })),
    }

    console.log("[v0] Charts data fetched successfully")

    return NextResponse.json(chartsData, {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
      },
    })
  } catch (error) {
    console.error("[v0] Error fetching charts data:", error)
    return NextResponse.json({ error: "Failed to fetch charts data" }, { status: 500 })
  }
}

function getMockChartsData(months: number) {
  console.log("[v0] Using mock charts data")

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
  const monthlyReservations = monthNames.slice(0, months).map((month, index) => ({
    month,
    value: Math.floor(Math.random() * 30) + 15,
    completed: Math.floor(Math.random() * 25) + 10,
  }))

  const fleetStatus = [
    { name: "active", value: 45 },
    { name: "maintenance", value: 20 },
    { name: "inactive", value: 25 },
  ]

  return NextResponse.json(
    {
      monthlyReservations,
      fleetStatus,
    },
    {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
      },
    },
  )
}
