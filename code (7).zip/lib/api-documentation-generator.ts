/**
 * API Documentation Generator Utility
 *
 * This utility helps generate API documentation automatically from route files.
 * It can be used to keep documentation in sync with actual implementation.
 */

import { readFileSync, readdirSync, statSync } from "fs"
import { join } from "path"

interface APIEndpoint {
  path: string
  method: string
  description: string
  requiredPermission?: string
  parameters?: Array<{
    name: string
    type: string
    required: boolean
    description: string
  }>
  requestBody?: object
  responses?: object
}

/**
 * Extract API endpoints from route files
 */
export function extractEndpointsFromRoutes(routesDir: string): APIEndpoint[] {
  const endpoints: APIEndpoint[] = []

  function scanDirectory(dir: string, basePath = "") {
    const files = readdirSync(dir)

    for (const file of files) {
      const fullPath = join(dir, file)
      const stat = statSync(fullPath)

      if (stat.isDirectory()) {
        // Handle dynamic routes like [id]
        const pathSegment = file.startsWith("[") && file.endsWith("]") ? `{${file.slice(1, -1)}}` : file
        scanDirectory(fullPath, `${basePath}/${pathSegment}`)
      } else if (file === "route.ts") {
        const content = readFileSync(fullPath, "utf-8")
        const routeEndpoints = parseRouteFile(content, basePath)
        endpoints.push(...routeEndpoints)
      }
    }
  }

  scanDirectory(routesDir)
  return endpoints
}

/**
 * Parse a route file and extract endpoint information
 */
function parseRouteFile(content: string, path: string): APIEndpoint[] {
  const endpoints: APIEndpoint[] = []
  const methods = ["GET", "POST", "PUT", "DELETE", "PATCH"]

  for (const method of methods) {
    const regex = new RegExp(`export async function ${method}`, "g")
    if (regex.test(content)) {
      // Extract JSDoc comments if present
      const jsdocRegex = new RegExp(`/\\*\\*([^*]|\\*(?!/))*\\*/\\s*export async function ${method}`, "g")
      const match = jsdocRegex.exec(content)

      let description = ""
      let requiredPermission = ""

      if (match) {
        const jsdoc = match[0]
        const descMatch = /@description\s+(.+)/.exec(jsdoc)
        const permMatch = /@permission\s+(.+)/.exec(jsdoc)

        if (descMatch) description = descMatch[1].trim()
        if (permMatch) requiredPermission = permMatch[1].trim()
      }

      endpoints.push({
        path: `/api${path}`,
        method,
        description: description || `${method} ${path}`,
        requiredPermission: requiredPermission || undefined,
      })
    }
  }

  return endpoints
}

/**
 * Generate Markdown documentation from endpoints
 */
export function generateMarkdownDocs(endpoints: APIEndpoint[]): string {
  let markdown = "# API Endpoints\n\n"

  // Group by path
  const groupedEndpoints = endpoints.reduce(
    (acc, endpoint) => {
      if (!acc[endpoint.path]) {
        acc[endpoint.path] = []
      }
      acc[endpoint.path].push(endpoint)
      return acc
    },
    {} as Record<string, APIEndpoint[]>,
  )

  for (const [path, pathEndpoints] of Object.entries(groupedEndpoints)) {
    markdown += `## ${path}\n\n`

    for (const endpoint of pathEndpoints) {
      markdown += `### ${endpoint.method} ${path}\n\n`
      markdown += `${endpoint.description}\n\n`

      if (endpoint.requiredPermission) {
        markdown += `**Required Permission:** \`${endpoint.requiredPermission}\`\n\n`
      }

      markdown += "---\n\n"
    }
  }

  return markdown
}

/**
 * Validate that all endpoints have proper documentation
 */
export function validateDocumentation(endpoints: APIEndpoint[]): {
  valid: boolean
  errors: string[]
} {
  const errors: string[] = []

  for (const endpoint of endpoints) {
    if (!endpoint.description || endpoint.description === `${endpoint.method} ${endpoint.path}`) {
      errors.push(`Missing description for ${endpoint.method} ${endpoint.path}`)
    }

    if (endpoint.path.includes("/admin/") && !endpoint.requiredPermission) {
      errors.push(`Missing permission for admin endpoint ${endpoint.method} ${endpoint.path}`)
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  }
}
