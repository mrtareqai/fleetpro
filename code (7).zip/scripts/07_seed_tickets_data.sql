-- Insert sample ticket data
INSERT INTO tickets (
  passenger_name,
  trip_number,
  trip_name,
  trip_date,
  ticket_number,
  trip_time,
  seat_number,
  mobile_number,
  issue_date,
  issued_by,
  branch,
  status,
  priority,
  category
) VALUES
('محمد أحمد السعيد', 'TR-001', 'الرياض - جدة', '2025-01-15', 'TKT-000001', '08:00', 'A12', '0501234567', '2025-01-10', 'أحمد علي', 'الرياض', 'confirmed', 'high', 'standard'),
('سارة محمد العلي', 'TR-001', 'الرياض - جدة', '2025-01-15', 'TKT-000002', '08:00', 'A13', '0507654321', '2025-01-10', 'أحمد علي', 'الرياض', 'confirmed', 'high', 'standard'),
('خالد عبدالله', 'TR-002', 'الدمام - الخبر', '2025-01-15', 'TKT-000003', '10:30', 'B05', '0551234567', '2025-01-11', 'فاطمة حسن', 'الدمام', 'confirmed', 'medium', 'standard'),
('نورة يوسف', 'TR-003', 'مكة - المدينة', '2025-01-16', 'TKT-000004', '14:00', 'C08', '0561234567', '2025-01-12', 'محمد سعيد', 'مكة', 'pending', 'high', 'vip'),
('عبدالرحمن أحمد', 'TR-004', 'جدة - الطائف', '2025-01-17', 'TKT-000005', '09:00', 'A01', '0541234567', '2025-01-13', 'علي محمد', 'جدة', 'confirmed', 'medium', 'standard')
ON CONFLICT DO NOTHING;
