-- Ensure vehicles table has all required columns
ALTER TABLE vehicles 
ADD COLUMN IF NOT EXISTS base_number VARCHAR(50),
ADD COLUMN IF NOT EXISTS issue_date DATE;

-- Add some sample data for base_number and issue_date
UPDATE vehicles 
SET 
  base_number = 'BASE-' || LPAD(id::TEXT, 4, '0'),
  issue_date = manufacture_date + INTERVAL '30 days'
WHERE base_number IS NULL;
