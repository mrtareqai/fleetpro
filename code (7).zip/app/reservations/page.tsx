import DashboardLayout from "@/components/dashboard-layout"
import ReservationsTable from "@/components/reservations-table"

export default function ReservationsPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="reservations">
      <ReservationsTable locale={locale} />
    </DashboardLayout>
  )
}
