import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { mockStore } from "@/lib/mock-store"

// GET /api/admin/roles/[id] - Get role with permissions
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    if (!sql) {
      const roleWithPermissions = mockStore.getRoleWithPermissions(Number.parseInt(id))

      if (!roleWithPermissions) {
        return NextResponse.json({ error: "Role not found" }, { status: 404 })
      }

      return NextResponse.json({
        role: {
          ...roleWithPermissions,
          is_system: true,
        },
      })
    }

    const [role] = await sql`
      SELECT id, name, display_name, description, is_system, created_at, updated_at
      FROM roles
      WHERE id = ${id}
    `

    if (!role) {
      return NextResponse.json({ error: "Role not found" }, { status: 404 })
    }

    const permissions = await sql`
      SELECT p.id, p.name, p.display_name, p.description, p.resource, p.action
      FROM permissions p
      JOIN role_permissions rp ON p.id = rp.permission_id
      WHERE rp.role_id = ${id}
    `

    return NextResponse.json({ role: { ...role, permissions } })
  } catch (error) {
    console.error("[v0] Error fetching role:", error)
    return NextResponse.json({ error: "Failed to fetch role" }, { status: 500 })
  }
}

// PUT /api/admin/roles/[id] - Update role and permissions
export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params
    const body = await request.json()
    const { display_name, description, permission_ids } = body

    console.log("[v0] Updating role:", id, "with data:", {
      display_name,
      description,
      permission_count: permission_ids?.length || 0,
    })

    if (!sql) {
      const roleId = Number.parseInt(id)
      const updated = mockStore.updateRole(roleId, { display_name, description })

      if (!updated) {
        return NextResponse.json({ error: "Role not found" }, { status: 404 })
      }

      if (permission_ids !== undefined) {
        mockStore.updateRolePermissions(roleId, permission_ids)
      }

      const roleWithPermissions = mockStore.getRoleWithPermissions(roleId)

      console.log("[v0] Role updated successfully:", roleWithPermissions)

      return new NextResponse(JSON.stringify({ role: roleWithPermissions }), {
        status: 200,
        headers: {
          "Content-Type": "application/json",
        },
      })
    }

    // Update role
    const [role] = await sql`
      UPDATE roles
      SET display_name = ${display_name},
          description = ${description},
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING id, name, display_name, description
    `

    // Update permissions
    if (permission_ids !== undefined) {
      // Remove existing permissions
      await sql`DELETE FROM role_permissions WHERE role_id = ${id}`

      // Add new permissions
      if (permission_ids.length > 0) {
        for (const permission_id of permission_ids) {
          await sql`
            INSERT INTO role_permissions (role_id, permission_id)
            VALUES (${id}, ${permission_id})
            ON CONFLICT DO NOTHING
          `
        }
      }
    }

    return NextResponse.json({ role })
  } catch (error) {
    console.error("[v0] Error updating role:", error)
    return NextResponse.json({ error: "Failed to update role" }, { status: 500 })
  }
}

// DELETE /api/admin/roles/[id] - Delete role
export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params

    if (!sql) {
      return NextResponse.json({ success: true })
    }

    // Check if role is system role
    const [role] = await sql`SELECT is_system FROM roles WHERE id = ${id}`

    if (role?.is_system) {
      return NextResponse.json({ error: "Cannot delete system role" }, { status: 400 })
    }

    await sql`DELETE FROM roles WHERE id = ${id}`

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error deleting role:", error)
    return NextResponse.json({ error: "Failed to delete role" }, { status: 500 })
  }
}
