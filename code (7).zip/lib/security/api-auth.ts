/**
 * Enhanced API Authentication Middleware
 *
 * This module provides secure authentication and authorization for API routes.
 *
 * Features:
 * - JWT-based authentication
 * - Permission-based authorization
 * - Rate limiting integration
 * - Comprehensive error handling
 *
 * Migration from old system:
 * - Replaces x-user-id header with JWT tokens
 * - Adds proper token verification
 * - Integrates with rate limiting
 *
 * Usage:
 * \`\`\`typescript
 * export async function GET(request: NextRequest) {
 *   const authResult = await requireAuth(request)
 *   if (authResult instanceof Response) return authResult
 *
 *   const { userId, permissions } = authResult
 *   // Your API logic here
 * }
 * \`\`\`
 */

import type { NextRequest } from "next/server"
import { verifyToken, extractTokenFromHeader, type DecodedToken } from "./jwt"
import { getUserPermissions, hasPermission, hasAnyPermission } from "@/lib/permissions"
import { apiRateLimiter, getClientIp } from "./rate-limit"

export interface AuthenticatedRequest {
  userId: string
  role: string
  permissions: string[]
  companyId?: number
  token: DecodedToken
}

/**
 * Custom error classes for better error handling
 */
export class AuthenticationError extends Error {
  constructor(
    message: string,
    public statusCode = 401,
  ) {
    super(message)
    this.name = "AuthenticationError"
  }
}

export class AuthorizationError extends Error {
  constructor(
    message: string,
    public statusCode = 403,
  ) {
    super(message)
    this.name = "AuthorizationError"
  }
}

/**
 * Get authenticated user from JWT token
 *
 * @param request - Next.js request object
 * @returns Decoded token or throws error
 * @throws AuthenticationError if token is missing or invalid
 */
export async function getAuthenticatedUser(request: NextRequest): Promise<DecodedToken> {
  console.log("[v0] Authenticating user from request")

  const authHeader = request.headers.get("Authorization")
  console.log("[v0] Authorization header present:", !!authHeader)

  const token = extractTokenFromHeader(authHeader)

  if (!token) {
    console.log("[v0] No token found in Authorization header")
    throw new AuthenticationError("No authentication token provided")
  }

  console.log("[v0] Token extracted, verifying...")

  try {
    const decoded = await verifyToken(token)
    console.log("[v0] Token verified successfully for user:", decoded.userId)
    return decoded
  } catch (error) {
    const message = error instanceof Error ? error.message : "Invalid token"
    console.error("[v0] Token verification failed:", message)
    throw new AuthenticationError(message)
  }
}

/**
 * Middleware to require authentication
 *
 * @param request - Next.js request object
 * @param options - Optional configuration
 * @returns Authenticated request data or error response
 *
 * @example
 * const authResult = await requireAuth(request)
 * if (authResult instanceof Response) return authResult
 * const { userId } = authResult
 */
export async function requireAuth(
  request: NextRequest,
  options?: {
    checkRateLimit?: boolean
  },
): Promise<AuthenticatedRequest | Response> {
  try {
    console.log("[v0] requireAuth called")

    // Apply rate limiting if enabled
    if (options?.checkRateLimit !== false) {
      const ip = getClientIp(request)
      const rateLimitResult = await apiRateLimiter.check(ip)

      if (!rateLimitResult.success) {
        console.log("[v0] Rate limit exceeded for IP:", ip)
        return new Response(
          JSON.stringify({
            error: "Too many requests",
            retryAfter: rateLimitResult.retryAfter,
          }),
          {
            status: 429,
            headers: {
              "Content-Type": "application/json",
              "X-RateLimit-Limit": rateLimitResult.limit.toString(),
              "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
              "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
              "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            },
          },
        )
      }
    }

    console.log("[v0] Authenticating user...")
    // Authenticate user
    const token = await getAuthenticatedUser(request)
    console.log("[v0] User authenticated, getting permissions...")

    // Get user permissions from database
    const userPermissions = await getUserPermissions(token.userId)
    console.log("[v0] User permissions retrieved:", userPermissions.permissions.length, "permissions")

    return {
      userId: token.userId,
      role: token.role,
      permissions: userPermissions.permissions,
      companyId: token.companyId,
      token,
    }
  } catch (error) {
    console.error("[v0] Error in requireAuth:", error)
    if (error instanceof AuthenticationError) {
      console.log("[v0] Authentication error:", error.message)
      return new Response(JSON.stringify({ error: error.message }), {
        status: error.statusCode,
        headers: { "Content-Type": "application/json" },
      })
    }

    console.error("[v0] Unexpected authentication error:", error)
    return new Response(JSON.stringify({ error: "Authentication failed" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    })
  }
}

/**
 * Middleware to require specific permission
 *
 * @param request - Next.js request object
 * @param permission - Required permission (e.g., 'users.read')
 * @param options - Optional configuration
 * @returns Authenticated request data or error response
 *
 * @example
 * const authResult = await requirePermission(request, 'users.write')
 * if (authResult instanceof Response) return authResult
 */
export async function requirePermission(
  request: NextRequest,
  permission: string,
  options?: {
    checkRateLimit?: boolean
  },
): Promise<AuthenticatedRequest | Response> {
  console.log("[v0] requirePermission called for permission:", permission)

  const authResult = await requireAuth(request, options)

  if (authResult instanceof Response) {
    console.log("[v0] Auth failed, returning response")
    return authResult
  }

  console.log("[v0] Checking if user has permission:", permission)
  const userPermissions = { userId: authResult.userId, permissions: authResult.permissions, roles: [] }

  if (!hasPermission(userPermissions, permission)) {
    console.log("[v0] User does not have required permission")
    return new Response(
      JSON.stringify({
        error: "Forbidden",
        message: `Missing required permission: ${permission}`,
      }),
      {
        status: 403,
        headers: { "Content-Type": "application/json" },
      },
    )
  }

  console.log("[v0] User has required permission, proceeding")
  return authResult
}

/**
 * Middleware to require any of the specified permissions
 *
 * @param request - Next.js request object
 * @param permissions - Array of acceptable permissions
 * @param options - Optional configuration
 * @returns Authenticated request data or error response
 *
 * @example
 * const authResult = await requireAnyPermission(request, ['users.read', 'users.write'])
 * if (authResult instanceof Response) return authResult
 */
export async function requireAnyPermission(
  request: NextRequest,
  permissions: string[],
  options?: {
    checkRateLimit?: boolean
  },
): Promise<AuthenticatedRequest | Response> {
  const authResult = await requireAuth(request, options)

  if (authResult instanceof Response) {
    return authResult
  }

  const userPermissions = { userId: authResult.userId, permissions: authResult.permissions, roles: [] }

  if (!hasAnyPermission(userPermissions, permissions)) {
    return new Response(
      JSON.stringify({
        error: "Forbidden",
        message: `Missing required permissions. Need one of: ${permissions.join(", ")}`,
      }),
      {
        status: 403,
        headers: { "Content-Type": "application/json" },
      },
    )
  }

  return authResult
}

/**
 * Middleware to require specific role
 *
 * @param request - Next.js request object
 * @param role - Required role (e.g., 'admin')
 * @param options - Optional configuration
 * @returns Authenticated request data or error response
 */
export async function requireRole(
  request: NextRequest,
  role: string,
  options?: {
    checkRateLimit?: boolean
  },
): Promise<AuthenticatedRequest | Response> {
  const authResult = await requireAuth(request, options)

  if (authResult instanceof Response) {
    return authResult
  }

  if (authResult.role !== role) {
    return new Response(
      JSON.stringify({
        error: "Forbidden",
        message: `Required role: ${role}`,
      }),
      {
        status: 403,
        headers: { "Content-Type": "application/json" },
      },
    )
  }

  return authResult
}
