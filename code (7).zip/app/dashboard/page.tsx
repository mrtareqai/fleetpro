import DashboardLayout from "@/components/dashboard-layout"
import DashboardOverview from "@/components/dashboard-overview"

export default function DashboardPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="dashboard">
      <DashboardOverview locale={locale} />
    </DashboardLayout>
  )
}
