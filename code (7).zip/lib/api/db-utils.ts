/**
 * Database Utility Functions
 *
 * Provides optimized database operations with connection pooling,
 * transaction support, and query optimization.
 */

import { neon, type NeonQueryFunction } from "@neondatabase/serverless"

let sqlInstance: NeonQueryFunction<false, false> | null = null

export function getDbConnection(): NeonQueryFunction<false, false> {
  if (!sqlInstance) {
    const dbUrl = process.env.NEON_DATABASE_URL || process.env.DATABASE_URL

    if (!dbUrl) {
      throw new Error("Database URL not configured. Please set NEON_DATABASE_URL environment variable.")
    }

    sqlInstance = neon(dbUrl)
  }

  return sqlInstance
}

/**
 * Execute a database query with automatic retry on transient failures
 */
export async function executeQuery<T>(
  queryFn: (sql: NeonQueryFunction<false, false>) => Promise<T>,
  options: {
    maxRetries?: number
    retryDelay?: number
  } = {},
): Promise<T> {
  const { maxRetries = 3, retryDelay = 100 } = options
  const sql = getDbConnection()

  let lastError: Error | null = null

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await queryFn(sql)
    } catch (error) {
      lastError = error as Error

      // Check if error is retryable (connection issues, timeouts)
      const isRetryable =
        error instanceof Error &&
        (error.message.includes("ECONNRESET") ||
          error.message.includes("ETIMEDOUT") ||
          error.message.includes("connection") ||
          error.message.includes("timeout"))

      if (!isRetryable || attempt === maxRetries - 1) {
        throw error
      }

      // Exponential backoff
      await new Promise((resolve) => setTimeout(resolve, retryDelay * Math.pow(2, attempt)))
    }
  }

  throw lastError
}

/**
 * Check if a record exists before insertion (prevents duplicates)
 */
export async function checkDuplicate(
  table: string,
  field: string,
  value: string | number,
  excludeId?: number,
): Promise<boolean> {
  return executeQuery(async (sql) => {
    const query = excludeId
      ? sql`SELECT EXISTS(SELECT 1 FROM ${sql(table)} WHERE ${sql(field)} = ${value} AND id != ${excludeId})`
      : sql`SELECT EXISTS(SELECT 1 FROM ${sql(table)} WHERE ${sql(field)} = ${value})`

    const result = await query
    return result[0]?.exists || false
  })
}

/**
 * Batch insert with transaction support
 */
export async function batchInsert<T>(table: string, records: T[], batchSize = 100): Promise<number> {
  if (records.length === 0) return 0

  let totalInserted = 0

  for (let i = 0; i < records.length; i += batchSize) {
    const batch = records.slice(i, i + batchSize)

    await executeQuery(async (sql) => {
      // This would need to be customized per table
      // Just a placeholder for the pattern
      const result =
        await sql`INSERT INTO ${sql(table)} SELECT * FROM json_populate_recordset(NULL::${sql(table)}, ${JSON.stringify(batch)})`
      totalInserted += result.length
    })
  }

  return totalInserted
}
