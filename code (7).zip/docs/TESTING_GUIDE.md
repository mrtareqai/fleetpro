# Security Framework Testing Guide

## Overview

This guide provides comprehensive testing procedures for the FleetPro security framework, including unit tests, integration tests, and manual testing scenarios.

## Table of Contents

1. [Setup](#setup)
2. [Unit Tests](#unit-tests)
3. [Integration Tests](#integration-tests)
4. [Manual Testing](#manual-testing)
5. [Security Testing](#security-testing)
6. [Performance Testing](#performance-testing)

---

## Setup

### Install Testing Dependencies

\`\`\`bash
npm install --save-dev jest @testing-library/react @testing-library/jest-dom @testing-library/user-event
\`\`\`

### Configure Jest

Create `jest.config.js`:

\`\`\`javascript
module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>'],
  testMatch: ['**/__tests__/**/*.ts', '**/?(*.)+(spec|test).ts'],
  transform: {
    '^.+\\.ts$': 'ts-jest',
  },
  collectCoverageFrom: [
    'lib/security/**/*.ts',
    '!lib/security/**/*.d.ts',
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80,
    },
  },
}
\`\`\`

---

## Unit Tests

### Password Hashing Tests

Create `lib/security/__tests__/password.test.ts`:

\`\`\`typescript
import { hashPassword, verifyPassword, validatePasswordStrength } from '../password'

describe('Password Hashing', () => {
  describe('hashPassword', () => {
    it('should hash a password', async () => {
      const password = 'TestPassword123!'
      const hash = await hashPassword(password)
      
      expect(hash).toBeDefined()
      expect(hash).not.toBe(password)
      expect(hash.length).toBeGreaterThan(50)
    })

    it('should generate different hashes for same password', async () => {
      const password = 'TestPassword123!'
      const hash1 = await hashPassword(password)
      const hash2 = await hashPassword(password)
      
      expect(hash1).not.toBe(hash2)
    })

    it('should use bcrypt format', async () => {
      const password = 'TestPassword123!'
      const hash = await hashPassword(password)
      
      expect(hash).toMatch(/^\$2[aby]\$\d{2}\$/)
    })
  })

  describe('verifyPassword', () => {
    it('should verify correct password', async () => {
      const password = 'TestPassword123!'
      const hash = await hashPassword(password)
      const isValid = await verifyPassword(password, hash)
      
      expect(isValid).toBe(true)
    })

    it('should reject incorrect password', async () => {
      const password = 'TestPassword123!'
      const hash = await hashPassword(password)
      const isValid = await verifyPassword('WrongPassword123!', hash)
      
      expect(isValid).toBe(false)
    })

    it('should reject empty password', async () => {
      const password = 'TestPassword123!'
      const hash = await hashPassword(password)
      const isValid = await verifyPassword('', hash)
      
      expect(isValid).toBe(false)
    })
  })

  describe('validatePasswordStrength', () => {
    it('should accept strong password', () => {
      const result = validatePasswordStrength('StrongPass123!')
      expect(result.isValid).toBe(true)
      expect(result.error).toBeUndefined()
    })

    it('should reject short password', () => {
      const result = validatePasswordStrength('Short1!')
      expect(result.isValid).toBe(false)
      expect(result.error).toContain('at least 8 characters')
    })

    it('should reject password without uppercase', () => {
      const result = validatePasswordStrength('lowercase123!')
      expect(result.isValid).toBe(false)
      expect(result.error).toContain('uppercase letter')
    })

    it('should reject password without lowercase', () => {
      const result = validatePasswordStrength('UPPERCASE123!')
      expect(result.isValid).toBe(false)
      expect(result.error).toContain('lowercase letter')
    })

    it('should reject password without number', () => {
      const result = validatePasswordStrength('NoNumbers!')
      expect(result.isValid).toBe(false)
      expect(result.error).toContain('number')
    })

    it('should reject password without special character', () => {
      const result = validatePasswordStrength('NoSpecial123')
      expect(result.isValid).toBe(false)
      expect(result.error).toContain('special character')
    })
  })
})
\`\`\`

### JWT Tests

Create `lib/security/__tests__/jwt.test.ts`:

\`\`\`typescript
import { generateToken, verifyToken, extractTokenFromHeader, generateRefreshToken } from '../jwt'

describe('JWT', () => {
  const mockPayload = {
    userId: '123',
    role: 'admin',
    permissions: ['users.read', 'users.write'],
    companyId: 1,
  }

  describe('generateToken', () => {
    it('should generate a valid token', async () => {
      const token = await generateToken(mockPayload)
      
      expect(token).toBeDefined()
      expect(typeof token).toBe('string')
      expect(token.split('.').length).toBe(3) // JWT has 3 parts
    })

    it('should include payload data', async () => {
      const token = await generateToken(mockPayload)
      const decoded = await verifyToken(token)
      
      expect(decoded.userId).toBe(mockPayload.userId)
      expect(decoded.role).toBe(mockPayload.role)
      expect(decoded.permissions).toEqual(mockPayload.permissions)
    })
  })

  describe('verifyToken', () => {
    it('should verify valid token', async () => {
      const token = await generateToken(mockPayload)
      const decoded = await verifyToken(token)
      
      expect(decoded).toBeDefined()
      expect(decoded.userId).toBe('123')
    })

    it('should reject invalid token', async () => {
      await expect(verifyToken('invalid.token.here')).rejects.toThrow()
    })

    it('should reject malformed token', async () => {
      await expect(verifyToken('not-a-jwt')).rejects.toThrow()
    })

    it('should include expiration', async () => {
      const token = await generateToken(mockPayload)
      const decoded = await verifyToken(token)
      
      expect(decoded.exp).toBeDefined()
      expect(decoded.exp).toBeGreaterThan(Date.now() / 1000)
    })
  })

  describe('extractTokenFromHeader', () => {
    it('should extract token from Bearer header', () => {
      const token = extractTokenFromHeader('Bearer abc123')
      expect(token).toBe('abc123')
    })

    it('should return null for missing header', () => {
      const token = extractTokenFromHeader(null)
      expect(token).toBeNull()
    })

    it('should return null for invalid format', () => {
      const token = extractTokenFromHeader('InvalidFormat')
      expect(token).toBeNull()
    })

    it('should return null for wrong scheme', () => {
      const token = extractTokenFromHeader('Basic abc123')
      expect(token).toBeNull()
    })
  })

  describe('generateRefreshToken', () => {
    it('should generate refresh token', async () => {
      const token = await generateRefreshToken(mockPayload)
      
      expect(token).toBeDefined()
      expect(typeof token).toBe('string')
    })

    it('should have longer expiration than access token', async () => {
      const accessToken = await generateToken(mockPayload)
      const refreshToken = await generateRefreshToken(mockPayload)
      
      const accessDecoded = await verifyToken(accessToken)
      const refreshDecoded = await verifyToken(refreshToken)
      
      expect(refreshDecoded.exp).toBeGreaterThan(accessDecoded.exp)
    })
  })
})
\`\`\`

### Rate Limiting Tests

Create `lib/security/__tests__/rate-limit.test.ts`:

\`\`\`typescript
import { createRateLimiter, getClientIp } from '../rate-limit'

describe('Rate Limiting', () => {
  describe('createRateLimiter', () => {
    it('should allow requests within limit', async () => {
      const limiter = createRateLimiter({
        maxRequests: 5,
        windowMs: 60000,
      })

      const result = await limiter.check('test-user')
      
      expect(result.success).toBe(true)
      expect(result.remaining).toBe(4)
    })

    it('should block requests exceeding limit', async () => {
      const limiter = createRateLimiter({
        maxRequests: 3,
        windowMs: 60000,
      })

      // Make 3 allowed requests
      await limiter.check('test-user')
      await limiter.check('test-user')
      await limiter.check('test-user')

      // 4th request should be blocked
      const result = await limiter.check('test-user')
      
      expect(result.success).toBe(false)
      expect(result.remaining).toBe(0)
      expect(result.retryAfter).toBeDefined()
    })

    it('should track different users separately', async () => {
      const limiter = createRateLimiter({
        maxRequests: 2,
        windowMs: 60000,
      })

      await limiter.check('user1')
      await limiter.check('user1')
      
      // user1 is at limit, but user2 should still work
      const result = await limiter.check('user2')
      
      expect(result.success).toBe(true)
    })

    it('should reset after time window', async () => {
      const limiter = createRateLimiter({
        maxRequests: 1,
        windowMs: 100, // 100ms window
      })

      await limiter.check('test-user')
      
      // Wait for window to expire
      await new Promise(resolve => setTimeout(resolve, 150))
      
      const result = await limiter.check('test-user')
      expect(result.success).toBe(true)
    })

    it('should provide correct rate limit info', async () => {
      const limiter = createRateLimiter({
        maxRequests: 10,
        windowMs: 60000,
      })

      const result = await limiter.check('test-user')
      
      expect(result.limit).toBe(10)
      expect(result.remaining).toBe(9)
      expect(result.reset).toBeGreaterThan(Date.now())
    })
  })

  describe('getClientIp', () => {
    it('should extract IP from x-real-ip header', () => {
      const request = new Request('http://localhost', {
        headers: { 'x-real-ip': '192.168.1.1' }
      })
      
      const ip = getClientIp(request)
      expect(ip).toBe('192.168.1.1')
    })

    it('should extract IP from x-forwarded-for header', () => {
      const request = new Request('http://localhost', {
        headers: { 'x-forwarded-for': '192.168.1.1, 10.0.0.1' }
      })
      
      const ip = getClientIp(request)
      expect(ip).toBe('192.168.1.1')
    })

    it('should return unknown for missing headers', () => {
      const request = new Request('http://localhost')
      
      const ip = getClientIp(request)
      expect(ip).toBe('unknown')
    })
  })
})
\`\`\`

---

## Integration Tests

### Login API Tests

Create `app/api/auth/__tests__/login.test.ts`:

\`\`\`typescript
import { POST } from '../login/route'
import { NextRequest } from 'next/server'

describe('POST /api/auth/login', () => {
  it('should login with valid credentials', async () => {
    const request = new NextRequest('http://localhost/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: 'admin',
        password: 'password123'
      })
    })

    const response = await POST(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.access_token).toBeDefined()
    expect(data.refresh_token).toBeDefined()
    expect(data.user).toBeDefined()
    expect(data.user.username).toBe('admin')
  })

  it('should reject invalid credentials', async () => {
    const request = new NextRequest('http://localhost/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong_password'
      })
    })

    const response = await POST(request)
    const data = await response.json()

    expect(response.status).toBe(401)
    expect(data.error).toBeDefined()
  })

  it('should reject missing credentials', async () => {
    const request = new NextRequest('http://localhost/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({})
    })

    const response = await POST(request)

    expect(response.status).toBe(400)
  })

  it('should enforce rate limiting', async () => {
    const requests = []

    // Make 6 requests (limit is 5)
    for (let i = 0; i < 6; i++) {
      const request = new NextRequest('http://localhost/api/auth/login', {
        method: 'POST',
        headers: { 'x-real-ip': '192.168.1.100' },
        body: JSON.stringify({
          username: 'admin',
          password: 'wrong'
        })
      })
      requests.push(POST(request))
    }

    const responses = await Promise.all(requests)
    const lastResponse = responses[5]

    expect(lastResponse.status).toBe(429)
  })
})
\`\`\`

---

## Manual Testing

### Test Scenarios

#### Scenario 1: Complete Authentication Flow

\`\`\`bash
# Step 1: Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123"
  }'

# Expected Response:
# {
#   "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
#   "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
#   "user": {
#     "id": "1",
#     "username": "admin",
#     "email": "admin@fleetpro.com",
#     "role": "admin",
#     "full_name": "Admin User"
#   }
# }

# Step 2: Access Protected Endpoint
curl http://localhost:3000/api/admin/users \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Expected: 200 OK with user list

# Step 3: Access Without Token
curl http://localhost:3000/api/admin/users

# Expected: 401 Unauthorized

# Step 4: Refresh Token
curl -X POST http://localhost:3000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{
    "refresh_token": "YOUR_REFRESH_TOKEN"
  }'

# Expected: New access and refresh tokens

# Step 5: Logout
curl -X POST http://localhost:3000/api/auth/logout \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Expected: 200 OK
\`\`\`

#### Scenario 2: Rate Limiting Test

\`\`\`bash
# Make multiple failed login attempts
for i in {1..6}; do
  echo "Attempt $i:"
  curl -X POST http://localhost:3000/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{
      "username": "admin",
      "password": "wrong"
    }'
  echo "\n"
done

# Expected: First 5 return 401, 6th returns 429
\`\`\`

#### Scenario 3: Permission Testing

\`\`\`bash
# Login as regular user
TOKEN=$(curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"user","password":"password123"}' \
  | jq -r '.access_token')

# Try to access admin endpoint
curl http://localhost:3000/api/admin/users \
  -H "Authorization: Bearer $TOKEN"

# Expected: 403 Forbidden
\`\`\`

---

## Security Testing

### Penetration Testing Checklist

#### Authentication Tests

- [ ] Test SQL injection in login form
- [ ] Test XSS in username/password fields
- [ ] Test brute force protection (rate limiting)
- [ ] Test password reset flow
- [ ] Test session fixation
- [ ] Test credential stuffing

#### Authorization Tests

- [ ] Test horizontal privilege escalation
- [ ] Test vertical privilege escalation
- [ ] Test missing function level access control
- [ ] Test insecure direct object references

#### Token Security Tests

- [ ] Test token expiration
- [ ] Test token signature verification
- [ ] Test token replay attacks
- [ ] Test token in URL parameters
- [ ] Test token storage security

### Security Test Scripts

#### Test SQL Injection

\`\`\`bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin'\'' OR 1=1--",
    "password": "anything"
  }'

# Expected: 401 Unauthorized (not successful login)
\`\`\`

#### Test XSS

\`\`\`bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "<script>alert(1)</script>",
    "password": "test"
  }'

# Expected: Sanitized input, no script execution
\`\`\`

#### Test Token Tampering

\`\`\`bash
# Get valid token
TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIxMjMifQ.invalid"

# Try to use tampered token
curl http://localhost:3000/api/admin/users \
  -H "Authorization: Bearer $TOKEN"

# Expected: 401 Unauthorized
\`\`\`

---

## Performance Testing

### Load Testing

#### Test Login Endpoint

\`\`\`bash
# Using Apache Bench
ab -n 1000 -c 10 -p login.json -T application/json \
  http://localhost:3000/api/auth/login

# login.json:
# {"username":"admin","password":"password123"}
\`\`\`

#### Test Protected Endpoint

\`\`\`bash
# Get token first
TOKEN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password123"}' \
  | jq -r '.access_token')

# Load test
ab -n 1000 -c 10 -H "Authorization: Bearer $TOKEN" \
  http://localhost:3000/api/admin/users
\`\`\`

### Performance Benchmarks

| Operation | Target | Acceptable |
|-----------|--------|------------|
| Password Hash | < 500ms | < 1000ms |
| JWT Generate | < 10ms | < 50ms |
| JWT Verify | < 10ms | < 50ms |
| Rate Limit Check | < 5ms | < 20ms |
| Login (total) | < 600ms | < 1200ms |

---

## Continuous Integration

### GitHub Actions Workflow

Create `.github/workflows/security-tests.yml`:

\`\`\`yaml
name: Security Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Run unit tests
        run: npm test
      
      - name: Run security audit
        run: npm audit
      
      - name: Check for vulnerabilities
        run: npm audit --audit-level=high
\`\`\`

---

## Test Coverage

### Generate Coverage Report

\`\`\`bash
npm test -- --coverage

# View HTML report
open coverage/lcov-report/index.html
\`\`\`

### Coverage Goals

- **Statements**: > 80%
- **Branches**: > 80%
- **Functions**: > 80%
- **Lines**: > 80%

---

**Last Updated:** January 2025  
**Version:** 1.0.0
