-- RBAC (Role-Based Access Control) Schema
-- This script adds comprehensive role and permission management

-- Drop existing RBAC tables if they exist
DROP TABLE IF EXISTS user_roles CASCADE;
DROP TABLE IF EXISTS role_permissions CASCADE;
DROP TABLE IF EXISTS permissions CASCADE;
DROP TABLE IF EXISTS roles CASCADE;

-- Roles table (predefined system roles)
CREATE TABLE roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    description TEXT,
    is_system BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Permissions table (granular permissions)
CREATE TABLE permissions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    display_name VARCHAR(255) NOT NULL,
    description TEXT,
    resource VARCHAR(100) NOT NULL,
    action VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Role-Permission mapping (many-to-many)
CREATE TABLE role_permissions (
    id SERIAL PRIMARY KEY,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    permission_id INTEGER REFERENCES permissions(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(role_id, permission_id)
);

-- User-Role mapping (users can have multiple roles)
CREATE TABLE user_roles (
    id SERIAL PRIMARY KEY,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    role_id INTEGER REFERENCES roles(id) ON DELETE CASCADE,
    assigned_by UUID REFERENCES users(id) ON DELETE SET NULL,
    assigned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, role_id)
);

-- Create indexes for performance
CREATE INDEX idx_role_permissions_role ON role_permissions(role_id);
CREATE INDEX idx_role_permissions_permission ON role_permissions(permission_id);
CREATE INDEX idx_user_roles_user ON user_roles(user_id);
CREATE INDEX idx_user_roles_role ON user_roles(role_id);
CREATE INDEX idx_permissions_resource ON permissions(resource);

-- Add trigger for roles updated_at
CREATE TRIGGER update_roles_updated_at BEFORE UPDATE ON roles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert system roles
INSERT INTO roles (name, display_name, description, is_system) VALUES
('super_admin', 'Super Administrator', 'Full system access with all permissions', true),
('admin', 'Administrator', 'Administrative access to manage users and system settings', true),
('fleet_manager', 'Fleet Manager', 'Manage vehicles, drivers, and reservations', true),
('dispatcher', 'Dispatcher', 'Manage reservations and movements', true),
('maintenance_staff', 'Maintenance Staff', 'Manage tickets and vehicle maintenance', true),
('viewer', 'Viewer', 'Read-only access to all data', true);

-- Insert granular permissions
INSERT INTO permissions (name, display_name, description, resource, action) VALUES
-- User management permissions
('users.create', 'Create Users', 'Create new user accounts', 'users', 'create'),
('users.read', 'View Users', 'View user information', 'users', 'read'),
('users.update', 'Update Users', 'Update user information', 'users', 'update'),
('users.delete', 'Delete Users', 'Delete user accounts', 'users', 'delete'),
('users.manage_roles', 'Manage User Roles', 'Assign and revoke user roles', 'users', 'manage_roles'),

-- Role management permissions
('roles.create', 'Create Roles', 'Create new roles', 'roles', 'create'),
('roles.read', 'View Roles', 'View role information', 'roles', 'read'),
('roles.update', 'Update Roles', 'Update role information', 'roles', 'update'),
('roles.delete', 'Delete Roles', 'Delete roles', 'roles', 'delete'),
('roles.manage_permissions', 'Manage Role Permissions', 'Assign permissions to roles', 'roles', 'manage_permissions'),

-- Vehicle management permissions
('vehicles.create', 'Create Vehicles', 'Add new vehicles to fleet', 'vehicles', 'create'),
('vehicles.read', 'View Vehicles', 'View vehicle information', 'vehicles', 'read'),
('vehicles.update', 'Update Vehicles', 'Update vehicle information', 'vehicles', 'update'),
('vehicles.delete', 'Delete Vehicles', 'Remove vehicles from fleet', 'vehicles', 'delete'),

-- Driver management permissions
('drivers.create', 'Create Drivers', 'Add new drivers', 'drivers', 'create'),
('drivers.read', 'View Drivers', 'View driver information', 'drivers', 'read'),
('drivers.update', 'Update Drivers', 'Update driver information', 'drivers', 'update'),
('drivers.delete', 'Delete Drivers', 'Remove drivers', 'drivers', 'delete'),

-- Reservation management permissions
('reservations.create', 'Create Reservations', 'Create new reservations', 'reservations', 'create'),
('reservations.read', 'View Reservations', 'View reservation information', 'reservations', 'read'),
('reservations.update', 'Update Reservations', 'Update reservation information', 'reservations', 'update'),
('reservations.delete', 'Delete Reservations', 'Cancel reservations', 'reservations', 'delete'),

-- Ticket management permissions
('tickets.create', 'Create Tickets', 'Create new tickets', 'tickets', 'create'),
('tickets.read', 'View Tickets', 'View ticket information', 'tickets', 'read'),
('tickets.update', 'Update Tickets', 'Update ticket information', 'tickets', 'update'),
('tickets.delete', 'Delete Tickets', 'Delete tickets', 'tickets', 'delete'),

-- Movement management permissions
('movements.create', 'Create Movements', 'Create new movements', 'movements', 'create'),
('movements.read', 'View Movements', 'View movement information', 'movements', 'read'),
('movements.update', 'Update Movements', 'Update movement information', 'movements', 'update'),
('movements.delete', 'Delete Movements', 'Delete movements', 'movements', 'delete'),

-- Agency supplies permissions
('supplies.create', 'Create Supplies', 'Create new supply records', 'supplies', 'create'),
('supplies.read', 'View Supplies', 'View supply information', 'supplies', 'read'),
('supplies.update', 'Update Supplies', 'Update supply information', 'supplies', 'update'),
('supplies.delete', 'Delete Supplies', 'Delete supply records', 'supplies', 'delete'),

-- Dashboard and reports permissions
('dashboard.view', 'View Dashboard', 'Access dashboard and statistics', 'dashboard', 'read'),
('reports.view', 'View Reports', 'Access reports', 'reports', 'read'),
('reports.export', 'Export Reports', 'Export reports to files', 'reports', 'export');

-- Assign permissions to Super Admin (all permissions)
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'super_admin';

-- Assign permissions to Admin
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'admin'
AND p.name IN (
    'users.create', 'users.read', 'users.update', 'users.delete', 'users.manage_roles',
    'roles.read',
    'vehicles.create', 'vehicles.read', 'vehicles.update', 'vehicles.delete',
    'drivers.create', 'drivers.read', 'drivers.update', 'drivers.delete',
    'reservations.create', 'reservations.read', 'reservations.update', 'reservations.delete',
    'tickets.create', 'tickets.read', 'tickets.update', 'tickets.delete',
    'movements.create', 'movements.read', 'movements.update', 'movements.delete',
    'supplies.create', 'supplies.read', 'supplies.update', 'supplies.delete',
    'dashboard.view', 'reports.view', 'reports.export'
);

-- Assign permissions to Fleet Manager
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'fleet_manager'
AND p.name IN (
    'vehicles.create', 'vehicles.read', 'vehicles.update', 'vehicles.delete',
    'drivers.create', 'drivers.read', 'drivers.update', 'drivers.delete',
    'reservations.create', 'reservations.read', 'reservations.update', 'reservations.delete',
    'movements.read', 'movements.update',
    'supplies.read', 'supplies.update',
    'dashboard.view', 'reports.view'
);

-- Assign permissions to Dispatcher
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'dispatcher'
AND p.name IN (
    'vehicles.read',
    'drivers.read',
    'reservations.create', 'reservations.read', 'reservations.update',
    'movements.create', 'movements.read', 'movements.update',
    'dashboard.view'
);

-- Assign permissions to Maintenance Staff
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'maintenance_staff'
AND p.name IN (
    'vehicles.read', 'vehicles.update',
    'tickets.create', 'tickets.read', 'tickets.update',
    'supplies.create', 'supplies.read', 'supplies.update',
    'dashboard.view'
);

-- Assign permissions to Viewer
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'viewer'
AND (p.name LIKE '%.read' OR p.name = 'dashboard.view');
