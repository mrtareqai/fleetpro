import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "reports.read")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Generating fleet utilization report...")

    const { searchParams } = new URL(request.url)
    const startDate = searchParams.get("start_date") || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
    const endDate = searchParams.get("end_date") || new Date().toISOString()

    if (!sql) {
      return getMockFleetUtilization()
    }

    const utilizationData = await sql`
      WITH daily_stats AS (
        SELECT 
          DATE(start_date) as date,
          COUNT(DISTINCT vehicle_id) as vehicles_used,
          (SELECT COUNT(*) FROM vehicles WHERE status = 'active') as total_vehicles
        FROM reservations
        WHERE start_date >= ${startDate}
          AND start_date <= ${endDate}
          AND status IN ('confirmed', 'completed')
        GROUP BY DATE(start_date)
      )
      SELECT 
        TO_CHAR(date, 'YYYY-MM-DD') as date,
        vehicles_used,
        total_vehicles,
        ROUND((vehicles_used::numeric / NULLIF(total_vehicles, 0)) * 100, 2) as utilization_rate
      FROM daily_stats
      ORDER BY date
    `

    const report = {
      period: { start: startDate, end: endDate },
      data: utilizationData.map((row) => ({
        date: row.date,
        vehiclesUsed: Number(row.vehicles_used),
        totalVehicles: Number(row.total_vehicles),
        utilizationRate: Number(row.utilization_rate),
      })),
      summary: {
        avgUtilization:
          utilizationData.reduce((sum, row) => sum + Number(row.utilization_rate), 0) / utilizationData.length || 0,
        peakUtilization: Math.max(...utilizationData.map((row) => Number(row.utilization_rate)), 0),
        lowestUtilization: Math.min(...utilizationData.map((row) => Number(row.utilization_rate)), 100),
      },
    }

    console.log("[v0] Fleet utilization report generated")

    return NextResponse.json(report, {
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("[v0] Error generating fleet utilization report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

function getMockFleetUtilization() {
  console.log("[v0] Using mock fleet utilization data")

  const data = Array.from({ length: 30 }, (_, i) => {
    const date = new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000)
    const utilizationRate = Math.floor(Math.random() * 40) + 50
    return {
      date: date.toISOString().split("T")[0],
      vehiclesUsed: Math.floor((utilizationRate / 100) * 90),
      totalVehicles: 90,
      utilizationRate,
    }
  })

  return NextResponse.json({
    period: {
      start: data[0].date,
      end: data[data.length - 1].date,
    },
    data,
    summary: {
      avgUtilization: data.reduce((sum, d) => sum + d.utilizationRate, 0) / data.length,
      peakUtilization: Math.max(...data.map((d) => d.utilizationRate)),
      lowestUtilization: Math.min(...data.map((d) => d.utilizationRate)),
    },
  })
}
