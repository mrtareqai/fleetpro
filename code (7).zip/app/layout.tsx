import type React from "react"
import "./globals.css"
import { AuthProvider } from "@/lib/auth-context"
import { SelectionProvider } from "@/lib/selection-context"
import { CompanyProvider } from "@/lib/company-context"

export const metadata = {
  title: "FleetPro Management",
  description: "Fleet Management System",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <CompanyProvider>
          <AuthProvider>
            <SelectionProvider>{children}</SelectionProvider>
          </AuthProvider>
        </CompanyProvider>
      </body>
    </html>
  )
}
