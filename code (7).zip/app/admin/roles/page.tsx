"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { Plus, Edit, Trash2, Shield, Lock, CheckCircle2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import ProtectedRoute from "@/components/protected-route"
import PermissionGate from "@/components/permission-gate"

interface Permission {
  id: number
  name: string
  display_name: string
  description?: string
  resource: string
  action: string
}

interface Role {
  id: number
  name: string
  display_name: string
  description: string
  is_system: boolean
  permissions?: Permission[]
}

export default function RolesManagementPage() {
  const searchParams = useSearchParams()
  const locale = (searchParams.get("locale") as "en" | "ar") || "en"

  const [roles, setRoles] = useState<Role[]>([])
  const [permissions, setPermissions] = useState<Permission[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedRole, setSelectedRole] = useState<Role | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    display_name: "",
    description: "",
    permission_ids: [] as number[],
  })

  const t = {
    en: {
      title: "Roles & Permissions Management",
      addRole: "Add Role",
      roleName: "Role Name",
      displayName: "Display Name",
      description: "Description",
      permissions: "Permissions",
      actions: "Actions",
      edit: "Edit",
      delete: "Delete",
      cancel: "Cancel",
      save: "Save",
      selectPermissions: "Select Permissions",
      confirmDelete: "Are you sure you want to delete this role?",
      systemRole: "System Role",
      cannotDeleteSystem: "System roles cannot be deleted",
      permissionCount: "permissions",
      groupedByResource: "Grouped by Resource",
    },
    ar: {
      title: "إدارة الأدوار والصلاحيات",
      addRole: "إضافة دور",
      roleName: "اسم الدور",
      displayName: "الاسم المعروض",
      description: "الوصف",
      permissions: "الصلاحيات",
      actions: "الإجراءات",
      edit: "تعديل",
      delete: "حذف",
      cancel: "إلغاء",
      save: "حفظ",
      selectPermissions: "اختر الصلاحيات",
      confirmDelete: "هل أنت متأكد من حذف هذا الدور؟",
      systemRole: "دور النظام",
      cannotDeleteSystem: "لا يمكن حذف أدوار النظام",
      permissionCount: "صلاحية",
      groupedByResource: "مجموعة حسب المورد",
    },
  }

  useEffect(() => {
    fetchRoles()
    fetchPermissions()
  }, [])

  const fetchRoles = async () => {
    try {
      const response = await fetch("/api/admin/roles")

      if (!response.ok) {
        console.error("[v0] Failed to fetch roles, using mock data")
        setRoles(getMockRoles())
        setLoading(false)
        return
      }

      const data = await response.json()

      if (!data.roles || !Array.isArray(data.roles)) {
        console.error("[v0] Invalid roles data, using mock data")
        setRoles(getMockRoles())
        setLoading(false)
        return
      }

      // Fetch permissions for each role
      const rolesWithPermissions = await Promise.all(
        data.roles.map(async (role: Role) => {
          try {
            const roleResponse = await fetch(`/api/admin/roles/${role.id}`)

            if (!roleResponse.ok) {
              console.error(`[v0] Failed to fetch role ${role.id}, using base data`)
              return { ...role, permissions: [] }
            }

            const roleData = await roleResponse.json()
            return roleData.role || { ...role, permissions: [] }
          } catch (error) {
            console.error(`[v0] Error fetching role ${role.id}:`, error)
            return { ...role, permissions: [] }
          }
        }),
      )

      setRoles(rolesWithPermissions)
    } catch (error) {
      console.error("[v0] Error fetching roles:", error)
      setRoles(getMockRoles())
    } finally {
      setLoading(false)
    }
  }

  const fetchPermissions = async () => {
    try {
      const response = await fetch("/api/admin/permissions")

      if (!response.ok) {
        console.error("[v0] Failed to fetch permissions, using mock data")
        setPermissions(getMockPermissions())
        return
      }

      const data = await response.json()

      const validPermissions = (data.permissions || []).filter(
        (p: any) => p && p.id && p.name && p.display_name && p.resource && p.action,
      )

      setPermissions(validPermissions)
    } catch (error) {
      console.error("[v0] Error fetching permissions:", error)
      setPermissions(getMockPermissions())
    }
  }

  const getMockRoles = (): Role[] => [
    {
      id: 1,
      name: "super_admin",
      display_name: "Super Administrator",
      description: "Full system access",
      is_system: true,
      permissions: [],
    },
    {
      id: 2,
      name: "admin",
      display_name: "Administrator",
      description: "Administrative access",
      is_system: true,
      permissions: [],
    },
    {
      id: 3,
      name: "fleet_manager",
      display_name: "Fleet Manager",
      description: "Manage fleet operations",
      is_system: true,
      permissions: [],
    },
    {
      id: 4,
      name: "dispatcher",
      display_name: "Dispatcher",
      description: "Manage reservations",
      is_system: true,
      permissions: [],
    },
    {
      id: 5,
      name: "maintenance_staff",
      display_name: "Maintenance Staff",
      description: "Manage maintenance",
      is_system: true,
      permissions: [],
    },
    {
      id: 6,
      name: "viewer",
      display_name: "Viewer",
      description: "Read-only access",
      is_system: true,
      permissions: [],
    },
  ]

  const getMockPermissions = (): Permission[] => [
    { id: 1, name: "users.create", display_name: "Create Users", resource: "users", action: "create" },
    { id: 2, name: "users.read", display_name: "View Users", resource: "users", action: "read" },
    { id: 3, name: "users.update", display_name: "Update Users", resource: "users", action: "update" },
    { id: 4, name: "users.delete", display_name: "Delete Users", resource: "users", action: "delete" },
    { id: 5, name: "vehicles.create", display_name: "Create Vehicles", resource: "vehicles", action: "create" },
    { id: 6, name: "vehicles.read", display_name: "View Vehicles", resource: "vehicles", action: "read" },
    { id: 7, name: "vehicles.update", display_name: "Update Vehicles", resource: "vehicles", action: "update" },
    { id: 8, name: "vehicles.delete", display_name: "Delete Vehicles", resource: "vehicles", action: "delete" },
  ]

  const handleAddRole = async () => {
    if (!formData.name || !formData.display_name) {
      alert(locale === "en" ? "Please fill in all required fields" : "يرجى ملء جميع الحقول المطلوبة")
      return
    }

    setSaving(true)
    console.log("[v0] handleAddRole called with formData:", formData)

    try {
      const response = await fetch("/api/admin/roles/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      console.log("[v0] Add role response status:", response.status, "ok:", response.ok)

      if (response.ok) {
        const result = await response.json()
        console.log("[v0] Add role successful, closing modal and refreshing")

        if (result && result.role) {
          setRoles((prev) => [...prev, result.role])
        }

        setIsAddModalOpen(false)
        setFormData({ name: "", display_name: "", description: "", permission_ids: [] })

        setSuccessMessage(locale === "en" ? "Role added successfully!" : "تمت إضافة الدور بنجاح!")
        setTimeout(() => setSuccessMessage(""), 3000)

        await fetchRoles()
      } else {
        console.error("[v0] Add role failed with status:", response.status)
        alert(locale === "en" ? "Failed to add role. Please try again." : "فشل في إضافة الدور. يرجى المحاولة مرة أخرى.")
      }
    } catch (error) {
      console.error("[v0] Error adding role:", error)
      alert(locale === "en" ? "Failed to add role. Please try again." : "فشل في إضافة الدور. يرجى المحاولة مرة أخرى.")
    } finally {
      setSaving(false)
    }
  }

  const handleEditRole = async () => {
    if (!selectedRole) return

    if (!formData.display_name) {
      alert(locale === "en" ? "Please fill in all required fields" : "يرجى ملء جميع الحقول المطلوبة")
      return
    }

    setSaving(true)
    console.log("[v0] handleEditRole called with formData:", formData)

    try {
      const response = await fetch(`/api/admin/roles/${selectedRole.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      console.log("[v0] Edit role response status:", response.status, "ok:", response.ok)

      if (response.ok) {
        const result = await response.json()
        console.log("[v0] Edit role successful, closing modal and refreshing")

        if (result && result.role) {
          setRoles((prev) => prev.map((r) => (r.id === selectedRole.id ? result.role : r)))
        }

        setIsEditModalOpen(false)
        setSelectedRole(null)
        setFormData({ name: "", display_name: "", description: "", permission_ids: [] })

        setSuccessMessage(locale === "en" ? "Role updated successfully!" : "تم تحديث الدور بنجاح!")
        setTimeout(() => setSuccessMessage(""), 3000)

        await fetchRoles()
      } else {
        console.error("[v0] Edit role failed with status:", response.status)
        alert(
          locale === "en" ? "Failed to update role. Please try again." : "فشل في تحديث الدور. يرجى المحاولة مرة أخرى.",
        )
      }
    } catch (error) {
      console.error("[v0] Error updating role:", error)
      alert(
        locale === "en" ? "Failed to update role. Please try again." : "فشل في تحديث الدور. يرجى المحاولة مرة أخرى.",
      )
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteRole = async (roleId: number, isSystem: boolean) => {
    if (isSystem) {
      alert(t[locale].cannotDeleteSystem)
      return
    }

    if (!confirm(t[locale].confirmDelete)) return

    try {
      const response = await fetch(`/api/admin/roles/${roleId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        fetchRoles()
      }
    } catch (error) {
      console.error("[v0] Error deleting role:", error)
    }
  }

  const openEditModal = (role: Role) => {
    setSelectedRole(role)
    setFormData({
      name: role.name,
      display_name: role.display_name,
      description: role.description,
      permission_ids: role.permissions?.map((p) => p.id) || [],
    })
    setIsEditModalOpen(true)
  }

  const togglePermission = (permissionId: number) => {
    setFormData((prev) => ({
      ...prev,
      permission_ids: prev.permission_ids.includes(permissionId)
        ? prev.permission_ids.filter((id) => id !== permissionId)
        : [...prev.permission_ids, permissionId],
    }))
  }

  // Group permissions by resource
  const groupedPermissions = permissions.reduce(
    (acc, permission) => {
      // Add defensive check for undefined permission
      if (!permission || !permission.resource) {
        return acc
      }

      if (!acc[permission.resource]) {
        acc[permission.resource] = []
      }
      acc[permission.resource].push(permission)
      return acc
    },
    {} as Record<string, Permission[]>,
  )

  return (
    <ProtectedRoute requiredPermission="roles.read">
      <DashboardLayout locale={locale} activePage="roles">
        <div className="p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>
            <PermissionGate permission="roles.create">
              <Button onClick={() => setIsAddModalOpen(true)} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                {t[locale].addRole}
              </Button>
            </PermissionGate>
          </div>

          {successMessage && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <p className="text-green-800 font-medium">{successMessage}</p>
            </div>
          )}

          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {roles.map((role) => (
                <div key={role.id} className="bg-white rounded-lg shadow p-6 space-y-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Shield className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-slate-900">{role.display_name}</h3>
                        <p className="text-sm text-slate-500">{role.name}</p>
                      </div>
                    </div>
                    {role.is_system && (
                      <span className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                        <Lock className="w-3 h-3" />
                        {t[locale].systemRole}
                      </span>
                    )}
                  </div>

                  <p className="text-sm text-slate-600">{role.description}</p>

                  <div className="pt-4 border-t border-slate-200">
                    <div className="text-sm text-slate-500 mb-2">
                      {role.permissions?.length || 0} {t[locale].permissionCount}
                    </div>
                    <div className="flex items-center gap-2">
                      <PermissionGate permission="roles.update">
                        <button
                          onClick={() => openEditModal(role)}
                          className="flex items-center gap-1 px-3 py-1.5 text-sm text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                        >
                          <Edit className="w-4 h-4" />
                          {t[locale].edit}
                        </button>
                      </PermissionGate>
                      <PermissionGate permission="roles.delete">
                        <button
                          onClick={() => handleDeleteRole(role.id, role.is_system)}
                          disabled={role.is_system}
                          className={`flex items-center gap-1 px-3 py-1.5 text-sm rounded-md transition-colors ${
                            role.is_system ? "text-slate-400 cursor-not-allowed" : "text-red-600 hover:bg-red-50"
                          }`}
                        >
                          <Trash2 className="w-4 h-4" />
                          {t[locale].delete}
                        </button>
                      </PermissionGate>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Add Role Modal */}
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>{t[locale].addRole}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t[locale].roleName}</Label>
                  <Input
                    id="name"
                    placeholder="e.g., custom_manager"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="display_name">{t[locale].displayName}</Label>
                  <Input
                    id="display_name"
                    placeholder="e.g., Custom Manager"
                    value={formData.display_name}
                    onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">{t[locale].description}</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe the role's purpose..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t[locale].selectPermissions}</Label>
                  <div className="space-y-4 max-h-96 overflow-y-auto border rounded-md p-4">
                    {Object.entries(groupedPermissions).map(([resource, perms]) => (
                      <div key={resource} className="space-y-2">
                        <h4 className="font-semibold text-sm text-slate-700 capitalize">{resource}</h4>
                        <div className="space-y-1 pl-4">
                          {perms.map((permission) => (
                            <label key={permission.id} className="flex items-center gap-2 cursor-pointer py-1">
                              <input
                                type="checkbox"
                                checked={formData.permission_ids.includes(permission.id)}
                                onChange={() => togglePermission(permission.id)}
                                className="rounded border-slate-300"
                              />
                              <span className="text-sm">
                                {permission.display_name || permission.name}
                                {permission.description && (
                                  <span className="text-slate-500 text-xs ml-2">({permission.description})</span>
                                )}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddModalOpen(false)} disabled={saving}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleAddRole} disabled={saving}>
                  {saving ? (locale === "en" ? "Saving..." : "جاري الحفظ...") : t[locale].save}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Edit Role Modal */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {t[locale].edit} {selectedRole?.display_name}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-display_name">{t[locale].displayName}</Label>
                  <Input
                    id="edit-display_name"
                    value={formData.display_name}
                    onChange={(e) => setFormData({ ...formData, display_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-description">{t[locale].description}</Label>
                  <Textarea
                    id="edit-description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>{t[locale].selectPermissions}</Label>
                  <div className="space-y-4 max-h-96 overflow-y-auto border rounded-md p-4">
                    {Object.entries(groupedPermissions).map(([resource, perms]) => (
                      <div key={resource} className="space-y-2">
                        <h4 className="font-semibold text-sm text-slate-700 capitalize">{resource}</h4>
                        <div className="space-y-1 pl-4">
                          {perms.map((permission) => (
                            <label key={permission.id} className="flex items-center gap-2 cursor-pointer py-1">
                              <input
                                type="checkbox"
                                checked={formData.permission_ids.includes(permission.id)}
                                onChange={() => togglePermission(permission.id)}
                                className="rounded border-slate-300"
                              />
                              <span className="text-sm">
                                {permission.display_name || permission.name}
                                {permission.description && (
                                  <span className="text-slate-500 text-xs ml-2">({permission.description})</span>
                                )}
                              </span>
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditModalOpen(false)} disabled={saving}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleEditRole} disabled={saving}>
                  {saving ? (locale === "en" ? "Saving..." : "جاري الحفظ...") : t[locale].save}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}
