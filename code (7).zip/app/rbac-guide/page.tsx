"use client"

import { useSearchParams } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { Shield, CheckCircle, XCircle, Users, Lock, Key, FileText } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function RBACGuidePage() {
  const searchParams = useSearchParams()
  const locale = (searchParams.get("locale") as "en" | "ar") || "en"

  const t = {
    en: {
      title: "Role-Based Access Control Guide",
      subtitle: "Complete overview of roles, permissions, and access levels in FleetPro",
      rolesOverview: "System Roles Overview",
      permissionsMatrix: "Permissions Matrix",
      implementationDetails: "Implementation Details",
      securityNotes: "Security Notes",
      resource: "Resource",
      action: "Action",
      fullAccess: "Full Access",
      noAccess: "No Access",
      readOnly: "Read Only",
      create: "Create",
      read: "Read",
      update: "Update",
      delete: "Delete",
      approve: "Approve",
      export: "Export",
    },
    ar: {
      title: "دليل التحكم في الوصول القائم على الأدوار",
      subtitle: "نظرة عامة كاملة على الأدوار والصلاحيات ومستويات الوصول في FleetPro",
      rolesOverview: "نظرة عامة على أدوار النظام",
      permissionsMatrix: "مصفوفة الصلاحيات",
      implementationDetails: "تفاصيل التنفيذ",
      securityNotes: "ملاحظات الأمان",
      resource: "المورد",
      action: "الإجراء",
      fullAccess: "وصول كامل",
      noAccess: "لا يوجد وصول",
      readOnly: "قراءة فقط",
      create: "إنشاء",
      read: "قراءة",
      update: "تحديث",
      delete: "حذف",
      approve: "موافقة",
      export: "تصدير",
    },
  }

  const roles = [
    {
      name: "Super Administrator",
      nameAr: "المسؤول الأعلى",
      key: "super_admin",
      color: "bg-purple-100 text-purple-800 border-purple-300",
      icon: Shield,
      description: "Full system access with all permissions",
      descriptionAr: "وصول كامل للنظام مع جميع الصلاحيات",
      permissions: ["*"],
    },
    {
      name: "Administrator",
      nameAr: "المسؤول",
      key: "admin",
      color: "bg-red-100 text-red-800 border-red-300",
      icon: Lock,
      description: "Administrative access to manage users and system settings",
      descriptionAr: "وصول إداري لإدارة المستخدمين وإعدادات النظام",
      permissions: [
        "users.*",
        "roles.read",
        "vehicles.*",
        "drivers.*",
        "reservations.*",
        "tickets.*",
        "movements.*",
        "supplies.*",
        "dashboard.view",
        "reports.*",
        "transactions.*",
      ],
    },
    {
      name: "Fleet Manager",
      nameAr: "مدير الأسطول",
      key: "fleet_manager",
      color: "bg-blue-100 text-blue-800 border-blue-300",
      icon: Users,
      description: "Manage vehicles, drivers, and reservations",
      descriptionAr: "إدارة المركبات والسائقين والحجوزات",
      permissions: [
        "vehicles.*",
        "drivers.*",
        "reservations.*",
        "movements.read",
        "movements.update",
        "supplies.read",
        "supplies.update",
        "dashboard.view",
        "reports.view",
        "transactions.read",
        "transactions.create",
        "transactions.update",
        "transactions.export",
      ],
    },
    {
      name: "Dispatcher",
      nameAr: "المرسل",
      key: "dispatcher",
      color: "bg-green-100 text-green-800 border-green-300",
      icon: FileText,
      description: "Manage reservations and movements",
      descriptionAr: "إدارة الحجوزات والحركة",
      permissions: [
        "vehicles.read",
        "drivers.read",
        "reservations.*",
        "movements.*",
        "dashboard.view",
        "transactions.read",
        "transactions.create",
      ],
    },
    {
      name: "Maintenance Staff",
      nameAr: "موظف الصيانة",
      key: "maintenance_staff",
      color: "bg-yellow-100 text-yellow-800 border-yellow-300",
      icon: Key,
      description: "Manage tickets and vehicle maintenance",
      descriptionAr: "إدارة التذاكر وصيانة المركبات",
      permissions: [
        "vehicles.read",
        "vehicles.update",
        "tickets.*",
        "supplies.*",
        "dashboard.view",
        "transactions.read",
      ],
    },
    {
      name: "Viewer",
      nameAr: "المشاهد",
      key: "viewer",
      color: "bg-gray-100 text-gray-800 border-gray-300",
      icon: FileText,
      description: "Read-only access to all data",
      descriptionAr: "وصول للقراءة فقط لجميع البيانات",
      permissions: [
        "users.read",
        "vehicles.read",
        "drivers.read",
        "reservations.read",
        "tickets.read",
        "movements.read",
        "supplies.read",
        "dashboard.view",
        "reports.view",
        "transactions.read",
      ],
    },
  ]

  const resources = [
    { key: "users", name: "Users", nameAr: "المستخدمون" },
    { key: "roles", name: "Roles", nameAr: "الأدوار" },
    { key: "vehicles", name: "Vehicles", nameAr: "المركبات" },
    { key: "drivers", name: "Drivers", nameAr: "السائقون" },
    { key: "reservations", name: "Reservations", nameAr: "الحجوزات" },
    { key: "tickets", name: "Tickets", nameAr: "التذاكر" },
    { key: "movements", name: "Movements", nameAr: "الحركة" },
    { key: "supplies", name: "Supplies", nameAr: "المستلزمات" },
    { key: "transactions", name: "Transactions", nameAr: "المعاملات" },
    { key: "dashboard", name: "Dashboard", nameAr: "لوحة التحكم" },
    { key: "reports", name: "Reports", nameAr: "التقارير" },
  ]

  const actions = ["create", "read", "update", "delete", "approve", "export"]

  const hasPermission = (rolePermissions: string[], resource: string, action: string) => {
    if (rolePermissions.includes("*")) return true
    if (rolePermissions.includes(`${resource}.*`)) return true
    if (rolePermissions.includes(`${resource}.${action}`)) return true
    return false
  }

  return (
    <DashboardLayout locale={locale} activePage="rbac-guide">
      <div className="p-6 space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl font-bold text-slate-800">{t[locale].title}</h1>
          <p className="text-slate-600">{t[locale].subtitle}</p>
        </div>

        {/* Roles Overview */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-800 flex items-center gap-2">
            <Shield className="w-6 h-6" />
            {t[locale].rolesOverview}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {roles.map((role) => {
              const Icon = role.icon
              return (
                <Card key={role.key} className={`border-2 ${role.color}`}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="w-5 h-5" />
                      {locale === "en" ? role.name : role.nameAr}
                    </CardTitle>
                    <CardDescription className="text-sm font-medium">
                      {locale === "en" ? role.description : role.descriptionAr}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-xs font-semibold text-slate-600 uppercase">
                        {locale === "en" ? "Permissions" : "الصلاحيات"}
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {role.permissions.slice(0, 5).map((perm, idx) => (
                          <Badge key={idx} variant="secondary" className="text-xs">
                            {perm}
                          </Badge>
                        ))}
                        {role.permissions.length > 5 && (
                          <Badge variant="outline" className="text-xs">
                            +{role.permissions.length - 5}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Permissions Matrix */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-800 flex items-center gap-2">
            <Key className="w-6 h-6" />
            {t[locale].permissionsMatrix}
          </h2>
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-slate-100 border-b-2 border-slate-300">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-slate-700 sticky left-0 bg-slate-100 z-10">
                      {t[locale].resource}
                    </th>
                    {roles.map((role) => (
                      <th key={role.key} className="px-4 py-3 text-center font-semibold text-slate-700 min-w-[120px]">
                        <div className="flex flex-col items-center gap-1">
                          <span>{locale === "en" ? role.name : role.nameAr}</span>
                          <Badge className={role.color}>{role.key}</Badge>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {resources.map((resource) => (
                    <tr key={resource.key} className="hover:bg-slate-50">
                      <td className="px-4 py-3 font-medium text-slate-900 sticky left-0 bg-white">
                        {locale === "en" ? resource.name : resource.nameAr}
                      </td>
                      {roles.map((role) => {
                        const hasFullAccess =
                          role.permissions.includes("*") || role.permissions.includes(`${resource.key}.*`)
                        const hasReadOnly =
                          !hasFullAccess && role.permissions.some((p) => p.startsWith(`${resource.key}.read`))
                        const hasNoAccess = !hasFullAccess && !hasReadOnly

                        return (
                          <td key={role.key} className="px-4 py-3 text-center">
                            {hasFullAccess && (
                              <div className="flex items-center justify-center gap-1 text-green-700">
                                <CheckCircle className="w-4 h-4" />
                                <span className="text-xs font-medium">{t[locale].fullAccess}</span>
                              </div>
                            )}
                            {hasReadOnly && (
                              <div className="flex items-center justify-center gap-1 text-blue-700">
                                <CheckCircle className="w-4 h-4" />
                                <span className="text-xs font-medium">{t[locale].readOnly}</span>
                              </div>
                            )}
                            {hasNoAccess && (
                              <div className="flex items-center justify-center gap-1 text-gray-400">
                                <XCircle className="w-4 h-4" />
                                <span className="text-xs font-medium">{t[locale].noAccess}</span>
                              </div>
                            )}
                          </td>
                        )
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Implementation Details */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-slate-800">{t[locale].implementationDetails}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">{locale === "en" ? "Permission Checking" : "فحص الصلاحيات"}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="bg-slate-50 p-3 rounded font-mono text-xs">
                  <div>hasPermission("vehicles.read")</div>
                  <div>hasAnyPermission(["vehicles.*"])</div>
                  <div>hasRole("fleet_manager")</div>
                </div>
                <p className="text-slate-600">
                  {locale === "en"
                    ? "Use these methods from useAuth() hook to check permissions in components"
                    : "استخدم هذه الطرق من useAuth() hook للتحقق من الصلاحيات في المكونات"}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">
                  {locale === "en" ? "Permission Gate Component" : "مكون بوابة الصلاحيات"}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="bg-slate-50 p-3 rounded font-mono text-xs">
                  <div>{"<PermissionGate"}</div>
                  <div className="pl-4">{'permission="vehicles.create"'}</div>
                  <div>{">"}</div>
                  <div className="pl-4">{"<Button>Create</Button>"}</div>
                  <div>{"</PermissionGate>"}</div>
                </div>
                <p className="text-slate-600">
                  {locale === "en"
                    ? "Wrap UI elements to conditionally render based on permissions"
                    : "قم بتغليف عناصر واجهة المستخدم للعرض الشرطي بناءً على الصلاحيات"}
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Security Notes */}
        <Alert>
          <Shield className="w-4 h-4" />
          <AlertTitle className="font-semibold">{t[locale].securityNotes}</AlertTitle>
          <AlertDescription className="space-y-2 text-sm">
            <ul className="list-disc list-inside space-y-1">
              <li>
                {locale === "en"
                  ? "All permissions are enforced on both client and server side"
                  : "يتم فرض جميع الصلاحيات على جانب العميل والخادم"}
              </li>
              <li>
                {locale === "en"
                  ? "Super Admin role has wildcard (*) permission for all resources"
                  : "دور المسؤول الأعلى لديه صلاحية wildcard (*) لجميع الموارد"}
              </li>
              <li>
                {locale === "en"
                  ? "User roles are stored in database and cached in JWT tokens"
                  : "يتم تخزين أدوار المستخدم في قاعدة البيانات وتخزينها مؤقتًا في رموز JWT"}
              </li>
              <li>
                {locale === "en"
                  ? "All user actions are tracked with created_by, updated_by, approved_by fields"
                  : "يتم تتبع جميع إجراءات المستخدم باستخدام حقول created_by و updated_by و approved_by"}
              </li>
            </ul>
          </AlertDescription>
        </Alert>
      </div>
    </DashboardLayout>
  )
}
