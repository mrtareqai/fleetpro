/**
 * Zod Validation Schemas
 *
 * This module provides comprehensive data validation schemas for all entities
 * in the FleetPro Management System using Zod.
 *
 * Benefits:
 * - Type-safe validation at runtime
 * - Automatic TypeScript type inference
 * - Clear error messages for invalid data
 * - Reusable validation logic
 *
 * Usage:
 * \`\`\`typescript
 * const result = userSchema.safeParse(data)
 * if (!result.success) {
 *   console.error(result.error.errors)
 * }
 * \`\`\`
 */

import { z } from "zod"

// ============================================================================
// Common Schemas
// ============================================================================

/**
 * Common validation patterns
 */
export const commonSchemas = {
  id: z.number().int().positive(),
  email: z.string().email("Invalid email format"),
  phone: z.string().regex(/^\+?[1-9]\d{1,14}$/, "Invalid phone number format"),
  url: z.string().url("Invalid URL format"),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format"),
  datetime: z.string().datetime("Invalid datetime format"),
  status: z.enum(["active", "inactive"]),
}

// ============================================================================
// User Schemas
// ============================================================================

/**
 * User creation schema
 */
export const createUserSchema = z.object({
  username: z
    .string()
    .min(3, "Username must be at least 3 characters")
    .max(50, "Username must not exceed 50 characters")
    .regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, hyphens, and underscores"),
  email: commonSchemas.email,
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[!@#$%^&*(),.?":{}|<>]/, "Password must contain at least one special character"),
  full_name: z.string().min(1, "Full name is required").max(100, "Full name must not exceed 100 characters"),
  role: z.string().min(1, "Role is required"),
  company_id: z.number().int().positive().optional(),
})

/**
 * User update schema (all fields optional)
 */
export const updateUserSchema = z.object({
  username: z
    .string()
    .min(3, "Username must be at least 3 characters")
    .max(50, "Username must not exceed 50 characters")
    .regex(/^[a-zA-Z0-9_-]+$/, "Username can only contain letters, numbers, hyphens, and underscores")
    .optional(),
  email: commonSchemas.email.optional(),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters")
    .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
    .regex(/[a-z]/, "Password must contain at least one lowercase letter")
    .regex(/[0-9]/, "Password must contain at least one number")
    .regex(/[!@#$%^&*(),.?":{}|<>]/, "Password must contain at least one special character")
    .optional(),
  full_name: z.string().min(1, "Full name is required").max(100, "Full name must not exceed 100 characters").optional(),
  role: z.string().min(1, "Role is required").optional(),
  company_id: z.number().int().positive().optional(),
})

/**
 * User login schema
 */
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
})

/**
 * Password change schema
 */
export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Current password is required"),
    newPassword: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(/[!@#$%^&*(),.?":{}|<>]/, "Password must contain at least one special character"),
    confirmPassword: z.string().min(1, "Password confirmation is required"),
  })
  .refine((data) => data.newPassword === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  })

// ============================================================================
// Driver Schemas
// ============================================================================

/**
 * Driver creation schema
 */
export const createDriverSchema = z.object({
  name: z.string().min(1, "Driver name is required").max(100, "Name must not exceed 100 characters"),
  license_number: z
    .string()
    .min(1, "License number is required")
    .max(50, "License number must not exceed 50 characters"),
  phone: commonSchemas.phone.optional(),
  email: commonSchemas.email.optional(),
  status: commonSchemas.status.default("active"),
  company_id: z.number().int().positive().optional(),
})

/**
 * Driver update schema
 */
export const updateDriverSchema = z.object({
  name: z.string().min(1, "Driver name is required").max(100, "Name must not exceed 100 characters").optional(),
  license_number: z
    .string()
    .min(1, "License number is required")
    .max(50, "License number must not exceed 50 characters")
    .optional(),
  phone: commonSchemas.phone.optional(),
  email: commonSchemas.email.optional(),
  status: commonSchemas.status.optional(),
  company_id: z.number().int().positive().optional(),
})

// ============================================================================
// Vehicle Schemas
// ============================================================================

/**
 * Vehicle status enum
 */
export const vehicleStatusSchema = z.enum(["active", "inactive", "maintenance", "expired"])

/**
 * Vehicle creation schema
 */
export const createVehicleSchema = z.object({
  model: z.string().min(1, "Vehicle model is required").max(100, "Model must not exceed 100 characters"),
  manufacture_date: commonSchemas.date,
  plate_number: z.string().min(1, "Plate number is required").max(50, "Plate number must not exceed 50 characters"),
  base_number: z.string().max(50, "Base number must not exceed 50 characters").optional(),
  card_number: z.string().max(50, "Card number must not exceed 50 characters").optional(),
  issue_date: commonSchemas.date.optional(),
  expiry_date: commonSchemas.date.optional(),
  status: vehicleStatusSchema.default("active"),
  company_id: z.number().int().positive().optional(),
})

/**
 * Vehicle update schema
 */
export const updateVehicleSchema = z.object({
  model: z.string().min(1, "Vehicle model is required").max(100, "Model must not exceed 100 characters").optional(),
  manufacture_date: commonSchemas.date.optional(),
  plate_number: z
    .string()
    .min(1, "Plate number is required")
    .max(50, "Plate number must not exceed 50 characters")
    .optional(),
  base_number: z.string().max(50, "Base number must not exceed 50 characters").optional(),
  card_number: z.string().max(50, "Card number must not exceed 50 characters").optional(),
  issue_date: commonSchemas.date.optional(),
  expiry_date: commonSchemas.date.optional(),
  status: vehicleStatusSchema.optional(),
  company_id: z.number().int().positive().optional(),
})

// ============================================================================
// Movement Schemas
// ============================================================================

/**
 * Movement status enum
 */
export const movementStatusSchema = z.enum(["scheduled", "in-progress", "completed", "cancelled"])

/**
 * Movement creation schema
 */
export const createMovementSchema = z.object({
  driver_name: z.string().min(1, "Driver name is required").max(100),
  assistant_name: z.string().max(100).optional(),
  bus_number: z.string().min(1, "Bus number is required").max(50),
  trip_name: z.string().min(1, "Trip name is required").max(200),
  trip_date: commonSchemas.date,
  trip_time: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Time must be in HH:MM format"),
  seats: z.number().int().positive("Seats must be a positive number"),
  pending_seats: z.number().int().min(0, "Pending seats cannot be negative"),
  status: movementStatusSchema.default("scheduled"),
  company_id: z.number().int().positive().optional(),
})

/**
 * Movement update schema
 */
export const updateMovementSchema = z.object({
  driver_name: z.string().min(1, "Driver name is required").max(100).optional(),
  assistant_name: z.string().max(100).optional(),
  bus_number: z.string().min(1, "Bus number is required").max(50).optional(),
  trip_name: z.string().min(1, "Trip name is required").max(200).optional(),
  trip_date: commonSchemas.date.optional(),
  trip_time: z
    .string()
    .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Time must be in HH:MM format")
    .optional(),
  seats: z.number().int().positive("Seats must be a positive number").optional(),
  pending_seats: z.number().int().min(0, "Pending seats cannot be negative").optional(),
  status: movementStatusSchema.optional(),
  company_id: z.number().int().positive().optional(),
})

// ============================================================================
// Reservation Schemas
// ============================================================================

/**
 * Reservation status enum
 */
export const reservationStatusSchema = z.enum(["pending", "confirmed", "active", "completed", "cancelled"])

/**
 * Reservation creation schema
 */
export const createReservationSchema = z
  .object({
    vehicle_id: z.number().int().positive("Vehicle ID is required"),
    driver_id: z.number().int().positive("Driver ID is required"),
    start_date: commonSchemas.date,
    end_date: commonSchemas.date,
    purpose: z.string().min(1, "Purpose is required").max(500),
    status: reservationStatusSchema.default("pending"),
    company_id: z.number().int().positive().optional(),
  })
  .refine((data) => new Date(data.end_date) >= new Date(data.start_date), {
    message: "End date must be after or equal to start date",
    path: ["end_date"],
  })

/**
 * Reservation update schema
 */
export const updateReservationSchema = z.object({
  vehicle_id: z.number().int().positive("Vehicle ID is required").optional(),
  driver_id: z.number().int().positive("Driver ID is required").optional(),
  start_date: commonSchemas.date.optional(),
  end_date: commonSchemas.date.optional(),
  purpose: z.string().min(1, "Purpose is required").max(500).optional(),
  status: reservationStatusSchema.optional(),
  company_id: z.number().int().positive().optional(),
})

// ============================================================================
// Ticket Schemas
// ============================================================================

/**
 * Ticket status enum
 */
export const ticketStatusSchema = z.enum(["pending", "confirmed", "cancelled", "used"])

/**
 * Ticket creation schema
 */
export const createTicketSchema = z.object({
  passenger_name: z.string().min(1, "Passenger name is required").max(100),
  trip_number: z.string().min(1, "Trip number is required").max(50),
  trip_name: z.string().min(1, "Trip name is required").max(200),
  trip_date: commonSchemas.date,
  ticket_number: z.string().min(1, "Ticket number is required").max(50),
  trip_time: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Time must be in HH:MM format"),
  seat_number: z.string().min(1, "Seat number is required").max(10),
  mobile_number: commonSchemas.phone,
  issue_date: commonSchemas.date,
  user: z.string().min(1, "User is required").max(100),
  branch: z.string().min(1, "Branch is required").max(100),
  status: ticketStatusSchema.default("pending"),
  company_id: z.number().int().positive().optional(),
})

/**
 * Ticket update schema
 */
export const updateTicketSchema = z.object({
  passenger_name: z.string().min(1, "Passenger name is required").max(100).optional(),
  trip_number: z.string().min(1, "Trip number is required").max(50).optional(),
  trip_name: z.string().min(1, "Trip name is required").max(200).optional(),
  trip_date: commonSchemas.date.optional(),
  ticket_number: z.string().min(1, "Ticket number is required").max(50).optional(),
  trip_time: z
    .string()
    .regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "Time must be in HH:MM format")
    .optional(),
  seat_number: z.string().min(1, "Seat number is required").max(10).optional(),
  mobile_number: commonSchemas.phone.optional(),
  issue_date: commonSchemas.date.optional(),
  user: z.string().min(1, "User is required").max(100).optional(),
  branch: z.string().min(1, "Branch is required").max(100).optional(),
  status: ticketStatusSchema.optional(),
  company_id: z.number().int().positive().optional(),
})

// ============================================================================
// Company Schemas
// ============================================================================

/**
 * Company creation schema
 */
export const createCompanySchema = z.object({
  name: z.string().min(1, "Company name is required").max(200),
  owner_name: z.string().min(1, "Owner name is required").max(100),
  contact_number: commonSchemas.phone,
  email: commonSchemas.email,
  neon_url: commonSchemas.url.optional(),
  github_api_key: z.string().max(200).optional(),
  admin_username: z.string().min(3, "Admin username must be at least 3 characters").max(50),
  admin_password: z.string().min(8, "Admin password must be at least 8 characters"),
  is_active: z.boolean().default(true),
})

/**
 * Company update schema
 */
export const updateCompanySchema = z.object({
  name: z.string().min(1, "Company name is required").max(200).optional(),
  owner_name: z.string().min(1, "Owner name is required").max(100).optional(),
  contact_number: commonSchemas.phone.optional(),
  email: commonSchemas.email.optional(),
  neon_url: commonSchemas.url.optional(),
  github_api_key: z.string().max(200).optional(),
  admin_username: z.string().min(3, "Admin username must be at least 3 characters").max(50).optional(),
  admin_password: z.string().min(8, "Admin password must be at least 8 characters").optional(),
  is_active: z.boolean().optional(),
})

// ============================================================================
// Role & Permission Schemas
// ============================================================================

/**
 * Permission creation schema
 */
export const createPermissionSchema = z.object({
  name: z.string().min(1, "Permission name is required").max(100),
  display_name: z.string().min(1, "Display name is required").max(100),
  description: z.string().max(500).optional(),
  resource: z.string().min(1, "Resource is required").max(50),
  action: z.string().min(1, "Action is required").max(50),
})

/**
 * Role creation schema
 */
export const createRoleSchema = z.object({
  name: z.string().min(1, "Role name is required").max(100),
  display_name: z.string().min(1, "Display name is required").max(100),
  description: z.string().max(500).optional(),
  is_system: z.boolean().default(false),
  permission_ids: z.array(z.number().int().positive()).optional(),
})

/**
 * Role update schema
 */
export const updateRoleSchema = z.object({
  name: z.string().min(1, "Role name is required").max(100).optional(),
  display_name: z.string().min(1, "Display name is required").max(100).optional(),
  description: z.string().max(500).optional(),
  is_system: z.boolean().optional(),
  permission_ids: z.array(z.number().int().positive()).optional(),
})

// ============================================================================
// Query Parameter Schemas
// ============================================================================

/**
 * Pagination schema
 */
export const paginationSchema = z.object({
  page: z.coerce.number().int().positive().default(1),
  limit: z.coerce.number().int().positive().max(100).default(20),
  sort: z.string().optional(),
  order: z.enum(["asc", "desc"]).default("desc"),
})

/**
 * Search schema
 */
export const searchSchema = z.object({
  q: z.string().min(1, "Search query is required"),
  fields: z.array(z.string()).optional(),
})

/**
 * Filter schema
 */
export const filterSchema = z.object({
  status: z.string().optional(),
  company_id: z.coerce.number().int().positive().optional(),
  start_date: commonSchemas.date.optional(),
  end_date: commonSchemas.date.optional(),
})

// ============================================================================
// Supply Schemas
// ============================================================================

/**
 * Supply status enum
 */
export const supplyStatusSchema = z.enum(["pending", "approved", "ordered", "received", "cancelled"])

/**
 * Supply priority enum
 */
export const supplyPrioritySchema = z.enum(["low", "medium", "high", "urgent"])

/**
 * Supply creation schema
 */
export const createSupplySchema = z.object({
  vehicle_id: z.number().int().positive("Vehicle ID is required"),
  supply_type: z.string().min(1, "Supply type is required").max(100, "Supply type must not exceed 100 characters"),
  category: z.string().min(1, "Category is required").max(100, "Category must not exceed 100 characters"),
  subject: z.string().min(1, "Subject is required").max(500, "Subject must not exceed 500 characters"),
  quantity: z.number().int().positive("Quantity must be a positive number"),
  date: commonSchemas.date,
  priority: supplyPrioritySchema.default("medium"),
  status: supplyStatusSchema.default("pending"),
  company_id: z.number().int().positive().optional(),
})

/**
 * Supply update schema
 */
export const updateSupplySchema = z.object({
  vehicle_id: z.number().int().positive("Vehicle ID is required").optional(),
  supply_type: z
    .string()
    .min(1, "Supply type is required")
    .max(100, "Supply type must not exceed 100 characters")
    .optional(),
  category: z.string().min(1, "Category is required").max(100, "Category must not exceed 100 characters").optional(),
  subject: z.string().min(1, "Subject is required").max(500, "Subject must not exceed 500 characters").optional(),
  quantity: z.number().int().positive("Quantity must be a positive number").optional(),
  date: commonSchemas.date.optional(),
  priority: supplyPrioritySchema.optional(),
  status: supplyStatusSchema.optional(),
  company_id: z.number().int().positive().optional(),
})

// ============================================================================
// Type Exports (inferred from schemas)
// ============================================================================

export type CreateUserInput = z.infer<typeof createUserSchema>
export type UpdateUserInput = z.infer<typeof updateUserSchema>
export type LoginInput = z.infer<typeof loginSchema>
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>

export type CreateDriverInput = z.infer<typeof createDriverSchema>
export type UpdateDriverInput = z.infer<typeof updateDriverSchema>

export type CreateVehicleInput = z.infer<typeof createVehicleSchema>
export type UpdateVehicleInput = z.infer<typeof updateVehicleSchema>

export type CreateMovementInput = z.infer<typeof createMovementSchema>
export type UpdateMovementInput = z.infer<typeof updateMovementSchema>

export type CreateReservationInput = z.infer<typeof createReservationSchema>
export type UpdateReservationInput = z.infer<typeof updateReservationSchema>

export type CreateTicketInput = z.infer<typeof createTicketSchema>
export type UpdateTicketInput = z.infer<typeof updateTicketSchema>

export type CreateCompanyInput = z.infer<typeof createCompanySchema>
export type UpdateCompanyInput = z.infer<typeof updateCompanySchema>

export type CreatePermissionInput = z.infer<typeof createPermissionSchema>
export type CreateRoleInput = z.infer<typeof createRoleSchema>
export type UpdateRoleInput = z.infer<typeof updateRoleSchema>

export type PaginationInput = z.infer<typeof paginationSchema>
export type SearchInput = z.infer<typeof searchSchema>
export type FilterInput = z.infer<typeof filterSchema>

export type CreateSupplyInput = z.infer<typeof createSupplySchema>
export type UpdateSupplyInput = z.infer<typeof updateSupplySchema>
