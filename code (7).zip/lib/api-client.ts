import { mockHandler } from "./api/mock-handler"
import { mockConfig, logMockOperation } from "./api/mock-config"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api"
const USE_MOCK_DATA = mockConfig.enabled

interface RequestOptions extends RequestInit {
  token?: string
}

class ApiClient {
  private baseUrl: string

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl
  }

  private async request<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    if (USE_MOCK_DATA) {
      return this.mockRequest<T>(endpoint, options)
    }

    const { token, ...fetchOptions } = options

    const headers: HeadersInit = {
      "Content-Type": "application/json",
      ...fetchOptions.headers,
    }

    const authToken = token || this.getAuthToken()
    if (authToken) {
      headers["Authorization"] = `Bearer ${authToken}`
    }

    try {
      const response = await fetch(`${this.baseUrl}${endpoint}`, {
        ...fetchOptions,
        headers,
        credentials: "include", // إضافة credentials للـ JWT cookies
      })

      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: "An error occurred" }))
        throw new Error(error.message || `HTTP error! status: ${response.status}`)
      }

      return response.json()
    } catch (error) {
      if (error instanceof TypeError && error.message === "Failed to fetch") {
        throw new Error("Cannot connect to backend server. Please ensure the backend is running at " + this.baseUrl)
      }
      throw error
    }
  }

  private getAuthToken(): string | null {
    if (typeof window === "undefined") return null
    return localStorage.getItem("auth_token")
  }

  private async mockRequest<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
    const method = options.method || "GET"
    const body = options.body ? JSON.parse(options.body as string) : undefined

    try {
      return await mockHandler.handleRequest<T>(endpoint, method, body)
    } catch (error) {
      logMockOperation("Request failed", { endpoint, method, error })
      throw error
    }
  }

  private getCurrentUser() {
    if (typeof window === "undefined") return null
    const userStr = localStorage.getItem("user")
    return userStr ? JSON.parse(userStr) : null
  }

  // Vehicles
  async getVehicles(token?: string) {
    return this.request("/vehicles", { token })
  }

  async getVehicle(id: number, token?: string) {
    return this.request(`/vehicles/${id}`, { token })
  }

  async createVehicle(data: any, token?: string) {
    return this.request("/vehicles", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateVehicle(id: number, data: any, token?: string) {
    return this.request(`/vehicles/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteVehicle(id: number, token?: string) {
    return this.request(`/vehicles/${id}`, {
      method: "DELETE",
      token,
    })
  }

  // Drivers
  async getDrivers(token?: string) {
    return this.request("/drivers", { token })
  }

  async createDriver(data: any, token?: string) {
    return this.request("/drivers", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateDriver(id: number, data: any, token?: string) {
    return this.request(`/drivers/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteDriver(id: number, token?: string) {
    return this.request(`/drivers/${id}`, {
      method: "DELETE",
      token,
    })
  }

  // Reservations
  async getReservations(token?: string) {
    return this.request("/reservations", { token })
  }

  async createReservation(data: any, token?: string) {
    return this.request("/reservations", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateReservation(id: number, data: any, token?: string) {
    return this.request(`/reservations/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteReservation(id: number, token?: string) {
    return this.request(`/reservations/${id}`, {
      method: "DELETE",
      token,
    })
  }

  // Tickets
  async getTickets(token?: string) {
    return this.request("/tickets", { token })
  }

  async addTicket(data: any, token?: string) {
    return this.request("/tickets", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateTicket(id: number, data: any, token?: string) {
    return this.request(`/tickets/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteTicket(id: number, token?: string) {
    return this.request(`/tickets/${id}`, {
      method: "DELETE",
      token,
    })
  }

  // Dashboard
  async getDashboardStats(token?: string) {
    return this.request("/dashboard/stats", { token })
  }

  async getChartData(token?: string) {
    return this.request("/dashboard/charts", { token })
  }

  // Reports API methods
  async getFleetUtilizationReport(startDate?: string, endDate?: string, token?: string) {
    const params = new URLSearchParams()
    if (startDate) params.append("start_date", startDate)
    if (endDate) params.append("end_date", endDate)
    const query = params.toString() ? `?${params.toString()}` : ""
    return this.request(`/reports/fleet-utilization${query}`, { token })
  }

  async getExpensesReport(year?: string, month?: string, token?: string) {
    const params = new URLSearchParams()
    if (year) params.append("year", year)
    if (month) params.append("month", month)
    const query = params.toString() ? `?${params.toString()}` : ""
    return this.request(`/reports/expenses${query}`, { token })
  }

  async getDriverPerformanceReport(startDate?: string, endDate?: string, token?: string) {
    const params = new URLSearchParams()
    if (startDate) params.append("start_date", startDate)
    if (endDate) params.append("end_date", endDate)
    const query = params.toString() ? `?${params.toString()}` : ""
    return this.request(`/reports/driver-performance${query}`, { token })
  }

  async getMonthlyReservationsReport(year?: string, token?: string) {
    const params = new URLSearchParams()
    if (year) params.append("year", year)
    const query = params.toString() ? `?${params.toString()}` : ""
    return this.request(`/reports/monthly-reservations${query}`, { token })
  }

  async getFleetStatusReport(token?: string) {
    return this.request("/reports/fleet-status", { token })
  }

  async exportReport(reportType: string, format: string, data: any, token?: string) {
    return this.request("/reports/export", {
      method: "POST",
      body: JSON.stringify({ reportType, format, data }),
      token,
    })
  }

  // Auth
  async login(credentials: { username: string; password: string; company_code?: string }) {
    return this.request("/auth/login", {
      method: "POST",
      body: JSON.stringify(credentials),
    })
  }

  async register(data: any) {
    return this.request("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
    })
  }

  // Movements
  async getMovements(token?: string) {
    return this.request("/movements", { token })
  }

  async createMovement(data: any, token?: string) {
    return this.request("/movements", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateMovement(id: number, data: any, token?: string) {
    return this.request(`/movements/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteMovement(id: number, token?: string) {
    return this.request(`/movements/${id}`, {
      method: "DELETE",
      token,
    })
  }

  // Company management methods
  async getCompanies(token?: string) {
    return this.request("/companies", { token })
  }

  async createCompany(data: any, token?: string) {
    return this.request("/companies", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateCompany(id: number, data: any, token?: string) {
    return this.request(`/companies/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteCompany(id: number, token?: string) {
    return this.request(`/companies/${id}`, {
      method: "DELETE",
      token,
    })
  }

  // Supplies API methods
  async getSupplies(token?: string) {
    return this.request("/supplies", { token })
  }

  async createSupply(data: any, token?: string) {
    return this.request("/supplies", {
      method: "POST",
      body: JSON.stringify(data),
      token,
    })
  }

  async updateSupply(id: number, data: any, token?: string) {
    return this.request(`/supplies/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
      token,
    })
  }

  async deleteSupply(id: number, token?: string) {
    return this.request(`/supplies/${id}`, {
      method: "DELETE",
      token,
    })
  }
}

export const apiClient = new ApiClient(API_BASE_URL)
