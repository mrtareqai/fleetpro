import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { logger } from "@/lib/logging/logger"
import { z } from "zod"
import { validateOrRespond } from "@/lib/validation/validator"

const sql = neon(process.env.DATABASE_URL!)

const updateSupplySchema = z.object({
  vehicle_id: z.number().int().positive().optional(),
  supply_type: z.string().min(1).max(100).optional(),
  category: z.string().min(1).max(100).optional(),
  subject: z.string().min(1).max(500).optional(),
  quantity: z.number().int().positive().optional(),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/)
    .optional(),
  priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
  status: z.enum(["pending", "approved", "ordered", "received", "cancelled"]).optional(),
})

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "supplies.read")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const supplyId = Number.parseInt(params.id)

    if (isNaN(supplyId)) {
      return NextResponse.json({ error: "Invalid supply ID" }, { status: 400 })
    }

    logger.info("Fetching agency supply", { userId: user.id, supplyId })

    const result = await sql`
      SELECT 
        s.*,
        v.model as vehicle_model,
        v.plate_number as vehicle_plate
      FROM agency_supplies s
      LEFT JOIN vehicles v ON s.vehicle_id = v.id
      WHERE s.id = ${supplyId}
    `

    if (result.length === 0) {
      logger.warn("Agency supply not found", { userId: user.id, supplyId })
      return NextResponse.json({ error: "Agency supply not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Agency supply fetched successfully", { userId: user.id, supplyId, duration })

    return NextResponse.json({ supply: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching agency supply", { error, supplyId: params.id, duration })

    return NextResponse.json({ error: "Failed to fetch agency supply" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "supplies.update")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const supplyId = Number.parseInt(params.id)

    if (isNaN(supplyId)) {
      return NextResponse.json({ error: "Invalid supply ID" }, { status: 400 })
    }

    // Validate request body
    const body = await request.json()
    const validatedData = await validateOrRespond(updateSupplySchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Updating agency supply", { userId: user.id, supplyId })

    // Build dynamic update query
    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1

    if (validatedData.vehicle_id !== undefined) {
      updates.push(`vehicle_id = $${paramIndex++}`)
      values.push(validatedData.vehicle_id)
    }
    if (validatedData.supply_type !== undefined) {
      updates.push(`supply_type = $${paramIndex++}`)
      values.push(validatedData.supply_type)
    }
    if (validatedData.category !== undefined) {
      updates.push(`category = $${paramIndex++}`)
      values.push(validatedData.category)
    }
    if (validatedData.subject !== undefined) {
      updates.push(`subject = $${paramIndex++}`)
      values.push(validatedData.subject)
    }
    if (validatedData.quantity !== undefined) {
      updates.push(`quantity = $${paramIndex++}`)
      values.push(validatedData.quantity)
    }
    if (validatedData.date !== undefined) {
      updates.push(`date = $${paramIndex++}`)
      values.push(validatedData.date)
    }
    if (validatedData.priority !== undefined) {
      updates.push(`priority = $${paramIndex++}`)
      values.push(validatedData.priority)
    }
    if (validatedData.status !== undefined) {
      updates.push(`status = $${paramIndex++}`)
      values.push(validatedData.status)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(supplyId)

    const query = `
      UPDATE agency_supplies 
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `

    const result = await sql(query, values)

    if (result.length === 0) {
      logger.warn("Agency supply not found for update", { userId: user.id, supplyId })
      return NextResponse.json({ error: "Agency supply not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Agency supply updated successfully", { userId: user.id, supplyId, duration })

    return NextResponse.json({ supply: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error updating agency supply", { error, supplyId: params.id, duration })

    return NextResponse.json({ error: "Failed to update agency supply" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "supplies.delete")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const supplyId = Number.parseInt(params.id)

    if (isNaN(supplyId)) {
      return NextResponse.json({ error: "Invalid supply ID" }, { status: 400 })
    }

    logger.info("Deleting agency supply", { userId: user.id, supplyId })

    const result = await sql`
      DELETE FROM agency_supplies 
      WHERE id = ${supplyId}
      RETURNING id
    `

    if (result.length === 0) {
      logger.warn("Agency supply not found for deletion", { userId: user.id, supplyId })
      return NextResponse.json({ error: "Agency supply not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Agency supply deleted successfully", { userId: user.id, supplyId, duration })

    return NextResponse.json({
      message: "Agency supply deleted successfully",
      id: supplyId,
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error deleting agency supply", { error, supplyId: params.id, duration })

    return NextResponse.json({ error: "Failed to delete agency supply" }, { status: 500 })
  }
}
