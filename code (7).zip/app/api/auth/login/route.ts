/**
 * Login API Endpoint
 *
 * POST /api/auth/login
 *
 * Authenticates user credentials and returns JWT tokens.
 *
 * Security Features:
 * - Rate limiting (5 attempts per 15 minutes per IP)
 * - Password verification using bcrypt
 * - JWT token generation
 * - Secure error messages (no user enumeration)
 *
 * Request Body:
 * {
 *   username: string,
 *   password: string,
 *   company_code?: string
 * }
 *
 * Response:
 * {
 *   access_token: string,
 *   refresh_token: string,
 *   user: {
 *     id: string,
 *     username: string,
 *     email: string,
 *     role: string,
 *     full_name: string,
 *     company_id: string | null,
 *     company_code: string | null
 *   }
 * }
 */

import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { verifyPassword } from "@/lib/security/password"
import { generateToken, generateRefreshToken } from "@/lib/security/jwt"
import { loginRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import { getUserPermissions } from "@/lib/permissions"

export async function POST(request: NextRequest) {
  try {
    // Apply rate limiting
    const ip = getClientIp(request)
    const rateLimitResult = await loginRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many login attempts",
          message: "Please try again later",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
            "Retry-After": rateLimitResult.retryAfter?.toString() || "900",
          },
        },
      )
    }

    // Parse request body
    const body = await request.json()
    const { username, password, company_code } = body

    // Validate input
    if (!username || !password) {
      return NextResponse.json({ error: "Username and password are required" }, { status: 400 })
    }

    if (!sql) {
      // Mock data fallback for development
      return handleMockLogin(username, password, company_code)
    }

    let companyId = null
    let companyCode = null

    if (company_code) {
      const companies = await sql`
        SELECT id, url_code, is_active
        FROM companies
        WHERE url_code = ${company_code}
        LIMIT 1
      `

      const company = companies[0]

      if (!company) {
        return NextResponse.json({ error: "Company not found" }, { status: 404 })
      }

      if (!company.is_active) {
        return NextResponse.json({ error: "Company is not active" }, { status: 403 })
      }

      companyId = company.id
      companyCode = company.url_code
    }

    // Find user by username
    const userQuery = companyId
      ? sql`
          SELECT 
            u.id,
            u.username,
            u.email,
            u.password_hash,
            u.full_name,
            u.role,
            u.company_id,
            u.is_active
          FROM users u
          WHERE u.username = ${username} AND u.company_id = ${companyId}
          LIMIT 1
        `
      : sql`
          SELECT 
            u.id,
            u.username,
            u.email,
            u.password_hash,
            u.full_name,
            u.role,
            u.company_id,
            u.is_active
          FROM users u
          WHERE u.username = ${username}
          LIMIT 1
        `

    const users = await userQuery
    const user = users[0]

    // User not found or inactive
    if (!user || !user.is_active) {
      // Use generic error message to prevent user enumeration
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // Verify password
    const isValidPassword = await verifyPassword(password, user.password_hash)

    if (!isValidPassword) {
      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // Get user permissions
    const permissions = await getUserPermissions(user.id.toString())

    // Generate JWT tokens
    const tokenPayload = {
      userId: user.id.toString(),
      role: user.role,
      permissions: permissions.permissions,
      companyId: user.company_id,
      companyCode: companyCode || undefined,
    }

    const accessToken = await generateToken(tokenPayload)
    const refreshToken = await generateRefreshToken(tokenPayload)

    // Update last login timestamp
    await sql`
      UPDATE users
      SET last_login = NOW()
      WHERE id = ${user.id}
    `

    // Return success response
    return NextResponse.json({
      access_token: accessToken,
      refresh_token: refreshToken,
      user: {
        id: user.id.toString(),
        username: user.username,
        email: user.email,
        role: user.role,
        full_name: user.full_name,
        company_id: user.company_id,
        company_code: companyCode,
      },
    })
  } catch (error) {
    console.error("[v0] Login error:", error)
    return NextResponse.json({ error: "An error occurred during login" }, { status: 500 })
  }
}

/**
 * Mock login handler for development/demo
 */
async function handleMockLogin(username: string, password: string, company_code?: string) {
  console.warn("[v0] WARNING: Using mock authentication. This should only be used in development.")

  // Mock users for demo
  const mockUsers = [
    {
      id: "1",
      username: "admin",
      password: "password123",
      email: "admin@fleetpro.com",
      full_name: "Admin User",
      role: "admin",
      company_id: 1,
    },
    {
      id: "2",
      username: "manager",
      password: "password123",
      email: "manager@fleetpro.com",
      full_name: "Fleet Manager",
      role: "manager",
      company_id: 1,
    },
    {
      id: "3",
      username: "topowner",
      password: "mrtareq2008",
      email: "topowner@fleetpro.com",
      full_name: "Super Admin",
      role: "superadmin",
      company_id: null,
    },
  ]

  const user = mockUsers.find((u) => u.username === username && u.password === password)

  if (!user) {
    return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
  }

  // In production, this would use bcrypt.compare(password, user.passwordHash)
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json({ error: "Mock authentication not available in production" }, { status: 503 })
  }

  // Get permissions
  const permissions = await getUserPermissions(user.id)

  // Generate tokens
  const tokenPayload = {
    userId: user.id,
    role: user.role,
    permissions: permissions.permissions,
    companyId: user.company_id,
    companyCode: company_code,
  }

  const accessToken = await generateToken(tokenPayload)
  const refreshToken = await generateRefreshToken(tokenPayload)

  return NextResponse.json({
    access_token: accessToken,
    refresh_token: refreshToken,
    user: {
      id: user.id,
      username: user.username,
      email: user.email,
      role: user.role,
      full_name: user.full_name,
      company_id: user.company_id,
      company_code: company_code,
    },
  })
}
