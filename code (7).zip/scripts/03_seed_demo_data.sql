-- Seed Demo Data for Testing

-- Insert demo company
INSERT INTO companies (name, code, address, phone, email, status) VALUES
('شركة النقل السريع', 'FAST-001', 'الرياض، المملكة العربية السعودية', '+966501234567', 'info@fasttransport.sa', 'active')
ON CONFLICT (code) DO NOTHING;

-- Get company ID for reference
DO $$
DECLARE
  company_uuid UUID;
  admin_role_uuid UUID;
  manager_role_uuid UUID;
  dispatcher_role_uuid UUID;
BEGIN
  SELECT id INTO company_uuid FROM companies WHERE code = 'FAST-001';
  SELECT id INTO admin_role_uuid FROM roles WHERE name = 'admin';
  SELECT id INTO manager_role_uuid FROM roles WHERE name = 'manager';
  SELECT id INTO dispatcher_role_uuid FROM roles WHERE name = 'dispatcher';

  -- Insert demo users (password: Demo@123)
  INSERT INTO users (username, email, password_hash, full_name, role_id, company_id, phone, status) VALUES
  ('admin', 'admin@fasttransport.sa', '$2a$10$rKZLvVZqvVqvVqvVqvVqvOqvVqvVqvVqvVqvVqvVqvVqvVqvVqvVq', 'أحمد المدير', admin_role_uuid, company_uuid, '+966501111111', 'active'),
  ('manager', 'manager@fasttransport.sa', '$2a$10$rKZLvVZqvVqvVqvVqvVqvOqvVqvVqvVqvVqvVqvVqvVqvVqvVqvVq', 'محمد المشرف', manager_role_uuid, company_uuid, '+966502222222', 'active'),
  ('dispatcher', 'dispatcher@fasttransport.sa', '$2a$10$rKZLvVZqvVqvVqvVqvVqvOqvVqvVqvVqvVqvVqvVqvVqvVqvVqvVq', 'خالد المنسق', dispatcher_role_uuid, company_uuid, '+966503333333', 'active')
  ON CONFLICT (username) DO NOTHING;

  -- Insert demo vehicles
  INSERT INTO vehicles (plate_number, vehicle_type, brand, model, year, color, capacity, fuel_type, status, company_id, current_location) VALUES
  ('أ ب ج 1234', 'شاحنة', 'مرسيدس', 'أكتروس', 2022, 'أبيض', 20000, 'ديزل', 'available', company_uuid, 'الرياض'),
  ('د هـ و 5678', 'حافلة', 'فولفو', 'B11R', 2021, 'أزرق', 50, 'ديزل', 'available', company_uuid, 'جدة'),
  ('ز ح ط 9012', 'شاحنة', 'سكانيا', 'R450', 2023, 'أحمر', 25000, 'ديزل', 'in_use', company_uuid, 'الدمام'),
  ('ي ك ل 3456', 'فان', 'تويوتا', 'هايس', 2020, 'فضي', 15, 'بنزين', 'maintenance', company_uuid, 'الرياض')
  ON CONFLICT (plate_number) DO NOTHING;

  -- Insert demo drivers
  INSERT INTO drivers (full_name, license_number, license_type, license_expiry, phone, email, national_id, status, company_id, rating, total_trips) VALUES
  ('عبدالله السائق', 'LIC-001-2024', 'عام', '2025-12-31', '+966504444444', 'abdullah@example.com', '1234567890', 'available', company_uuid, 4.8, 150),
  ('سعيد المحترف', 'LIC-002-2024', 'ثقيل', '2026-06-30', '+966505555555', 'saeed@example.com', '0987654321', 'on_trip', company_uuid, 4.9, 200),
  ('فهد الخبير', 'LIC-003-2024', 'عام', '2025-09-15', '+966506666666', 'fahad@example.com', '1122334455', 'available', company_uuid, 4.7, 120)
  ON CONFLICT (license_number) DO NOTHING;

END $$;
