import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/api-auth"
import { createVehicleSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"
import { handleApiError, AppError } from "@/lib/api/error-handler"
import { executeQuery } from "@/lib/api/db-utils"
import { apiRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import { withCache, CACHE_TTL, invalidateCachePattern } from "@/lib/api/cache-utils"
import { getPaginationParams, getSearchParams, createPaginatedResponse } from "@/lib/api/pagination-utils"

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: { "Retry-After": "60" } },
      )
    }

    const authResult = await requirePermission(request, "vehicles.read")
    if (authResult instanceof Response) return authResult

    const { userId, role } = authResult

    const { page, limit, offset, sort, order } = getPaginationParams(request)
    const { search, status } = getSearchParams(request)

    logger.info("Fetching vehicles", { userId, role, page, limit, search, status })

    const cacheKey = `vehicles:list:${page}:${limit}:${search || "all"}:${status || "all"}:${sort || "default"}:${order}`

    const result = await withCache(
      cacheKey,
      async () => {
        const vehicles = await executeQuery(async (sql) => {
          let query = sql`
            SELECT 
              id, model, manufacture_date, plate_number, base_number,
              card_number, issue_date, expiry_date, status, company_id,
              created_at, updated_at
            FROM vehicles
            WHERE 1=1
          `

          if (search) {
            query = sql`${query} AND (
              model ILIKE ${"%" + search + "%"} OR
              plate_number ILIKE ${"%" + search + "%"} OR
              base_number ILIKE ${"%" + search + "%"}
            )`
          }

          if (status) {
            query = sql`${query} AND status = ${status}`
          }

          const sortColumn = sort || "created_at"
          const sortOrder = order === "asc" ? sql`ASC` : sql`DESC`
          query = sql`${query} ORDER BY ${sql(sortColumn)} ${sortOrder}`

          query = sql`${query} LIMIT ${limit} OFFSET ${offset}`

          return await query
        })

        const totalResult = await executeQuery(async (sql) => {
          let countQuery = sql`SELECT COUNT(*) as count FROM vehicles WHERE 1=1`

          if (search) {
            countQuery = sql`${countQuery} AND (
              model ILIKE ${"%" + search + "%"} OR
              plate_number ILIKE ${"%" + search + "%"} OR
              base_number ILIKE ${"%" + search + "%"}
            )`
          }

          if (status) {
            countQuery = sql`${countQuery} AND status = ${status}`
          }

          return await countQuery
        })

        const total = Number.parseInt(totalResult[0]?.count || "0", 10)

        return createPaginatedResponse(vehicles, page, limit, total)
      },
      CACHE_TTL.MEDIUM,
    )

    const duration = Date.now() - startTime
    logger.info("Vehicles fetched successfully", {
      userId,
      count: result.data.length,
      total: result.pagination.total,
      duration,
    })

    return NextResponse.json(result)
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Fetch vehicles", duration })
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: { "Retry-After": "60" } },
      )
    }

    const authResult = await requirePermission(request, "vehicles.create")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult

    let body
    try {
      body = await request.json()
    } catch {
      throw new AppError("Invalid JSON in request body", 400, "INVALID_JSON")
    }

    const validatedData = await validateOrRespond(createVehicleSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Creating new vehicle", {
      userId,
      vehicleModel: validatedData.model,
      plateNumber: validatedData.plate_number,
    })

    const duplicateExists = await executeQuery(async (sql) => {
      const result = await sql`
        SELECT EXISTS(
          SELECT 1 FROM vehicles 
          WHERE plate_number = ${validatedData.plate_number}
        ) as exists
      `
      return result[0]?.exists
    })

    if (duplicateExists) {
      throw new AppError("A vehicle with this plate number already exists", 409, "DUPLICATE_PLATE")
    }

    if (validatedData.issue_date && validatedData.expiry_date) {
      if (new Date(validatedData.expiry_date) <= new Date(validatedData.issue_date)) {
        throw new AppError("Expiry date must be after issue date", 400, "INVALID_DATE_RANGE")
      }
    }

    const vehicle = await executeQuery(async (sql) => {
      const result = await sql`
        INSERT INTO vehicles (
          model, manufacture_date, plate_number, base_number, card_number,
          issue_date, expiry_date, status, company_id, created_at, updated_at
        ) VALUES (
          ${validatedData.model}, ${validatedData.manufacture_date}, ${validatedData.plate_number},
          ${validatedData.base_number || null}, ${validatedData.card_number || null},
          ${validatedData.issue_date || null}, ${validatedData.expiry_date || null},
          ${validatedData.status}, ${validatedData.company_id || null}, NOW(), NOW()
        )
        RETURNING *
      `
      return result[0]
    })

    await invalidateCachePattern("vehicles:*")

    const duration = Date.now() - startTime

    logger.info("Vehicle created successfully", {
      userId,
      vehicleId: vehicle.id,
      duration,
    })

    return NextResponse.json(
      { vehicle, message: "Vehicle created successfully" },
      { status: 201, headers: { Location: `/api/vehicles/${vehicle.id}` } },
    )
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Create vehicle", duration })
  }
}
