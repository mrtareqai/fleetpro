// Mock data for demo mode (no backend required)

export interface User {
  id: number
  username: string
  email: string
  password: string
  role: string
  full_name: string
  company_id?: number // Added company_id for multi-tenancy
}

export interface Vehicle {
  id: number
  model: string
  manufacture_date: string
  plate_number: string
  base_number: string
  card_number: string
  issue_date: string
  expiry_date: string
  status: "active" | "inactive" | "expired"
}

export interface Driver {
  id: number
  name: string
  license_number: string
  phone: string
  status: string
}

export interface Reservation {
  id: number
  vehicle_id: number
  driver_id: number
  start_date: string
  end_date: string
  status: string
  purpose: string
}

export interface Ticket {
  id: number
  passenger_name: string
  trip_number: string
  trip_name: string
  trip_date: string
  ticket_number: string
  trip_time: string
  seat_number: string
  mobile_number: string
  issue_date: string
  user: string
  branch: string
  status: "confirmed" | "pending" | "cancelled"
}

export interface Movement {
  id: number
  driver_name: string
  assistant_name: string
  bus_number: string
  trip_name: string
  trip_date: string
  trip_time: string
  seats: number
  pending_seats: number
  status: "scheduled" | "in-progress" | "completed" | "cancelled"
}

export interface Company {
  id: number
  name: string
  owner_name: string
  contact_number: string
  email: string
  neon_url: string
  github_api_key: string
  admin_username: string
  admin_password: string
  is_active: boolean
  created_at: string
}

export interface Supply {
  id: number
  item_name: string
  category: string
  quantity: number
  unit: string
  supplier: string
  purchase_date: string
  expiry_date: string
  status: "available" | "low-stock" | "out-of-stock"
}

// Mock users
export const mockUsers: User[] = [
  {
    id: 0,
    username: "topowner",
    email: "topowner@fleetpro.com",
    password: "mrtareq2008",
    role: "superadmin",
    full_name: "Top Owner",
  },
  {
    id: 1,
    username: "admin",
    email: "admin@fleetpro.com",
    password: "password123",
    role: "admin",
    full_name: "Admin User",
    company_id: 1, // Linked to demo company
  },
  {
    id: 2,
    username: "manager",
    email: "manager@fleetpro.com",
    password: "password123",
    role: "manager",
    full_name: "Fleet Manager",
    company_id: 1,
  },
  {
    id: 3,
    username: "user1",
    email: "user1@fleetpro.com",
    password: "password123",
    role: "user",
    full_name: "Regular User",
    company_id: 1,
  },
]

// Mock vehicles
export const mockVehicles: Vehicle[] = [
  {
    id: 1,
    model: "تويوتا كوستر 2023",
    manufacture_date: "2023-01-15",
    plate_number: "أ ب ج 1234",
    base_number: "BS-001",
    card_number: "CARD-001",
    issue_date: "2023-02-01",
    expiry_date: "2025-12-31",
    status: "active",
  },
  {
    id: 2,
    model: "هيونداي يونيفرس 2022",
    manufacture_date: "2022-06-20",
    plate_number: "س ص ع 5678",
    base_number: "BS-002",
    card_number: "CARD-002",
    issue_date: "2022-07-15",
    expiry_date: "2025-06-30",
    status: "active",
  },
  {
    id: 3,
    model: "مرسيدس سبرنتر 2021",
    manufacture_date: "2021-03-10",
    plate_number: "ن ه و 9012",
    base_number: "BS-003",
    card_number: "CARD-003",
    issue_date: "2021-04-05",
    expiry_date: "2024-12-31",
    status: "inactive",
  },
  {
    id: 4,
    model: "كينج لونج 2020",
    manufacture_date: "2020-09-05",
    plate_number: "ل م ك 3456",
    base_number: "BS-004",
    card_number: "CARD-004",
    issue_date: "2020-10-01",
    expiry_date: "2024-01-15",
    status: "expired",
  },
  {
    id: 5,
    model: "يوتونج 2023",
    manufacture_date: "2023-05-12",
    plate_number: "ر ز ط 7890",
    base_number: "BS-005",
    card_number: "CARD-005",
    issue_date: "2023-06-01",
    expiry_date: "2026-05-31",
    status: "active",
  },
]

// Mock drivers
export const mockDrivers: Driver[] = [
  {
    id: 1,
    name: "John Smith",
    license_number: "DL-12345",
    phone: "+1-555-0101",
    status: "active",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    license_number: "DL-67890",
    phone: "+1-555-0102",
    status: "active",
  },
  {
    id: 3,
    name: "Michael Brown",
    license_number: "DL-11223",
    phone: "+1-555-0103",
    status: "inactive",
  },
]

// Mock reservations
export const mockReservations: Reservation[] = [
  {
    id: 1,
    vehicle_id: 1,
    driver_id: 1,
    start_date: "2025-01-15",
    end_date: "2025-01-20",
    status: "active",
    purpose: "Business trip to New York",
  },
  {
    id: 2,
    vehicle_id: 2,
    driver_id: 2,
    start_date: "2025-01-18",
    end_date: "2025-01-22",
    status: "active",
    purpose: "Client meeting in Boston",
  },
  {
    id: 3,
    vehicle_id: 5,
    driver_id: 1,
    start_date: "2025-01-25",
    end_date: "2025-01-28",
    status: "upcoming",
    purpose: "Conference attendance",
  },
]

// Mock tickets
export const mockTickets: Ticket[] = [
  {
    id: 1,
    passenger_name: "أحمد محمد علي",
    trip_number: "TR-001",
    trip_name: "الرياض - جدة",
    trip_date: "2025-01-15",
    ticket_number: "TK-10001",
    trip_time: "08:00",
    seat_number: "A12",
    mobile_number: "+966501234567",
    issue_date: "2025-01-10",
    user: "محمد السالم",
    branch: "الرياض الرئيسي",
    status: "confirmed",
  },
  {
    id: 2,
    passenger_name: "فاطمة عبدالله",
    trip_number: "TR-002",
    trip_name: "جدة - مكة",
    trip_date: "2025-01-15",
    ticket_number: "TK-10002",
    trip_time: "10:30",
    seat_number: "B05",
    mobile_number: "+966502345678",
    issue_date: "2025-01-11",
    user: "خالد أحمد",
    branch: "جدة",
    status: "confirmed",
  },
  {
    id: 3,
    passenger_name: "عبدالرحمن سعيد",
    trip_number: "TR-003",
    trip_name: "الدمام - الرياض",
    trip_date: "2025-01-16",
    ticket_number: "TK-10003",
    trip_time: "06:00",
    seat_number: "C08",
    mobile_number: "+966503456789",
    issue_date: "2025-01-12",
    user: "سارة محمد",
    branch: "الدمام",
    status: "pending",
  },
  {
    id: 4,
    passenger_name: "نورة خالد",
    trip_number: "TR-004",
    trip_name: "الرياض - الدمام",
    trip_date: "2025-01-16",
    ticket_number: "TK-10004",
    trip_time: "14:00",
    seat_number: "A15",
    mobile_number: "+966504567890",
    issue_date: "2025-01-13",
    user: "عمر فيصل",
    branch: "الرياض الرئيسي",
    status: "confirmed",
  },
  {
    id: 5,
    passenger_name: "يوسف إبراهيم",
    trip_number: "TR-005",
    trip_name: "مكة - المدينة",
    trip_date: "2025-01-14",
    ticket_number: "TK-10005",
    trip_time: "16:00",
    seat_number: "D20",
    mobile_number: "+966505678901",
    issue_date: "2025-01-09",
    user: "ليلى حسن",
    branch: "مكة",
    status: "cancelled",
  },
]

export const mockMovements: Movement[] = [
  {
    id: 1,
    driver_name: "أحمد محمد",
    assistant_name: "خالد علي",
    bus_number: "101",
    trip_name: "الرياض - جدة",
    trip_date: "2025-01-15",
    trip_time: "08:00",
    seats: 45,
    pending_seats: 5,
    status: "scheduled",
  },
  {
    id: 2,
    driver_name: "محمد عبدالله",
    assistant_name: "سعيد حسن",
    bus_number: "102",
    trip_name: "جدة - مكة",
    trip_date: "2025-01-15",
    trip_time: "10:30",
    seats: 50,
    pending_seats: 0,
    status: "in-progress",
  },
  {
    id: 3,
    driver_name: "عبدالرحمن سالم",
    assistant_name: "فهد عمر",
    bus_number: "103",
    trip_name: "الدمام - الرياض",
    trip_date: "2025-01-16",
    trip_time: "06:00",
    seats: 40,
    pending_seats: 8,
    status: "scheduled",
  },
  {
    id: 4,
    driver_name: "يوسف إبراهيم",
    assistant_name: "ماجد فيصل",
    bus_number: "104",
    trip_name: "الرياض - الدمام",
    trip_date: "2025-01-16",
    trip_time: "14:00",
    seats: 45,
    pending_seats: 12,
    status: "scheduled",
  },
  {
    id: 5,
    driver_name: "عمر خالد",
    assistant_name: "طارق محمود",
    bus_number: "105",
    trip_name: "مكة - المدينة",
    trip_date: "2025-01-14",
    trip_time: "16:00",
    seats: 50,
    pending_seats: 0,
    status: "completed",
  },
]

// Mock companies
export const mockCompanies: Company[] = [
  {
    id: 1,
    name: "Demo Company",
    owner_name: "John Doe",
    contact_number: "+1-555-0000",
    email: "contact@democompany.com",
    neon_url: "https://neon.democompany.com",
    github_api_key: "abcdef123456",
    admin_username: "admin",
    admin_password: "adminpass",
    is_active: true,
    created_at: "2023-01-01",
  },
]

export const mockSupplies: Supply[] = [
  {
    id: 1,
    item_name: "زيت المحرك",
    category: "صيانة",
    quantity: 50,
    unit: "لتر",
    supplier: "شركة الزيوت المتحدة",
    purchase_date: "2025-01-10",
    expiry_date: "2026-01-10",
    status: "available",
  },
  {
    id: 2,
    item_name: "فلاتر الهواء",
    category: "قطع غيار",
    quantity: 15,
    unit: "قطعة",
    supplier: "مؤسسة القطع الأصلية",
    purchase_date: "2025-01-08",
    expiry_date: "2027-01-08",
    status: "available",
  },
  {
    id: 3,
    item_name: "إطارات",
    category: "قطع غيار",
    quantity: 8,
    unit: "قطعة",
    supplier: "شركة الإطارات الوطنية",
    purchase_date: "2024-12-20",
    expiry_date: "2029-12-20",
    status: "low-stock",
  },
  {
    id: 4,
    item_name: "سائل التبريد",
    category: "صيانة",
    quantity: 0,
    unit: "لتر",
    supplier: "شركة الكيماويات",
    purchase_date: "2024-11-15",
    expiry_date: "2025-11-15",
    status: "out-of-stock",
  },
]

// Helper functions to simulate API delays
export const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Mock localStorage-based data persistence
export class MockDataStore {
  private static STORAGE_KEY = "fleetpro_mock_data"

  static getData() {
    if (typeof window === "undefined") return null
    const data = localStorage.getItem(this.STORAGE_KEY)
    return data ? JSON.parse(data) : null
  }

  static setData(data: any) {
    if (typeof window === "undefined") return
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data))
  }

  static initializeData() {
    const existing = this.getData()
    if (!existing) {
      this.setData({
        vehicles: mockVehicles,
        drivers: mockDrivers,
        reservations: mockReservations,
        tickets: mockTickets,
        movements: mockMovements,
        companies: mockCompanies,
        supplies: mockSupplies, // Added supplies to initial data
      })
    }
  }

  static getVehicles(): Vehicle[] {
    const data = this.getData()
    return data?.vehicles || mockVehicles
  }

  static getDrivers(): Driver[] {
    const data = this.getData()
    return data?.drivers || mockDrivers
  }

  static getReservations(): Reservation[] {
    const data = this.getData()
    return data?.reservations || mockReservations
  }

  static getTickets(): Ticket[] {
    const data = this.getData()
    return data?.tickets || mockTickets
  }

  static getMovements(): Movement[] {
    const data = this.getData()
    return data?.movements || mockMovements
  }

  static getCompanies(): Company[] {
    const data = this.getData()
    return data?.companies || mockCompanies
  }

  static getSupplies(): Supply[] {
    const data = this.getData()
    return data?.supplies || mockSupplies
  }

  static addVehicle(vehicle: Vehicle) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.vehicles.push(vehicle)
    this.setData(data)
  }

  static updateVehicle(id: number, updates: Partial<Vehicle>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    const index = data.vehicles.findIndex((v: Vehicle) => v.id === id)
    if (index !== -1) {
      data.vehicles[index] = { ...data.vehicles[index], ...updates }
      this.setData(data)
    }
  }

  static deleteVehicle(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.vehicles = data.vehicles.filter((v: Vehicle) => v.id !== id)
    this.setData(data)
  }

  static addTicket(ticket: Ticket) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.tickets.push(ticket)
    this.setData(data)
  }

  static updateTicket(id: number, updates: Partial<Ticket>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    const index = data.tickets.findIndex((t: Ticket) => t.id === id)
    if (index !== -1) {
      data.tickets[index] = { ...data.tickets[index], ...updates }
      this.setData(data)
    }
  }

  static deleteTicket(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.tickets = data.tickets.filter((t: Ticket) => t.id !== id)
    this.setData(data)
  }

  static addDriver(driver: Driver) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.drivers.push(driver)
    this.setData(data)
  }

  static updateDriver(id: number, updates: Partial<Driver>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    const index = data.drivers.findIndex((d: Driver) => d.id === id)
    if (index !== -1) {
      data.drivers[index] = { ...data.drivers[index], ...updates }
      this.setData(data)
    }
  }

  static deleteDriver(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.drivers = data.drivers.filter((d: Driver) => d.id !== id)
    this.setData(data)
  }

  static addMovement(movement: Movement) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.movements.push(movement)
    this.setData(data)
  }

  static updateMovement(id: number, updates: Partial<Movement>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    const index = data.movements.findIndex((m: Movement) => m.id === id)
    if (index !== -1) {
      data.movements[index] = { ...data.movements[index], ...updates }
      this.setData(data)
    }
  }

  static deleteMovement(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.movements = data.movements.filter((m: Movement) => m.id !== id)
    this.setData(data)
  }

  static addCompany(company: Company) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.companies.push(company)
    this.setData(data)
  }

  static updateCompany(id: number, updates: Partial<Company>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    const index = data.companies.findIndex((c: Company) => c.id === id)
    if (index !== -1) {
      data.companies[index] = { ...data.companies[index], ...updates }
      this.setData(data)
    }
  }

  static deleteCompany(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.companies = data.companies.filter((c: Company) => c.id !== id)
    this.setData(data)
  }

  static addReservation(reservation: Reservation) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.reservations.push(reservation)
    this.setData(data)
  }

  static updateReservation(id: number, updates: Partial<Reservation>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    const index = data.reservations.findIndex((r: Reservation) => r.id === id)
    if (index !== -1) {
      data.reservations[index] = { ...data.reservations[index], ...updates }
      this.setData(data)
    }
  }

  static deleteReservation(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    data.reservations = data.reservations.filter((r: Reservation) => r.id !== id)
    this.setData(data)
  }

  static addSupply(supply: Supply) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    if (!data.supplies) {
      data.supplies = []
    }
    data.supplies.push(supply)
    this.setData(data)
  }

  static updateSupply(id: number, updates: Partial<Supply>) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    if (!data.supplies) {
      data.supplies = []
    }
    const index = data.supplies.findIndex((s: Supply) => s.id === id)
    if (index !== -1) {
      data.supplies[index] = { ...data.supplies[index], ...updates }
      this.setData(data)
    }
  }

  static deleteSupply(id: number) {
    const data = this.getData() || {
      vehicles: [],
      drivers: [],
      reservations: [],
      tickets: [],
      movements: [],
      companies: [],
      supplies: [],
    }
    if (!data.supplies) {
      data.supplies = []
    }
    data.supplies = data.supplies.filter((s: Supply) => s.id !== id)
    this.setData(data)
  }
}
