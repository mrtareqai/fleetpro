import {
  requireAuth as newRequireAuth,
  requirePermission as newRequirePermission,
  requireAnyPermission as newRequireAnyPermission,
  requireRole,
  type AuthenticatedRequest,
} from "./security/api-auth"

/**
 * DEPRECATED: This file is kept for backward compatibility
 *
 * Please use the new security modules:
 * - @/lib/security/api-auth for authentication
 * - @/lib/security/jwt for token management
 * - @/lib/security/password for password hashing
 * - @/lib/security/rate-limit for rate limiting
 *
 * Migration guide:
 *
 * Old:
 * import { requireAuth } from '@/lib/api-auth'
 *
 * New:
 * import { requireAuth } from '@/lib/security/api-auth'
 */

// Re-export new functions for backward compatibility
export {
  newRequireAuth as requireAuth,
  newRequirePermission as requirePermission,
  newRequireAnyPermission as requireAnyPermission,
  requireRole,
  type AuthenticatedRequest,
}

// Keep old function for backward compatibility
export function getUserIdFromRequest(request: any): string | null {
  console.warn("[v0] getUserIdFromRequest is deprecated. Use requireAuth instead.")
  const userId = request.headers.get("x-user-id")
  return userId
}
