"use client"

import { useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { AlertTriangle } from "lucide-react"

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // Next.js redirects throw special errors that shouldn't be logged as actual errors
    if (error.message !== "NEXT_REDIRECT") {
      console.error("[v0] Application error:", error)
    }
  }, [error])

  if (error.message === "NEXT_REDIRECT") {
    return null
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            <CardTitle>حدث خطأ</CardTitle>
          </div>
          <CardDescription>عذراً، حدث خطأ غير متوقع في التطبيق</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">
            {error.message || "حدث خطأ أثناء معالجة طلبك. يرجى المحاولة مرة أخرى."}
          </p>
          {error.digest && (
            <p className="mt-2 text-xs text-muted-foreground">
              معرف الخطأ: <code className="rounded bg-muted px-1 py-0.5">{error.digest}</code>
            </p>
          )}
        </CardContent>
        <CardFooter className="flex gap-2">
          <Button onClick={reset} className="flex-1">
            حاول مرة أخرى
          </Button>
          <Button variant="outline" onClick={() => (window.location.href = "/")} className="flex-1">
            العودة للرئيسية
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}
