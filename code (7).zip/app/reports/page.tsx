import DashboardLayout from "@/components/dashboard-layout"
import ReportsView from "@/components/reports-view"

export default function ReportsPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="reports">
      <ReportsView locale={locale} />
    </DashboardLayout>
  )
}
