/**
 * Validation Schemas Unit Tests
 */

import { describe, it, expect } from "@jest/globals"
import {
  createUserSchema,
  createDriverSchema,
  createVehicleSchema,
  createReservationSchema,
  loginSchema,
  paginationSchema,
} from "@/lib/validation/schemas"

describe("Validation Schemas", () => {
  describe("createUserSchema", () => {
    it("should validate correct user data", () => {
      const validUser = {
        username: "testuser",
        email: "test@example.com",
        password: "StrongPass123!",
        full_name: "Test User",
        role: "admin",
      }

      const result = createUserSchema.safeParse(validUser)
      expect(result.success).toBe(true)
    })

    it("should reject invalid email", () => {
      const invalidUser = {
        username: "testuser",
        email: "invalid-email",
        password: "StrongPass123!",
        full_name: "Test User",
        role: "admin",
      }

      const result = createUserSchema.safeParse(invalidUser)
      expect(result.success).toBe(false)
    })

    it("should reject weak password", () => {
      const invalidUser = {
        username: "testuser",
        email: "test@example.com",
        password: "weak",
        full_name: "Test User",
        role: "admin",
      }

      const result = createUserSchema.safeParse(invalidUser)
      expect(result.success).toBe(false)
    })

    it("should reject short username", () => {
      const invalidUser = {
        username: "ab",
        email: "test@example.com",
        password: "StrongPass123!",
        full_name: "Test User",
        role: "admin",
      }

      const result = createUserSchema.safeParse(invalidUser)
      expect(result.success).toBe(false)
    })
  })

  describe("createDriverSchema", () => {
    it("should validate correct driver data", () => {
      const validDriver = {
        name: "John Doe",
        license_number: "DL-12345",
        phone: "+1234567890",
        status: "active",
      }

      const result = createDriverSchema.safeParse(validDriver)
      expect(result.success).toBe(true)
    })

    it("should reject missing required fields", () => {
      const invalidDriver = {
        name: "John Doe",
      }

      const result = createDriverSchema.safeParse(invalidDriver)
      expect(result.success).toBe(false)
    })
  })

  describe("createVehicleSchema", () => {
    it("should validate correct vehicle data", () => {
      const validVehicle = {
        model: "Toyota Coaster",
        manufacture_date: "2023-01-15",
        plate_number: "ABC-1234",
        status: "active",
      }

      const result = createVehicleSchema.safeParse(validVehicle)
      expect(result.success).toBe(true)
    })

    it("should reject invalid date format", () => {
      const invalidVehicle = {
        model: "Toyota Coaster",
        manufacture_date: "15/01/2023",
        plate_number: "ABC-1234",
        status: "active",
      }

      const result = createVehicleSchema.safeParse(invalidVehicle)
      expect(result.success).toBe(false)
    })
  })

  describe("createReservationSchema", () => {
    it("should validate correct reservation data", () => {
      const validReservation = {
        vehicle_id: 1,
        driver_id: 1,
        start_date: "2025-01-15",
        end_date: "2025-01-20",
        purpose: "Business trip",
        status: "pending",
      }

      const result = createReservationSchema.safeParse(validReservation)
      expect(result.success).toBe(true)
    })

    it("should reject end date before start date", () => {
      const invalidReservation = {
        vehicle_id: 1,
        driver_id: 1,
        start_date: "2025-01-20",
        end_date: "2025-01-15",
        purpose: "Business trip",
        status: "pending",
      }

      const result = createReservationSchema.safeParse(invalidReservation)
      expect(result.success).toBe(false)
    })
  })

  describe("loginSchema", () => {
    it("should validate correct login data", () => {
      const validLogin = {
        username: "testuser",
        password: "password123",
      }

      const result = loginSchema.safeParse(validLogin)
      expect(result.success).toBe(true)
    })

    it("should reject missing fields", () => {
      const invalidLogin = {
        username: "testuser",
      }

      const result = loginSchema.safeParse(invalidLogin)
      expect(result.success).toBe(false)
    })
  })

  describe("paginationSchema", () => {
    it("should validate and set defaults", () => {
      const result = paginationSchema.safeParse({})

      expect(result.success).toBe(true)
      if (result.success) {
        expect(result.data.page).toBe(1)
        expect(result.data.limit).toBe(20)
        expect(result.data.order).toBe("desc")
      }
    })

    it("should coerce string numbers to integers", () => {
      const result = paginationSchema.safeParse({ page: "2", limit: "50" })

      expect(result.success).toBe(true)
      if (result.success) {
        expect(result.data.page).toBe(2)
        expect(result.data.limit).toBe(50)
      }
    })

    it("should reject limit over 100", () => {
      const result = paginationSchema.safeParse({ limit: 150 })
      expect(result.success).toBe(false)
    })
  })
})
