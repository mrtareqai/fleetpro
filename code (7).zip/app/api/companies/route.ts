import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { adminRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import { requirePermission } from "@/lib/security/api-auth"

export async function GET(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const rateLimitResult = await adminRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "companies.read")
    if (authResult instanceof Response) return authResult

    if (!sql) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const { role, companyId } = authResult

    let companies
    if (role === "admin" || role === "super_admin") {
      // Admins can see all companies
      companies = await sql`
        SELECT 
          id,
          name,
          url_code,
          owner_name,
          contact_number,
          email,
          neon_url,
          github_api_key,
          admin_username,
          is_active,
          created_at,
          updated_at
        FROM companies
        ORDER BY created_at DESC
      `
    } else {
      // Regular users can only see their own company
      companies = await sql`
        SELECT 
          id,
          name,
          url_code,
          owner_name,
          contact_number,
          email,
          is_active,
          created_at,
          updated_at
        FROM companies
        WHERE id = ${companyId}
      `
    }

    const response = NextResponse.json(companies)

    response.headers.set("X-RateLimit-Limit", rateLimitResult.limit.toString())
    response.headers.set("X-RateLimit-Remaining", rateLimitResult.remaining.toString())
    response.headers.set("X-RateLimit-Reset", new Date(rateLimitResult.reset).toISOString())

    return response
  } catch (error) {
    console.error("[v0] Error fetching companies:", error)
    return NextResponse.json({ error: "Failed to fetch companies" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const ip = getClientIp(request)
    const rateLimitResult = await adminRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "companies.create")
    if (authResult instanceof Response) return authResult

    if (authResult.role !== "super_admin") {
      return NextResponse.json({ error: "Only super administrators can create companies" }, { status: 403 })
    }

    if (!sql) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const body = await request.json()
    const {
      name,
      url_code,
      owner_name,
      contact_number,
      email,
      neon_url,
      github_api_key,
      admin_username,
      admin_password,
      is_active = true,
    } = body

    // Validate required fields
    if (!name || !url_code || !owner_name || !email || !admin_username || !admin_password) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if url_code already exists
    const existing = await sql`
      SELECT id FROM companies WHERE url_code = ${url_code}
    `

    if (existing.length > 0) {
      return NextResponse.json({ error: "URL code already exists" }, { status: 400 })
    }

    // Insert new company
    const result = await sql`
      INSERT INTO companies (
        name,
        url_code,
        owner_name,
        contact_number,
        email,
        neon_url,
        github_api_key,
        admin_username,
        admin_password,
        is_active,
        created_at,
        updated_at
      ) VALUES (
        ${name},
        ${url_code},
        ${owner_name},
        ${contact_number},
        ${email},
        ${neon_url || null},
        ${github_api_key || null},
        ${admin_username},
        ${admin_password},
        ${is_active},
        NOW(),
        NOW()
      )
      RETURNING *
    `

    const response = NextResponse.json(result[0], { status: 201 })

    response.headers.set("X-RateLimit-Limit", rateLimitResult.limit.toString())
    response.headers.set("X-RateLimit-Remaining", rateLimitResult.remaining.toString())
    response.headers.set("X-RateLimit-Reset", new Date(rateLimitResult.reset).toISOString())

    return response
  } catch (error) {
    console.error("[v0] Error creating company:", error)
    return NextResponse.json({ error: "Failed to create company" }, { status: 500 })
  }
}
