// Permission checking utilities

import { sql } from "@/lib/db"

export interface UserPermissions {
  userId: string
  permissions: string[]
  roles: string[]
}

/**
 * Get all permissions for a user based on their roles
 */
export async function getUserPermissions(userId: string): Promise<UserPermissions> {
  try {
    console.log("[v0] getUserPermissions called for userId:", userId)

    if (!sql) {
      console.log("[v0] Database not available, using mock permissions")
      // Mock permissions for demo mode (when database is not available)
      return getMockPermissions(userId)
    }

    console.log("[v0] Querying database for user permissions")
    // Get user's roles and permissions from database
    const result = await sql`
      SELECT DISTINCT
        p.name as permission_name,
        r.name as role_name
      FROM users u
      JOIN user_roles ur ON u.id = ur.user_id
      JOIN roles r ON ur.role_id = r.id
      JOIN role_permissions rp ON r.id = rp.role_id
      JOIN permissions p ON rp.permission_id = p.id
      WHERE u.id = ${userId}
    `

    console.log("[v0] Database query returned", result.length, "rows")
    const permissions = [...new Set(result.map((row: any) => row.permission_name))]
    const roles = [...new Set(result.map((row: any) => row.role_name))]

    console.log("[v0] User permissions:", permissions)
    console.log("[v0] User roles:", roles)

    return {
      userId,
      permissions,
      roles,
    }
  } catch (error) {
    console.error("[v0] Error in getUserPermissions:", error)
    console.log("[v0] Falling back to mock permissions")
    return getMockPermissions(userId)
  }
}

/**
 * Get mock permissions for demo mode
 * This is used when database is not available
 */
function getMockPermissions(userId: string): UserPermissions {
  // Default mock permissions based on userId
  // In production, this should never be called
  const mockPermissionsMap: Record<string, UserPermissions> = {
    "1": {
      userId: "1",
      permissions: ["*"], // Admin gets all permissions
      roles: ["admin"],
    },
    "2": {
      userId: "2",
      permissions: [
        "vehicles.read",
        "vehicles.create",
        "vehicles.update",
        "drivers.read",
        "drivers.create",
        "drivers.update",
        "reservations.read",
        "reservations.create",
        "reservations.update",
        "dashboard.view",
      ],
      roles: ["fleet_manager"],
    },
    "3": {
      userId: "3",
      permissions: ["*"], // Super admin gets all permissions
      roles: ["superadmin"],
    },
  }

  return (
    mockPermissionsMap[userId] || {
      userId,
      permissions: ["vehicles.read", "drivers.read", "reservations.read", "tickets.read", "dashboard.view"],
      roles: ["viewer"],
    }
  )
}

/**
 * Check if user has a specific permission
 */
export function hasPermission(userPermissions: UserPermissions, permission: string): boolean {
  // Check for wildcard (super admin)
  if (userPermissions.permissions.includes("*")) {
    return true
  }

  // Check for exact permission match
  if (userPermissions.permissions.includes(permission)) {
    return true
  }

  // Check for resource-level wildcard (e.g., "vehicles.*")
  const [resource] = permission.split(".")
  if (userPermissions.permissions.includes(`${resource}.*`)) {
    return true
  }

  return false
}

/**
 * Check if user has any of the specified permissions
 */
export function hasAnyPermission(userPermissions: UserPermissions, permissions: string[]): boolean {
  return permissions.some((permission) => hasPermission(userPermissions, permission))
}

/**
 * Check if user has all of the specified permissions
 */
export function hasAllPermissions(userPermissions: UserPermissions, permissions: string[]): boolean {
  return permissions.every((permission) => hasPermission(userPermissions, permission))
}

/**
 * Check if user has a specific role
 */
export function hasRole(userPermissions: UserPermissions, role: string): boolean {
  return userPermissions.roles.includes(role)
}

/**
 * Check if user has any of the specified roles
 */
export function hasAnyRole(userPermissions: UserPermissions, roles: string[]): boolean {
  return roles.some((role) => hasRole(userPermissions, role))
}

export const TRANSACTION_PERMISSIONS = {
  READ: "transactions.read",
  CREATE: "transactions.create",
  UPDATE: "transactions.update",
  APPROVE: "transactions.approve",
  REJECT: "transactions.reject",
  DELETE: "transactions.delete",
  EXPORT: "transactions.export",
} as const

export const ROLE_TRANSACTION_PERMISSIONS: Record<string, string[]> = {
  super_admin: ["*"],
  admin: ["transactions.*"],
  fleet_manager: [
    TRANSACTION_PERMISSIONS.READ,
    TRANSACTION_PERMISSIONS.CREATE,
    TRANSACTION_PERMISSIONS.UPDATE,
    TRANSACTION_PERMISSIONS.EXPORT,
  ],
  dispatcher: [TRANSACTION_PERMISSIONS.READ, TRANSACTION_PERMISSIONS.CREATE],
  maintenance_staff: [TRANSACTION_PERMISSIONS.READ],
  viewer: [TRANSACTION_PERMISSIONS.READ],
}
