import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "reports.read")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Generating driver performance report...")

    const { searchParams } = new URL(request.url)
    const startDate = searchParams.get("start_date") || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
    const endDate = searchParams.get("end_date") || new Date().toISOString()

    if (!sql) {
      return getMockDriverPerformance()
    }

    const performance = await sql`
      SELECT 
        d.id,
        d.name,
        d.license_number,
        COUNT(DISTINCT r.id) as total_reservations,
        COUNT(DISTINCT m.id) as total_trips,
        d.status
      FROM drivers d
      LEFT JOIN reservations r ON r.driver_id = d.id 
        AND r.start_date >= ${startDate}
        AND r.start_date <= ${endDate}
      LEFT JOIN movements m ON m.driver_name = d.name
        AND m.trip_date >= ${startDate}
        AND m.trip_date <= ${endDate}
      GROUP BY d.id, d.name, d.license_number, d.status
      ORDER BY total_reservations DESC, total_trips DESC
    `

    const report = {
      period: { start: startDate, end: endDate },
      drivers: performance.map((row, index) => ({
        rank: index + 1,
        id: row.id,
        name: row.name,
        licenseNumber: row.license_number,
        totalReservations: Number(row.total_reservations),
        totalTrips: Number(row.total_trips),
        status: row.status,
        score: Number(row.total_reservations) * 2 + Number(row.total_trips) * 3,
      })),
    }

    console.log("[v0] Driver performance report generated")

    return NextResponse.json(report, {
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("[v0] Error generating driver performance report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

function getMockDriverPerformance() {
  console.log("[v0] Using mock driver performance data")

  const drivers = [
    { name: "Ahmed Ali", totalReservations: 45, totalTrips: 120 },
    { name: "Mohammed Hassan", totalReservations: 38, totalTrips: 95 },
    { name: "Khalid Ibrahim", totalReservations: 35, totalTrips: 88 },
    { name: "Omar Saeed", totalReservations: 32, totalTrips: 82 },
    { name: "Ali Mohammed", totalReservations: 28, totalTrips: 75 },
  ]

  return NextResponse.json({
    period: {
      start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
      end: new Date().toISOString().split("T")[0],
    },
    drivers: drivers.map((driver, index) => ({
      rank: index + 1,
      id: index + 1,
      name: driver.name,
      licenseNumber: `DL-${1000 + index}`,
      totalReservations: driver.totalReservations,
      totalTrips: driver.totalTrips,
      status: "active",
      score: driver.totalReservations * 2 + driver.totalTrips * 3,
    })),
  })
}
