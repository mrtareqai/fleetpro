/**
 * Integration Tests for Rate Limiting
 *
 * These tests verify rate limiting works correctly across the application
 */

import { describe, it, expect, beforeEach } from "@jest/globals"
import { createRateLimiter, loginRateLimiter, getClientIp } from "@/lib/security/rate-limit"

describe("Rate Limiting Integration Tests", () => {
  describe("Login Endpoint", () => {
    beforeEach(() => {
      // Reset rate limiter before each test
      loginRateLimiter.reset("test-ip")
    })

    it("should allow 5 login attempts", async () => {
      for (let i = 0; i < 5; i++) {
        const response = await fetch("http://localhost:3000/api/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-real-ip": "test-ip",
          },
          body: JSON.stringify({
            username: "admin",
            password: "wrong",
          }),
        })

        expect(response.status).toBe(401) // Wrong password, not rate limited
        expect(response.headers.get("X-RateLimit-Remaining")).toBe((4 - i).toString())
      }
    })

    it("should block 6th login attempt", async () => {
      // Make 5 failed attempts
      for (let i = 0; i < 5; i++) {
        await fetch("http://localhost:3000/api/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-real-ip": "test-ip",
          },
          body: JSON.stringify({
            username: "admin",
            password: "wrong",
          }),
        })
      }

      // 6th attempt should be rate limited
      const response = await fetch("http://localhost:3000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-real-ip": "test-ip",
        },
        body: JSON.stringify({
          username: "admin",
          password: "wrong",
        }),
      })

      expect(response.status).toBe(429)

      const data = await response.json()
      expect(data.error).toBe("Too many login attempts")
      expect(data.retryAfter).toBeGreaterThan(0)

      // Check headers
      expect(response.headers.get("X-RateLimit-Limit")).toBe("5")
      expect(response.headers.get("X-RateLimit-Remaining")).toBe("0")
      expect(response.headers.get("Retry-After")).toBeDefined()
    })

    it("should track different IPs separately", async () => {
      // IP 1 uses up limit
      for (let i = 0; i < 5; i++) {
        await fetch("http://localhost:3000/api/auth/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-real-ip": "ip-1",
          },
          body: JSON.stringify({
            username: "admin",
            password: "wrong",
          }),
        })
      }

      // IP 1 should be blocked
      let response = await fetch("http://localhost:3000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-real-ip": "ip-1",
        },
        body: JSON.stringify({
          username: "admin",
          password: "wrong",
        }),
      })
      expect(response.status).toBe(429)

      // IP 2 should still be allowed
      response = await fetch("http://localhost:3000/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-real-ip": "ip-2",
        },
        body: JSON.stringify({
          username: "admin",
          password: "wrong",
        }),
      })
      expect(response.status).toBe(401) // Wrong password, not rate limited
    })

    it("should reset after window expires", async () => {
      // Create limiter with short window for testing
      const testLimiter = createRateLimiter({
        maxRequests: 2,
        windowMs: 100, // 100ms
      })

      // Use up limit
      await testLimiter.check("test-user")
      await testLimiter.check("test-user")

      // Should be blocked
      let result = await testLimiter.check("test-user")
      expect(result.success).toBe(false)

      // Wait for window to expire
      await new Promise((resolve) => setTimeout(resolve, 150))

      // Should be allowed again
      result = await testLimiter.check("test-user")
      expect(result.success).toBe(true)
    })
  })

  describe("API Endpoints", () => {
    let authToken: string

    beforeAll(async () => {
      // Get auth token
      const response = await fetch("http://localhost:3000/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: "admin",
          password: "password123",
        }),
      })
      const data = await response.json()
      authToken = data.access_token
    })

    it("should allow 100 API requests per minute", async () => {
      for (let i = 0; i < 100; i++) {
        const response = await fetch("http://localhost:3000/api/drivers", {
          headers: {
            Authorization: `Bearer ${authToken}`,
            "x-real-ip": "test-api-ip",
          },
        })

        expect(response.status).toBe(200)
      }
    })

    it("should block 101st API request", async () => {
      // Make 100 requests
      for (let i = 0; i < 100; i++) {
        await fetch("http://localhost:3000/api/drivers", {
          headers: {
            Authorization: `Bearer ${authToken}`,
            "x-real-ip": "test-api-ip-2",
          },
        })
      }

      // 101st should be blocked
      const response = await fetch("http://localhost:3000/api/drivers", {
        headers: {
          Authorization: `Bearer ${authToken}`,
          "x-real-ip": "test-api-ip-2",
        },
      })

      expect(response.status).toBe(429)
    })

    it("should include rate limit headers in all responses", async () => {
      const response = await fetch("http://localhost:3000/api/drivers", {
        headers: {
          Authorization: `Bearer ${authToken}`,
          "x-real-ip": "test-headers-ip",
        },
      })

      expect(response.headers.get("X-RateLimit-Limit")).toBeDefined()
      expect(response.headers.get("X-RateLimit-Remaining")).toBeDefined()
      expect(response.headers.get("X-RateLimit-Reset")).toBeDefined()
    })
  })

  describe("IP Extraction", () => {
    it("should extract IP from x-real-ip header", () => {
      const request = new Request("http://localhost", {
        headers: { "x-real-ip": "192.168.1.1" },
      })

      expect(getClientIp(request)).toBe("192.168.1.1")
    })

    it("should extract first IP from x-forwarded-for", () => {
      const request = new Request("http://localhost", {
        headers: { "x-forwarded-for": "192.168.1.1, 10.0.0.1" },
      })

      expect(getClientIp(request)).toBe("192.168.1.1")
    })

    it("should return unknown if no IP headers", () => {
      const request = new Request("http://localhost")

      expect(getClientIp(request)).toBe("unknown")
    })

    it("should prioritize x-real-ip over x-forwarded-for", () => {
      const request = new Request("http://localhost", {
        headers: {
          "x-real-ip": "192.168.1.1",
          "x-forwarded-for": "10.0.0.1",
        },
      })

      expect(getClientIp(request)).toBe("192.168.1.1")
    })
  })

  describe("Rate Limit Reset", () => {
    it("should reset rate limit for specific identifier", async () => {
      const limiter = createRateLimiter({
        maxRequests: 1,
        windowMs: 60000,
      })

      // Use up limit
      await limiter.check("test-user")

      // Should be blocked
      let result = await limiter.check("test-user")
      expect(result.success).toBe(false)

      // Reset
      limiter.reset("test-user")

      // Should be allowed again
      result = await limiter.check("test-user")
      expect(result.success).toBe(true)
    })
  })

  describe("Concurrent Requests", () => {
    it("should handle concurrent requests correctly", async () => {
      const limiter = createRateLimiter({
        maxRequests: 10,
        windowMs: 60000,
      })

      // Make 20 concurrent requests
      const promises = Array.from({ length: 20 }, () => limiter.check("concurrent-user"))

      const results = await Promise.all(promises)

      // First 10 should succeed
      const successful = results.filter((r) => r.success).length
      const blocked = results.filter((r) => !r.success).length

      expect(successful).toBe(10)
      expect(blocked).toBe(10)
    })
  })
})
