/**
 * Password Hashing Utilities
 *
 * This module provides secure password hashing and verification using bcrypt.
 *
 * Security Features:
 * - Uses bcrypt with salt rounds of 12 (industry standard)
 * - Automatically generates unique salt for each password
 * - Resistant to rainbow table attacks
 * - Computationally expensive to prevent brute force
 *
 * Usage:
 * ```typescript
 * // Hash a password
 * const hash = await hashPassword('user_password')
 *
 * // Verify a password
 * const isValid = await verifyPassword('user_password', hash)
 * ```
 */

import bcrypt from "bcryptjs"

/**
 * Number of salt rounds for bcrypt hashing
 * Higher = more secure but slower
 * 12 is recommended for production (takes ~300ms)
 */
const SALT_ROUNDS = 12

/**
 * Hash a plain text password using bcrypt
 *
 * @param password - Plain text password to hash
 * @returns Promise resolving to hashed password
 * @throws Error if hashing fails
 *
 * @example
 * const hash = await hashPassword('mySecurePassword123')
 * // Returns: $2a$12$R9h/cIPz0gi.URNNX3kh2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW
 */
export async function hashPassword(password: string): Promise<string> {
  try {
    const hash = await bcrypt.hash(password, SALT_ROUNDS)
    return hash
  } catch (error) {
    console.error("[v0] Password hashing error:", error)
    throw new Error("Failed to hash password")
  }
}

/**
 * Verify a plain text password against a hashed password
 *
 * @param password - Plain text password to verify
 * @param hash - Hashed password to compare against
 * @returns Promise resolving to true if password matches, false otherwise
 *
 * @example
 * const isValid = await verifyPassword('myPassword', storedHash)
 * if (isValid) {
 *   // Password is correct
 * }
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    const isValid = await bcrypt.compare(password, hash)
    return isValid
  } catch (error) {
    console.error("[v0] Password verification error:", error)
    return false
  }
}

/**
 * Validate password strength
 *
 * Requirements:
 * - Minimum 8 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one number
 * - At least one special character
 *
 * @param password - Password to validate
 * @returns Object with isValid boolean and error message if invalid
 *
 * @example
 * const result = validatePasswordStrength('weak')
 * if (!result.isValid) {
 *   console.log(result.error)
 * }
 */
export function validatePasswordStrength(password: string): {
  isValid: boolean
  error?: string
} {
  if (password.length < 8) {
    return {
      isValid: false,
      error: "Password must be at least 8 characters long",
    }
  }

  if (!/[A-Z]/.test(password)) {
    return {
      isValid: false,
      error: "Password must contain at least one uppercase letter",
    }
  }

  if (!/[a-z]/.test(password)) {
    return {
      isValid: false,
      error: "Password must contain at least one lowercase letter",
    }
  }

  if (!/[0-9]/.test(password)) {
    return {
      isValid: false,
      error: "Password must contain at least one number",
    }
  }

  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    return {
      isValid: false,
      error: "Password must contain at least one special character",
    }
  }

  return { isValid: true }
}
