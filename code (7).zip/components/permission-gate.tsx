"use client"

import type React from "react"

import { useAuth } from "@/lib/auth-context"

interface PermissionGateProps {
  children: React.ReactNode
  permission?: string
  permissions?: string[]
  role?: string
  fallback?: React.ReactNode
}

/**
 * Component to conditionally render content based on permissions
 */
export default function PermissionGate({ children, permission, permissions, role, fallback }: PermissionGateProps) {
  const { hasPermission, hasAnyPermission, hasRole } = useAuth()

  // Check permission requirements
  if (permission && !hasPermission(permission)) {
    return <>{fallback || null}</>
  }

  if (permissions && !hasAnyPermission(permissions)) {
    return <>{fallback || null}</>
  }

  if (role && !hasRole(role)) {
    return <>{fallback || null}</>
  }

  return <>{children}</>
}
