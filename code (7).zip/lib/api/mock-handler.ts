/**
 * Enhanced Mock Request Handler
 * Handles all mock API requests with realistic behavior
 */

import { MockDataStore, mockUsers } from "../mock-data"
import { mockCache } from "./mock-cache"
import { simulateNetworkDelay, shouldSimulateError, mockErrors, logMockOperation } from "./mock-config"

export class MockRequestHandler {
  async handleRequest<T>(endpoint: string, method = "GET", body?: any, options?: { skipCache?: boolean }): Promise<T> {
    // Simulate network delay
    await simulateNetworkDelay()

    // Simulate random errors for testing
    if (shouldSimulateError()) {
      logMockOperation("Error simulated", { endpoint, method })
      throw mockErrors.serverError
    }

    logMockOperation(`${method} ${endpoint}`, body)

    // Check cache for GET requests
    if (method === "GET" && !options?.skipCache) {
      const cached = mockCache.get<T>(endpoint)
      if (cached) {
        logMockOperation("Cache hit", endpoint)
        return cached
      }
    }

    // Initialize mock data
    MockDataStore.initializeData()

    // Route to appropriate handler
    const result = await this.routeRequest<T>(endpoint, method, body)

    // Cache GET requests
    if (method === "GET") {
      mockCache.set(endpoint, result)
    }

    // Invalidate related caches on mutations
    if (["POST", "PUT", "DELETE"].includes(method)) {
      this.invalidateRelatedCaches(endpoint)
    }

    return result
  }

  private async routeRequest<T>(endpoint: string, method: string, body?: any): Promise<T> {
    // Auth endpoints
    if (endpoint === "/auth/login") {
      return this.handleLogin(body) as T
    }

    // Companies
    if (endpoint === "/companies") {
      return this.handleCompanies(method, body) as T
    }
    if (endpoint.startsWith("/companies/")) {
      return this.handleCompanyById(endpoint, method, body) as T
    }

    // Vehicles
    if (endpoint === "/vehicles") {
      return this.handleVehicles(method, body) as T
    }
    if (endpoint.startsWith("/vehicles/")) {
      return this.handleVehicleById(endpoint, method, body) as T
    }

    // Drivers
    if (endpoint === "/drivers") {
      return this.handleDrivers(method, body) as T
    }
    if (endpoint.startsWith("/drivers/")) {
      return this.handleDriverById(endpoint, method, body) as T
    }

    // Reservations
    if (endpoint === "/reservations") {
      return this.handleReservations(method, body) as T
    }
    if (endpoint.startsWith("/reservations/")) {
      return this.handleReservationById(endpoint, method, body) as T
    }

    // Tickets
    if (endpoint === "/tickets") {
      return this.handleTickets(method, body) as T
    }
    if (endpoint.startsWith("/tickets/")) {
      return this.handleTicketById(endpoint, method, body) as T
    }

    // Movements
    if (endpoint === "/movements") {
      return this.handleMovements(method, body) as T
    }
    if (endpoint.startsWith("/movements/")) {
      return this.handleMovementById(endpoint, method, body) as T
    }

    // Supplies
    if (endpoint === "/supplies") {
      return this.handleSupplies(method, body) as T
    }
    if (endpoint.startsWith("/supplies/")) {
      return this.handleSupplyById(endpoint, method, body) as T
    }

    // Dashboard
    if (endpoint === "/dashboard/stats") {
      return this.handleDashboardStats() as T
    }
    if (endpoint === "/dashboard/charts") {
      return this.handleDashboardCharts() as T
    }

    // Reports
    if (endpoint.startsWith("/reports/fleet-utilization")) {
      return this.handleFleetUtilizationReport() as T
    }
    if (endpoint.startsWith("/reports/expenses")) {
      return this.handleExpensesReport() as T
    }
    if (endpoint.startsWith("/reports/driver-performance")) {
      return this.handleDriverPerformanceReport() as T
    }
    if (endpoint.startsWith("/reports/monthly-reservations")) {
      return this.handleMonthlyReservationsReport() as T
    }
    if (endpoint.startsWith("/reports/fleet-status")) {
      return this.handleFleetStatusReport() as T
    }
    if (endpoint === "/reports/export") {
      return this.handleExportReport(body) as T
    }

    throw new Error(`Mock endpoint not implemented: ${endpoint}`)
  }

  // Auth handlers
  private handleLogin(body: any) {
    const username = body.username?.trim() || ""
    const password = body.password?.trim() || ""

    const user = mockUsers.find((u) => u.username === username && u.password === password)

    if (user) {
      logMockOperation("Login successful", { username, role: user.role })
      return {
        access_token: `mock_token_${user.id}_${Date.now()}`,
        refresh_token: `mock_refresh_token_${user.id}_${Date.now()}`,
        user: {
          id: user.id.toString(),
          username: user.username,
          email: user.email,
          role: user.role,
          full_name: user.full_name,
          company_id: user.company_id || null,
          company_code: body.company_code || null,
        },
      }
    }

    logMockOperation("Login failed", { username })
    throw mockErrors.unauthorized
  }

  // Company handlers
  private handleCompanies(method: string, body?: any) {
    if (method === "POST") {
      const newCompany = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addCompany(newCompany)
      return newCompany
    }
    return MockDataStore.getCompanies()
  }

  private handleCompanyById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateCompany(id, body)
      return { success: true, id }
    }
    if (method === "DELETE") {
      MockDataStore.deleteCompany(id)
      return { success: true, id }
    }

    const company = MockDataStore.getCompanies().find((c) => c.id === id)
    if (!company) throw mockErrors.notFound
    return company
  }

  // Vehicle handlers
  private handleVehicles(method: string, body?: any) {
    if (method === "POST") {
      const newVehicle = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addVehicle(newVehicle)
      return newVehicle
    }
    return MockDataStore.getVehicles()
  }

  private handleVehicleById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateVehicle(id, body)
      return { success: true, id }
    }
    if (method === "DELETE") {
      MockDataStore.deleteVehicle(id)
      return { success: true, id }
    }

    const vehicle = MockDataStore.getVehicles().find((v) => v.id === id)
    if (!vehicle) throw mockErrors.notFound
    return vehicle
  }

  // Driver handlers
  private handleDrivers(method: string, body?: any) {
    if (method === "POST") {
      const newDriver = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addDriver(newDriver)
      return newDriver
    }
    return MockDataStore.getDrivers()
  }

  private handleDriverById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateDriver(id, body)
      return { success: true, id }
    }
    if (method === "DELETE") {
      MockDataStore.deleteDriver(id)
      return { success: true, id }
    }

    const driver = MockDataStore.getDrivers().find((d) => d.id === id)
    if (!driver) throw mockErrors.notFound
    return driver
  }

  // Reservation handlers
  private handleReservations(method: string, body?: any) {
    if (method === "POST") {
      const newReservation = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addReservation(newReservation)
      return newReservation
    }
    return MockDataStore.getReservations()
  }

  private handleReservationById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateReservation(id, body)
      return { success: true, id }
    }
    if (method === "DELETE") {
      MockDataStore.deleteReservation(id)
      return { success: true, id }
    }

    const reservation = MockDataStore.getReservations().find((r) => r.id === id)
    if (!reservation) throw mockErrors.notFound
    return reservation
  }

  // Ticket handlers
  private handleTickets(method: string, body?: any) {
    if (method === "POST") {
      const newTicket = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addTicket(newTicket)
      return newTicket
    }
    return MockDataStore.getTickets()
  }

  private handleTicketById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateTicket(id, body)
      const ticket = MockDataStore.getTickets().find((t) => t.id === id)
      return ticket
    }
    if (method === "DELETE") {
      MockDataStore.deleteTicket(id)
      return { success: true, id }
    }

    const ticket = MockDataStore.getTickets().find((t) => t.id === id)
    if (!ticket) throw mockErrors.notFound
    return ticket
  }

  // Movement handlers
  private handleMovements(method: string, body?: any) {
    if (method === "POST") {
      const newMovement = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addMovement(newMovement)
      return newMovement
    }
    return MockDataStore.getMovements()
  }

  private handleMovementById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateMovement(id, body)
      return { success: true, id }
    }
    if (method === "DELETE") {
      MockDataStore.deleteMovement(id)
      return { success: true, id }
    }

    const movement = MockDataStore.getMovements().find((m) => m.id === id)
    if (!movement) throw mockErrors.notFound
    return movement
  }

  // Supply handlers
  private handleSupplies(method: string, body?: any) {
    if (method === "POST") {
      const newSupply = {
        id: Date.now(),
        ...body,
        created_at: new Date().toISOString(),
      }
      MockDataStore.addSupply(newSupply)
      return newSupply
    }
    return MockDataStore.getSupplies()
  }

  private handleSupplyById(endpoint: string, method: string, body?: any) {
    const id = Number.parseInt(endpoint.split("/")[2])

    if (method === "PUT") {
      MockDataStore.updateSupply(id, body)
      return { success: true, id }
    }
    if (method === "DELETE") {
      MockDataStore.deleteSupply(id)
      return { success: true, id }
    }

    const supply = MockDataStore.getSupplies().find((s) => s.id === id)
    if (!supply) throw mockErrors.notFound
    return supply
  }

  // Dashboard handlers
  private handleDashboardStats() {
    const vehicles = MockDataStore.getVehicles()
    const reservations = MockDataStore.getReservations()
    const drivers = MockDataStore.getDrivers()
    const tickets = MockDataStore.getTickets()

    return {
      total_vehicles: vehicles.length,
      active_vehicles: vehicles.filter((v) => v.status === "active").length,
      total_drivers: drivers.length,
      active_drivers: drivers.filter((d) => d.status === "active").length,
      active_reservations: reservations.filter((r) => r.status === "active").length,
      upcoming_reservations: reservations.filter((r) => r.status === "upcoming").length,
      total_tickets: tickets.length,
      confirmed_tickets: tickets.filter((t) => t.status === "confirmed").length,
    }
  }

  private handleDashboardCharts() {
    const reservations = MockDataStore.getReservations()
    const vehicles = MockDataStore.getVehicles()

    // Generate monthly reservations data for the last 6 months
    const monthlyData = []
    const now = new Date()
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthName = date.toLocaleDateString("en-US", { month: "short" })
      const count = Math.floor(Math.random() * 20) + 10
      monthlyData.push({ month: monthName, value: count })
    }

    const activeCount = vehicles.filter((v) => v.status === "active").length
    const maintenanceCount = vehicles.filter((v) => v.status === "maintenance").length
    const inactiveCount = vehicles.filter((v) => v.status === "inactive").length

    const fleetStatus = [
      { name: "active", value: activeCount },
      { name: "maintenance", value: maintenanceCount },
      { name: "inactive", value: inactiveCount },
    ]

    return {
      monthlyReservations: monthlyData,
      fleetStatus,
    }
  }

  // Reports handlers
  private handleFleetUtilizationReport() {
    const vehicles = MockDataStore.getVehicles()
    const reservations = MockDataStore.getReservations()

    // Generate utilization data for the last 30 days
    const data = []
    const now = new Date()
    for (let i = 29; i >= 0; i--) {
      const date = new Date(now)
      date.setDate(date.getDate() - i)
      const vehiclesUsed = Math.floor(Math.random() * vehicles.length * 0.8) + Math.floor(vehicles.length * 0.2)
      const utilizationRate = Math.round((vehiclesUsed / vehicles.length) * 100)

      data.push({
        date: date.toISOString().split("T")[0],
        vehiclesUsed,
        totalVehicles: vehicles.length,
        utilizationRate,
      })
    }

    return {
      data,
      summary: {
        averageUtilization: Math.round(data.reduce((sum, d) => sum + d.utilizationRate, 0) / data.length),
        totalVehicles: vehicles.length,
        peakUtilization: Math.max(...data.map((d) => d.utilizationRate)),
      },
    }
  }

  private handleExpensesReport() {
    const supplies = MockDataStore.getSupplies()

    // Group supplies by category
    const categoryMap = new Map<string, number>()
    supplies.forEach((supply) => {
      const category = supply.category || supply.supply_type || "Other"
      categoryMap.set(category, (categoryMap.get(category) || 0) + (supply.quantity || 1))
    })

    const breakdown = Array.from(categoryMap.entries()).map(([category, totalQuantity]) => ({
      category,
      totalQuantity,
      percentage: 0, // Will be calculated below
    }))

    const total = breakdown.reduce((sum, item) => sum + item.totalQuantity, 0)
    breakdown.forEach((item) => {
      item.percentage = Math.round((item.totalQuantity / total) * 100)
    })

    return {
      breakdown,
      total,
      period: {
        start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        end: new Date().toISOString().split("T")[0],
      },
    }
  }

  private handleDriverPerformanceReport() {
    const drivers = MockDataStore.getDrivers()
    const reservations = MockDataStore.getReservations()

    // Calculate performance scores for each driver
    const driverPerformance = drivers
      .map((driver, index) => {
        const driverReservations = reservations.filter((r) => r.driver_id === driver.id)
        const completedTrips = driverReservations.filter((r) => r.status === "completed").length
        const score = Math.floor(Math.random() * 30) + 70 // Random score between 70-100

        return {
          rank: index + 1,
          driverId: driver.id,
          name: driver.name,
          score,
          completedTrips,
          status: driver.status,
        }
      })
      .sort((a, b) => b.score - a.score)

    // Update ranks after sorting
    driverPerformance.forEach((driver, index) => {
      driver.rank = index + 1
    })

    return {
      drivers: driverPerformance,
      summary: {
        totalDrivers: drivers.length,
        activeDrivers: drivers.filter((d) => d.status === "active").length,
        averageScore: Math.round(driverPerformance.reduce((sum, d) => sum + d.score, 0) / driverPerformance.length),
      },
    }
  }

  private handleMonthlyReservationsReport() {
    const reservations = MockDataStore.getReservations()

    // Generate monthly data for the last 12 months
    const monthlyData = []
    const now = new Date()
    for (let i = 11; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthName = date.toLocaleDateString("en-US", { month: "short" })
      const year = date.getFullYear()
      const count = Math.floor(Math.random() * 30) + 15
      const revenue = count * (Math.floor(Math.random() * 200) + 300)

      monthlyData.push({
        month: monthName,
        year,
        count,
        revenue,
      })
    }

    return {
      months: monthlyData,
      summary: {
        totalReservations: monthlyData.reduce((sum, m) => sum + m.count, 0),
        totalRevenue: monthlyData.reduce((sum, m) => sum + m.revenue, 0),
        averagePerMonth: Math.round(monthlyData.reduce((sum, m) => sum + m.count, 0) / monthlyData.length),
      },
    }
  }

  private handleFleetStatusReport() {
    const vehicles = MockDataStore.getVehicles()

    const statusCounts = {
      active: vehicles.filter((v) => v.status === "active").length,
      maintenance: vehicles.filter((v) => v.status === "maintenance").length,
      inactive: vehicles.filter((v) => v.status === "inactive").length,
      total: vehicles.length,
    }

    const percentages = {
      active: Math.round((statusCounts.active / statusCounts.total) * 100),
      maintenance: Math.round((statusCounts.maintenance / statusCounts.total) * 100),
      inactive: Math.round((statusCounts.inactive / statusCounts.total) * 100),
    }

    return {
      ...statusCounts,
      percentages,
      vehicles: vehicles.map((v) => ({
        id: v.id,
        model: v.model,
        plate_number: v.plate_number,
        status: v.status,
        last_maintenance: v.issue_date,
        next_maintenance: v.expiry_date,
      })),
    }
  }

  private handleExportReport(body: any) {
    const { reportType, format, data } = body

    if (format === "csv") {
      // Generate CSV content
      let csv = ""
      if (reportType === "fleet-utilization" && data.data) {
        csv = "Date,Vehicles Used,Total Vehicles,Utilization Rate\n"
        data.data.forEach((row: any) => {
          csv += `${row.date},${row.vehiclesUsed},${row.totalVehicles},${row.utilizationRate}%\n`
        })
      } else if (reportType === "expenses" && data.breakdown) {
        csv = "Category,Total Quantity,Percentage\n"
        data.breakdown.forEach((row: any) => {
          csv += `${row.category},${row.totalQuantity},${row.percentage}%\n`
        })
      } else if (reportType === "driver-performance" && data.drivers) {
        csv = "Rank,Driver Name,Score,Completed Trips,Status\n"
        data.drivers.forEach((row: any) => {
          csv += `${row.rank},${row.name},${row.score},${row.completedTrips},${row.status}\n`
        })
      }
      return csv
    } else if (format === "json") {
      return JSON.stringify(data, null, 2)
    } else if (format === "pdf") {
      return { message: "PDF generation is not available in mock mode. Use real backend for PDF export." }
    }

    return { message: "Export format not supported" }
  }

  // Cache invalidation
  private invalidateRelatedCaches(endpoint: string) {
    const resource = endpoint.split("/")[1]
    mockCache.invalidatePattern(`/${resource}`)

    // Invalidate dashboard stats when any data changes
    mockCache.invalidate("/dashboard/stats")
    mockCache.invalidate("/dashboard/charts")

    mockCache.invalidatePattern("/reports/")

    logMockOperation("Cache invalidated", resource)
  }
}

export const mockHandler = new MockRequestHandler()
