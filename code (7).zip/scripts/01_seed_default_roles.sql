-- Seed Default Roles for FleetPro Management System
-- This script creates the 6 core system roles

-- Insert default roles
INSERT INTO roles (name, display_name, description, is_system) VALUES
  ('super_admin', 'Super Administrator', 'Full system access', true),
  ('admin', 'Administrator', 'Administrative access', true),
  ('fleet_manager', 'Fleet Manager', 'Manage fleet operations', true),
  ('dispatcher', 'Dispatcher', 'Manage reservations', true),
  ('maintenance_staff', 'Maintenance Staff', 'Manage maintenance', true),
  ('viewer', 'Viewer', 'Read-only access', true)
ON CONFLICT (name) DO UPDATE SET
  display_name = EXCLUDED.display_name,
  description = EXCLUDED.description,
  is_system = EXCLUDED.is_system;

-- Verify roles were created
SELECT id, name, display_name, description, is_system 
FROM roles 
ORDER BY 
  CASE 
    WHEN name = 'super_admin' THEN 1
    WHEN name = 'admin' THEN 2
    WHEN name = 'fleet_manager' THEN 3
    WHEN name = 'dispatcher' THEN 4
    WHEN name = 'maintenance_staff' THEN 5
    WHEN name = 'viewer' THEN 6
    ELSE 7
  END;
