-- Insert sample movement/trip data
INSERT INTO movements (
  driver_name, 
  assistant_name, 
  bus_number, 
  trip_name, 
  trip_date, 
  trip_time, 
  seats, 
  pending_seats, 
  status,
  movement_type,
  category,
  priority
) VALUES
('أحمد محمد', 'خالد علي', 'BUS-001', 'الرياض - جدة', '2025-01-15', '08:00', 45, 5, 'active', 'trip', 'intercity', 'high'),
('سارة أحمد', 'فاطمة حسن', 'BUS-002', 'الدمام - الخبر', '2025-01-15', '10:30', 40, 0, 'completed', 'trip', 'local', 'medium'),
('محمد عبدالله', 'عمر يوسف', 'BUS-003', 'مكة - المدينة', '2025-01-16', '14:00', 50, 12, 'pending', 'trip', 'intercity', 'high'),
('علي حسن', 'يوسف أحمد', 'BUS-004', 'جدة - الطائف', '2025-01-17', '09:00', 42, 8, 'active', 'trip', 'intercity', 'medium'),
('فاطمة علي', 'نورة محمد', 'BUS-005', 'الرياض - الدمام', '2025-01-18', '07:30', 48, 3, 'pending', 'trip', 'intercity', 'high')
ON CONFLICT DO NOTHING;
