/**
 * JWT (JSON Web Token) Authentication Utilities
 *
 * This module provides secure JWT token generation and verification.
 *
 * Security Features:
 * - Uses HS256 algorithm (HMAC with SHA-256)
 * - Tokens expire after configurable time (default 7 days)
 * - Includes user ID, role, and permissions in payload
 * - Validates token signature and expiration
 *
 * Token Structure:
 * {
 *   userId: string,
 *   role: string,
 *   permissions: string[],
 *   iat: number (issued at),
 *   exp: number (expiration)
 * }
 *
 * Usage:
 * \`\`\`typescript
 * // Generate token
 * const token = await generateToken({ userId: '1', role: 'admin', permissions: ['*'] })
 *
 * // Verify token
 * const payload = await verifyToken(token)
 * \`\`\`
 */

import jwt from "jsonwebtoken"

/**
 * JWT secret key - MUST be set in environment variables for production
 * Generate a secure random string: openssl rand -base64 32
 *
 * Deferred production check from module load time to runtime
 * to allow builds to complete. The actual check happens in functions.
 */
const JWT_SECRET = process.env.JWT_SECRET

if (!JWT_SECRET && process.env.NODE_ENV === "production") {
  console.warn(
    "[v0] WARNING: JWT_SECRET not set in production. Tokens will use default key. This is INSECURE and should only happen during build.",
  )
}

const JWT_SECRET_KEY = JWT_SECRET || "dev-secret-key-change-in-production"

/**
 * Token expiration time
 * Default: 7 days
 */
const JWT_EXPIRATION = process.env.JWT_EXPIRATION || "7d"

/**
 * Refresh token expiration time
 * Default: 30 days
 */
const REFRESH_TOKEN_EXPIRATION = process.env.REFRESH_TOKEN_EXPIRATION || "30d"

/**
 * JWT Payload interface
 */
export interface JWTPayload {
  userId: string
  role: string
  permissions: string[]
  companyId?: number
  companyCode?: string
}

/**
 * Decoded JWT token interface
 */
export interface DecodedToken extends JWTPayload {
  iat: number
  exp: number
}

/**
 * Validate JWT_SECRET is configured (for runtime checks)
 * Added runtime validation function
 */
function validateJWTSecretConfigured(): void {
  if (!JWT_SECRET && process.env.NODE_ENV === "production") {
    throw new Error(
      "JWT_SECRET environment variable is required in production. " +
        "Set it in your .env.local file (development) or in your deployment platform (production).",
    )
  }
}

/**
 * Generate a JWT access token
 *
 * @param payload - User data to encode in token
 * @returns Promise resolving to JWT token string
 *
 * @example
 * const token = await generateToken({
 *   userId: '123',
 *   role: 'admin',
 *   permissions: ['users.read', 'users.write']
 * })
 */
export async function generateToken(payload: JWTPayload): Promise<string> {
  try {
    validateJWTSecretConfigured()

    const token = jwt.sign(payload, JWT_SECRET_KEY, {
      expiresIn: JWT_EXPIRATION,
      algorithm: "HS256",
    })
    return token
  } catch (error) {
    if (error instanceof Error && error.message.includes("JWT_SECRET")) {
      throw error
    }
    throw new Error("Failed to generate token")
  }
}

/**
 * Generate a refresh token (longer expiration)
 *
 * @param payload - User data to encode in token
 * @returns Promise resolving to refresh token string
 *
 * @example
 * const refreshToken = await generateRefreshToken({
 *   userId: '123',
 *   role: 'admin',
 *   permissions: ['users.read']
 * })
 */
export async function generateRefreshToken(payload: JWTPayload): Promise<string> {
  try {
    validateJWTSecretConfigured()

    const token = jwt.sign(payload, JWT_SECRET_KEY, {
      expiresIn: REFRESH_TOKEN_EXPIRATION,
      algorithm: "HS256",
    })
    return token
  } catch (error) {
    if (error instanceof Error && error.message.includes("JWT_SECRET")) {
      throw error
    }
    throw new Error("Failed to generate refresh token")
  }
}

/**
 * Verify and decode a JWT token
 *
 * @param token - JWT token to verify
 * @returns Promise resolving to decoded token payload
 * @throws Error if token is invalid or expired
 *
 * @example
 * try {
 *   const payload = await verifyToken(token)
 *   console.log('User ID:', payload.userId)
 * } catch (error) {
 *   console.error('Invalid token')
 * }
 */
export async function verifyToken(token: string): Promise<DecodedToken> {
  try {
    const decoded = jwt.verify(token, JWT_SECRET_KEY, {
      algorithms: ["HS256"],
    }) as DecodedToken
    return decoded
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      throw new Error("Token has expired")
    }
    if (error instanceof jwt.JsonWebTokenError) {
      throw new Error("Invalid token")
    }
    throw new Error("Token verification failed")
  }
}

/**
 * Extract token from Authorization header
 *
 * @param authHeader - Authorization header value (e.g., "Bearer token123")
 * @returns Token string or null if not found
 *
 * @example
 * const token = extractTokenFromHeader(request.headers.get('Authorization'))
 */
export function extractTokenFromHeader(authHeader: string | null): string | null {
  if (!authHeader) {
    return null
  }

  const parts = authHeader.split(" ")
  if (parts.length !== 2 || parts[0] !== "Bearer") {
    return null
  }

  return parts[1]
}

/**
 * Decode token without verification (for debugging only)
 * WARNING: Do not use for authentication - always use verifyToken()
 *
 * @param token - JWT token to decode
 * @returns Decoded payload or null if invalid
 */
export function decodeTokenUnsafe(token: string): DecodedToken | null {
  try {
    const decoded = jwt.decode(token) as DecodedToken
    return decoded
  } catch (error) {
    return null
  }
}
