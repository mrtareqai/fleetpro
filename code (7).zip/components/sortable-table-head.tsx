"use client"

import { ArrowUpDown, ArrowUp, ArrowDown } from "lucide-react"
import { TableHead } from "@/components/ui/table"
import type { SortDirection } from "@/lib/table-utils"

interface SortableTableHeadProps {
  label: string
  sortKey: string
  currentSortKey: string | null
  currentSortDirection: SortDirection
  onSort: (key: string) => void
  className?: string
}

export function SortableTableHead({
  label,
  sortKey,
  currentSortKey,
  currentSortDirection,
  onSort,
  className = "",
}: SortableTableHeadProps) {
  const isActive = currentSortKey === sortKey

  const getSortIcon = () => {
    if (!isActive) {
      return <ArrowUpDown className="w-4 h-4 text-slate-400" />
    }
    if (currentSortDirection === "asc") {
      return <ArrowUp className="w-4 h-4 text-blue-600" />
    }
    return <ArrowDown className="w-4 h-4 text-blue-600" />
  }

  return (
    <TableHead className={className}>
      <button
        onClick={() => onSort(sortKey)}
        className={`flex items-center gap-2 hover:text-slate-900 transition-colors font-semibold ${
          isActive ? "text-blue-600" : "text-slate-700"
        }`}
      >
        <span>{label}</span>
        {getSortIcon()}
      </button>
    </TableHead>
  )
}
