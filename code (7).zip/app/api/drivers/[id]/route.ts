import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { updateDriverSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "drivers.read")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const driverId = Number.parseInt(params.id)

    if (isNaN(driverId)) {
      return NextResponse.json({ error: "Invalid driver ID" }, { status: 400 })
    }

    logger.info("Fetching driver", { userId, driverId })

    const result = await sql`
      SELECT * FROM drivers WHERE id = ${driverId}
    `

    if (result.length === 0) {
      logger.warn("Driver not found", { userId, driverId })
      return NextResponse.json({ error: "Driver not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Driver fetched successfully", { userId, driverId, duration })

    return NextResponse.json({ driver: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching driver", { error, driverId: params.id, duration })

    return NextResponse.json({ error: "Failed to fetch driver" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "drivers.update")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const driverId = Number.parseInt(params.id)

    if (isNaN(driverId)) {
      return NextResponse.json({ error: "Invalid driver ID" }, { status: 400 })
    }

    const body = await request.json()
    const validatedData = await validateOrRespond(updateDriverSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Updating driver", { userId, driverId })

    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1

    if (validatedData.name !== undefined) {
      updates.push(`name = $${paramIndex++}`)
      values.push(validatedData.name)
    }
    if (validatedData.license_number !== undefined) {
      updates.push(`license_number = $${paramIndex++}`)
      values.push(validatedData.license_number)
    }
    if (validatedData.phone !== undefined) {
      updates.push(`phone = $${paramIndex++}`)
      values.push(validatedData.phone)
    }
    if (validatedData.email !== undefined) {
      updates.push(`email = $${paramIndex++}`)
      values.push(validatedData.email)
    }
    if (validatedData.status !== undefined) {
      updates.push(`status = $${paramIndex++}`)
      values.push(validatedData.status)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(driverId)

    const query = `
      UPDATE drivers 
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `

    const result = await sql(query, values)

    if (result.length === 0) {
      logger.warn("Driver not found for update", { userId, driverId })
      return NextResponse.json({ error: "Driver not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Driver updated successfully", { userId, driverId, duration })

    return NextResponse.json({ driver: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error updating driver", { error, driverId: params.id, duration })

    return NextResponse.json({ error: "Failed to update driver" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "drivers.delete")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const driverId = Number.parseInt(params.id)

    if (isNaN(driverId)) {
      return NextResponse.json({ error: "Invalid driver ID" }, { status: 400 })
    }

    logger.info("Deleting driver", { userId, driverId })

    const result = await sql`
      DELETE FROM drivers 
      WHERE id = ${driverId}
      RETURNING id
    `

    if (result.length === 0) {
      logger.warn("Driver not found for deletion", { userId, driverId })
      return NextResponse.json({ error: "Driver not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Driver deleted successfully", { userId, driverId, duration })

    return NextResponse.json({
      message: "Driver deleted successfully",
      id: driverId,
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error deleting driver", { error, driverId: params.id, duration })

    return NextResponse.json({ error: "Failed to delete driver" }, { status: 500 })
  }
}
