"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Plus, Edit, Trash2, Scan, X } from "lucide-react"
import { useSelection } from "@/lib/selection-context"
import { useAuth } from "@/lib/auth-context"
import { apiClient } from "@/lib/api-client"

interface SuppliesTableProps {
  locale: "en" | "ar"
}

interface Supply {
  id: number
  item_name: string
  category: string
  quantity: number
  unit: string
  supplier: string
  purchase_date: string
  expiry_date: string
  status: "available" | "low-stock" | "out-of-stock"
}

export default function SuppliesTable({ locale }: SuppliesTableProps) {
  const [supplies, setSupplies] = useState<Supply[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [formData, setFormData] = useState({
    item_name: "",
    category: "",
    quantity: 0,
    unit: "",
    supplier: "",
    purchase_date: "",
    expiry_date: "",
    status: "available" as "available" | "low-stock" | "out-of-stock",
  })
  const modalRef = useRef<HTMLDivElement>(null)
  const firstInputRef = useRef<HTMLInputElement>(null)

  const { isSelectionMode, toggleSelectionMode, selectedItems, toggleItem, selectAll, clearSelection, isSelected } =
    useSelection()
  const { hasPermission } = useAuth()

  const t = {
    en: {
      title: "Agency Supplies Management",
      add: "Add Supply",
      edit: "Edit",
      delete: "Delete",
      itemName: "Item Name",
      category: "Category",
      quantity: "Quantity",
      unit: "Unit",
      supplier: "Supplier",
      purchaseDate: "Purchase Date",
      expiryDate: "Expiry Date",
      status: "Status",
      available: "Available",
      lowStock: "Low Stock",
      outOfStock: "Out of Stock",
      scan: "Scan",
      selectAll: "Select All",
      selected: "selected",
      deleteSelected: "Delete Selected",
      selectionModeActive: "Selection mode active - Select items to delete",
      loading: "Loading...",
      noSupplies: "No supplies found",
      cancel: "Cancel",
      save: "Save",
    },
    ar: {
      title: "إدارة مستلزمات الوكالة",
      add: "إضافة مستلزم",
      edit: "تعديل",
      delete: "حذف",
      itemName: "اسم الصنف",
      category: "الفئة",
      quantity: "الكمية",
      unit: "الوحدة",
      supplier: "المورد",
      purchaseDate: "تاريخ الشراء",
      expiryDate: "تاريخ الانتهاء",
      status: "الحالة",
      available: "متوفر",
      lowStock: "مخزون منخفض",
      outOfStock: "نفذ المخزون",
      scan: "مسح",
      selectAll: "تحديد الكل",
      selected: "محدد",
      deleteSelected: "حذف المحدد",
      selectionModeActive: "وضع التحديد نشط - حدد العناصر للحذف",
      loading: "جاري التحميل...",
      noSupplies: "لا توجد مستلزمات",
      cancel: "إلغاء",
      save: "حفظ",
    },
  }

  useEffect(() => {
    fetchSupplies()
  }, [])

  const fetchSupplies = async () => {
    try {
      setLoading(true)
      const data = await apiClient.getSupplies()
      setSupplies(data)
    } catch (err) {
      console.error("[v0] Error fetching supplies:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleRowClick = (id: number) => {
    if (isSelectionMode) {
      toggleItem(id)
    } else {
      setSelectedId(id)
    }
  }

  const handleSelectAll = () => {
    selectAll(supplies.map((s) => s.id))
  }

  const handleEdit = () => {
    if (!selectedId) return
    const supply = supplies.find((s) => s.id === selectedId)
    if (supply) {
      setFormData({
        item_name: supply.item_name,
        category: supply.category,
        quantity: supply.quantity,
        unit: supply.unit,
        supplier: supply.supplier,
        purchase_date: supply.purchase_date,
        expiry_date: supply.expiry_date,
        status: supply.status,
      })
      setShowEditModal(true)
    }
  }

  useEffect(() => {
    if (showAddModal || showEditModal) {
      document.body.style.overflow = "hidden"
      firstInputRef.current?.focus()
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [showAddModal, showEditModal])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (showAddModal) setShowAddModal(false)
        if (showEditModal) setShowEditModal(false)
      }
    }
    window.addEventListener("keydown", handleEscape)
    return () => window.removeEventListener("keydown", handleEscape)
  }, [showAddModal, showEditModal])

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      if (showAddModal) setShowAddModal(false)
      if (showEditModal) setShowEditModal(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiClient.createSupply(formData)
      setFormData({
        item_name: "",
        category: "",
        quantity: 0,
        unit: "",
        supplier: "",
        purchase_date: "",
        expiry_date: "",
        status: "available",
      })
      setShowAddModal(false)
      fetchSupplies()
    } catch (error) {
      console.error("[v0] Error adding supply:", error)
      alert(locale === "en" ? "Failed to add supply" : "فشل إضافة المستلزم")
    }
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedId) return
    try {
      await apiClient.updateSupply(selectedId, formData)
      setFormData({
        item_name: "",
        category: "",
        quantity: 0,
        unit: "",
        supplier: "",
        purchase_date: "",
        expiry_date: "",
        status: "available",
      })
      setShowEditModal(false)
      setSelectedId(null)
      fetchSupplies()
    } catch (error) {
      console.error("[v0] Error updating supply:", error)
      alert(locale === "en" ? "Failed to update supply" : "فشل تحديث المستلزم")
    }
  }

  const handleDelete = async () => {
    if (!selectedId) return

    const confirmMessage =
      locale === "en" ? "Are you sure you want to delete this supply?" : "هل أنت متأكد من حذف هذا المستلزم؟"

    if (!confirm(confirmMessage)) return

    try {
      await apiClient.deleteSupply(selectedId)
      setSelectedId(null)
      fetchSupplies()
    } catch (error) {
      console.error("[v0] Error deleting supply:", error)
      alert(locale === "en" ? "Failed to delete supply" : "فشل حذف المستلزم")
    }
  }

  const handleDeleteSelected = async () => {
    if (selectedItems.size === 0) return

    const confirmMessage =
      locale === "en"
        ? `Are you sure you want to delete ${selectedItems.size} supply item(s)?`
        : `هل أنت متأكد من حذف ${selectedItems.size} مستلزم؟`

    if (!confirm(confirmMessage)) return

    try {
      const deletePromises = Array.from(selectedItems).map((id) => apiClient.deleteSupply(id))
      await Promise.all(deletePromises)
      clearSelection()
      toggleSelectionMode()
      fetchSupplies()
    } catch (error) {
      console.error("[v0] Error deleting supplies:", error)
      alert(locale === "en" ? "Failed to delete supplies" : "فشل حذف المستلزمات")
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="flex flex-wrap gap-2 md:gap-3">
        {hasPermission("supplies.delete") && (
          <button
            onClick={toggleSelectionMode}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
              isSelectionMode
                ? "bg-purple-600 hover:bg-purple-700 text-white"
                : "bg-purple-500 hover:bg-purple-600 text-white"
            }`}
          >
            <Scan className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].scan}
          </button>
        )}

        {isSelectionMode ? (
          <button
            onClick={handleDeleteSelected}
            disabled={selectedItems.size === 0}
            className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
          >
            <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].deleteSelected}
          </button>
        ) : (
          <>
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
            >
              <Plus className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].add}
            </button>
            <button
              disabled={!selectedId}
              onClick={handleEdit}
              className="flex items-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Edit className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].edit}
            </button>
            <button
              disabled={!selectedId}
              onClick={handleDelete}
              className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].delete}
            </button>
          </>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px]">
            <thead className="bg-slate-100 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].itemName}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].category}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].quantity}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].unit}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].supplier}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].purchaseDate}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].expiryDate}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].status}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {supplies.length === 0 ? (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-slate-500">
                    {t[locale].noSupplies}
                  </td>
                </tr>
              ) : (
                supplies.map((supply) => (
                  <tr
                    key={supply.id}
                    onClick={() => handleRowClick(supply.id)}
                    className={`cursor-pointer transition-colors ${
                      selectedId === supply.id ? "bg-blue-50" : "hover:bg-slate-50"
                    }`}
                  >
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.item_name}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.category}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.quantity}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.unit}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.supplier}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.purchase_date}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{supply.expiry_date}</td>
                    <td className="px-4 py-3">
                      {supply.status === "available" && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                          {t[locale].available}
                        </span>
                      )}
                      {supply.status === "low-stock" && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                          {t[locale].lowStock}
                        </span>
                      )}
                      {supply.status === "out-of-stock" && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                          {t[locale].outOfStock}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="px-6 py-4 border-t border-slate-200">
          <p className="text-sm text-slate-500">© 2025 FleetPro System – All rights reserved</p>
        </div>
      </div>

      {showAddModal && (
        <div
          onClick={handleBackdropClick}
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-supply-title"
        >
          <div ref={modalRef} className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 id="add-supply-title" className="text-xl font-bold text-slate-800">
                {locale === "en" ? "Add New Supply" : "إضافة مستلزم جديد"}
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors"
                aria-label={locale === "en" ? "Close" : "إغلاق"}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="item_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].itemName}
                  </label>
                  <input
                    ref={firstInputRef}
                    id="item_name"
                    type="text"
                    required
                    value={formData.item_name}
                    onChange={(e) => setFormData({ ...formData, item_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].category}
                  </label>
                  <input
                    id="category"
                    type="text"
                    required
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="quantity" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].quantity}
                  </label>
                  <input
                    id="quantity"
                    type="number"
                    required
                    min="0"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: Number.parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="unit" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].unit}
                  </label>
                  <input
                    id="unit"
                    type="text"
                    required
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="supplier" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].supplier}
                  </label>
                  <input
                    id="supplier"
                    type="text"
                    required
                    value={formData.supplier}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="purchase_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].purchaseDate}
                  </label>
                  <input
                    id="purchase_date"
                    type="date"
                    required
                    value={formData.purchase_date}
                    onChange={(e) => setFormData({ ...formData, purchase_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="expiry_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].expiryDate}
                  </label>
                  <input
                    id="expiry_date"
                    type="date"
                    required
                    value={formData.expiry_date}
                    onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].status}
                  </label>
                  <select
                    id="status"
                    required
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        status: e.target.value as "available" | "low-stock" | "out-of-stock",
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="available">{t[locale].available}</option>
                    <option value="low-stock">{t[locale].lowStock}</option>
                    <option value="out-of-stock">{t[locale].outOfStock}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  {locale === "en" ? "Cancel" : "إلغاء"}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                >
                  {locale === "en" ? "Add Supply" : "إضافة المستلزم"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && (
        <div
          onClick={handleBackdropClick}
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-supply-title"
        >
          <div ref={modalRef} className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 id="edit-supply-title" className="text-xl font-bold text-slate-800">
                {locale === "en" ? "Edit Supply" : "تعديل المستلزم"}
              </h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors"
                aria-label={locale === "en" ? "Close" : "إغلاق"}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="edit_item_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].itemName}
                  </label>
                  <input
                    ref={firstInputRef}
                    id="edit_item_name"
                    type="text"
                    required
                    value={formData.item_name}
                    onChange={(e) => setFormData({ ...formData, item_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_category" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].category}
                  </label>
                  <input
                    id="edit_category"
                    type="text"
                    required
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_quantity" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].quantity}
                  </label>
                  <input
                    id="edit_quantity"
                    type="number"
                    required
                    min="0"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: Number.parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_unit" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].unit}
                  </label>
                  <input
                    id="edit_unit"
                    type="text"
                    required
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_supplier" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].supplier}
                  </label>
                  <input
                    id="edit_supplier"
                    type="text"
                    required
                    value={formData.supplier}
                    onChange={(e) => setFormData({ ...formData, supplier: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_purchase_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].purchaseDate}
                  </label>
                  <input
                    id="edit_purchase_date"
                    type="date"
                    required
                    value={formData.purchase_date}
                    onChange={(e) => setFormData({ ...formData, purchase_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_expiry_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].expiryDate}
                  </label>
                  <input
                    id="edit_expiry_date"
                    type="date"
                    required
                    value={formData.expiry_date}
                    onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_status" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].status}
                  </label>
                  <select
                    id="edit_status"
                    required
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        status: e.target.value as "available" | "low-stock" | "out-of-stock",
                      })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="available">{t[locale].available}</option>
                    <option value="low-stock">{t[locale].lowStock}</option>
                    <option value="out-of-stock">{t[locale].outOfStock}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  {locale === "en" ? "Cancel" : "إلغاء"}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                >
                  {locale === "en" ? "Update Supply" : "تحديث المستلزم"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
