import { neon } from "@neondatabase/serverless"

class DatabaseConnectionManager {
  private connections: Map<string, any> = new Map()
  private defaultConnection: any = null

  constructor() {
    // Initialize default connection
    if (process.env.NEON_DATABASE_URL) {
      this.defaultConnection = neon(process.env.NEON_DATABASE_URL)
    }
  }

  // Get connection for a specific company
  getConnection(companyCode?: string, neonUrl?: string) {
    // If no company code, return default connection
    if (!companyCode) {
      return this.defaultConnection
    }

    // Check if connection already exists
    if (this.connections.has(companyCode)) {
      return this.connections.get(companyCode)
    }

    // Create new connection if neonUrl is provided
    if (neonUrl) {
      try {
        const connection = neon(neonUrl)
        this.connections.set(companyCode, connection)
        return connection
      } catch (error) {
        console.error(`[v0] Failed to create connection for ${companyCode}:`, error)
        return this.defaultConnection
      }
    }

    // Fallback to default connection
    return this.defaultConnection
  }

  // Clear a specific connection
  clearConnection(companyCode: string) {
    this.connections.delete(companyCode)
  }

  // Clear all connections
  clearAllConnections() {
    this.connections.clear()
  }
}

// Export singleton instance
export const dbManager = new DatabaseConnectionManager()

// Helper function to get SQL connection based on company
export function getCompanySQL(companyCode?: string, neonUrl?: string) {
  return dbManager.getConnection(companyCode, neonUrl)
}
