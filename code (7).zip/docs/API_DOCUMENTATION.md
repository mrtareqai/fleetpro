# FleetPro Management System - API Documentation
# توثيق واجهة برمجة التطبيقات - نظام إدارة الأسطول FleetPro

**Version:** 1.0.0  
**Last Updated:** December 2024

---

## Table of Contents / جدول المحتويات

1. [Overview / نظرة عامة](#overview)
2. [Authentication / المصادقة](#authentication)
3. [Rate Limiting / تحديد المعدل](#rate-limiting)
4. [Error Handling / معالجة الأخطاء](#error-handling)
5. [API Endpoints / نقاط النهاية](#api-endpoints)
6. [Data Models / نماذج البيانات](#data-models)
7. [Code Examples / أمثلة الكود](#code-examples)
8. [Best Practices / أفضل الممارسات](#best-practices)

---

## Overview / نظرة عامة

### English

The FleetPro Management System API is a RESTful API that provides comprehensive fleet management capabilities including user management, vehicle tracking, driver management, trip scheduling, and more.

**Base URL:**
- Development: `http://localhost:3000`
- Production: `https://api.fleetpro.com`

**API Version:** v1  
**Protocol:** HTTPS (Production), HTTP (Development)  
**Data Format:** JSON

### العربية

واجهة برمجة تطبيقات نظام إدارة الأسطول FleetPro هي واجهة RESTful توفر إمكانيات شاملة لإدارة الأسطول بما في ذلك إدارة المستخدمين، تتبع المركبات، إدارة السائقين، جدولة الرحلات، والمزيد.

**عنوان URL الأساسي:**
- التطوير: `http://localhost:3000`
- الإنتاج: `https://api.fleetpro.com`

**إصدار API:** v1  
**البروتوكول:** HTTPS (الإنتاج)، HTTP (التطوير)  
**تنسيق البيانات:** JSON

---

## Authentication / المصادقة

### English

The API uses JWT (JSON Web Token) authentication. All endpoints except `/api/auth/login` require authentication.

#### Authentication Flow

1. **Login** - Obtain access and refresh tokens
2. **Use Access Token** - Include in Authorization header for API requests
3. **Refresh Token** - Exchange refresh token for new tokens when access token expires
4. **Logout** - Invalidate refresh token

#### Token Lifetimes

- **Access Token:** 15 minutes
- **Refresh Token:** 7 days

#### How to Authenticate

Include the access token in the `Authorization` header:

\`\`\`
Authorization: Bearer <your_access_token>
\`\`\`

### العربية

تستخدم الواجهة مصادقة JWT (رمز الويب JSON). جميع نقاط النهاية باستثناء `/api/auth/login` تتطلب المصادقة.

#### تدفق المصادقة

1. **تسجيل الدخول** - الحصول على رموز الوصول والتحديث
2. **استخدام رمز الوصول** - تضمينه في رأس التفويض لطلبات API
3. **تحديث الرمز** - استبدال رمز التحديث برموز جديدة عند انتهاء صلاحية رمز الوصول
4. **تسجيل الخروج** - إبطال رمز التحديث

#### مدة صلاحية الرموز

- **رمز الوصول:** 15 دقيقة
- **رمز التحديث:** 7 أيام

#### كيفية المصادقة

قم بتضمين رمز الوصول في رأس `Authorization`:

\`\`\`
Authorization: Bearer <your_access_token>
\`\`\`

---

## Rate Limiting / تحديد المعدل

### English

Rate limiting protects the API from abuse and ensures fair usage.

#### Rate Limits by Endpoint Type

| Endpoint Type | Limit | Window |
|--------------|-------|--------|
| Login (`/api/auth/login`) | 5 requests | 15 minutes |
| Admin endpoints (`/api/admin/*`) | 50 requests | 15 minutes |
| Standard endpoints | 100 requests | 15 minutes |

#### Rate Limit Headers

Every response includes rate limit information:

\`\`\`
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640000000
\`\`\`

#### Handling Rate Limits

When rate limit is exceeded, the API returns:

\`\`\`json
{
  "error": "Too many requests",
  "code": "RATE_LIMIT_EXCEEDED",
  "retryAfter": 900
}
\`\`\`

**HTTP Status Code:** 429 Too Many Requests

### العربية

يحمي تحديد المعدل الواجهة من سوء الاستخدام ويضمن الاستخدام العادل.

#### حدود المعدل حسب نوع نقطة النهاية

| نوع نقطة النهاية | الحد | النافذة الزمنية |
|------------------|------|----------------|
| تسجيل الدخول (`/api/auth/login`) | 5 طلبات | 15 دقيقة |
| نقاط نهاية المسؤول (`/api/admin/*`) | 50 طلب | 15 دقيقة |
| نقاط النهاية القياسية | 100 طلب | 15 دقيقة |

#### رؤوس حد المعدل

تتضمن كل استجابة معلومات حد المعدل:

\`\`\`
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1640000000
\`\`\`

#### التعامل مع حدود المعدل

عند تجاوز حد المعدل، ترجع الواجهة:

\`\`\`json
{
  "error": "عدد كبير جداً من الطلبات",
  "code": "RATE_LIMIT_EXCEEDED",
  "retryAfter": 900
}
\`\`\`

**رمز حالة HTTP:** 429 طلبات كثيرة جداً

---

## Error Handling / معالجة الأخطاء

### English

All errors follow a consistent format with appropriate HTTP status codes.

#### Error Response Format

\`\`\`json
{
  "error": "Human-readable error message",
  "code": "ERROR_CODE",
  "details": {
    "field": "Additional error details"
  }
}
\`\`\`

#### HTTP Status Codes

| Code | Meaning | Description |
|------|---------|-------------|
| 200 | OK | Request successful |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Invalid request data |
| 401 | Unauthorized | Authentication required or token invalid |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Resource not found |
| 409 | Conflict | Resource already exists |
| 422 | Unprocessable Entity | Validation failed |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server error |

#### Common Error Codes

- `UNAUTHORIZED` - Authentication required
- `FORBIDDEN` - Insufficient permissions
- `NOT_FOUND` - Resource not found
- `VALIDATION_ERROR` - Invalid input data
- `RATE_LIMIT_EXCEEDED` - Too many requests
- `INVALID_CREDENTIALS` - Wrong username/password
- `TOKEN_EXPIRED` - Access token expired
- `INVALID_TOKEN` - Malformed or invalid token

### العربية

تتبع جميع الأخطاء تنسيقاً موحداً مع رموز حالة HTTP المناسبة.

#### تنسيق استجابة الخطأ

\`\`\`json
{
  "error": "رسالة خطأ قابلة للقراءة",
  "code": "رمز_الخطأ",
  "details": {
    "field": "تفاصيل إضافية للخطأ"
  }
}
\`\`\`

#### رموز حالة HTTP

| الرمز | المعنى | الوصف |
|------|---------|-------|
| 200 | موافق | الطلب ناجح |
| 201 | تم الإنشاء | تم إنشاء المورد بنجاح |
| 400 | طلب خاطئ | بيانات الطلب غير صالحة |
| 401 | غير مصرح | المصادقة مطلوبة أو الرمز غير صالح |
| 403 | محظور | صلاحيات غير كافية |
| 404 | غير موجود | المورد غير موجود |
| 409 | تعارض | المورد موجود بالفعل |
| 422 | كيان غير قابل للمعالجة | فشل التحقق |
| 429 | طلبات كثيرة جداً | تم تجاوز حد المعدل |
| 500 | خطأ في الخادم | خطأ في الخادم |

#### رموز الأخطاء الشائعة

- `UNAUTHORIZED` - المصادقة مطلوبة
- `FORBIDDEN` - صلاحيات غير كافية
- `NOT_FOUND` - المورد غير موجود
- `VALIDATION_ERROR` - بيانات إدخال غير صالحة
- `RATE_LIMIT_EXCEEDED` - طلبات كثيرة جداً
- `INVALID_CREDENTIALS` - اسم مستخدم/كلمة مرور خاطئة
- `TOKEN_EXPIRED` - انتهت صلاحية رمز الوصول
- `INVALID_TOKEN` - رمز غير صالح أو مشوه

---

## API Endpoints / نقاط النهاية

### Authentication Endpoints / نقاط نهاية المصادقة

#### POST /api/auth/login

**English:** Authenticate user and obtain JWT tokens.

**العربية:** مصادقة المستخدم والحصول على رموز JWT.

**Request Body:**
\`\`\`json
{
  "username": "admin",
  "password": "SecurePassword123!"
}
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "success": true,
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "admin",
    "email": "admin@example.com",
    "full_name": "System Administrator",
    "roles": [
      {
        "id": 1,
        "name": "super_admin",
        "display_name": "Super Administrator"
      }
    ]
  },
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
\`\`\`

**Rate Limit:** 5 requests per 15 minutes per IP

**Security Notes:**
- Passwords are hashed using bcrypt with salt rounds of 12
- Failed login attempts are logged for security monitoring
- Consider implementing account lockout after multiple failed attempts

---

#### POST /api/auth/refresh

**English:** Exchange refresh token for new access and refresh tokens.

**العربية:** استبدال رمز التحديث برموز وصول وتحديث جديدة.

**Request Body:**
\`\`\`json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
\`\`\`

**Error Response (401 Unauthorized):**
\`\`\`json
{
  "error": "Invalid or expired refresh token",
  "code": "INVALID_TOKEN"
}
\`\`\`

---

#### POST /api/auth/logout

**English:** Invalidate refresh token and logout user.

**العربية:** إبطال رمز التحديث وتسجيل خروج المستخدم.

**Headers:**
\`\`\`
Authorization: Bearer <access_token>
\`\`\`

**Request Body:**
\`\`\`json
{
  "refreshToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "success": true
}
\`\`\`

---

### User Management Endpoints / نقاط نهاية إدارة المستخدمين

#### GET /api/admin/users

**English:** Retrieve list of all users with their roles.

**العربية:** استرجاع قائمة بجميع المستخدمين مع أدوارهم.

**Required Permission:** `users.read`

**Headers:**
\`\`\`
Authorization: Bearer <access_token>
\`\`\`

**Query Parameters:**
- `company_id` (optional): Filter by company ID
- `role` (optional): Filter by role name

**Example Request:**
\`\`\`
GET /api/admin/users?company_id=1&role=fleet_manager
\`\`\`

**Response (200 OK):**
\`\`\`json
{
  "users": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "username": "john.doe",
      "email": "john.doe@example.com",
      "full_name": "John Doe",
      "company_id": 1,
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-15T10:30:00Z",
      "roles": [
        {
          "id": 3,
          "name": "fleet_manager",
          "display_name": "Fleet Manager",
          "description": "Manage fleet operations"
        }
      ]
    }
  ]
}
\`\`\`

---

#### POST /api/admin/users

**English:** Create a new user account.

**العربية:** إنشاء حساب مستخدم جديد.

**Required Permission:** `users.create`

**Headers:**
\`\`\`
Authorization: Bearer <access_token>
\`\`\`

**Request Body:**
\`\`\`json
{
  "username": "john.doe",
  "email": "john.doe@example.com",
  "password": "SecurePass123!",
  "full_name": "John Doe",
  "company_id": 1,
  "role_ids": [3, 4]
}
\`\`\`

**Validation Rules:**
- `username`: 3-50 characters, alphanumeric and underscore only
- `email`: Valid email format
- `password`: Minimum 8 characters
- `full_name`: Required, non-empty
- `role_ids`: Array of valid role IDs

**Response (201 Created):**
\`\`\`json
{
  "user": {
    "id": "660e8400-e29b-41d4-a716-446655440001",
    "username": "john.doe",
    "email": "john.doe@example.com",
    "full_name": "John Doe",
    "company_id": 1,
    "created_at": "2024-12-20T14:30:00Z",
    "roles": [
      {
        "id": 3,
        "name": "fleet_manager",
        "display_name": "Fleet Manager"
      },
      {
        "id": 4,
        "name": "dispatcher",
        "display_name": "Dispatcher"
      }
    ]
  }
}
\`\`\`

**Error Response (409 Conflict):**
\`\`\`json
{
  "error": "Username already exists",
  "code": "DUPLICATE_USERNAME"
}
\`\`\`

---

#### GET /api/admin/users/{id}

**English:** Get detailed information about a specific user.

**العربية:** الحصول على معلومات تفصيلية عن مستخدم محدد.

**Required Permission:** `users.read`

**Path Parameters:**
- `id`: User UUID

**Response (200 OK):**
\`\`\`json
{
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "john.doe",
    "email": "john.doe@example.com",
    "full_name": "John Doe",
    "company_id": 1,
    "created_at": "2024-01-15T10:30:00Z",
    "updated_at": "2024-12-20T14:30:00Z",
    "roles": [
      {
        "id": 3,
        "name": "fleet_manager",
        "display_name": "Fleet Manager",
        "description": "Manage fleet operations"
      }
    ]
  }
}
\`\`\`

---

#### PUT /api/admin/users/{id}

**English:** Update user information and roles.

**العربية:** تحديث معلومات المستخدم والأدوار.

**Required Permission:** `users.update`

**Path Parameters:**
- `id`: User UUID

**Request Body:**
\`\`\`json
{
  "username": "john.doe.updated",
  "email": "john.updated@example.com",
  "full_name": "John Doe Updated",
  "company_id": 2,
  "role_ids": [3]
}
\`\`\`

**Notes:**
- All fields are optional
- Password cannot be updated through this endpoint
- Username must be unique if changed

**Response (200 OK):**
\`\`\`json
{
  "user": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "john.doe.updated",
    "email": "john.updated@example.com",
    "full_name": "John Doe Updated",
    "company_id": 2,
    "updated_at": "2024-12-20T15:00:00Z",
    "roles": [
      {
        "id": 3,
        "name": "fleet_manager",
        "display_name": "Fleet Manager"
      }
    ]
  }
}
\`\`\`

---

#### DELETE /api/admin/users/{id}

**English:** Permanently delete a user account.

**العربية:** حذف حساب مستخدم بشكل دائم.

**Required Permission:** `users.delete`

**Path Parameters:**
- `id`: User UUID

**Response (200 OK):**
\`\`\`json
{
  "success": true
}
\`\`\`

**Warning:** This action cannot be undone. Consider implementing soft delete for production environments.

---

### Role Management Endpoints / نقاط نهاية إدارة الأدوار

#### GET /api/admin/roles

**English:** Retrieve all available roles.

**العربية:** استرجاع جميع الأدوار المتاحة.

**Required Permission:** `roles.read`

**Response (200 OK):**
\`\`\`json
{
  "roles": [
    {
      "id": 1,
      "name": "super_admin",
      "display_name": "Super Administrator",
      "description": "Full system access",
      "is_system": true,
      "created_at": "2024-01-01T00:00:00Z"
    },
    {
      "id": 2,
      "name": "admin",
      "display_name": "Administrator",
      "description": "Administrative access",
      "is_system": true,
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
\`\`\`

---

#### GET /api/admin/roles/{id}

**English:** Get role details with associated permissions.

**العربية:** الحصول على تفاصيل الدور مع الصلاحيات المرتبطة.

**Required Permission:** `roles.read`

**Path Parameters:**
- `id`: Role ID

**Response (200 OK):**
\`\`\`json
{
  "role": {
    "id": 3,
    "name": "fleet_manager",
    "display_name": "Fleet Manager",
    "description": "Manage fleet operations",
    "is_system": true,
    "created_at": "2024-01-01T00:00:00Z",
    "permissions": [
      {
        "id": 5,
        "name": "vehicles.create",
        "display_name": "Create Vehicles",
        "resource": "vehicles",
        "action": "create"
      },
      {
        "id": 6,
        "name": "vehicles.read",
        "display_name": "View Vehicles",
        "resource": "vehicles",
        "action": "read"
      }
    ]
  }
}
\`\`\`

---

#### GET /api/admin/permissions

**English:** Retrieve all available permissions.

**العربية:** استرجاع جميع الصلاحيات المتاحة.

**Required Permission:** `roles.read`

**Response (200 OK):**
\`\`\`json
{
  "permissions": [
    {
      "id": 1,
      "name": "users.create",
      "display_name": "Create Users",
      "description": "Ability to create new user accounts",
      "resource": "users",
      "action": "create",
      "created_at": "2024-01-01T00:00:00Z"
    },
    {
      "id": 2,
      "name": "users.read",
      "display_name": "View Users",
      "description": "Ability to view user information",
      "resource": "users",
      "action": "read",
      "created_at": "2024-01-01T00:00:00Z"
    }
  ]
}
\`\`\`

---

### Driver Management Endpoints / نقاط نهاية إدارة السائقين

#### GET /api/drivers

**English:** Retrieve list of all drivers.

**العربية:** استرجاع قائمة بجميع السائقين.

**Required Permission:** `drivers.read`

**Query Parameters:**
- `status` (optional): Filter by status (active, inactive, on_leave)
- `company_id` (optional): Filter by company ID

**Response (200 OK):**
\`\`\`json
[
  {
    "id": 1,
    "name": "Ahmed Hassan",
    "license_number": "DL123456",
    "phone": "+966501234567",
    "email": "ahmed@example.com",
    "status": "active",
    "company_id": 1,
    "created_at": "2024-01-10T08:00:00Z",
    "updated_at": "2024-01-10T08:00:00Z"
  }
]
\`\`\`

---

#### POST /api/drivers

**English:** Create a new driver.

**العربية:** إنشاء سائق جديد.

**Required Permission:** `drivers.create`

**Request Body:**
\`\`\`json
{
  "name": "Ahmed Hassan",
  "license_number": "DL123456",
  "phone": "+966501234567",
  "email": "ahmed@example.com",
  "status": "active",
  "company_id": 1
}
\`\`\`

**Validation Rules:**
- `name`: Required, non-empty
- `license_number`: Required, unique
- `phone`: Optional, valid phone format
- `email`: Optional, valid email format
- `status`: Optional, one of: active, inactive, on_leave

**Response (201 Created):**
\`\`\`json
{
  "id": 2,
  "name": "Ahmed Hassan",
  "license_number": "DL123456",
  "phone": "+966501234567",
  "email": "ahmed@example.com",
  "status": "active",
  "company_id": 1,
  "created_at": "2024-12-20T16:00:00Z",
  "updated_at": "2024-12-20T16:00:00Z"
}
\`\`\`

---

### Vehicle Management Endpoints / نقاط نهاية إدارة المركبات

#### GET /api/vehicles

**English:** Retrieve list of all vehicles.

**العربية:** استرجاع قائمة بجميع المركبات.

**Required Permission:** `vehicles.read`

**Query Parameters:**
- `status` (optional): Filter by status (active, maintenance, inactive)
- `company_id` (optional): Filter by company ID

**Response (200 OK):**
\`\`\`json
[
  {
    "id": 1,
    "plate_number": "ABC-1234",
    "model": "Mercedes-Benz Sprinter",
    "base_number": "BASE-001",
    "card_number": "CARD-001",
    "country": "Saudi Arabia",
    "manufacture_date": "2023-01-15",
    "issue_date": "2023-02-01",
    "expiry_date": "2025-02-01",
    "status": "active",
    "company_id": 1,
    "created_at": "2024-01-05T10:00:00Z",
    "updated_at": "2024-01-05T10:00:00Z"
  }
]
\`\`\`

---

#### POST /api/vehicles

**English:** Add a new vehicle to the fleet.

**العربية:** إضافة مركبة جديدة إلى الأسطول.

**Required Permission:** `vehicles.create`

**Request Body:**
\`\`\`json
{
  "plate_number": "ABC-1234",
  "model": "Mercedes-Benz Sprinter",
  "base_number": "BASE-001",
  "card_number": "CARD-001",
  "country": "Saudi Arabia",
  "manufacture_date": "2023-01-15",
  "issue_date": "2023-02-01",
  "expiry_date": "2025-02-01",
  "status": "active",
  "company_id": 1
}
\`\`\`

**Validation Rules:**
- `plate_number`: Required, unique
- `model`: Required
- `status`: Optional, one of: active, maintenance, inactive
- Dates must be in YYYY-MM-DD format

**Response (201 Created):**
\`\`\`json
{
  "id": 2,
  "plate_number": "ABC-1234",
  "model": "Mercedes-Benz Sprinter",
  "base_number": "BASE-001",
  "status": "active",
  "company_id": 1,
  "created_at": "2024-12-20T17:00:00Z",
  "updated_at": "2024-12-20T17:00:00Z"
}
\`\`\`

---

### Movement Management Endpoints / نقاط نهاية إدارة الحركة

#### GET /api/movements

**English:** Retrieve list of all trip movements.

**العربية:** استرجاع قائمة بجميع حركات الرحلات.

**Required Permission:** `movements.read`

**Query Parameters:**
- `status` (optional): Filter by status
- `trip_date` (optional): Filter by date (YYYY-MM-DD)
- `driver_name` (optional): Filter by driver name

**Response (200 OK):**
\`\`\`json
[
  {
    "id": 1,
    "driver_name": "Ahmed Hassan",
    "assistant_name": "Mohammed Ali",
    "bus_number": "BUS-101",
    "trip_name": "Riyadh to Jeddah",
    "trip_date": "2024-12-25",
    "trip_time": "08:00:00",
    "seats": 45,
    "pending_seats": 10,
    "status": "scheduled",
    "movement_type": "trip",
    "category": "intercity",
    "priority": "medium",
    "created_at": "2024-12-20T10:00:00Z",
    "updated_at": "2024-12-20T10:00:00Z"
  }
]
\`\`\`

---

#### POST /api/movements

**English:** Schedule a new trip movement.

**العربية:** جدولة حركة رحلة جديدة.

**Required Permission:** `movements.create`

**Request Body:**
\`\`\`json
{
  "driver_name": "Ahmed Hassan",
  "assistant_name": "Mohammed Ali",
  "bus_number": "BUS-101",
  "trip_name": "Riyadh to Jeddah",
  "trip_date": "2024-12-25",
  "trip_time": "08:00:00",
  "seats": 45,
  "pending_seats": 0,
  "status": "scheduled"
}
\`\`\`

**Business Rules:**
- `pending_seats` cannot exceed `seats`
- `trip_date` should be in the future
- `trip_time` must be in HH:MM:SS format

**Response (201 Created):**
\`\`\`json
{
  "id": 2,
  "driver_name": "Ahmed Hassan",
  "assistant_name": "Mohammed Ali",
  "bus_number": "BUS-101",
  "trip_name": "Riyadh to Jeddah",
  "trip_date": "2024-12-25",
  "trip_time": "08:00:00",
  "seats": 45,
  "pending_seats": 0,
  "status": "scheduled",
  "movement_type": "trip",
  "category": "intercity",
  "priority": "medium",
  "created_at": "2024-12-20T18:00:00Z",
  "updated_at": "2024-12-20T18:00:00Z"
}
\`\`\`

---

#### PUT /api/movements/{id}

**English:** Update an existing movement.

**العربية:** تحديث حركة موجودة.

**Required Permission:** `movements.update`

**Path Parameters:**
- `id`: Movement ID

**Request Body:** Same as POST /api/movements

**Response (200 OK):** Updated movement object

---

#### DELETE /api/movements/{id}

**English:** Delete a movement.

**العربية:** حذف حركة.

**Required Permission:** `movements.delete`

**Path Parameters:**
- `id`: Movement ID

**Response (200 OK):**
\`\`\`json
{
  "success": true
}
\`\`\`

**Note:** Consider changing status to 'cancelled' instead of deleting for audit trail purposes.

---

## Code Examples / أمثلة الكود

### JavaScript/TypeScript Example

\`\`\`typescript
// Authentication and API Client Setup
class FleetProAPI {
  private baseURL: string
  private accessToken: string | null = null
  private refreshToken: string | null = null

  constructor(baseURL: string = 'http://localhost:3000') {
    this.baseURL = baseURL
  }

  // Login
  async login(username: string, password: string) {
    const response = await fetch(`${this.baseURL}/api/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error)
    }

    const data = await response.json()
    this.accessToken = data.accessToken
    this.refreshToken = data.refreshToken
    
    return data
  }

  // Refresh Token
  async refreshAccessToken() {
    if (!this.refreshToken) {
      throw new Error('No refresh token available')
    }

    const response = await fetch(`${this.baseURL}/api/auth/refresh`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ refreshToken: this.refreshToken }),
    })

    if (!response.ok) {
      throw new Error('Failed to refresh token')
    }

    const data = await response.json()
    this.accessToken = data.accessToken
    this.refreshToken = data.refreshToken
    
    return data
  }

  // Generic API Request with Auto-Retry on Token Expiry
  async request(endpoint: string, options: RequestInit = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...(this.accessToken && { Authorization: `Bearer ${this.accessToken}` }),
      ...options.headers,
    }

    let response = await fetch(`${this.baseURL}${endpoint}`, {
      ...options,
      headers,
    })

    // If token expired, refresh and retry
    if (response.status === 401 && this.refreshToken) {
      await this.refreshAccessToken()
      
      headers.Authorization = `Bearer ${this.accessToken}`
      response = await fetch(`${this.baseURL}${endpoint}`, {
        ...options,
        headers,
      })
    }

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.error || 'Request failed')
    }

    return response.json()
  }

  // Get all users
  async getUsers(filters?: { company_id?: number; role?: string }) {
    const params = new URLSearchParams()
    if (filters?.company_id) params.append('company_id', filters.company_id.toString())
    if (filters?.role) params.append('role', filters.role)
    
    const query = params.toString() ? `?${params.toString()}` : ''
    return this.request(`/api/admin/users${query}`)
  }

  // Create user
  async createUser(userData: {
    username: string
    email: string
    password: string
    full_name: string
    company_id?: number
    role_ids?: number[]
  }) {
    return this.request('/api/admin/users', {
      method: 'POST',
      body: JSON.stringify(userData),
    })
  }

  // Get drivers
  async getDrivers(filters?: { status?: string; company_id?: number }) {
    const params = new URLSearchParams()
    if (filters?.status) params.append('status', filters.status)
    if (filters?.company_id) params.append('company_id', filters.company_id.toString())
    
    const query = params.toString() ? `?${params.toString()}` : ''
    return this.request(`/api/drivers${query}`)
  }

  // Create movement
  async createMovement(movementData: {
    driver_name: string
    bus_number: string
    trip_name: string
    trip_date: string
    trip_time: string
    seats: number
    assistant_name?: string
    pending_seats?: number
    status?: string
  }) {
    return this.request('/api/movements', {
      method: 'POST',
      body: JSON.stringify(movementData),
    })
  }
}

// Usage Example
async function example() {
  const api = new FleetProAPI()

  try {
    // Login
    const loginResult = await api.login('admin', 'password123')
    console.log('Logged in:', loginResult.user)

    // Get users
    const users = await api.getUsers({ company_id: 1 })
    console.log('Users:', users)

    // Create a new driver
    const newDriver = await api.createUser({
      username: 'driver1',
      email: 'driver1@example.com',
      password: 'SecurePass123!',
      full_name: 'Driver One',
      role_ids: [3],
    })
    console.log('Created driver:', newDriver)

    // Get active drivers
    const drivers = await api.getDrivers({ status: 'active' })
    console.log('Active drivers:', drivers)

    // Schedule a trip
    const movement = await api.createMovement({
      driver_name: 'Ahmed Hassan',
      bus_number: 'BUS-101',
      trip_name: 'Riyadh to Jeddah',
      trip_date: '2024-12-25',
      trip_time: '08:00:00',
      seats: 45,
    })
    console.log('Scheduled trip:', movement)

  } catch (error) {
    console.error('Error:', error)
  }
}
\`\`\`

### Python Example

\`\`\`python
import requests
from typing import Optional, Dict, Any

class FleetProAPI:
    def __init__(self, base_url: str = "http://localhost:3000"):
        self.base_url = base_url
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None

    def login(self, username: str, password: str) -> Dict[str, Any]:
        """Authenticate and obtain tokens"""
        response = requests.post(
            f"{self.base_url}/api/auth/login",
            json={"username": username, "password": password}
        )
        response.raise_for_status()
        
        data = response.json()
        self.access_token = data["accessToken"]
        self.refresh_token = data["refreshToken"]
        
        return data

    def refresh_access_token(self) -> Dict[str, Any]:
        """Refresh the access token"""
        if not self.refresh_token:
            raise ValueError("No refresh token available")
        
        response = requests.post(
            f"{self.base_url}/api/auth/refresh",
            json={"refreshToken": self.refresh_token}
        )
        response.raise_for_status()
        
        data = response.json()
        self.access_token = data["accessToken"]
        self.refresh_token = data["refreshToken"]
        
        return data

    def request(self, endpoint: str, method: str = "GET", **kwargs) -> Dict[str, Any]:
        """Make authenticated API request with auto-retry on token expiry"""
        headers = kwargs.pop("headers", {})
        if self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        
        response = requests.request(
            method,
            f"{self.base_url}{endpoint}",
            headers=headers,
            **kwargs
        )
        
        # If token expired, refresh and retry
        if response.status_code == 401 and self.refresh_token:
            self.refresh_access_token()
            headers["Authorization"] = f"Bearer {self.access_token}"
            response = requests.request(
                method,
                f"{self.base_url}{endpoint}",
                headers=headers,
                **kwargs
            )
        
        response.raise_for_status()
        return response.json()

    def get_users(self, company_id: Optional[int] = None, role: Optional[str] = None):
        """Get all users with optional filters"""
        params = {}
        if company_id:
            params["company_id"] = company_id
        if role:
            params["role"] = role
        
        return self.request("/api/admin/users", params=params)

    def create_user(self, username: str, email: str, password: str, 
                   full_name: str, company_id: Optional[int] = None,
                   role_ids: Optional[list] = None):
        """Create a new user"""
        data = {
            "username": username,
            "email": email,
            "password": password,
            "full_name": full_name
        }
        if company_id:
            data["company_id"] = company_id
        if role_ids:
            data["role_ids"] = role_ids
        
        return self.request("/api/admin/users", method="POST", json=data)

    def get_movements(self, status: Optional[str] = None, 
                     trip_date: Optional[str] = None):
        """Get all movements with optional filters"""
        params = {}
        if status:
            params["status"] = status
        if trip_date:
            params["trip_date"] = trip_date
        
        return self.request("/api/movements", params=params)

# Usage Example
if __name__ == "__main__":
    api = FleetProAPI()
    
    try:
        # Login
        login_result = api.login("admin", "password123")
        print(f"Logged in as: {login_result['user']['username']}")
        
        # Get users
        users = api.get_users(company_id=1)
        print(f"Found {len(users['users'])} users")
        
        # Get movements
        movements = api.get_movements(status="scheduled")
        print(f"Found {len(movements)} scheduled movements")
        
    except requests.exceptions.HTTPError as e:
        print(f"HTTP Error: {e}")
    except Exception as e:
        print(f"Error: {e}")
\`\`\`

### cURL Examples

\`\`\`bash
# Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "password123"
  }'

# Get users (with authentication)
curl -X GET http://localhost:3000/api/admin/users \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Create user
curl -X POST http://localhost:3000/api/admin/users \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "username": "john.doe",
    "email": "john@example.com",
    "password": "SecurePass123!",
    "full_name": "John Doe",
    "role_ids": [3]
  }'

# Get drivers with filter
curl -X GET "http://localhost:3000/api/drivers?status=active" \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"

# Create movement
curl -X POST http://localhost:3000/api/movements \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "driver_name": "Ahmed Hassan",
    "bus_number": "BUS-101",
    "trip_name": "Riyadh to Jeddah",
    "trip_date": "2024-12-25",
    "trip_time": "08:00:00",
    "seats": 45
  }'

# Refresh token
curl -X POST http://localhost:3000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{
    "refreshToken": "YOUR_REFRESH_TOKEN"
  }'
\`\`\`

---

## Best Practices / أفضل الممارسات

### English

1. **Always use HTTPS in production** - Never send credentials over unencrypted connections

2. **Store tokens securely**
   - Use httpOnly cookies for refresh tokens
   - Store access tokens in memory, not localStorage
   - Never log tokens

3. **Handle token expiration gracefully**
   - Implement automatic token refresh
   - Provide clear error messages
   - Redirect to login when refresh fails

4. **Respect rate limits**
   - Implement exponential backoff
   - Cache responses when appropriate
   - Monitor rate limit headers

5. **Validate input on client side**
   - Reduce unnecessary API calls
   - Provide immediate feedback
   - Still validate on server side

6. **Handle errors properly**
   - Check HTTP status codes
   - Parse error responses
   - Provide user-friendly messages

7. **Use appropriate HTTP methods**
   - GET for reading
   - POST for creating
   - PUT for updating
   - DELETE for removing

8. **Implement proper logging**
   - Log all authentication attempts
   - Track API usage
   - Monitor for suspicious activity

### العربية

1. **استخدم دائماً HTTPS في الإنتاج** - لا ترسل بيانات الاعتماد عبر اتصالات غير مشفرة

2. **احفظ الرموز بشكل آمن**
   - استخدم ملفات تعريف الارتباط httpOnly لرموز التحديث
   - احفظ رموز الوصول في الذاكرة، وليس في localStorage
   - لا تسجل الرموز أبداً

3. **تعامل مع انتهاء صلاحية الرمز بشكل سلس**
   - نفذ تحديث الرمز التلقائي
   - قدم رسائل خطأ واضحة
   - أعد التوجيه إلى تسجيل الدخول عند فشل التحديث

4. **احترم حدود المعدل**
   - نفذ التراجع الأسي
   - خزن الاستجابات عند الاقتضاء
   - راقب رؤوس حد المعدل

5. **تحقق من الإدخال على جانب العميل**
   - قلل من استدعاءات API غير الضرورية
   - قدم ملاحظات فورية
   - تحقق أيضاً على جانب الخادم

6. **تعامل مع الأخطاء بشكل صحيح**
   - تحقق من رموز حالة HTTP
   - حلل استجابات الخطأ
   - قدم رسائل سهلة الاستخدام

7. **استخدم طرق HTTP المناسبة**
   - GET للقراءة
   - POST للإنشاء
   - PUT للتحديث
   - DELETE للحذف

8. **نفذ التسجيل المناسب**
   - سجل جميع محاولات المصادقة
   - تتبع استخدام API
   - راقب النشاط المشبوه

---

## Support / الدعم

### English

For API support and questions:
- Email: support@fleetpro.com
- Documentation: https://docs.fleetpro.com
- GitHub Issues: https://github.com/fleetpro/api/issues

### العربية

للحصول على دعم API والأسئلة:
- البريد الإلكتروني: support@fleetpro.com
- التوثيق: https://docs.fleetpro.com
- مشاكل GitHub: https://github.com/fleetpro/api/issues

---

**Last Updated:** December 2024  
**API Version:** 1.0.0
