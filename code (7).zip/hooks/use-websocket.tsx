"use client"

import { useEffect } from "react"
import { getWebSocketClient } from "@/lib/websocket-client"

type MessageHandler = (data: any) => void

export function useWebSocket(handler: MessageHandler) {
  useEffect(() => {
    const client = getWebSocketClient()
    client.connect()

    const unsubscribe = client.onMessage(handler)

    return () => {
      unsubscribe()
    }
  }, [handler])
}
