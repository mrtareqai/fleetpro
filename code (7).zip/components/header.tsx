"use client"

import { Menu, Bell } from "lucide-react"

interface HeaderProps {
  locale: "en" | "ar"
  onMenuClick?: () => void
}

export default function Header({ locale, onMenuClick }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 lg:hidden">
      <div className="flex items-center justify-between px-4 py-3">
        <button
          onClick={onMenuClick}
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors touch-manipulation"
          aria-label="Open menu"
        >
          <Menu className="w-6 h-6 text-slate-700" />
        </button>

        <div className="flex items-center gap-2">
          <div className="bg-slate-700 p-1.5 rounded-lg">
            <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z" />
            </svg>
          </div>
          <span className="text-lg font-bold text-slate-800">FleetPro</span>
        </div>

        <button
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors touch-manipulation relative"
          aria-label="Notifications"
        >
          <Bell className="w-6 h-6 text-slate-700" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full"></span>
        </button>
      </div>
    </header>
  )
}
