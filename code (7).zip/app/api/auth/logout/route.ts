/**
 * Logout API Endpoint
 *
 * POST /api/auth/logout
 *
 * Logs out the current user.
 *
 * Note: With JWT, logout is primarily handled client-side by removing tokens.
 * This endpoint can be used for additional cleanup (e.g., token blacklisting).
 */

import { type NextRequest, NextResponse } from "next/server"
import { requireAuth } from "@/lib/security/api-auth"

export async function POST(request: NextRequest) {
  const authResult = await requireAuth(request, { checkRateLimit: false })
  if (authResult instanceof Response) return authResult

  // In a production system, you might want to:
  // 1. Add token to blacklist (requires Redis or database)
  // 2. Log the logout event
  // 3. Clear any server-side sessions

  return NextResponse.json({
    message: "Logged out successfully",
  })
}
