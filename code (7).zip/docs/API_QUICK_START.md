# FleetPro API Quick Start Guide
# دليل البدء السريع لواجهة FleetPro API

This guide will help you get started with the FleetPro API in 5 minutes.

سيساعدك هذا الدليل على البدء مع واجهة FleetPro API في 5 دقائق.

---

## Step 1: Get Your Credentials / الخطوة 1: احصل على بيانات الاعتماد

Contact your system administrator to get:
- Username / اسم المستخدم
- Password / كلمة المرور
- API Base URL / عنوان URL الأساسي للواجهة

---

## Step 2: Login / الخطوة 2: تسجيل الدخول

\`\`\`bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "your_username",
    "password": "your_password"
  }'
\`\`\`

**Response:**
\`\`\`json
{
  "success": true,
  "user": { ... },
  "accessToken": "eyJhbGc...",
  "refreshToken": "eyJhbGc..."
}
\`\`\`

Save the `accessToken` - you'll need it for all subsequent requests.

احفظ `accessToken` - ستحتاجه لجميع الطلبات اللاحقة.

---

## Step 3: Make Your First API Call / الخطوة 3: قم بأول استدعاء API

\`\`\`bash
curl -X GET http://localhost:3000/api/drivers \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
\`\`\`

---

## Step 4: Create a Resource / الخطوة 4: أنشئ مورداً

\`\`\`bash
curl -X POST http://localhost:3000/api/drivers \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Ahmed Hassan",
    "license_number": "DL123456",
    "phone": "+966501234567",
    "status": "active"
  }'
\`\`\`

---

## Common Errors / الأخطاء الشائعة

### 401 Unauthorized
Your token is invalid or expired. Login again.

الرمز الخاص بك غير صالح أو منتهي الصلاحية. سجل الدخول مرة أخرى.

### 403 Forbidden
You don't have permission for this action. Contact your administrator.

ليس لديك إذن لهذا الإجراء. اتصل بالمسؤول.

### 429 Too Many Requests
You've exceeded the rate limit. Wait and try again.

لقد تجاوزت حد المعدل. انتظر وحاول مرة أخرى.

---

## Next Steps / الخطوات التالية

- Read the full [API Documentation](./API_DOCUMENTATION.md)
- Explore the [OpenAPI Specification](./openapi.yaml)
- Check out [Code Examples](./API_DOCUMENTATION.md#code-examples)

---

**Need Help?** support@fleetpro.com
