"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Plus, Edit, Trash2, Scan, X } from "lucide-react"
import { apiClient } from "@/lib/api-client"
import { useWebSocket } from "@/lib/websocket-client"
import { useSelection } from "@/lib/selection-context"
import { useAuth } from "@/lib/auth-context"

interface TicketsTableProps {
  locale: "en" | "ar"
}

interface Ticket {
  id: number
  passenger_name: string
  trip_number: string
  trip_name: string
  trip_date: string
  ticket_number: string
  trip_time: string
  seat_number: string
  mobile_number: string
  issue_date: string
  user: string
  branch: string
  status: "confirmed" | "pending" | "cancelled"
}

export default function TicketsTable({ locale }: TicketsTableProps) {
  const [tickets, setTickets] = useState<Ticket[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingTicket, setEditingTicket] = useState<Ticket | null>(null)
  const [formData, setFormData] = useState({
    passenger_name: "",
    trip_number: "",
    trip_name: "",
    trip_date: "",
    ticket_number: "",
    trip_time: "",
    seat_number: "",
    mobile_number: "",
    issue_date: "",
    user: "",
    branch: "",
    status: "confirmed" as "confirmed" | "pending" | "cancelled",
  })
  const modalRef = useRef<HTMLDivElement>(null)
  const editModalRef = useRef<HTMLDivElement>(null)

  const { isSelectionMode, toggleSelectionMode, selectedItems, toggleItem, selectAll, clearSelection, isSelected } =
    useSelection()
  const { hasPermission } = useAuth()

  const t = {
    en: {
      title: "Tickets Management",
      add: "Add",
      edit: "Edit",
      delete: "Delete",
      passengerName: "Passenger Name",
      tripNumber: "Trip Number",
      trip: "Trip",
      tripDate: "Trip Date",
      ticketNumber: "Ticket Number",
      tripTime: "Trip Time",
      seatNumber: "Seat Number",
      mobileNumber: "Mobile Number",
      issueDate: "Issue Date",
      user: "User",
      branch: "Branch",
      status: "Status",
      confirmed: "Confirmed",
      pending: "Pending",
      cancelled: "Cancelled",
      loading: "Loading...",
      error: "Error loading data",
      scan: "Scan",
      selectAll: "Select All",
      selected: "selected",
      deleteSelected: "Delete Selected",
      selectionModeActive: "Selection mode active - Select items to delete",
    },
    ar: {
      title: "إدارة التذاكر",
      add: "إضافة",
      edit: "تعديل",
      delete: "حذف",
      passengerName: "اسم الراكب",
      tripNumber: "رقم الرحلة",
      trip: "الرحلة",
      tripDate: "تاريخ الرحلة",
      ticketNumber: "رقم التذكرة",
      tripTime: "وقت الرحلة",
      seatNumber: "رقم المقعد",
      mobileNumber: "رقم الجوال",
      issueDate: "تاريخ الإصدار",
      user: "المستخدم",
      branch: "الفرع",
      status: "الحالة",
      confirmed: "مؤكد",
      pending: "معلق",
      cancelled: "ملغي",
      loading: "جاري التحميل...",
      error: "خطأ في تحميل البيانات",
      scan: "مسح",
      selectAll: "تحديد الكل",
      selected: "محدد",
      deleteSelected: "حذف المحدد",
      selectionModeActive: "وضع التحديد نشط - حدد العناصر للحذف",
    },
  }

  useEffect(() => {
    fetchTickets()
  }, [])

  useWebSocket((message) => {
    if (message.type === "ticket_update") {
      fetchTickets()
    }
  })

  const fetchTickets = async () => {
    try {
      setLoading(true)
      const data = await apiClient.getTickets()
      console.log("[v0] Fetched tickets data:", data)
      setTickets(data)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch tickets")
      console.error("[v0] Error fetching tickets:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    const itemsToDelete = isSelectionMode ? Array.from(selectedItems) : selectedId ? [selectedId] : []

    if (itemsToDelete.length === 0) {
      alert(locale === "en" ? "Please select items to delete" : "الرجاء تحديد عناصر للحذف")
      return
    }

    if (!confirm(locale === "en" ? `Delete ${itemsToDelete.length} item(s)?` : `حذف ${itemsToDelete.length} عنصر؟`)) {
      return
    }

    try {
      for (const id of itemsToDelete) {
        await apiClient.deleteTicket(id)
      }
      setSelectedId(null)
      clearSelection()
      fetchTickets()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete items" : "فشل حذف العناصر")
      console.error("[v0] Error deleting tickets:", err)
    }
  }

  const handleRowClick = (id: number) => {
    if (isSelectionMode) {
      toggleItem(id)
    } else {
      setSelectedId(id)
    }
  }

  const handleSelectAll = () => {
    selectAll(tickets.map((t) => t.id))
  }

  const handleEditClick = () => {
    if (!selectedId) return
    const ticket = tickets.find((t) => t.id === selectedId)
    if (ticket) {
      setEditingTicket(ticket)
      setFormData({
        passenger_name: ticket.passenger_name,
        trip_number: ticket.trip_number,
        trip_name: ticket.trip_name,
        trip_date: ticket.trip_date,
        ticket_number: ticket.ticket_number,
        trip_time: ticket.trip_time,
        seat_number: ticket.seat_number,
        mobile_number: ticket.mobile_number,
        issue_date: ticket.issue_date,
        user: ticket.user,
        branch: ticket.branch,
        status: ticket.status,
      })
      setShowEditModal(true)
    }
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingTicket) return
    try {
      await apiClient.updateTicket(editingTicket.id, formData)
      setShowEditModal(false)
      setEditingTicket(null)
      setSelectedId(null)
      setFormData({
        passenger_name: "",
        trip_number: "",
        trip_name: "",
        trip_date: "",
        ticket_number: "",
        trip_time: "",
        seat_number: "",
        mobile_number: "",
        issue_date: "",
        user: "",
        branch: "",
        status: "confirmed",
      })
      fetchTickets()
    } catch (err) {
      alert(locale === "en" ? "Failed to update ticket" : "فشل تحديث التذكرة")
      console.error("[v0] Error updating ticket:", err)
    }
  }

  useEffect(() => {
    if (showAddModal) {
      document.body.style.overflow = "hidden"
      const firstInput = modalRef.current?.querySelector("input")
      firstInput?.focus()
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [showAddModal])

  useEffect(() => {
    if (showEditModal) {
      document.body.style.overflow = "hidden"
      const firstInput = editModalRef.current?.querySelector("input")
      firstInput?.focus()
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [showEditModal])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (showAddModal) setShowAddModal(false)
        if (showEditModal) setShowEditModal(false)
      }
    }
    window.addEventListener("keydown", handleEscape)
    return () => window.removeEventListener("keydown", handleEscape)
  }, [showAddModal, showEditModal])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiClient.addTicket(formData)
      setShowAddModal(false)
      setFormData({
        passenger_name: "",
        trip_number: "",
        trip_name: "",
        trip_date: "",
        ticket_number: "",
        trip_time: "",
        seat_number: "",
        mobile_number: "",
        issue_date: "",
        user: "",
        branch: "",
        status: "confirmed",
      })
      fetchTickets()
    } catch (err) {
      alert(locale === "en" ? "Failed to add ticket" : "فشل إضافة التذكرة")
      console.error("[v0] Error adding ticket:", err)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-red-600">
          {t[locale].error}: {error}
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="flex flex-wrap gap-2 md:gap-3">
        {hasPermission("tickets.delete") && (
          <button
            onClick={toggleSelectionMode}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
              isSelectionMode
                ? "bg-purple-600 hover:bg-purple-700 text-white"
                : "bg-purple-500 hover:bg-purple-600 text-white"
            }`}
          >
            <Scan className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].scan}
          </button>
        )}

        {!isSelectionMode && (
          <>
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
            >
              <Plus className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].add}
            </button>
            <button
              onClick={handleEditClick}
              disabled={!selectedId}
              className="flex items-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Edit className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].edit}
            </button>
            <button
              onClick={handleDelete}
              disabled={!selectedId}
              className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].delete}
            </button>
          </>
        )}

        {isSelectionMode && selectedItems.size > 0 && (
          <button
            onClick={handleDelete}
            className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
          >
            <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].deleteSelected}
          </button>
        )}
      </div>

      {showAddModal && (
        <div
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowAddModal(false)
          }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-ticket-title"
        >
          <div ref={modalRef} className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 id="add-ticket-title" className="text-xl font-bold text-slate-800">
                {locale === "en" ? "Add New Ticket" : "إضافة تذكرة جديدة"}
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-100"
                aria-label={locale === "en" ? "Close dialog" : "إغلاق"}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="passenger_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].passengerName}
                  </label>
                  <input
                    id="passenger_name"
                    type="text"
                    required
                    value={formData.passenger_name}
                    onChange={(e) => setFormData({ ...formData, passenger_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="trip_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripNumber}
                  </label>
                  <input
                    id="trip_number"
                    type="text"
                    required
                    value={formData.trip_number}
                    onChange={(e) => setFormData({ ...formData, trip_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="trip_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].trip}
                  </label>
                  <input
                    id="trip_name"
                    type="text"
                    required
                    value={formData.trip_name}
                    onChange={(e) => setFormData({ ...formData, trip_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="trip_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripDate}
                  </label>
                  <input
                    id="trip_date"
                    type="date"
                    required
                    value={formData.trip_date}
                    onChange={(e) => setFormData({ ...formData, trip_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="ticket_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].ticketNumber}
                  </label>
                  <input
                    id="ticket_number"
                    type="text"
                    required
                    value={formData.ticket_number}
                    onChange={(e) => setFormData({ ...formData, ticket_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="trip_time" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripTime}
                  </label>
                  <input
                    id="trip_time"
                    type="time"
                    required
                    value={formData.trip_time}
                    onChange={(e) => setFormData({ ...formData, trip_time: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="seat_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].seatNumber}
                  </label>
                  <input
                    id="seat_number"
                    type="text"
                    required
                    value={formData.seat_number}
                    onChange={(e) => setFormData({ ...formData, seat_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="mobile_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].mobileNumber}
                  </label>
                  <input
                    id="mobile_number"
                    type="tel"
                    required
                    value={formData.mobile_number}
                    onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="issue_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].issueDate}
                  </label>
                  <input
                    id="issue_date"
                    type="date"
                    required
                    value={formData.issue_date}
                    onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="user" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].user}
                  </label>
                  <input
                    id="user"
                    type="text"
                    required
                    value={formData.user}
                    onChange={(e) => setFormData({ ...formData, user: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="branch" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].branch}
                  </label>
                  <input
                    id="branch"
                    type="text"
                    required
                    value={formData.branch}
                    onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].status}
                  </label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as "confirmed" | "pending" | "cancelled" })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="confirmed">{t[locale].confirmed}</option>
                    <option value="pending">{t[locale].pending}</option>
                    <option value="cancelled">{t[locale].cancelled}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium"
                >
                  {locale === "en" ? "Cancel" : "إلغاء"}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors font-medium"
                >
                  {locale === "en" ? "Add Ticket" : "إضافة التذكرة"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && editingTicket && (
        <div
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowEditModal(false)
          }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-ticket-title"
        >
          <div
            ref={editModalRef}
            className="bg-white rounded-xl shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 id="edit-ticket-title" className="text-xl font-bold text-slate-800">
                {locale === "en" ? "Edit Ticket" : "تعديل التذكرة"}
              </h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-100"
                aria-label={locale === "en" ? "Close dialog" : "إغلاق"}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="edit_passenger_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].passengerName}
                  </label>
                  <input
                    id="edit_passenger_name"
                    type="text"
                    required
                    value={formData.passenger_name}
                    onChange={(e) => setFormData({ ...formData, passenger_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripNumber}
                  </label>
                  <input
                    id="edit_trip_number"
                    type="text"
                    required
                    value={formData.trip_number}
                    onChange={(e) => setFormData({ ...formData, trip_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].trip}
                  </label>
                  <input
                    id="edit_trip_name"
                    type="text"
                    required
                    value={formData.trip_name}
                    onChange={(e) => setFormData({ ...formData, trip_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripDate}
                  </label>
                  <input
                    id="edit_trip_date"
                    type="date"
                    required
                    value={formData.trip_date}
                    onChange={(e) => setFormData({ ...formData, trip_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_ticket_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].ticketNumber}
                  </label>
                  <input
                    id="edit_ticket_number"
                    type="text"
                    required
                    value={formData.ticket_number}
                    onChange={(e) => setFormData({ ...formData, ticket_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_time" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripTime}
                  </label>
                  <input
                    id="edit_trip_time"
                    type="time"
                    required
                    value={formData.trip_time}
                    onChange={(e) => setFormData({ ...formData, trip_time: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_seat_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].seatNumber}
                  </label>
                  <input
                    id="edit_seat_number"
                    type="text"
                    required
                    value={formData.seat_number}
                    onChange={(e) => setFormData({ ...formData, seat_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_mobile_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].mobileNumber}
                  </label>
                  <input
                    id="edit_mobile_number"
                    type="tel"
                    required
                    value={formData.mobile_number}
                    onChange={(e) => setFormData({ ...formData, mobile_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_issue_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].issueDate}
                  </label>
                  <input
                    id="edit_issue_date"
                    type="date"
                    required
                    value={formData.issue_date}
                    onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_user" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].user}
                  </label>
                  <input
                    id="edit_user"
                    type="text"
                    required
                    value={formData.user}
                    onChange={(e) => setFormData({ ...formData, user: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_branch" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].branch}
                  </label>
                  <input
                    id="edit_branch"
                    type="text"
                    required
                    value={formData.branch}
                    onChange={(e) => setFormData({ ...formData, branch: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label htmlFor="edit_status" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].status}
                  </label>
                  <select
                    id="edit_status"
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as "confirmed" | "pending" | "cancelled" })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="confirmed">{t[locale].confirmed}</option>
                    <option value="pending">{t[locale].pending}</option>
                    <option value="cancelled">{t[locale].cancelled}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium"
                >
                  {locale === "en" ? "Cancel" : "إلغاء"}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors font-medium"
                >
                  {locale === "en" ? "Update Ticket" : "تحديث التذكرة"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1200px]">
            <thead className="bg-slate-100 border-b border-slate-200">
              <tr>
                {isSelectionMode && (
                  <th className="px-4 py-3 w-12">
                    <input
                      type="checkbox"
                      checked={selectedItems.size === tickets.length && tickets.length > 0}
                      onChange={handleSelectAll}
                      className="w-4 h-4 rounded border-slate-300"
                    />
                  </th>
                )}
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].passengerName}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].tripNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].trip}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].tripDate}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].ticketNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].tripTime}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].seatNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].mobileNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].issueDate}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].user}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].branch}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].status}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {tickets.length === 0 ? (
                <tr>
                  <td colSpan={isSelectionMode ? 13 : 12} className="px-4 py-8 text-center text-slate-500">
                    {locale === "en" ? "No tickets found" : "لا توجد تذاكر"}
                  </td>
                </tr>
              ) : (
                tickets.map((ticket) => (
                  <tr
                    key={ticket.id}
                    onClick={() => handleRowClick(ticket.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelectionMode
                        ? isSelected(ticket.id)
                          ? "bg-purple-50 border-l-4 border-purple-500"
                          : "hover:bg-slate-50"
                        : selectedId === ticket.id
                          ? "bg-blue-50"
                          : "hover:bg-slate-50"
                    }`}
                  >
                    {isSelectionMode && (
                      <td className="px-4 py-3">
                        <input
                          type="checkbox"
                          checked={isSelected(ticket.id)}
                          onChange={() => toggleItem(ticket.id)}
                          className="w-4 h-4 rounded border-slate-300"
                          onClick={(e) => e.stopPropagation()}
                        />
                      </td>
                    )}
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.passenger_name}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.trip_number}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.trip_name}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.trip_date}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.ticket_number}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.trip_time}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.seat_number}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.mobile_number}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.issue_date}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.user}</td>
                    <td className="px-4 py-3 text-sm text-slate-700">{ticket.branch}</td>
                    <td className="px-4 py-3">
                      {ticket.status === "confirmed" && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                          {t[locale].confirmed}
                        </span>
                      )}
                      {ticket.status === "pending" && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700">
                          {t[locale].pending}
                        </span>
                      )}
                      {ticket.status === "cancelled" && (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                          {t[locale].cancelled}
                        </span>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="px-6 py-4 border-t border-slate-200">
          <p className="text-sm text-slate-500">© 2025 FleetPro System – All rights reserved</p>
        </div>
      </div>
    </div>
  )
}
