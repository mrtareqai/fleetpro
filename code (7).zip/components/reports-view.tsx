"use client"

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { useState, useEffect } from "react"
import { apiClient } from "@/lib/api-client"
import { exportToExcel, exportToCSV, exportToJSON } from "@/lib/export-utils"

interface ReportsViewProps {
  locale: "en" | "ar"
}

export default function ReportsView({ locale }: ReportsViewProps) {
  const [downloading, setDownloading] = useState(false)
  const [utilizationData, setUtilizationData] = useState<any[]>([])
  const [expenseData, setExpenseData] = useState<any[]>([])
  const [performanceData, setPerformanceData] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  const t = {
    en: {
      title: "Reports & Analytics",
      fleetUtilization: "Fleet Utilization Rate",
      expenseBreakdown: "Expense Breakdown by Category",
      driverPerformance: "Driver Performance by Rankings",
      generatedReports: "Generated Reports",
      reportId: "Report ID",
      type: "Type",
      date: "Date",
      status: "Status",
      download: "Download",
      fuel: "Fuel",
      maintenance: "Maintenance",
      other: "Other",
      downloading: "Downloading...",
      fleetReport: "Fleet Report",
      maintenanceReport: "Maintenance",
      financialReport: "Financial",
      completed: "Completed",
      pending: "Pending",
      processing: "Processing",
      exportExcel: "Excel",
      exportCSV: "CSV",
      exportJSON: "JSON",
    },
    ar: {
      title: "التقارير والتحليلات",
      fleetUtilization: "معدل استخدام الأسطول",
      expenseBreakdown: "تفصيل النفقات حسب الفئة",
      driverPerformance: "أداء السائق حسب التصنيفات",
      generatedReports: "التقارير المُنشأة",
      reportId: "معرف التقرير",
      type: "النوع",
      date: "التاريخ",
      status: "الحالة",
      download: "تحميل",
      fuel: "الوقود",
      maintenance: "الصيانة",
      other: "أخرى",
      downloading: "جاري التحميل...",
      fleetReport: "تقرير الأسطول",
      maintenanceReport: "الصيانة",
      financialReport: "المالية",
      completed: "مكتمل",
      pending: "قيد الانتظار",
      processing: "قيد المعالجة",
      exportExcel: "إكسل",
      exportCSV: "CSV",
      exportJSON: "JSON",
    },
  }

  const sampleReports = [
    {
      id: "RPT-2024-001",
      type: "fleet-utilization",
      typeName: t[locale].fleetReport,
      date: "2024-01-15",
      status: "completed",
    },
    {
      id: "RPT-2024-002",
      type: "expenses",
      typeName: t[locale].maintenanceReport,
      date: "2024-01-14",
      status: "pending",
    },
    {
      id: "RPT-2024-003",
      type: "driver-performance",
      typeName: t[locale].financialReport,
      date: "2024-01-13",
      status: "processing",
    },
    {
      id: "RPT-2024-004",
      type: "monthly-reservations",
      typeName: "Monthly Reservations Report",
      date: "2024-01-12",
      status: "completed",
    },
    {
      id: "RPT-2024-005",
      type: "fleet-status",
      typeName: "Fleet Status Report",
      date: "2024-01-11",
      status: "completed",
    },
  ]

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      completed: {
        bg: "bg-green-100",
        text: "text-green-700",
        label: t[locale].completed,
      },
      pending: {
        bg: "bg-yellow-100",
        text: "text-yellow-700",
        label: t[locale].pending,
      },
      processing: {
        bg: "bg-blue-100",
        text: "text-blue-700",
        label: t[locale].processing,
      },
    }
    return statusConfig[status as keyof typeof statusConfig] || statusConfig.pending
  }

  const getTypeBadge = (type: string) => {
    const typeConfig = {
      "fleet-utilization": { bg: "bg-blue-100", text: "text-blue-700", icon: "🚗" },
      expenses: { bg: "bg-orange-100", text: "text-orange-700", icon: "💰" },
      "driver-performance": { bg: "bg-purple-100", text: "text-purple-700", icon: "👨‍✈️" },
      "monthly-reservations": { bg: "bg-teal-100", text: "text-teal-700", icon: "📅" },
      "fleet-status": { bg: "bg-red-100", text: "text-red-700", icon: "📊" },
    }
    return typeConfig[type as keyof typeof typeConfig] || typeConfig["fleet-utilization"]
  }

  useEffect(() => {
    fetchReportsData()
  }, [])

  const fetchReportsData = async () => {
    try {
      setLoading(true)

      const [utilization, expenses, performance] = await Promise.all([
        apiClient.getFleetUtilizationReport(),
        apiClient.getExpensesReport(),
        apiClient.getDriverPerformanceReport(),
      ])

      if (utilization.data) {
        setUtilizationData(
          utilization.data.slice(0, 10).map((item: any, index: number) => ({
            time: new Date(item.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
            value1: item.vehiclesUsed,
            value2: item.utilizationRate,
          })),
        )
      }

      if (expenses.breakdown) {
        const total =
          expenses.total || expenses.breakdown.reduce((sum: number, item: any) => sum + item.totalQuantity, 0)
        setExpenseData(
          expenses.breakdown.map((item: any) => ({
            name: item.category,
            value: item.percentage || Math.round((item.totalQuantity / total) * 100),
            color:
              item.category === "Fuel"
                ? "#3b82f6"
                : item.category === "Maintenance"
                  ? "#22c55e"
                  : item.category === "Parts"
                    ? "#f97316"
                    : "#8b5cf6",
          })),
        )
      }

      if (performance.drivers) {
        setPerformanceData(
          performance.drivers.slice(0, 7).map((driver: any) => ({
            rank: driver.rank.toString(),
            value: driver.score,
            name: driver.name,
          })),
        )
      }
    } catch (error) {
      console.error("[v0] Error fetching reports data:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleDownloadReport = async (reportType: string, format = "excel") => {
    setDownloading(true)

    try {
      let reportData: any

      switch (reportType) {
        case "fleet-utilization":
          reportData = await apiClient.getFleetUtilizationReport()
          break
        case "expenses":
          reportData = await apiClient.getExpensesReport()
          break
        case "driver-performance":
          reportData = await apiClient.getDriverPerformanceReport()
          break
        case "monthly-reservations":
          reportData = await apiClient.getMonthlyReservationsReport()
          break
        case "fleet-status":
          reportData = await apiClient.getFleetStatusReport()
          break
        default:
          reportData = { utilizationData, expenseData, performanceData }
      }

      let success = false
      const filename = `${reportType}-${Date.now()}`

      if (format === "excel" || format === "xlsx") {
        success = exportToExcel(reportType, reportData, `${filename}.xlsx`)
      } else if (format === "csv") {
        // For CSV, use the data array from the report
        const dataArray = reportData.data || reportData.breakdown || reportData.drivers || reportData.months || []
        success = exportToCSV(reportType, dataArray, `${filename}.csv`)
      } else if (format === "json") {
        success = exportToJSON(reportType, reportData, `${filename}.json`)
      }

      if (!success) {
        throw new Error("Export failed")
      }
    } catch (error) {
      console.error("[v0] Error downloading report:", error)
      alert(locale === "en" ? "Failed to download report" : "فشل تحميل التقرير")
    } finally {
      setDownloading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{locale === "en" ? "Loading reports..." : "جاري تحميل التقارير..."}</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fleet Utilization */}
        <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-green-500">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
              <span className="text-xl">📊</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800">{t[locale].fleetUtilization}</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={utilizationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="time" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip />
              <Line type="monotone" dataKey="value1" stroke="#22c55e" strokeWidth={2} />
              <Line type="monotone" dataKey="value2" stroke="#3b82f6" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Expense Breakdown */}
        <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-orange-500">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
              <span className="text-xl">💰</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800">{t[locale].expenseBreakdown}</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={expenseData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={5}
                dataKey="value"
              >
                {expenseData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-3 gap-4 mt-4">
            {expenseData.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="text-sm text-slate-600">{item.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Driver Performance */}
        <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-blue-500">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <span className="text-xl">👨‍✈️</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800">{t[locale].driverPerformance}</h3>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={performanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="rank" stroke="#6b7280" />
              <YAxis stroke="#6b7280" />
              <Tooltip />
              <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Generated Reports */}
        <div className="bg-white rounded-xl p-6 shadow-sm border-l-4 border-purple-500">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
              <span className="text-xl">📄</span>
            </div>
            <h3 className="text-lg font-semibold text-slate-800">{t[locale].generatedReports}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50 border-b-2 border-slate-200">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">{t[locale].reportId}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">{t[locale].type}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">{t[locale].date}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">{t[locale].status}</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-slate-700">{t[locale].download}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {sampleReports.map((report) => {
                  const statusBadge = getStatusBadge(report.status)
                  const typeBadge = getTypeBadge(report.type)
                  return (
                    <tr key={report.id} className="hover:bg-slate-50 transition-colors">
                      <td className="px-4 py-3 text-sm font-medium text-slate-900">{report.id}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${typeBadge.bg} ${typeBadge.text}`}
                        >
                          <span>{typeBadge.icon}</span>
                          {report.typeName}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-600">{report.date}</td>
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${statusBadge.bg} ${statusBadge.text}`}
                        >
                          {statusBadge.label}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleDownloadReport(report.type, "excel")}
                            disabled={downloading || report.status !== "completed"}
                            className="px-3 py-1.5 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 disabled:from-slate-300 disabled:to-slate-400 disabled:cursor-not-allowed text-white text-xs rounded-lg transition-all shadow-sm hover:shadow-md"
                            title={t[locale].exportExcel}
                          >
                            📊 {t[locale].exportExcel}
                          </button>
                          <button
                            onClick={() => handleDownloadReport(report.type, "csv")}
                            disabled={downloading || report.status !== "completed"}
                            className="px-3 py-1.5 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 disabled:from-slate-300 disabled:to-slate-400 disabled:cursor-not-allowed text-white text-xs rounded-lg transition-all shadow-sm hover:shadow-md"
                            title={t[locale].exportCSV}
                          >
                            📄 {t[locale].exportCSV}
                          </button>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  )
}
