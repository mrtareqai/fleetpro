# تقرير شامل ومفصل لنظام FleetPro Management System

## 📋 جدول المحتويات

1. [نظرة عامة على النظام](#نظرة-عامة-على-النظام)
2. [البنية المعمارية](#البنية-المعمارية)
3. [المكونات الأساسية](#المكونات-الأساسية)
4. [واجهات برمجة التطبيقات (APIs)](#واجهات-برمجة-التطبيقات-apis)
5. [نظام الأمان والمصادقة](#نظام-الأمان-والمصادقة)
6. [إدارة البيانات](#إدارة-البيانات)
7. [واجهة المستخدم](#واجهة-المستخدم)
8. [التقارير والتحليلات](#التقارير-والتحليلات)
9. [تدفق البيانات](#تدفق-البيانات)
10. [الخلاصة](#الخلاصة)

---

## 🎯 نظرة عامة على النظام

### ما هو FleetPro Management System؟

**FleetPro Management System** هو نظام متكامل لإدارة الأساطيل والمركبات، مصمم لتسهيل عمليات إدارة المركبات، السائقين، الحجوزات، التذاكر، والحركات اليومية. النظام مبني باستخدام أحدث التقنيات ويدعم تعدد الشركات (Multi-tenancy) مع نظام صلاحيات متقدم.

### التقنيات المستخدمة

- **الإطار الأساسي**: Next.js 16 (App Router)
- **اللغة البرمجية**: TypeScript
- **قاعدة البيانات**: PostgreSQL (Neon)
- **التخزين المؤقت**: Redis (Upstash)
- **المصادقة**: JWT (JSON Web Tokens)
- **التحقق من البيانات**: Zod
- **واجهة المستخدم**: React + Tailwind CSS + shadcn/ui
- **الخطوط**: Inter (إنجليزي) + Cairo (عربي)

### الميزات الرئيسية

1. ✅ **إدارة متعددة الشركات**: دعم عدة شركات في نظام واحد
2. ✅ **نظام صلاحيات متقدم (RBAC)**: التحكم الدقيق في صلاحيات المستخدمين
3. ✅ **دعم اللغتين**: العربية والإنجليزية مع دعم RTL
4. ✅ **إدارة شاملة**: مركبات، سائقين، حجوزات، تذاكر، حركات، ومستلزمات
5. ✅ **تقارير تفصيلية**: تقارير متنوعة مع إمكانية التصدير (Excel, CSV, PDF)
6. ✅ **لوحة تحكم تفاعلية**: إحصائيات ورسوم بيانية في الوقت الفعلي
7. ✅ **أمان عالي**: تشفير البيانات، JWT، Rate Limiting

---

## 🏗️ البنية المعمارية

### نموذج البنية الثلاثية (Three-Tier Architecture)

\`\`\`
┌─────────────────────────────────────────────────────────────┐
│                    Presentation Layer                        │
│              (واجهة المستخدم - React Components)             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │Dashboard │  │ Vehicles │  │ Drivers  │  │ Reports  │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                    Business Logic Layer                      │
│              (طبقة المنطق - API Routes & Services)           │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │   Auth   │  │   CRUD   │  │ Reports  │  │Validation│   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└─────────────────────────────────────────────────────────────┘
                            ↕
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                              │
│              (طبقة البيانات - Database & Cache)              │
│  ┌──────────────────────┐      ┌──────────────────────┐    │
│  │   PostgreSQL (Neon)  │      │   Redis (Upstash)    │    │
│  │  - Users             │      │  - Sessions          │    │
│  │  - Vehicles          │      │  - Cache             │    │
│  │  - Drivers           │      │  - Rate Limiting     │    │
│  │  - Reservations      │      └──────────────────────┘    │
│  │  - Tickets           │                                   │
│  │  - Movements         │                                   │
│  └──────────────────────┘                                   │
└─────────────────────────────────────────────────────────────┘
\`\`\`

### هيكل المجلدات

\`\`\`
fleetpromanagement/
├── app/                          # صفحات التطبيق (Next.js App Router)
│   ├── api/                      # واجهات برمجة التطبيقات
│   │   ├── auth/                 # المصادقة (Login, Logout, Refresh)
│   │   ├── vehicles/             # إدارة المركبات
│   │   ├── drivers/              # إدارة السائقين
│   │   ├── reservations/         # إدارة الحجوزات
│   │   ├── tickets/              # إدارة التذاكر
│   │   ├── movements/            # إدارة الحركات
│   │   ├── supplies/             # إدارة المستلزمات
│   │   ├── companies/            # إدارة الشركات
│   │   ├── dashboard/            # إحصائيات لوحة التحكم
│   │   ├── reports/              # التقارير
│   │   └── admin/                # إدارة المستخدمين والصلاحيات
│   ├── dashboard/                # صفحة لوحة التحكم
│   ├── fleet/                    # صفحة إدارة المركبات
│   ├── drivers/                  # صفحة إدارة السائقين
│   ├── reservations/             # صفحة الحجوزات
│   ├── tickets/                  # صفحة التذاكر
│   ├── movement/                 # صفحة الحركات
│   ├── supplies/                 # صفحة المستلزمات
│   ├── reports/                  # صفحة التقارير
│   ├── admin/                    # صفحات الإدارة
│   ├── login/                    # صفحة تسجيل الدخول
│   ├── layout.tsx                # التخطيط الرئيسي
│   └── globals.css               # الأنماط العامة
│
├── components/                   # مكونات React القابلة لإعادة الاستخدام
│   ├── ui/                       # مكونات واجهة المستخدم (shadcn/ui)
│   ├── dashboard-layout.tsx      # تخطيط لوحة التحكم
│   ├── sidebar.tsx               # القائمة الجانبية
│   ├── header.tsx                # رأس الصفحة
│   ├── *-table.tsx               # جداول البيانات
│   └── reports-view.tsx          # عرض التقارير
│
├── lib/                          # المكتبات والوظائف المساعدة
│   ├── api/                      # وظائف API المساعدة
│   │   ├── mock-handler.ts       # معالج البيانات الوهمية
│   │   ├── mock-config.ts        # إعدادات البيانات الوهمية
│   │   ├── error-handler.ts      # معالجة الأخطاء
│   │   └── db-utils.ts           # وظائف قاعدة البيانات
│   ├── security/                 # الأمان والمصادقة
│   │   ├── jwt.ts                # إدارة JWT
│   │   ├── api-auth.ts           # مصادقة API
│   │   ├── password.ts           # تشفير كلمات المرور
│   │   └── rate-limit.ts         # تحديد معدل الطلبات
│   ├── validation/               # التحقق من البيانات
│   │   ├── schemas.ts            # مخططات Zod
│   │   └── validator.ts          # وظائف التحقق
│   ├── auth-context.tsx          # سياق المصادقة
│   ├── company-context.tsx       # سياق الشركة
│   ├── selection-context.tsx     # سياق الاختيار
│   ├── permissions.ts            # إدارة الصلاحيات
│   ├── api-client.ts             # عميل API
│   ├── db.ts                     # اتصال قاعدة البيانات
│   ├── export-utils.ts           # تصدير البيانات
│   └── utils.ts                  # وظائف مساعدة عامة
│
├── middleware.ts                 # Middleware للتوجيه والأمان
├── scripts/                      # سكريبتات قاعدة البيانات
└── docs/                         # الوثائق
\`\`\`

---

## 🧩 المكونات الأساسية

### 1. نظام المصادقة (Authentication System)

#### المكونات الرئيسية:

**أ. AuthContext (`lib/auth-context.tsx`)**
- **الوظيفة**: إدارة حالة المستخدم المسجل في التطبيق
- **المسؤوليات**:
  - تخزين معلومات المستخدم الحالي
  - إدارة الصلاحيات (Permissions)
  - توفير وظائف `login()` و `logout()`
  - التحقق من الصلاحيات عبر `hasPermission()` و `hasRole()`
- **التخزين**: localStorage للمتصفح

**ب. JWT Module (`lib/security/jwt.ts`)**
- **الوظيفة**: إنشاء والتحقق من رموز JWT
- **الميزات**:
  - توليد Access Token (صالح لمدة 7 أيام)
  - توليد Refresh Token (صالح لمدة 30 يوم)
  - التحقق من صحة الرموز
  - استخراج البيانات من الرموز
- **الخوارزمية**: HS256 (HMAC with SHA-256)

**ج. API Authentication (`lib/security/api-auth.ts`)**
- **الوظيفة**: حماية نقاط النهاية (API Endpoints)
- **الوظائف الرئيسية**:
  - `requireAuth()`: يتطلب مصادقة المستخدم
  - `requirePermission()`: يتطلب صلاحية محددة
  - `requireAnyPermission()`: يتطلب أي صلاحية من قائمة
  - `requireRole()`: يتطلب دور محدد
- **التكامل**: Rate Limiting تلقائي

#### تدفق المصادقة:

\`\`\`
1. المستخدم يدخل اسم المستخدم وكلمة المرور
   ↓
2. POST /api/auth/login
   ↓
3. التحقق من البيانات في قاعدة البيانات
   ↓
4. إنشاء JWT Token
   ↓
5. إرجاع Token + معلومات المستخدم
   ↓
6. تخزين Token في localStorage
   ↓
7. إضافة Token في رأس Authorization لكل طلب
   ↓
8. التحقق من Token في كل API Request
\`\`\`

### 2. نظام الصلاحيات (RBAC - Role-Based Access Control)

#### البنية:

\`\`\`
Users (المستخدمون)
  ↓
User_Roles (أدوار المستخدمين)
  ↓
Roles (الأدوار)
  ↓
Role_Permissions (صلاحيات الأدوار)
  ↓
Permissions (الصلاحيات)
\`\`\`

#### الأدوار المتاحة:

1. **Super Admin**: صلاحيات كاملة (`*`)
2. **Admin**: إدارة كاملة للشركة
3. **Fleet Manager**: إدارة المركبات والسائقين
4. **Dispatcher**: إدارة الحجوزات والحركات
5. **Maintenance Staff**: إدارة الصيانة
6. **Viewer**: عرض البيانات فقط

#### الصلاحيات (Permissions):

تتبع نمط: `resource.action`

أمثلة:
- `vehicles.read` - عرض المركبات
- `vehicles.create` - إضافة مركبة
- `vehicles.update` - تعديل مركبة
- `vehicles.delete` - حذف مركبة
- `vehicles.*` - جميع صلاحيات المركبات
- `*` - جميع الصلاحيات

#### التحقق من الصلاحيات:

**في الواجهة (Frontend):**
\`\`\`typescript
const { hasPermission } = useAuth()

if (hasPermission('vehicles.create')) {
  // عرض زر إضافة مركبة
}
\`\`\`

**في API:**
\`\`\`typescript
const authResult = await requirePermission(request, 'vehicles.create')
if (authResult instanceof Response) return authResult
// المستخدم لديه الصلاحية، متابعة العملية
\`\`\`

### 3. نظام إدارة الشركات (Multi-tenancy)

#### المكونات:

**أ. CompanyContext (`lib/company-context.tsx`)**
- **الوظيفة**: إدارة الشركة الحالية
- **المسؤوليات**:
  - تخزين معلومات الشركة
  - توفير `company_id` لجميع العمليات
  - عزل البيانات بين الشركات

**ب. Middleware (`middleware.ts`)**
- **الوظيفة**: استخراج رمز الشركة من URL
- **النمط**: `/{company_code}/...`
- **مثال**: `/acme/dashboard` → company_code = "acme"

#### عزل البيانات:

كل جدول في قاعدة البيانات يحتوي على `company_id`:

\`\`\`sql
SELECT * FROM vehicles WHERE company_id = $1
\`\`\`

هذا يضمن أن كل شركة ترى بياناتها فقط.

### 4. نظام التحقق من البيانات (Validation)

#### Zod Schemas (`lib/validation/schemas.ts`)

**الميزات**:
- التحقق من البيانات في وقت التشغيل
- رسائل خطأ واضحة بالعربية
- استنتاج أنواع TypeScript تلقائياً
- قابلة لإعادة الاستخدام

**أمثلة على المخططات**:

\`\`\`typescript
// مخطط إنشاء مركبة
createVehicleSchema = {
  model: string (1-100 حرف)
  manufacture_date: تاريخ بصيغة YYYY-MM-DD
  plate_number: string (1-50 حرف)
  status: enum ['active', 'inactive', 'maintenance', 'expired']
  company_id: number (اختياري)
}

// مخطط إنشاء سائق
createDriverSchema = {
  name: string (1-100 حرف)
  license_number: string (1-50 حرف)
  phone: رقم هاتف صحيح
  email: بريد إلكتروني صحيح
  status: enum ['active', 'inactive']
}
\`\`\`

**الاستخدام**:

\`\`\`typescript
const result = createVehicleSchema.safeParse(data)
if (!result.success) {
  return { error: result.error.errors }
}
// البيانات صحيحة، متابعة العملية
\`\`\`

---

## 🔌 واجهات برمجة التطبيقات (APIs)

### بنية API

جميع APIs تتبع معيار RESTful:

\`\`\`
GET    /api/resource      - قراءة جميع السجلات
GET    /api/resource/:id  - قراءة سجل واحد
POST   /api/resource      - إنشاء سجل جديد
PUT    /api/resource/:id  - تحديث سجل
DELETE /api/resource/:id  - حذف سجل
\`\`\`

### 1. APIs المصادقة

#### POST `/api/auth/login`
**الوظيفة**: تسجيل دخول المستخدم

**الطلب**:
\`\`\`json
{
  "username": "admin",
  "password": "password123",
  "company_code": "acme" // اختياري
}
\`\`\`

**الاستجابة**:
\`\`\`json
{
  "access_token": "eyJhbGc...",
  "refresh_token": "eyJhbGc...",
  "user": {
    "id": "1",
    "username": "admin",
    "email": "admin@example.com",
    "role": "admin",
    "full_name": "مدير النظام",
    "company_id": 1
  }
}
\`\`\`

#### POST `/api/auth/logout`
**الوظيفة**: تسجيل خروج المستخدم
**المصادقة**: مطلوبة

#### POST `/api/auth/refresh`
**الوظيفة**: تجديد Access Token باستخدام Refresh Token

### 2. APIs المركبات

#### GET `/api/vehicles`
**الوظيفة**: الحصول على قائمة المركبات
**الصلاحية المطلوبة**: `vehicles.read`

**الاستجابة**:
\`\`\`json
[
  {
    "id": 1,
    "model": "تويوتا كامري 2023",
    "plate_number": "أ ب ج 1234",
    "manufacture_date": "2023-01-15",
    "status": "active",
    "company_id": 1,
    "created_at": "2024-01-01T00:00:00Z"
  }
]
\`\`\`

#### POST `/api/vehicles`
**الوظيفة**: إضافة مركبة جديدة
**الصلاحية المطلوبة**: `vehicles.create`

**الطلب**:
\`\`\`json
{
  "model": "تويوتا كامري 2023",
  "plate_number": "أ ب ج 1234",
  "manufacture_date": "2023-01-15",
  "base_number": "12345",
  "card_number": "67890",
  "issue_date": "2023-01-20",
  "expiry_date": "2024-01-20",
  "status": "active"
}
\`\`\`

#### PUT `/api/vehicles/:id`
**الوظيفة**: تحديث مركبة
**الصلاحية المطلوبة**: `vehicles.update`

#### DELETE `/api/vehicles/:id`
**الوظيفة**: حذف مركبة
**الصلاحية المطلوبة**: `vehicles.delete`

### 3. APIs السائقين

#### GET `/api/drivers`
**الوظيفة**: الحصول على قائمة السائقين
**الصلاحية المطلوبة**: `drivers.read`

#### POST `/api/drivers`
**الوظيفة**: إضافة سائق جديد
**الصلاحية المطلوبة**: `drivers.create`

**الطلب**:
\`\`\`json
{
  "name": "أحمد محمد",
  "license_number": "123456789",
  "phone": "+966501234567",
  "email": "ahmed@example.com",
  "status": "active"
}
\`\`\`

### 4. APIs الحجوزات

#### GET `/api/reservations`
**الوظيفة**: الحصول على قائمة الحجوزات
**الصلاحية المطلوبة**: `reservations.read`

**الاستجابة**:
\`\`\`json
[
  {
    "id": 1,
    "vehicle_id": 5,
    "driver_id": 3,
    "start_date": "2024-01-15",
    "end_date": "2024-01-20",
    "purpose": "رحلة عمل إلى الرياض",
    "status": "confirmed",
    "vehicle": {
      "model": "تويوتا كامري",
      "plate_number": "أ ب ج 1234"
    },
    "driver": {
      "name": "أحمد محمد"
    }
  }
]
\`\`\`

#### POST `/api/reservations`
**الوظيفة**: إنشاء حجز جديد
**الصلاحية المطلوبة**: `reservations.create`

### 5. APIs التذاكر

#### GET `/api/tickets`
**الوظيفة**: الحصول على قائمة التذاكر
**الصلاحية المطلوبة**: `tickets.read`

#### POST `/api/tickets`
**الوظيفة**: إصدار تذكرة جديدة
**الصلاحية المطلوبة**: `tickets.create`

**الطلب**:
\`\`\`json
{
  "passenger_name": "محمد علي",
  "trip_number": "T001",
  "trip_name": "الرياض - جدة",
  "trip_date": "2024-01-15",
  "ticket_number": "TKT-001",
  "trip_time": "08:00",
  "seat_number": "A12",
  "mobile_number": "+966501234567",
  "issue_date": "2024-01-10",
  "user": "موظف الحجز",
  "branch": "فرع الرياض",
  "status": "confirmed"
}
\`\`\`

### 6. APIs الحركات

#### GET `/api/movements`
**الوظيفة**: الحصول على قائمة الحركات
**الصلاحية المطلوبة**: `movements.read`

#### POST `/api/movements`
**الوظيفة**: تسجيل حركة جديدة
**الصلاحية المطلوبة**: `movements.create`

**الطلب**:
\`\`\`json
{
  "driver_name": "أحمد محمد",
  "assistant_name": "خالد أحمد",
  "bus_number": "BUS-001",
  "trip_name": "الرياض - الدمام",
  "trip_date": "2024-01-15",
  "trip_time": "06:00",
  "seats": 50,
  "pending_seats": 10,
  "status": "scheduled"
}
\`\`\`

### 7. APIs المستلزمات

#### GET `/api/supplies`
**الوظيفة**: الحصول على قائمة المستلزمات
**الصلاحية المطلوبة**: `supplies.read`

#### POST `/api/supplies`
**الوظيفة**: إضافة مستلزم جديد
**الصلاحية المطلوبة**: `supplies.create`

### 8. APIs لوحة التحكم

#### GET `/api/dashboard/stats`
**الوظيفة**: الحصول على إحصائيات لوحة التحكم
**الصلاحية المطلوبة**: `dashboard.view`

**الاستجابة**:
\`\`\`json
{
  "total_vehicles": 50,
  "active_vehicles": 42,
  "total_drivers": 35,
  "active_drivers": 30,
  "active_reservations": 15,
  "upcoming_reservations": 8,
  "total_tickets": 120,
  "confirmed_tickets": 95
}
\`\`\`

#### GET `/api/dashboard/charts`
**الوظيفة**: الحصول على بيانات الرسوم البيانية

**الاستجابة**:
\`\`\`json
{
  "monthlyReservations": [
    { "month": "Jan", "value": 25 },
    { "month": "Feb", "value": 30 }
  ],
  "fleetStatus": [
    { "name": "active", "value": 42 },
    { "name": "maintenance", "value": 5 },
    { "name": "inactive", "value": 3 }
  ]
}
\`\`\`

### 9. APIs التقارير

#### GET `/api/reports/fleet-utilization`
**الوظيفة**: تقرير استخدام الأسطول
**المعاملات**: `start_date`, `end_date`

**الاستجابة**:
\`\`\`json
{
  "data": [
    {
      "date": "2024-01-01",
      "vehiclesUsed": 35,
      "totalVehicles": 50,
      "utilizationRate": 70
    }
  ],
  "summary": {
    "averageUtilization": 68,
    "totalVehicles": 50,
    "peakUtilization": 85
  }
}
\`\`\`

#### GET `/api/reports/expenses`
**الوظيفة**: تقرير المصروفات
**المعاملات**: `year`, `month`

#### GET `/api/reports/driver-performance`
**الوظيفة**: تقرير أداء السائقين
**المعاملات**: `start_date`, `end_date`

#### GET `/api/reports/monthly-reservations`
**الوظيفة**: تقرير الحجوزات الشهرية
**المعاملات**: `year`

#### GET `/api/reports/fleet-status`
**الوظيفة**: تقرير حالة الأسطول

#### POST `/api/reports/export`
**الوظيفة**: تصدير التقارير
**الصيغ المدعومة**: Excel, CSV, PDF, JSON

**الطلب**:
\`\`\`json
{
  "reportType": "fleet-utilization",
  "format": "excel",
  "data": { /* بيانات التقرير */ }
}
\`\`\`

### 10. APIs الإدارة

#### GET `/api/admin/users`
**الوظيفة**: قائمة المستخدمين
**الصلاحية المطلوبة**: `users.read`

#### POST `/api/admin/users`
**الوظيفة**: إضافة مستخدم جديد
**الصلاحية المطلوبة**: `users.create`

#### GET `/api/admin/roles`
**الوظيفة**: قائمة الأدوار
**الصلاحية المطلوبة**: `roles.read`

#### POST `/api/admin/roles/create`
**الوظيفة**: إنشاء دور جديد
**الصلاحية المطلوبة**: `roles.create`

#### GET `/api/admin/permissions`
**الوظيفة**: قائمة الصلاحيات
**الصلاحية المطلوبة**: `permissions.read`

---

## 🔒 نظام الأمان والمصادقة

### 1. JWT (JSON Web Tokens)

#### البنية:

\`\`\`
Header.Payload.Signature

Header:
{
  "alg": "HS256",
  "typ": "JWT"
}

Payload:
{
  "userId": "1",
  "role": "admin",
  "permissions": ["*"],
  "companyId": 1,
  "iat": 1234567890,
  "exp": 1234567890
}
\`\`\`

#### دورة حياة Token:

1. **إنشاء**: عند تسجيل الدخول
2. **التخزين**: في localStorage
3. **الإرسال**: في رأس Authorization
4. **التحقق**: في كل طلب API
5. **التجديد**: باستخدام Refresh Token
6. **الانتهاء**: بعد 7 أيام (Access) أو 30 يوم (Refresh)

### 2. تشفير كلمات المرور

**المكتبة**: bcrypt
**الخوارزمية**: bcrypt with salt rounds = 10

\`\`\`typescript
// تشفير كلمة المرور
const hashedPassword = await hashPassword('password123')

// التحقق من كلمة المرور
const isValid = await verifyPassword('password123', hashedPassword)
\`\`\`

### 3. Rate Limiting

**الغرض**: منع هجمات DDoS والطلبات المفرطة

**الإعدادات**:
- **الحد الأقصى**: 100 طلب
- **النافذة الزمنية**: 15 دقيقة
- **التخزين**: Redis (Upstash)

**الاستجابة عند تجاوز الحد**:
\`\`\`json
{
  "error": "Too many requests",
  "retryAfter": 60
}
\`\`\`

**الرؤوس**:
\`\`\`
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 0
X-RateLimit-Reset: 2024-01-15T10:30:00Z
Retry-After: 60
\`\`\`

### 4. معالجة الأخطاء

**المكون**: `lib/api/error-handler.ts`

**أنواع الأخطاء**:

1. **ValidationError** (400): بيانات غير صحيحة
2. **AuthenticationError** (401): غير مصادق
3. **AuthorizationError** (403): لا توجد صلاحية
4. **NotFoundError** (404): السجل غير موجود
5. **ConflictError** (409): تعارض في البيانات
6. **ServerError** (500): خطأ في الخادم

**تنسيق الاستجابة**:
\`\`\`json
{
  "error": "Validation Error",
  "message": "Invalid vehicle data",
  "details": [
    {
      "field": "plate_number",
      "message": "Plate number is required"
    }
  ],
  "timestamp": "2024-01-15T10:30:00Z"
}
\`\`\`

### 5. CORS (Cross-Origin Resource Sharing)

**الإعدادات**:
\`\`\`typescript
{
  credentials: 'include',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer token'
  }
}
\`\`\`

---

## 💾 إدارة البيانات

### 1. قاعدة البيانات (PostgreSQL - Neon)

#### الاتصال:

**المكون**: `lib/db.ts`

\`\`\`typescript
import { neon } from '@neondatabase/serverless'

const sql = neon(process.env.DATABASE_URL)
\`\`\`

**الميزات**:
- اتصال Serverless
- دعم Connection Pooling
- استعلامات SQL مباشرة
- عدم استخدام ORM (لتحسين الأداء)

#### الجداول الرئيسية:

**1. users (المستخدمون)**
\`\`\`sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  role VARCHAR(50) NOT NULL,
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**2. companies (الشركات)**
\`\`\`sql
CREATE TABLE companies (
  id SERIAL PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  owner_name VARCHAR(100) NOT NULL,
  contact_number VARCHAR(20) NOT NULL,
  email VARCHAR(100) NOT NULL,
  company_code VARCHAR(50) UNIQUE NOT NULL,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**3. vehicles (المركبات)**
\`\`\`sql
CREATE TABLE vehicles (
  id SERIAL PRIMARY KEY,
  model VARCHAR(100) NOT NULL,
  manufacture_date DATE NOT NULL,
  plate_number VARCHAR(50) NOT NULL,
  base_number VARCHAR(50),
  card_number VARCHAR(50),
  issue_date DATE,
  expiry_date DATE,
  status VARCHAR(20) DEFAULT 'active',
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**4. drivers (السائقون)**
\`\`\`sql
CREATE TABLE drivers (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  license_number VARCHAR(50) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(100),
  status VARCHAR(20) DEFAULT 'active',
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**5. reservations (الحجوزات)**
\`\`\`sql
CREATE TABLE reservations (
  id SERIAL PRIMARY KEY,
  vehicle_id INTEGER REFERENCES vehicles(id),
  driver_id INTEGER REFERENCES drivers(id),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  purpose TEXT NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**6. tickets (التذاكر)**
\`\`\`sql
CREATE TABLE tickets (
  id SERIAL PRIMARY KEY,
  passenger_name VARCHAR(100) NOT NULL,
  trip_number VARCHAR(50) NOT NULL,
  trip_name VARCHAR(200) NOT NULL,
  trip_date DATE NOT NULL,
  ticket_number VARCHAR(50) NOT NULL,
  trip_time TIME NOT NULL,
  seat_number VARCHAR(10) NOT NULL,
  mobile_number VARCHAR(20) NOT NULL,
  issue_date DATE NOT NULL,
  user VARCHAR(100) NOT NULL,
  branch VARCHAR(100) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending',
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**7. movements (الحركات)**
\`\`\`sql
CREATE TABLE movements (
  id SERIAL PRIMARY KEY,
  driver_name VARCHAR(100) NOT NULL,
  assistant_name VARCHAR(100),
  bus_number VARCHAR(50) NOT NULL,
  trip_name VARCHAR(200) NOT NULL,
  trip_date DATE NOT NULL,
  trip_time TIME NOT NULL,
  seats INTEGER NOT NULL,
  pending_seats INTEGER DEFAULT 0,
  status VARCHAR(20) DEFAULT 'scheduled',
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**8. supplies (المستلزمات)**
\`\`\`sql
CREATE TABLE supplies (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  category VARCHAR(50),
  quantity INTEGER NOT NULL,
  unit VARCHAR(20),
  cost DECIMAL(10, 2),
  supplier VARCHAR(100),
  purchase_date DATE,
  company_id INTEGER REFERENCES companies(id),
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**9. roles (الأدوار)**
\`\`\`sql
CREATE TABLE roles (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  display_name VARCHAR(100) NOT NULL,
  description TEXT,
  is_system BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**10. permissions (الصلاحيات)**
\`\`\`sql
CREATE TABLE permissions (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) UNIQUE NOT NULL,
  display_name VARCHAR(100) NOT NULL,
  description TEXT,
  resource VARCHAR(50) NOT NULL,
  action VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**11. role_permissions (صلاحيات الأدوار)**
\`\`\`sql
CREATE TABLE role_permissions (
  id SERIAL PRIMARY KEY,
  role_id INTEGER REFERENCES roles(id),
  permission_id INTEGER REFERENCES permissions(id),
  UNIQUE(role_id, permission_id)
);
\`\`\`

**12. user_roles (أدوار المستخدمين)**
\`\`\`sql
CREATE TABLE user_roles (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  role_id INTEGER REFERENCES roles(id),
  assigned_by INTEGER REFERENCES users(id),
  assigned_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, role_id)
);
\`\`\`

### 2. التخزين المؤقت (Redis - Upstash)

**الاستخدامات**:

1. **Session Management**: تخزين جلسات المستخدمين
2. **Rate Limiting**: تتبع عدد الطلبات
3. **Cache**: تخزين البيانات المتكررة
4. **Mock Data Cache**: تخزين البيانات الوهمية

**المكون**: `lib/api/mock-cache.ts`

**الوظائف**:
\`\`\`typescript
// تخزين بيانات
mockCache.set(key, value, ttl)

// استرجاع بيانات
const data = mockCache.get(key)

// حذف بيانات
mockCache.invalidate(key)

// حذف بنمط معين
mockCache.invalidatePattern('/vehicles')
\`\`\`

### 3. البيانات الوهمية (Mock Data)

**الغرض**: تشغيل النظام بدون قاعدة بيانات حقيقية للتطوير والاختبار

**المكونات**:
- `lib/mock-data.ts`: البيانات الوهمية
- `lib/mock-store.ts`: تخزين البيانات في الذاكرة
- `lib/api/mock-handler.ts`: معالجة طلبات API الوهمية
- `lib/api/mock-config.ts`: إعدادات البيانات الوهمية

**التفعيل/التعطيل**:
\`\`\`typescript
// في lib/api/mock-config.ts
export const mockConfig = {
  enabled: !process.env.DATABASE_URL, // تلقائي
  // أو يدوياً
  enabled: true
}
\`\`\`

**الميزات**:
- محاكاة تأخير الشبكة
- محاكاة الأخطاء العشوائية
- تخزين مؤقت للبيانات
- سجل العمليات (Logging)

---

## 🎨 واجهة المستخدم

### 1. البنية

**الإطار**: React + Next.js 16 (App Router)
**التصميم**: Tailwind CSS + shadcn/ui
**الخطوط**: Inter (إنجليزي) + Cairo (عربي)

### 2. المكونات الرئيسية

#### أ. DashboardLayout (`components/dashboard-layout.tsx`)

**الوظيفة**: التخطيط الأساسي لجميع الصفحات

**المكونات الفرعية**:
- Sidebar: القائمة الجانبية
- Header: رأس الصفحة
- Main Content: المحتوى الرئيسي

**الميزات**:
- دعم RTL للعربية
- Responsive Design
- Sidebar قابل للطي

#### ب. Sidebar (`components/sidebar.tsx`)

**الوظيفة**: القائمة الجانبية للتنقل

**الأقسام**:
1. **لوحة التحكم**: Dashboard
2. **إدارة الأسطول**: Vehicles, Drivers
3. **العمليات**: Reservations, Tickets, Movements
4. **المستلزمات**: Supplies
5. **التقارير**: Reports
6. **الإدارة**: Users, Roles (للمسؤولين فقط)

**التحكم بالصلاحيات**:
\`\`\`typescript
{hasPermission('vehicles.read') && (
  <Link href="/fleet">المركبات</Link>
)}
\`\`\`

#### ج. Header (`components/header.tsx`)

**الوظيفة**: رأس الصفحة

**المحتويات**:
- اسم المستخدم
- الشركة الحالية
- زر تسجيل الخروج
- زر القائمة (للموبايل)

#### د. جداول البيانات

**المكونات**:
- `fleet-table.tsx`: جدول المركبات
- `drivers-table.tsx`: جدول السائقين
- `reservations-table.tsx`: جدول الحجوزات
- `tickets-table.tsx`: جدول التذاكر
- `movement-table.tsx`: جدول الحركات
- `supplies-table.tsx`: جدول المستلزمات

**الميزات المشتركة**:
- الترتيب (Sorting)
- البحث (Search)
- التصفية (Filtering)
- الترقيم (Pagination)
- الإجراءات (Actions): عرض، تعديل، حذف

#### هـ. النماذج (Forms)

**المكونات**:
- `login-form.tsx`: نموذج تسجيل الدخول
- نماذج إضافة/تعديل لكل كيان

**التحقق**:
- استخدام Zod Schemas
- رسائل خطأ واضحة
- التحقق في الوقت الفعلي

### 3. مكتبة المكونات (shadcn/ui)

**المكونات المستخدمة**:

1. **Button**: الأزرار
2. **Input**: حقول الإدخال
3. **Select**: القوائم المنسدلة
4. **Dialog**: النوافذ المنبثقة
5. **Table**: الجداول
6. **Card**: البطاقات
7. **Badge**: الشارات
8. **Alert**: التنبيهات
9. **Dropdown Menu**: القوائم المنسدلة
10. **Calendar**: التقويم
11. **Chart**: الرسوم البيانية (Recharts)
12. **Tabs**: التبويبات
13. **Toast**: الإشعارات

### 4. الأنماط (Styling)

#### Tailwind CSS v4

**الإعدادات** (`app/globals.css`):

\`\`\`css
:root {
  --background: oklch(1 0 0);
  --foreground: oklch(0.145 0 0);
  --primary: oklch(0.205 0 0);
  --secondary: oklch(0.97 0 0);
  --muted: oklch(0.97 0 0);
  --accent: oklch(0.97 0 0);
  --destructive: oklch(0.577 0.245 27.325);
  --border: oklch(0.922 0 0);
  --radius: 0.625rem;
}

.dark {
  --background: oklch(0.145 0 0);
  --foreground: oklch(0.985 0 0);
  /* ... */
}
\`\`\`

**الميزات**:
- Design Tokens
- Dark Mode Support
- RTL Support
- Responsive Design

#### دعم اللغة العربية

\`\`\`css
[dir="rtl"] {
  font-family: var(--font-cairo), var(--font-inter);
}
\`\`\`

### 5. الحالة (State Management)

**Context APIs**:

1. **AuthContext**: حالة المصادقة
2. **CompanyContext**: حالة الشركة
3. **SelectionContext**: حالة الاختيار

**Local State**: useState, useEffect

**Server State**: SWR (للبيانات من API)

---

## 📊 التقارير والتحليلات

### 1. أنواع التقارير

#### أ. تقرير استخدام الأسطول (Fleet Utilization)

**الوظيفة**: تتبع استخدام المركبات يومياً

**البيانات**:
- التاريخ
- عدد المركبات المستخدمة
- إجمالي المركبات
- نسبة الاستخدام

**الفترة**: آخر 30 يوم

**الرسم البياني**: Line Chart

#### ب. تقرير المصروفات (Expenses)

**الوظيفة**: تحليل المصروفات حسب الفئة

**البيانات**:
- الفئة
- إجمالي الكمية
- النسبة المئوية

**الفترة**: شهر محدد

**الرسم البياني**: Pie Chart

#### ج. تقرير أداء السائقين (Driver Performance)

**الوظيفة**: تقييم أداء السائقين

**البيانات**:
- الترتيب
- اسم السائق
- النقاط
- عدد الرحلات المكتملة
- الحالة

**الفترة**: فترة محددة

**الرسم البياني**: Bar Chart

#### د. تقرير الحجوزات الشهرية (Monthly Reservations)

**الوظيفة**: تتبع الحجوزات شهرياً

**البيانات**:
- الشهر
- عدد الحجوزات
- الإيرادات

**الفترة**: آخر 12 شهر

**الرسم البياني**: Bar Chart

#### هـ. تقرير حالة الأسطول (Fleet Status)

**الوظيفة**: نظرة عامة على حالة المركبات

**البيانات**:
- عدد المركبات النشطة
- عدد المركبات في الصيانة
- عدد المركبات غير النشطة
- النسب المئوية

**الرسم البياني**: Pie Chart

### 2. التصدير

**الصيغ المدعومة**:

#### أ. Excel (.xlsx)

**المكتبة**: xlsx (SheetJS)

**الميزات**:
- عدة أوراق (Sheets)
- تنسيق الخلايا
- عرض الأعمدة التلقائي
- رؤوس ثنائية اللغة

**البنية**:
\`\`\`
Sheet 1: البيانات (Data)
  - الرؤوس بالعربية والإنجليزية
  - البيانات المنسقة

Sheet 2: الملخص (Summary)
  - إحصائيات عامة
  - معلومات التقرير

Sheet 3: معلومات التقرير (Metadata)
  - نوع التقرير
  - تاريخ الإنشاء
  - المستخدم
\`\`\`

#### ب. CSV

**التنسيق**: UTF-8 with BOM (لدعم العربية في Excel)

**البنية**:
\`\`\`csv
التاريخ,المركبات المستخدمة,إجمالي المركبات,نسبة الاستخدام
2024-01-01,35,50,70%
2024-01-02,38,50,76%
\`\`\`

#### ج. PDF

**المكتبة**: jsPDF

**الميزات**:
- دعم العربية
- تنسيق احترافي
- رأس وتذييل
- جداول منسقة

#### د. JSON

**الاستخدام**: للتكامل مع أنظمة أخرى

**التنسيق**:
\`\`\`json
{
  "reportType": "fleet-utilization",
  "generatedAt": "2024-01-15T10:30:00Z",
  "data": [ /* ... */ ],
  "summary": { /* ... */ }
}
\`\`\`

### 3. المكون: ReportsView

**الموقع**: `components/reports-view.tsx`

**الوظائف**:
1. اختيار نوع التقرير
2. تحديد الفترة الزمنية
3. عرض البيانات في جداول
4. عرض الرسوم البيانية
5. تصدير التقرير

**الاستخدام**:
\`\`\`typescript
<ReportsView locale="ar" />
\`\`\`

---

## 🔄 تدفق البيانات

### 1. تدفق المصادقة

\`\`\`
┌─────────────┐
│ Login Page  │
└──────┬──────┘
       │ 1. إدخال البيانات
       ↓
┌─────────────────┐
│  Login Form     │
└──────┬──────────┘
       │ 2. POST /api/auth/login
       ↓
┌─────────────────────┐
│  Auth API Handler   │
└──────┬──────────────┘
       │ 3. التحقق من قاعدة البيانات
       ↓
┌─────────────────┐
│   Database      │
└──────┬──────────┘
       │ 4. إرجاع بيانات المستخدم
       ↓
┌─────────────────────┐
│  Generate JWT       │
└──────┬──────────────┘
       │ 5. إرجاع Token + User
       ↓
┌─────────────────┐
│  AuthContext    │
└──────┬──────────┘
       │ 6. تخزين في localStorage
       ↓
┌─────────────────┐
│  Redirect to    │
│  Dashboard      │
└─────────────────┘
\`\`\`

### 2. تدفق CRUD (إنشاء، قراءة، تحديث، حذف)

#### مثال: إضافة مركبة جديدة

\`\`\`
┌─────────────────┐
│  Fleet Page     │
└──────┬──────────┘
       │ 1. النقر على "إضافة مركبة"
       ↓
┌─────────────────┐
│  Dialog Form    │
└──────┬──────────┘
       │ 2. إدخال البيانات
       ↓
┌─────────────────┐
│  Zod Validation │
└──────┬──────────┘
       │ 3. التحقق من البيانات
       ↓
┌─────────────────────┐
│  POST /api/vehicles │
└──────┬──────────────┘
       │ 4. إرسال الطلب مع JWT
       ↓
┌─────────────────────┐
│  API Middleware     │
│  - requireAuth()    │
│  - requirePermission│
└──────┬──────────────┘
       │ 5. التحقق من الصلاحيات
       ↓
┌─────────────────────┐
│  Validate Request   │
│  (Zod Schema)       │
└──────┬──────────────┘
       │ 6. التحقق من البيانات
       ↓
┌─────────────────────┐
│  Database Insert    │
└──────┬──────────────┘
       │ 7. إدراج في قاعدة البيانات
       ↓
┌─────────────────────┐
│  Return Response    │
└──────┬──────────────┘
       │ 8. إرجاع المركبة الجديدة
       ↓
┌─────────────────┐
│  Update UI      │
│  (SWR Mutate)   │
└─────────────────┘
\`\`\`

### 3. تدفق التقارير

\`\`\`
┌─────────────────┐
│  Reports Page   │
└──────┬──────────┘
       │ 1. اختيار نوع التقرير
       ↓
┌─────────────────┐
│  Select Filters │
│  (Date Range)   │
└──────┬──────────┘
       │ 2. تحديد الفترة
       ↓
┌─────────────────────────────┐
│  GET /api/reports/[type]    │
└──────┬──────────────────────┘
       │ 3. طلب البيانات
       ↓
┌─────────────────────┐
│  API Handler        │
│  - requireAuth()    │
│  - requirePermission│
└──────┬──────────────┘
       │ 4. التحقق من الصلاحيات
       ↓
┌─────────────────────┐
│  Query Database     │
│  - Aggregate Data   │
│  - Calculate Stats  │
└──────┬──────────────┘
       │ 5. جلب وحساب البيانات
       ↓
┌─────────────────────┐
│  Format Response    │
└──────┬──────────────┘
       │ 6. تنسيق البيانات
       ↓
┌─────────────────┐
│  Display Report │
│  - Table        │
│  - Charts       │
└──────┬──────────┘
       │ 7. عرض التقرير
       ↓
┌─────────────────┐
│  Export Option  │
└──────┬──────────┘
       │ 8. النقر على "تصدير"
       ↓
┌─────────────────────────┐
│  POST /api/reports/export│
└──────┬──────────────────┘
       │ 9. طلب التصدير
       ↓
┌─────────────────────┐
│  Generate File      │
│  (Excel/CSV/PDF)    │
└──────┬──────────────┘
       │ 10. إنشاء الملف
       ↓
┌─────────────────┐
│  Download File  │
└─────────────────┘
\`\`\`

### 4. تدفق الصلاحيات

\`\`\`
┌─────────────────┐
│  User Login     │
└──────┬──────────┘
       │
       ↓
┌─────────────────────────┐
│  Load User Permissions  │
│  FROM:                  │
│  users → user_roles →   │
│  roles → role_permissions│
│  → permissions          │
└──────┬──────────────────┘
       │
       ↓
┌─────────────────────┐
│  Store in Context   │
│  {                  │
│    permissions: [   │
│      'vehicles.read'│
│      'vehicles.write'│
│    ]                │
│  }                  │
└──────┬──────────────┘
       │
       ↓
┌─────────────────────┐
│  Check Permission   │
│  Before Action      │
└──────┬──────────────┘
       │
       ├─ YES → Allow Action
       │
       └─ NO  → Show Error/Hide Button
\`\`\`

---

## 🔗 العلاقات بين المكونات

### 1. علاقات قاعدة البيانات

\`\`\`
companies (الشركات)
    ↓ (1:N)
    ├─ users (المستخدمون)
    ├─ vehicles (المركبات)
    ├─ drivers (السائقون)
    ├─ reservations (الحجوزات)
    ├─ tickets (التذاكر)
    ├─ movements (الحركات)
    └─ supplies (المستلزمات)

vehicles (المركبات)
    ↓ (1:N)
    └─ reservations (الحجوزات)

drivers (السائقون)
    ↓ (1:N)
    └─ reservations (الحجوزات)

users (المستخدمون)
    ↓ (N:M)
    └─ roles (الأدوار)
        ↓ (N:M)
        └─ permissions (الصلاحيات)
\`\`\`

### 2. علاقات المكونات

\`\`\`
App Layout
├─ AuthProvider
│  └─ CompanyProvider
│     └─ SelectionProvider
│        └─ Page Content
│
DashboardLayout
├─ Sidebar
│  └─ Navigation Links
├─ Header
│  └─ User Menu
└─ Main Content
   └─ Page Component
      ├─ Data Table
      │  ├─ Table Header
      │  ├─ Table Body
      │  └─ Table Actions
      └─ Forms/Dialogs
\`\`\`

### 3. علاقات API

\`\`\`
Frontend Component
    ↓ (HTTP Request)
API Client (lib/api-client.ts)
    ↓ (fetch)
Middleware (middleware.ts)
    ↓ (extract company_code)
API Route Handler (app/api/*/route.ts)
    ↓ (authentication)
Security Layer (lib/security/api-auth.ts)
    ↓ (authorization)
Validation Layer (lib/validation/schemas.ts)
    ↓ (business logic)
Database Layer (lib/db.ts)
    ↓ (SQL query)
PostgreSQL Database
    ↓ (response)
API Response
    ↓ (JSON)
Frontend Component (update UI)
\`\`\`

---

## 📈 الأداء والتحسين

### 1. استراتيجيات التخزين المؤقت

**أ. Client-Side Caching (SWR)**
\`\`\`typescript
const { data, error } = useSWR('/api/vehicles', fetcher, {
  revalidateOnFocus: false,
  dedupingInterval: 60000 // 1 دقيقة
})
\`\`\`

**ب. Server-Side Caching (Redis)**
\`\`\`typescript
// تخزين لمدة 5 دقائق
mockCache.set('/api/dashboard/stats', data, 300)
\`\`\`

**ج. Database Query Optimization**
- استخدام Indexes
- تجنب N+1 Queries
- استخدام JOINs بدلاً من Multiple Queries

### 2. تحسين الأداء

**أ. Code Splitting**
- استخدام Dynamic Imports
- Lazy Loading للمكونات الثقيلة

**ب. Image Optimization**
- استخدام Next.js Image Component
- WebP Format
- Lazy Loading

**ج. Bundle Size Optimization**
- Tree Shaking
- Code Minification
- Compression (gzip/brotli)

### 3. مراقبة الأداء

**Logging System** (`lib/logging/logger.ts`):
\`\`\`typescript
logger.info('User logged in', { userId: '1' })
logger.error('Database error', { error })
logger.warn('Rate limit approaching', { remaining: 10 })
\`\`\`

---

## 🛠️ الصيانة والتطوير

### 1. إضافة ميزة جديدة

**الخطوات**:

1. **تحديد المتطلبات**
   - ما هي الميزة؟
   - من يستخدمها؟
   - ما هي الصلاحيات المطلوبة؟

2. **تصميم قاعدة البيانات**
   - إنشاء جداول جديدة
   - تحديد العلاقات
   - إضافة Indexes

3. **إنشاء Validation Schema**
   \`\`\`typescript
   // في lib/validation/schemas.ts
   export const createNewFeatureSchema = z.object({
     // ...
   })
   \`\`\`

4. **إنشاء API Routes**
   \`\`\`typescript
   // في app/api/new-feature/route.ts
   export async function GET(request: NextRequest) {
     const authResult = await requirePermission(request, 'new-feature.read')
     // ...
   }
   \`\`\`

5. **إنشاء UI Components**
   \`\`\`typescript
   // في components/new-feature-table.tsx
   export function NewFeatureTable() {
     // ...
   }
   \`\`\`

6. **إضافة الصفحة**
   \`\`\`typescript
   // في app/new-feature/page.tsx
   export default function NewFeaturePage() {
     // ...
   }
   \`\`\`

7. **تحديث Sidebar**
   \`\`\`typescript
   // في components/sidebar.tsx
   {hasPermission('new-feature.read') && (
     <Link href="/new-feature">الميزة الجديدة</Link>
   )}
   \`\`\`

8. **الاختبار**
   - اختبار الوظائف
   - اختبار الصلاحيات
   - اختبار الأداء

### 2. إضافة صلاحية جديدة

**الخطوات**:

1. **إضافة في قاعدة البيانات**
   \`\`\`sql
   INSERT INTO permissions (name, display_name, resource, action)
   VALUES ('new-feature.read', 'عرض الميزة الجديدة', 'new-feature', 'read');
   \`\`\`

2. **ربط بالأدوار**
   \`\`\`sql
   INSERT INTO role_permissions (role_id, permission_id)
   VALUES (1, (SELECT id FROM permissions WHERE name = 'new-feature.read'));
   \`\`\`

3. **استخدام في الكود**
   \`\`\`typescript
   await requirePermission(request, 'new-feature.read')
   \`\`\`

### 3. إضافة تقرير جديد

**الخطوات**:

1. **إنشاء API Route**
   \`\`\`typescript
   // في app/api/reports/new-report/route.ts
   export async function GET(request: NextRequest) {
     const authResult = await requirePermission(request, 'reports.read')
     // جلب البيانات من قاعدة البيانات
     // حساب الإحصائيات
     // إرجاع النتيجة
   }
   \`\`\`

2. **إضافة في ReportsView**
   \`\`\`typescript
   // في components/reports-view.tsx
   const reportTypes = [
     // ...
     { value: 'new-report', label: 'التقرير الجديد' }
   ]
   \`\`\`

3. **إضافة معالج التصدير**
   \`\`\`typescript
   // في lib/export-utils.ts
   if (reportType === 'new-report') {
     // منطق التصدير
   }
   \`\`\`

---

## 🔐 أفضل الممارسات الأمنية

### 1. المصادقة والترخيص

✅ **استخدام JWT** بدلاً من Sessions
✅ **تشفير كلمات المرور** باستخدام bcrypt
✅ **التحقق من الصلاحيات** في كل طلب API
✅ **Rate Limiting** لمنع الهجمات
✅ **HTTPS فقط** في الإنتاج

### 2. التحقق من البيانات

✅ **التحقق في الواجهة والخادم**
✅ **استخدام Zod Schemas**
✅ **تنظيف المدخلات** (Sanitization)
✅ **منع SQL Injection** باستخدام Parameterized Queries
✅ **منع XSS** بتنظيف HTML

### 3. إدارة الأخطاء

✅ **عدم كشف معلومات حساسة** في رسائل الخطأ
✅ **تسجيل الأخطاء** للمراجعة
✅ **رسائل خطأ واضحة** للمستخدم
✅ **معالجة جميع الحالات** الاستثنائية

### 4. حماية البيانات

✅ **عزل البيانات** بين الشركات (company_id)
✅ **تشفير البيانات الحساسة**
✅ **النسخ الاحتياطي** المنتظم
✅ **التحكم في الوصول** (RBAC)

---

## 📚 الخلاصة

### نقاط القوة

1. ✅ **بنية معمارية قوية**: فصل واضح بين الطبقات
2. ✅ **أمان عالي**: JWT, RBAC, Rate Limiting, Validation
3. ✅ **قابلية التوسع**: Multi-tenancy, Modular Design
4. ✅ **تجربة مستخدم ممتازة**: RTL, Responsive, Bilingual
5. ✅ **أداء محسّن**: Caching, Code Splitting, Optimization
6. ✅ **سهولة الصيانة**: TypeScript, Clean Code, Documentation

### التقنيات الرئيسية

| المجال | التقنية |
|--------|---------|
| Frontend | React + Next.js 16 |
| Backend | Next.js API Routes |
| Database | PostgreSQL (Neon) |
| Cache | Redis (Upstash) |
| Authentication | JWT |
| Validation | Zod |
| UI | Tailwind CSS + shadcn/ui |
| Language | TypeScript |

### الوحدات الرئيسية

1. **المصادقة والترخيص**: JWT + RBAC
2. **إدارة المركبات**: CRUD + Tracking
3. **إدارة السائقين**: CRUD + Performance
4. **الحجوزات**: Scheduling + Management
5. **التذاكر**: Booking + Tracking
6. **الحركات**: Trip Management
7. **المستلزمات**: Inventory Management
8. **التقارير**: Analytics + Export
9. **لوحة التحكم**: Stats + Charts
10. **الإدارة**: Users + Roles + Permissions

### مسار البيانات

\`\`\`
User Input → Validation → Authentication → Authorization 
→ Business Logic → Database → Response → UI Update
\`\`\`

### الأمان

\`\`\`
JWT + bcrypt + Rate Limiting + RBAC + Validation 
+ SQL Injection Prevention + XSS Prevention
\`\`\`

---

## 📞 الدعم والمساعدة

للمزيد من المعلومات أو المساعدة، يرجى الرجوع إلى:

- **الوثائق التقنية**: `/docs`
- **دليل API**: `/docs/API_DOCUMENTATION.md`
- **دليل الأمان**: `/docs/SECURITY_FRAMEWORK.md`
- **دليل RBAC**: `/app/rbac-guide/page.tsx`

---

**تم إعداد هذا التقرير بواسطة**: FleetPro Management System
**التاريخ**: 2024
**الإصدار**: 1.0

---

## 🎯 ملاحظات ختامية

هذا النظام مصمم ليكون:
- **آمن**: حماية متعددة الطبقات
- **قابل للتوسع**: دعم عدد غير محدود من الشركات
- **سهل الاستخدام**: واجهة بديهية بالعربية
- **قابل للصيانة**: كود نظيف وموثق
- **عالي الأداء**: تحسينات متعددة

النظام جاهز للاستخدام في بيئة الإنتاج مع إمكانية التوسع والتطوير المستمر.
