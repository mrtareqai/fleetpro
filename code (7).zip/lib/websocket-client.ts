"use client"

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000/ws"
const USE_MOCK_WS = true // Use mock WebSocket since no backend is configured

type MessageHandler = (data: any) => void

class WebSocketClient {
  private ws: WebSocket | null = null
  private clientId: string
  private reconnectAttempts = 0
  private maxReconnectAttempts = 5
  private reconnectDelay = 1000
  private messageHandlers: Set<MessageHandler> = new Set()
  private mockMode: boolean

  constructor(clientId: string, mockMode = USE_MOCK_WS) {
    this.clientId = clientId
    this.mockMode = mockMode
  }

  connect() {
    if (this.mockMode) {
      console.log("[v0] WebSocket running in mock mode (no backend required)")
      return
    }

    if (this.ws?.readyState === WebSocket.OPEN) {
      return
    }

    try {
      this.ws = new WebSocket(`${WS_URL}/${this.clientId}`)

      this.ws.onopen = () => {
        console.log("[v0] WebSocket connected")
        this.reconnectAttempts = 0
      }

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data)
          this.messageHandlers.forEach((handler) => handler(data))
        } catch (error) {
          console.error("[v0] Error parsing WebSocket message:", error)
        }
      }

      this.ws.onerror = (error) => {
        console.error("[v0] WebSocket error:", error)
      }

      this.ws.onclose = () => {
        console.log("[v0] WebSocket disconnected")
        this.reconnect()
      }
    } catch (error) {
      console.error("[v0] Error creating WebSocket:", error)
      this.reconnect()
    }
  }

  private reconnect() {
    if (this.mockMode) return

    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error("[v0] Max reconnection attempts reached")
      return
    }

    this.reconnectAttempts++
    const delay = this.reconnectDelay * this.reconnectAttempts

    console.log(`[v0] Reconnecting in ${delay}ms... (attempt ${this.reconnectAttempts})`)

    setTimeout(() => {
      this.connect()
    }, delay)
  }

  disconnect() {
    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
  }

  send(data: any) {
    if (this.mockMode) {
      console.log("[v0] Mock WebSocket send:", data)
      return
    }

    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data))
    } else {
      console.warn("[v0] WebSocket is not connected")
    }
  }

  onMessage(handler: MessageHandler) {
    this.messageHandlers.add(handler)
    return () => {
      this.messageHandlers.delete(handler)
    }
  }
}

// Singleton instance
let wsClient: WebSocketClient | null = null

export function getWebSocketClient(clientId?: string): WebSocketClient {
  if (!wsClient) {
    wsClient = new WebSocketClient(clientId || `client-${Date.now()}`)
  }
  return wsClient
}

import React from "react"

export function useWebSocket() {
  const [isConnected, setIsConnected] = React.useState(false)
  const [lastMessage, setLastMessage] = React.useState<any>(null)
  const wsClientRef = React.useRef<WebSocketClient | null>(null)

  React.useEffect(() => {
    const client = getWebSocketClient()
    wsClientRef.current = client

    client.connect()
    setIsConnected(true)

    const unsubscribe = client.onMessage((data) => {
      setLastMessage(data)
    })

    return () => {
      unsubscribe()
      client.disconnect()
      setIsConnected(false)
    }
  }, [])

  const sendMessage = React.useCallback((data: any) => {
    wsClientRef.current?.send(data)
  }, [])

  return {
    isConnected,
    lastMessage,
    sendMessage,
  }
}
