"use client"

import { useState, useEffect } from "react"
import { TrendingUp, Calendar, Truck } from "lucide-react"
import {
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts"
import { apiClient } from "@/lib/api-client"
import { useWebSocket } from "@/lib/websocket-client"

interface DashboardOverviewProps {
  locale: "en" | "ar"
}

interface DashboardStats {
  total_vehicles: number
  active_reservations: number
  upcoming_reservations: number
}

export default function DashboardOverview({ locale }: DashboardOverviewProps) {
  const [stats, setStats] = useState<DashboardStats>({
    total_vehicles: 0,
    active_reservations: 0,
    upcoming_reservations: 0,
  })
  const [loading, setLoading] = useState(true)
  const [trendData, setTrendData] = useState([
    { month: "Jan", value: 10 },
    { month: "Feb", value: 15 },
    { month: "Mar", value: 25 },
    { month: "Apr", value: 18 },
    { month: "May", value: 30 },
    { month: "Jun", value: 35 },
  ])

  const [fleetData, setFleetData] = useState([
    { name: "Active", value: 45, color: "#3b82f6" },
    { name: "Inactive", value: 25, color: "#60a5fa" },
    { name: "Maintenance", value: 20, color: "#22c55e" },
    { name: "Native", value: 10, color: "#f97316" },
  ])

  const t = {
    en: {
      title: "Dashboard Overview",
      totalVehicles: "Total Vehicles",
      activeReservations: "Active Reservations",
      upcoming: "Upcoming",
      reservations: "Reservations",
      inRoutes: "In Routes",
      monthlyTrend: "Monthly Reservations Trend",
      fleetStatus: "Fleet Status Maintenance",
      recentActivities: "Recent Activities",
      active: "Active",
      inactive: "Inactive",
      maintenance: "Maintenance",
      native: "Native",
      loading: "Loading...",
    },
    ar: {
      title: "نظرة عامة على لوحة التحكم",
      totalVehicles: "إجمالي المركبات",
      activeReservations: "الحجوزات النشطة",
      upcoming: "القادمة",
      reservations: "الحجوزات",
      inRoutes: "في الطرق",
      monthlyTrend: "اتجاه الحجوزات الشهرية",
      fleetStatus: "حالة صيانة الأسطول",
      recentActivities: "الأنشطة الأخيرة",
      active: "نشط",
      inactive: "غير نشط",
      maintenance: "صيانة",
      native: "أصلي",
      loading: "جاري التحميل...",
    },
  }

  useEffect(() => {
    fetchDashboardStats()
    fetchChartsData()
  }, [])

  useWebSocket((message) => {
    if (message.type === "dashboard_update") {
      console.log("[v0] Received dashboard update via WebSocket")
      fetchDashboardStats()
      fetchChartsData()
    }
  })

  const fetchDashboardStats = async () => {
    try {
      setLoading(true)
      const data = await apiClient.getDashboardStats()
      setStats(data)
    } catch (err) {
      console.error("[v0] Error fetching dashboard stats:", err)
    } finally {
      setLoading(false)
    }
  }

  const fetchChartsData = async () => {
    try {
      const data = await apiClient.getChartData()
      if (data.monthlyReservations) {
        setTrendData(data.monthlyReservations)
      }
      if (data.fleetStatus) {
        setFleetData(
          data.fleetStatus.map((item: any, index: number) => ({
            name:
              item.name === "active"
                ? t[locale].active
                : item.name === "inactive"
                  ? t[locale].inactive
                  : item.name === "maintenance"
                    ? t[locale].maintenance
                    : item.name,
            value: item.value,
            color: index === 0 ? "#3b82f6" : index === 1 ? "#60a5fa" : index === 2 ? "#22c55e" : "#f97316",
          })),
        )
      }
    } catch (err) {
      console.error("[v0] Error fetching charts data:", err)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6">
        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs md:text-sm text-slate-500">{t[locale].totalVehicles}</p>
              <p className="text-3xl md:text-4xl font-bold text-slate-800 mt-2">{stats.total_vehicles}</p>
              <p className="text-xs text-slate-400 mt-1">Vehicles</p>
            </div>
            <Truck className="w-10 h-10 md:w-12 md:h-12 text-slate-300" />
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs md:text-sm text-slate-500">{t[locale].activeReservations}</p>
              <p className="text-3xl md:text-4xl font-bold text-slate-800 mt-2">{stats.active_reservations}</p>
              <p className="text-xs text-slate-400 mt-1">{t[locale].reservations}</p>
            </div>
            <div className="w-10 h-10 md:w-12 md:h-12 bg-green-500 rounded-full flex items-center justify-center">
              <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs md:text-sm text-slate-500">{t[locale].upcoming}</p>
              <p className="text-3xl md:text-4xl font-bold text-slate-800 mt-2">{stats.upcoming_reservations}</p>
              <p className="text-xs text-slate-400 mt-1">{t[locale].inRoutes}</p>
            </div>
            <Calendar className="w-10 h-10 md:w-12 md:h-12 text-slate-300" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
          <h3 className="text-base md:text-lg font-semibold text-slate-800 mb-4">{t[locale].monthlyTrend}</h3>
          <ResponsiveContainer width="100%" height={200} className="md:h-[250px]">
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="month" stroke="#6b7280" style={{ fontSize: "12px" }} />
              <YAxis stroke="#6b7280" style={{ fontSize: "12px" }} />
              <Tooltip />
              <Line type="monotone" dataKey="value" stroke="#22c55e" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
          <h3 className="text-base md:text-lg font-semibold text-slate-800 mb-4">{t[locale].fleetStatus}</h3>
          <ResponsiveContainer width="100%" height={200} className="md:h-[250px]">
            <PieChart>
              <Pie
                data={fleetData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {fleetData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-3 md:gap-4 mt-4">
            {fleetData.map((item, index) => (
              <div key={index} className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full flex-shrink-0" style={{ backgroundColor: item.color }} />
                <span className="text-xs md:text-sm text-slate-600 truncate">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl p-4 md:p-6 shadow-sm">
        <h3 className="text-base md:text-lg font-semibold text-slate-800 mb-4">{t[locale].recentActivities}</h3>
        <p className="text-xs md:text-sm text-slate-500">Imstles</p>
      </div>
    </div>
  )
}
