import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/api-auth"
import { logger } from "@/lib/logging/logger"
import { createSupplySchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { handleApiError, AppError } from "@/lib/api/error-handler"
import { executeQuery } from "@/lib/api/db-utils"
import { apiRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import { withCache, CACHE_TTL, invalidateCachePattern } from "@/lib/api/cache-utils"
import { getPaginationParams, getSearchParams, createPaginatedResponse } from "@/lib/api/pagination-utils"

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: { "Retry-After": "60" } },
      )
    }

    const authResult = await requirePermission(request, "supplies.read")
    if (authResult instanceof Response) return authResult

    const { userId, role } = authResult

    const { page, limit, offset, sort, order } = getPaginationParams(request)
    const { search, status } = getSearchParams(request)

    logger.info("Fetching agency supplies", { userId, role, page, limit, search, status })

    const cacheKey = `supplies:list:${page}:${limit}:${search || "all"}:${status || "all"}:${sort || "default"}:${order}`

    const result = await withCache(
      cacheKey,
      async () => {
        const supplies = await executeQuery(async (sql) => {
          let query = sql`
            SELECT 
              s.id, s.vehicle_id, s.supply_type, s.category, s.subject,
              s.quantity, s.date, s.priority, s.status, s.company_id,
              s.created_at, s.updated_at,
              v.model as vehicle_model, v.plate_number as vehicle_plate
            FROM agency_supplies s
            LEFT JOIN vehicles v ON s.vehicle_id = v.id
            WHERE 1=1
          `

          if (search) {
            query = sql`${query} AND (
              s.supply_type ILIKE ${"%" + search + "%"} OR
              s.category ILIKE ${"%" + search + "%"} OR
              s.subject ILIKE ${"%" + search + "%"} OR
              v.plate_number ILIKE ${"%" + search + "%"}
            )`
          }

          if (status) {
            query = sql`${query} AND s.status = ${status}`
          }

          const sortColumn = sort || "date"
          const sortOrder = order === "asc" ? sql`ASC` : sql`DESC`
          query = sql`${query} ORDER BY s.${sql(sortColumn)} ${sortOrder}`

          query = sql`${query} LIMIT ${limit} OFFSET ${offset}`

          return await query
        })

        const totalResult = await executeQuery(async (sql) => {
          let countQuery = sql`
            SELECT COUNT(*) as count 
            FROM agency_supplies s
            LEFT JOIN vehicles v ON s.vehicle_id = v.id
            WHERE 1=1
          `

          if (search) {
            countQuery = sql`${countQuery} AND (
              s.supply_type ILIKE ${"%" + search + "%"} OR
              s.category ILIKE ${"%" + search + "%"} OR
              s.subject ILIKE ${"%" + search + "%"} OR
              v.plate_number ILIKE ${"%" + search + "%"}
            )`
          }

          if (status) {
            countQuery = sql`${countQuery} AND s.status = ${status}`
          }

          return await countQuery
        })

        const total = Number.parseInt(totalResult[0]?.count || "0", 10)

        return createPaginatedResponse(supplies, page, limit, total)
      },
      CACHE_TTL.MEDIUM,
    )

    const duration = Date.now() - startTime
    logger.info("Agency supplies fetched successfully", {
      userId,
      count: result.data.length,
      total: result.pagination.total,
      duration,
    })

    return NextResponse.json(result)
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Fetch supplies", duration })
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429, headers: { "Retry-After": "60" } },
      )
    }

    const authResult = await requirePermission(request, "supplies.create")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult

    let body
    try {
      body = await request.json()
    } catch {
      throw new AppError("Invalid JSON in request body", 400, "INVALID_JSON")
    }

    const validatedData = await validateOrRespond(createSupplySchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Creating new agency supply", {
      userId,
      vehicleId: validatedData.vehicle_id,
      supplyType: validatedData.supply_type,
    })

    const vehicleExists = await executeQuery(async (sql) => {
      const result = await sql`
        SELECT EXISTS(
          SELECT 1 FROM vehicles WHERE id = ${validatedData.vehicle_id}
        ) as exists
      `
      return result[0]?.exists
    })

    if (!vehicleExists) {
      throw new AppError("Vehicle not found", 404, "VEHICLE_NOT_FOUND")
    }

    const supplyDate = new Date(validatedData.date)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (supplyDate < today) {
      logger.warn("Supply date is in the past", {
        userId,
        supplyDate: validatedData.date,
      })
    }

    const supply = await executeQuery(async (sql) => {
      const result = await sql`
        INSERT INTO agency_supplies (
          vehicle_id, supply_type, category, subject, quantity, date,
          priority, status, company_id, created_at, updated_at
        ) VALUES (
          ${validatedData.vehicle_id}, ${validatedData.supply_type}, ${validatedData.category},
          ${validatedData.subject}, ${validatedData.quantity}, ${validatedData.date},
          ${validatedData.priority}, ${validatedData.status}, ${validatedData.company_id || null},
          NOW(), NOW()
        )
        RETURNING *
      `
      return result[0]
    })

    await invalidateCachePattern("supplies:*")

    const duration = Date.now() - startTime

    logger.info("Agency supply created successfully", {
      userId,
      supplyId: supply.id,
      duration,
    })

    return NextResponse.json(
      { supply, message: "Supply request created successfully" },
      { status: 201, headers: { Location: `/api/supplies/${supply.id}` } },
    )
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Create supply", duration })
  }
}
