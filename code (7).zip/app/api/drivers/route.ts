import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/api-auth"
import { createDriverSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"
import { handleApiError, AppError } from "@/lib/api/error-handler"
import { executeQuery } from "@/lib/api/db-utils"
import { apiRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import {
  getPaginationParams,
  getSearchParams,
  createPaginatedResponse,
  validatePaginationParams,
  generatePaginationCacheKey,
} from "@/lib/api/pagination-utils"
import { getCachedData, setCachedData } from "@/lib/api/cache-utils"

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "drivers.read")
    if (authResult instanceof Response) return authResult

    const { userId, role } = authResult

    const { page, limit, offset, sort, order } = getPaginationParams(request)
    const { search, status } = getSearchParams(request)

    const validation = validatePaginationParams(page, limit)
    if (!validation.valid) {
      return NextResponse.json({ error: validation.error }, { status: 400 })
    }

    logger.info("Fetching drivers", { userId, role, page, limit, search, status })

    const cacheKey = generatePaginationCacheKey("drivers", { page, limit, search, status, sort, order })

    const cached = await getCachedData(cacheKey)
    if (cached) {
      logger.info("Drivers fetched from cache", { userId, cacheKey })
      return NextResponse.json(cached, {
        headers: {
          "X-Cache": "HIT",
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      })
    }

    const drivers = await executeQuery(async (sql) => {
      let query = sql`
        SELECT 
          id,
          name,
          license_number,
          phone,
          email,
          status,
          company_id,
          created_at,
          updated_at
        FROM drivers
        WHERE 1=1
      `

      // Apply search filter
      if (search) {
        query = sql`${query} AND (
          name ILIKE ${"%" + search + "%"} OR
          license_number ILIKE ${"%" + search + "%"} OR
          phone ILIKE ${"%" + search + "%"}
        )`
      }

      // Apply status filter
      if (status) {
        query = sql`${query} AND status = ${status}`
      }

      // Apply sorting
      const sortField = sort === "name" ? "name" : "created_at"
      const sortOrder = order === "asc" ? sql`ASC` : sql`DESC`
      query = sql`${query} ORDER BY ${sql(sortField)} ${sortOrder}`

      // Apply pagination
      query = sql`${query} LIMIT ${limit} OFFSET ${offset}`

      return await query
    })

    const totalResult = await executeQuery(async (sql) => {
      let countQuery = sql`SELECT COUNT(*) as count FROM drivers WHERE 1=1`

      if (search) {
        countQuery = sql`${countQuery} AND (
          name ILIKE ${"%" + search + "%"} OR
          license_number ILIKE ${"%" + search + "%"} OR
          phone ILIKE ${"%" + search + "%"}
        )`
      }

      if (status) {
        countQuery = sql`${countQuery} AND status = ${status}`
      }

      return await countQuery
    })

    const total = Number(totalResult[0]?.count || 0)

    const response = createPaginatedResponse(drivers, page, limit, total)

    await setCachedData(cacheKey, response, 300)

    const duration = Date.now() - startTime
    logger.info("Drivers fetched successfully", {
      userId,
      count: drivers.length,
      total,
      page,
      duration,
    })

    return NextResponse.json(response, {
      headers: {
        "X-Cache": "MISS",
        "X-RateLimit-Limit": rateLimitResult.limit.toString(),
        "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
        "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
      },
    })
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Fetch drivers", userId: 0, duration })
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "drivers.create")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult

    let body
    try {
      body = await request.json()
    } catch {
      throw new AppError("Invalid JSON in request body", 400, "INVALID_JSON")
    }

    const validatedData = await validateOrRespond(createDriverSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Creating new driver", {
      userId,
      driverName: validatedData.name,
    })

    const duplicateExists = await executeQuery(async (sql) => {
      const result = await sql`
        SELECT EXISTS(
          SELECT 1 FROM drivers 
          WHERE license_number = ${validatedData.license_number}
        ) as exists
      `
      return result[0]?.exists
    })

    if (duplicateExists) {
      throw new AppError("A driver with this license number already exists", 409, "DUPLICATE_LICENSE")
    }

    const driver = await executeQuery(async (sql) => {
      const result = await sql`
        INSERT INTO drivers (
          name,
          license_number,
          phone,
          email,
          status,
          company_id,
          created_at,
          updated_at
        ) VALUES (
          ${validatedData.name},
          ${validatedData.license_number},
          ${validatedData.phone || null},
          ${validatedData.email || null},
          ${validatedData.status},
          ${validatedData.company_id || null},
          NOW(),
          NOW()
        )
        RETURNING 
          id,
          name,
          license_number,
          phone,
          email,
          status,
          company_id,
          created_at,
          updated_at
      `
      return result[0]
    })

    const duration = Date.now() - startTime

    logger.info("Driver created successfully", {
      userId,
      driverId: driver.id,
      duration,
    })

    const response = NextResponse.json(
      {
        driver,
        message: "Driver created successfully",
      },
      {
        status: 201,
        headers: {
          Location: `/api/drivers/${driver.id}`,
        },
      },
    )

    response.headers.set("X-RateLimit-Limit", rateLimitResult.limit.toString())
    response.headers.set("X-RateLimit-Remaining", rateLimitResult.remaining.toString())
    response.headers.set("X-RateLimit-Reset", new Date(rateLimitResult.reset).toISOString())

    return response
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Create driver", duration })
  }
}
