import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { mockStore } from "@/lib/mock-store"
import { requirePermission } from "@/lib/security/api-auth"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log("[v0] === GET /api/admin/users/[id] START ===")

    const authResult = await requirePermission(request, "users.read")
    if (authResult instanceof Response) return authResult

    if (authResult.role !== "admin" && authResult.role !== "super_admin") {
      return NextResponse.json({ error: "Only administrators can view user details" }, { status: 403 })
    }

    const { id } = params
    console.log("[v0] Fetching user with id:", id)

    if (!sql) {
      console.log("[v0] Using mock store")
      const user = mockStore.getUserById(id)
      if (!user) {
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }
      return NextResponse.json({ user })
    }

    try {
      const [user] = await sql`
        SELECT 
          u.id,
          u.username,
          u.email,
          u.full_name,
          u.role,
          u.created_at,
          u.updated_at
        FROM users u
        WHERE u.id = ${id}
      `

      if (!user) {
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }

      const roles = await sql`
        SELECT r.id, r.name, r.display_name, r.description
        FROM roles r
        JOIN user_roles ur ON r.id = ur.role_id
        WHERE ur.user_id = ${id}
      `

      return NextResponse.json({ user: { ...user, roles } })
    } catch (dbError) {
      console.error("[v0] Error fetching user from database:", dbError)
      return NextResponse.json({ error: "Failed to fetch user" }, { status: 500 })
    }
  } catch (error) {
    console.error("[v0] Error in GET /api/admin/users/[id]:", error)
    return NextResponse.json({ error: "Failed to fetch user" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log("[v0] === PUT /api/admin/users/[id] START ===")

    const authResult = await requirePermission(request, "users.update")
    if (authResult instanceof Response) {
      console.log("[v0] Auth failed, returning response")
      return authResult
    }

    if (authResult.role !== "admin" && authResult.role !== "super_admin") {
      console.log("[v0] User is not admin, returning 403")
      return NextResponse.json({ error: "Only administrators can update users" }, { status: 403 })
    }

    const { id } = params
    console.log("[v0] Updating user with id:", id)

    const body = await request.json()
    console.log("[v0] Request body:", JSON.stringify(body))

    const { username, email, full_name, role_ids, is_active } = body

    if (!sql) {
      console.log("[v0] Using mock store to update user")
      const updatedUser = mockStore.updateUser(id, {
        username,
        email,
        full_name,
        is_active,
        roles: role_ids
          ?.map((roleId: number) => {
            const role = mockStore.getRoleById(roleId)
            return role ? { id: role.id, name: role.name, display_name: role.display_name } : null
          })
          .filter(Boolean),
      })

      if (!updatedUser) {
        console.log("[v0] User not found in mock store")
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }

      console.log("[v0] User updated successfully:", updatedUser)
      return NextResponse.json({ user: updatedUser })
    }

    try {
      const [user] = await sql`
        UPDATE users
        SET username = ${username},
            email = ${email},
            full_name = ${full_name},
            updated_at = CURRENT_TIMESTAMP,
            is_active = ${is_active}
        WHERE id = ${id}
        RETURNING id, username, email, full_name, is_active
      `

      if (role_ids !== undefined) {
        await sql`DELETE FROM user_roles WHERE user_id = ${id}`

        if (role_ids.length > 0) {
          for (const role_id of role_ids) {
            await sql`
              INSERT INTO user_roles (user_id, role_id)
              VALUES (${id}, ${role_id})
              ON CONFLICT DO NOTHING
            `
          }
        }
      }

      return NextResponse.json({ user })
    } catch (dbError) {
      console.error("[v0] Error updating user in database:", dbError)
      return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
    }
  } catch (error) {
    console.error("[v0] Error in PUT /api/admin/users/[id]:", error)
    console.error("[v0] Error stack:", error instanceof Error ? error.stack : "No stack trace")
    return NextResponse.json({ error: "Failed to update user" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    console.log("[v0] === DELETE /api/admin/users/[id] START ===")

    const authResult = await requirePermission(request, "users.delete")
    if (authResult instanceof Response) return authResult

    if (authResult.role !== "admin" && authResult.role !== "super_admin") {
      return NextResponse.json({ error: "Only administrators can delete users" }, { status: 403 })
    }

    const { id } = params
    console.log("[v0] Deleting user with id:", id)

    if (authResult.userId === id) {
      return NextResponse.json({ error: "You cannot delete your own account" }, { status: 403 })
    }

    if (!sql) {
      console.log("[v0] Using mock store to delete user")
      const success = mockStore.deleteUser(id)
      if (!success) {
        return NextResponse.json({ error: "User not found" }, { status: 404 })
      }
      return NextResponse.json({ success: true })
    }

    try {
      await sql`DELETE FROM users WHERE id = ${id}`
      return NextResponse.json({ success: true })
    } catch (dbError) {
      console.error("[v0] Error deleting user from database:", dbError)
      return NextResponse.json({ error: "Failed to delete user" }, { status: 500 })
    }
  } catch (error) {
    console.error("[v0] Error in DELETE /api/admin/users/[id]:", error)
    return NextResponse.json({ error: "Failed to delete user" }, { status: 500 })
  }
}
