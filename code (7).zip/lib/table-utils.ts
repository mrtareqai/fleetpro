export type SortDirection = "asc" | "desc" | null

export interface SortConfig<T> {
  key: keyof T | null
  direction: SortDirection
}

export interface FilterConfig {
  searchQuery: string
  statusFilter: string
  dateRange?: {
    from: Date | null
    to: Date | null
  }
}

/**
 * Sort array of objects by a specific key
 */
export function sortData<T>(data: T[], sortConfig: SortConfig<T>): T[] {
  if (!sortConfig.key || !sortConfig.direction) {
    return data
  }

  return [...data].sort((a, b) => {
    const aValue = a[sortConfig.key!]
    const bValue = b[sortConfig.key!]

    // Handle null/undefined values
    if (aValue == null) return 1
    if (bValue == null) return -1

    // Handle different types
    if (typeof aValue === "string" && typeof bValue === "string") {
      const comparison = aValue.toLowerCase().localeCompare(bValue.toLowerCase())
      return sortConfig.direction === "asc" ? comparison : -comparison
    }

    if (typeof aValue === "number" && typeof bValue === "number") {
      return sortConfig.direction === "asc" ? aValue - bValue : bValue - aValue
    }

    // Handle dates
    if (aValue instanceof Date && bValue instanceof Date) {
      return sortConfig.direction === "asc" ? aValue.getTime() - bValue.getTime() : bValue.getTime() - aValue.getTime()
    }

    // Default string comparison
    const aStr = String(aValue)
    const bStr = String(bValue)
    const comparison = aStr.localeCompare(bStr)
    return sortConfig.direction === "asc" ? comparison : -comparison
  })
}

/**
 * Filter data based on search query and filters
 */
export function filterData<T extends Record<string, any>>(
  data: T[],
  filterConfig: FilterConfig,
  searchableFields: (keyof T)[],
  statusField?: keyof T,
  dateField?: keyof T,
): T[] {
  let filtered = [...data]

  // Apply search query
  if (filterConfig.searchQuery) {
    const query = filterConfig.searchQuery.toLowerCase()
    filtered = filtered.filter((item) =>
      searchableFields.some((field) => {
        const value = item[field]
        return value != null && String(value).toLowerCase().includes(query)
      }),
    )
  }

  // Apply status filter
  if (filterConfig.statusFilter && filterConfig.statusFilter !== "all" && statusField) {
    filtered = filtered.filter((item) => item[statusField] === filterConfig.statusFilter)
  }

  // Apply date range filter
  if (filterConfig.dateRange && dateField) {
    const { from, to } = filterConfig.dateRange
    filtered = filtered.filter((item) => {
      const itemDate = new Date(item[dateField])
      if (from && itemDate < from) return false
      if (to && itemDate > to) return false
      return true
    })
  }

  return filtered
}

/**
 * Export data to CSV format
 */
export function exportToCSV<T extends Record<string, any>>(
  data: T[],
  columns: { key: keyof T; label: string }[],
  filename = "export.csv",
): void {
  if (data.length === 0) {
    alert("No data to export")
    return
  }

  // Create CSV header
  const headers = columns.map((col) => col.label).join(",")

  // Create CSV rows
  const rows = data.map((item) =>
    columns
      .map((col) => {
        const value = item[col.key]
        // Handle values that contain commas or quotes
        if (value == null) return ""
        const stringValue = String(value)
        if (stringValue.includes(",") || stringValue.includes('"') || stringValue.includes("\n")) {
          return `"${stringValue.replace(/"/g, '""')}"`
        }
        return stringValue
      })
      .join(","),
  )

  // Combine header and rows
  const csv = [headers, ...rows].join("\n")

  // Create blob and download
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")
  const url = URL.createObjectURL(blob)

  link.setAttribute("href", url)
  link.setAttribute("download", filename)
  link.style.visibility = "hidden"

  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)

  URL.revokeObjectURL(url)
}

/**
 * Get unique values from a specific field for filter options
 */
export function getUniqueValues<T>(data: T[], field: keyof T): string[] {
  const values = data.map((item) => item[field])
  return Array.from(new Set(values.filter((v) => v != null).map(String)))
}

/**
 * Paginate data
 */
export function paginateData<T>(
  data: T[],
  page: number,
  pageSize: number,
): { data: T[]; totalPages: number; currentPage: number } {
  const totalPages = Math.ceil(data.length / pageSize)
  const currentPage = Math.min(Math.max(1, page), totalPages)
  const startIndex = (currentPage - 1) * pageSize
  const endIndex = startIndex + pageSize

  return {
    data: data.slice(startIndex, endIndex),
    totalPages,
    currentPage,
  }
}
