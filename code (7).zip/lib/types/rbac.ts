// RBAC Type Definitions

export interface Permission {
  id: number
  name: string
  display_name: string
  description: string
  resource: string
  action: string
  created_at: string
}

export interface Role {
  id: number
  name: string
  display_name: string
  description: string
  is_system: boolean
  permissions?: Permission[]
  created_at: string
  updated_at: string
}

export interface UserRole {
  id: number
  user_id: string
  role_id: number
  role?: Role
  assigned_by: string
  assigned_at: string
}

export interface User {
  id: string
  username: string
  email: string
  full_name: string
  role: string // Legacy field
  roles?: Role[] // New RBAC roles
  created_at: string
  updated_at: string
}

export interface UserWithRoles extends User {
  user_roles: UserRole[]
}
