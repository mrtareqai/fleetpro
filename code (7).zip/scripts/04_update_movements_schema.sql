-- Add columns to movements table for trip management
ALTER TABLE movements 
ADD COLUMN IF NOT EXISTS driver_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS assistant_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS bus_number VARCHAR(50),
ADD COLUMN IF NOT EXISTS trip_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS trip_date DATE,
ADD COLUMN IF NOT EXISTS trip_time TIME,
ADD COLUMN IF NOT EXISTS seats INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS pending_seats INTEGER DEFAULT 0;

-- Update existing records with sample data
UPDATE movements 
SET 
  driver_name = 'أحمد محمد',
  assistant_name = 'خالد علي',
  bus_number = 'BUS-' || LPAD(id::TEXT, 3, '0'),
  trip_name = 'رحلة ' || id,
  trip_date = CURRENT_DATE + (id || ' days')::INTERVAL,
  trip_time = '08:00:00',
  seats = 45,
  pending_seats = 5
WHERE driver_name IS NULL;
