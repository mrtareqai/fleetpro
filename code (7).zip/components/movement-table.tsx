"use client"

import type React from "react"

import { Plus, Edit, Trash2, Scan, X } from "lucide-react"
import { useState, useEffect, useRef } from "react"
import { apiClient } from "@/lib/api-client"
import { useSelection } from "@/lib/selection-context"
import { useAuth } from "@/lib/auth-context"

interface MovementTableProps {
  locale: "en" | "ar"
}

interface MovementRecord {
  id: number
  driver_name: string
  assistant_name: string
  bus_number: string
  trip_name: string
  trip_date: string
  trip_time: string
  seats: number
  pending_seats: number
  status: "active" | "completed" | "pending"
}

export default function MovementTable({ locale }: MovementTableProps) {
  const [selectedRow, setSelectedRow] = useState<number | null>(null)
  const [movements, setMovements] = useState<MovementRecord[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingMovement, setEditingMovement] = useState<MovementRecord | null>(null)
  const [formData, setFormData] = useState({
    driver_name: "",
    assistant_name: "",
    bus_number: "",
    trip_name: "",
    trip_date: "",
    trip_time: "",
    seats: "",
    pending_seats: "",
    status: "pending" as "active" | "completed" | "pending",
  })
  const modalRef = useRef<HTMLDivElement>(null)
  const firstInputRef = useRef<HTMLInputElement>(null)

  const { isSelectionMode, selectedItems, toggleSelectionMode, toggleItem, selectAll, clearSelection, isSelected } =
    useSelection()
  const { hasPermission } = useAuth()

  const t = {
    en: {
      title: "Movement Management",
      add: "Add",
      edit: "Edit",
      delete: "Delete",
      number: "Number",
      name: "Name",
      assistant: "Driver Assistant",
      busNumber: "Bus Number",
      tripName: "Trip Name",
      tripDate: "Trip Date",
      tripTime: "Trip Time",
      seats: "Seats",
      pendingSeats: "Pending Seats",
      status: "Status",
      active: "Active",
      completed: "Completed",
      pending: "Pending",
      loading: "Loading...",
      error: "Error loading data",
      scan: "Scan",
      selectAll: "Select All",
      deselectAll: "Deselect All",
      selectedCount: "selected",
      deleteSelected: "Delete Selected",
      selectItemsPrompt: "Selection mode active - Select items to delete",
      exitSelectionMode: "Exit Selection Mode",
      addMovement: "Add Movement",
      editMovement: "Edit Movement",
      updateMovement: "Update Movement",
      driverName: "Driver Name",
      assistantName: "Assistant Name",
      cancel: "Cancel",
      submit: "Add Movement",
    },
    ar: {
      title: "إدارة الحركة",
      add: "إضافة",
      edit: "تعديل",
      delete: "حذف",
      number: "الرقم",
      name: "الاسم",
      assistant: "مساعد السائق",
      busNumber: "رقم الباص",
      tripName: "اسم الرحلة",
      tripDate: "تاريخ الرحلة",
      tripTime: "وقت الرحلة",
      seats: "عدد المقاعد",
      pendingSeats: "مقاعد معلقة",
      status: "الحالة",
      active: "نشط",
      completed: "مكتمل",
      pending: "معلق",
      loading: "جاري التحميل...",
      error: "خطأ في تحميل البيانات",
      scan: "مسح",
      selectAll: "تحديد الكل",
      deselectAll: "إلغاء التحديد",
      selectedCount: "محدد",
      deleteSelected: "حذف المحدد",
      selectItemsPrompt: "وضع التحديد نشط - حدد العناصر للحذف",
      exitSelectionMode: "إنهاء وضع التحديد",
      addMovement: "إضافة حركة",
      editMovement: "تعديل الحركة",
      updateMovement: "تحديث الحركة",
      driverName: "اسم السائق",
      assistantName: "اسم المساعد",
      cancel: "إلغاء",
      submit: "إضافة الحركة",
    },
  }

  useEffect(() => {
    fetchMovements()
  }, [])

  useEffect(() => {
    if (showAddModal || showEditModal) {
      document.body.style.overflow = "hidden"
      setTimeout(() => firstInputRef.current?.focus(), 100)
    } else {
      document.body.style.overflow = "unset"
    }
    return () => {
      document.body.style.overflow = "unset"
    }
  }, [showAddModal, showEditModal])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape" && (showAddModal || showEditModal)) {
        setShowAddModal(false)
        setShowEditModal(false)
      }
    }
    window.addEventListener("keydown", handleEscape)
    return () => window.removeEventListener("keydown", handleEscape)
  }, [showAddModal, showEditModal])

  const fetchMovements = async () => {
    try {
      setLoading(true)
      console.log("[v0] Fetching movements from database...")
      const data = await apiClient.getMovements()
      console.log("[v0] Movements data received:", data)
      setMovements(data)
      setError(null)
    } catch (err) {
      console.error("[v0] Error fetching movements:", err)
      setError(err instanceof Error ? err.message : "Failed to fetch movements")
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (selectedRow === null) {
      alert(locale === "en" ? "Please select a row to delete" : "الرجاء تحديد صف للحذف")
      return
    }

    if (!confirm(locale === "en" ? "Are you sure you want to delete this record?" : "هل أنت متأكد من حذف هذا السجل؟")) {
      return
    }

    try {
      await apiClient.deleteMovement(selectedRow)
      setSelectedRow(null)
      fetchMovements()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete record" : "فشل حذف السجل")
      console.error("[v0] Error deleting movement:", err)
    }
  }

  const handleMultiDelete = async () => {
    if (selectedItems.size === 0) {
      alert(t[locale].selectItemsPrompt)
      return
    }

    const confirmMsg =
      locale === "en"
        ? `Are you sure you want to delete ${selectedItems.size} item(s)?`
        : `هل أنت متأكد من حذف ${selectedItems.size} عنصر؟`

    if (!confirm(confirmMsg)) {
      return
    }

    try {
      await Promise.all(Array.from(selectedItems).map((id) => apiClient.deleteMovement(id)))
      clearSelection()
      toggleSelectionMode()
      fetchMovements()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete items" : "فشل حذف العناصر")
      console.error("[v0] Error deleting movements:", err)
    }
  }

  const handleSelectAll = () => {
    if (selectedItems.size === movements.length) {
      clearSelection()
    } else {
      selectAll(movements.map((m) => m.id))
    }
  }

  const handleEdit = () => {
    if (selectedRow === null) return

    const movement = movements.find((m) => m.id === selectedRow)
    if (!movement) return

    setEditingMovement(movement)
    setFormData({
      driver_name: movement.driver_name,
      assistant_name: movement.assistant_name,
      bus_number: movement.bus_number,
      trip_name: movement.trip_name,
      trip_date: movement.trip_date,
      trip_time: movement.trip_time,
      seats: movement.seats.toString(),
      pending_seats: movement.pending_seats.toString(),
      status: movement.status,
    })
    setShowEditModal(true)
  }

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingMovement) return

    try {
      await apiClient.updateMovement(editingMovement.id, {
        driver_name: formData.driver_name,
        assistant_name: formData.assistant_name,
        bus_number: formData.bus_number,
        trip_name: formData.trip_name,
        trip_date: formData.trip_date,
        trip_time: formData.trip_time,
        seats: Number.parseInt(formData.seats),
        pending_seats: Number.parseInt(formData.pending_seats),
        status: formData.status,
      })
      setShowEditModal(false)
      setEditingMovement(null)
      setFormData({
        driver_name: "",
        assistant_name: "",
        bus_number: "",
        trip_name: "",
        trip_date: "",
        trip_time: "",
        seats: "",
        pending_seats: "",
        status: "pending",
      })
      fetchMovements()
    } catch (err) {
      alert(locale === "en" ? "Failed to update movement" : "فشل تحديث الحركة")
      console.error("[v0] Error updating movement:", err)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "completed":
        return "bg-blue-100 text-blue-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "active":
        return t[locale].active
      case "completed":
        return t[locale].completed
      case "pending":
        return t[locale].pending
      default:
        return status
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiClient.createMovement({
        driver_name: formData.driver_name,
        assistant_name: formData.assistant_name,
        bus_number: formData.bus_number,
        trip_name: formData.trip_name,
        trip_date: formData.trip_date,
        trip_time: formData.trip_time,
        seats: Number.parseInt(formData.seats),
        pending_seats: Number.parseInt(formData.pending_seats),
        status: formData.status,
      })
      setShowAddModal(false)
      setFormData({
        driver_name: "",
        assistant_name: "",
        bus_number: "",
        trip_name: "",
        trip_date: "",
        trip_time: "",
        seats: "",
        pending_seats: "",
        status: "pending",
      })
      fetchMovements()
    } catch (err) {
      alert(locale === "en" ? "Failed to add movement" : "فشل إضافة الحركة")
      console.error("[v0] Error adding movement:", err)
    }
  }

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      setShowAddModal(false)
      setShowEditModal(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-red-600">
          {t[locale].error}: {error}
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6" dir={locale === "ar" ? "rtl" : "ltr"}>
      <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="flex flex-wrap gap-2 md:gap-3">
        {hasPermission("movements.delete") && (
          <button
            onClick={toggleSelectionMode}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
              isSelectionMode
                ? "bg-purple-600 hover:bg-purple-700 text-white"
                : "bg-purple-500 hover:bg-purple-600 text-white"
            }`}
          >
            <Scan className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].scan}
          </button>
        )}

        {!isSelectionMode && (
          <>
            <button
              onClick={() => setShowAddModal(true)}
              disabled={!hasPermission("movements.create")}
              className="flex items-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Plus className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].add}
            </button>
            <button
              onClick={handleEdit}
              disabled={selectedRow === null || !hasPermission("movements.update")}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
                selectedRow !== null && hasPermission("movements.update")
                  ? "bg-blue-500 hover:bg-blue-600 text-white"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
            >
              <Edit className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].edit}
            </button>
            <button
              onClick={handleDelete}
              disabled={selectedRow === null || !hasPermission("movements.delete")}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
                selectedRow !== null && hasPermission("movements.delete")
                  ? "bg-red-500 hover:bg-red-600 text-white"
                  : "bg-gray-300 text-gray-500 cursor-not-allowed"
              }`}
            >
              <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].delete}
            </button>
          </>
        )}

        {isSelectionMode && selectedItems.size > 0 && (
          <button
            onClick={handleMultiDelete}
            className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
          >
            <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].deleteSelected}
          </button>
        )}
      </div>

      {showAddModal && (
        <div
          onClick={handleBackdropClick}
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-movement-title"
        >
          <div ref={modalRef} className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 id="add-movement-title" className="text-xl font-bold text-slate-800">
                {t[locale].addMovement}
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-100"
                aria-label={locale === "en" ? "Close" : "إغلاق"}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="driver_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].driverName}
                  </label>
                  <input
                    ref={firstInputRef}
                    id="driver_name"
                    type="text"
                    required
                    value={formData.driver_name}
                    onChange={(e) => setFormData({ ...formData, driver_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="assistant_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].assistantName}
                  </label>
                  <input
                    id="assistant_name"
                    type="text"
                    required
                    value={formData.assistant_name}
                    onChange={(e) => setFormData({ ...formData, assistant_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="bus_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].busNumber}
                  </label>
                  <input
                    id="bus_number"
                    type="text"
                    required
                    value={formData.bus_number}
                    onChange={(e) => setFormData({ ...formData, bus_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="trip_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripName}
                  </label>
                  <input
                    id="trip_name"
                    type="text"
                    required
                    value={formData.trip_name}
                    onChange={(e) => setFormData({ ...formData, trip_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="trip_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripDate}
                  </label>
                  <input
                    id="trip_date"
                    type="date"
                    required
                    value={formData.trip_date}
                    onChange={(e) => setFormData({ ...formData, trip_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="trip_time" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripTime}
                  </label>
                  <input
                    id="trip_time"
                    type="time"
                    required
                    value={formData.trip_time}
                    onChange={(e) => setFormData({ ...formData, trip_time: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="seats" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].seats}
                  </label>
                  <input
                    id="seats"
                    type="number"
                    required
                    min="0"
                    value={formData.seats}
                    onChange={(e) => setFormData({ ...formData, seats: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="pending_seats" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].pendingSeats}
                  </label>
                  <input
                    id="pending_seats"
                    type="number"
                    required
                    min="0"
                    value={formData.pending_seats}
                    onChange={(e) => setFormData({ ...formData, pending_seats: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].status}
                  </label>
                  <select
                    id="status"
                    required
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as "active" | "completed" | "pending" })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="pending">{t[locale].pending}</option>
                    <option value="active">{t[locale].active}</option>
                    <option value="completed">{t[locale].completed}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium"
                >
                  {t[locale].cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors font-medium"
                >
                  {t[locale].submit}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && editingMovement && (
        <div
          onClick={handleBackdropClick}
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-movement-title"
        >
          <div ref={modalRef} className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
              <h2 id="edit-movement-title" className="text-xl font-bold text-slate-800">
                {t[locale].editMovement}
              </h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded-lg hover:bg-slate-100"
                aria-label={locale === "en" ? "Close" : "إغلاق"}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleUpdate} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="edit_driver_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].driverName}
                  </label>
                  <input
                    ref={firstInputRef}
                    id="edit_driver_name"
                    type="text"
                    required
                    value={formData.driver_name}
                    onChange={(e) => setFormData({ ...formData, driver_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_assistant_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].assistantName}
                  </label>
                  <input
                    id="edit_assistant_name"
                    type="text"
                    required
                    value={formData.assistant_name}
                    onChange={(e) => setFormData({ ...formData, assistant_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_bus_number" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].busNumber}
                  </label>
                  <input
                    id="edit_bus_number"
                    type="text"
                    required
                    value={formData.bus_number}
                    onChange={(e) => setFormData({ ...formData, bus_number: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_name" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripName}
                  </label>
                  <input
                    id="edit_trip_name"
                    type="text"
                    required
                    value={formData.trip_name}
                    onChange={(e) => setFormData({ ...formData, trip_name: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_date" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripDate}
                  </label>
                  <input
                    id="edit_trip_date"
                    type="date"
                    required
                    value={formData.trip_date}
                    onChange={(e) => setFormData({ ...formData, trip_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_trip_time" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].tripTime}
                  </label>
                  <input
                    id="edit_trip_time"
                    type="time"
                    required
                    value={formData.trip_time}
                    onChange={(e) => setFormData({ ...formData, trip_time: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_seats" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].seats}
                  </label>
                  <input
                    id="edit_seats"
                    type="number"
                    required
                    min="0"
                    value={formData.seats}
                    onChange={(e) => setFormData({ ...formData, seats: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_pending_seats" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].pendingSeats}
                  </label>
                  <input
                    id="edit_pending_seats"
                    type="number"
                    required
                    min="0"
                    value={formData.pending_seats}
                    onChange={(e) => setFormData({ ...formData, pending_seats: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>

                <div>
                  <label htmlFor="edit_status" className="block text-sm font-medium text-slate-700 mb-1">
                    {t[locale].status}
                  </label>
                  <select
                    id="edit_status"
                    required
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as "active" | "completed" | "pending" })
                    }
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  >
                    <option value="pending">{t[locale].pending}</option>
                    <option value="active">{t[locale].active}</option>
                    <option value="completed">{t[locale].completed}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors font-medium"
                >
                  {t[locale].cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors font-medium"
                >
                  {t[locale].updateMovement}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {isSelectionMode && (
                  <th className="px-4 py-3 text-center w-12">
                    <input
                      type="checkbox"
                      checked={selectedItems.size === movements.length && movements.length > 0}
                      onChange={handleSelectAll}
                      className="w-4 h-4 cursor-pointer"
                    />
                  </th>
                )}
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].number}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].name}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].assistant}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].busNumber}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].tripName}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].tripDate}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].tripTime}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].seats}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].pendingSeats}</th>
                <th className="px-4 py-3 text-sm font-semibold text-slate-700 text-center">{t[locale].status}</th>
              </tr>
            </thead>
            <tbody>
              {movements.map((movement) => (
                <tr
                  key={movement.id}
                  onClick={() => {
                    if (isSelectionMode) {
                      toggleItem(movement.id)
                    } else {
                      setSelectedRow(movement.id)
                    }
                  }}
                  className={`border-b border-slate-100 cursor-pointer transition-colors ${
                    isSelectionMode
                      ? isSelected(movement.id)
                        ? "bg-purple-50 border-l-4 border-purple-500"
                        : "hover:bg-slate-50"
                      : selectedRow === movement.id
                        ? "bg-blue-50"
                        : "hover:bg-slate-50"
                  }`}
                >
                  {isSelectionMode && (
                    <td className="px-4 py-3 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected(movement.id)}
                        onChange={() => toggleItem(movement.id)}
                        className="w-4 h-4 cursor-pointer"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </td>
                  )}
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.id}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.driver_name}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.assistant_name}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.bus_number}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.trip_name}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">
                    {new Date(movement.trip_date).toLocaleDateString()}
                  </td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.trip_time}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.seats}</td>
                  <td className="px-4 py-3 text-sm text-slate-700 text-center">{movement.pending_seats}</td>
                  <td className="px-4 py-3 text-center">
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(
                        movement.status,
                      )}`}
                    >
                      {getStatusText(movement.status)}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
