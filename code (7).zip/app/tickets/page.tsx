import DashboardLayout from "@/components/dashboard-layout"
import TicketsTable from "@/components/tickets-table"

export default function TicketsPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="tickets">
      <TicketsTable locale={locale} />
    </DashboardLayout>
  )
}
