import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "reports.read")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Generating monthly reservations report...")

    const { searchParams } = new URL(request.url)
    const year = searchParams.get("year") || new Date().getFullYear().toString()

    if (!sql) {
      return getMockMonthlyReservations()
    }

    const monthlyData = await sql`
      SELECT 
        TO_CHAR(start_date, 'Mon') as month,
        EXTRACT(MONTH FROM start_date) as month_num,
        COUNT(*) as total_reservations,
        COUNT(*) FILTER (WHERE status = 'completed') as completed,
        COUNT(*) FILTER (WHERE status = 'cancelled') as cancelled,
        COUNT(*) FILTER (WHERE status = 'confirmed') as confirmed
      FROM reservations
      WHERE EXTRACT(YEAR FROM start_date) = ${year}
      GROUP BY month, month_num
      ORDER BY month_num
    `

    const report = {
      year,
      months: monthlyData.map((row) => ({
        month: row.month,
        monthNumber: Number(row.month_num),
        totalReservations: Number(row.total_reservations),
        completed: Number(row.completed),
        cancelled: Number(row.cancelled),
        confirmed: Number(row.confirmed),
      })),
      summary: {
        totalReservations: monthlyData.reduce((sum, row) => sum + Number(row.total_reservations), 0),
        avgPerMonth:
          monthlyData.reduce((sum, row) => sum + Number(row.total_reservations), 0) / monthlyData.length || 0,
      },
    }

    console.log("[v0] Monthly reservations report generated")

    return NextResponse.json(report, {
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("[v0] Error generating monthly reservations report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

function getMockMonthlyReservations() {
  console.log("[v0] Using mock monthly reservations data")

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]

  const months = monthNames.map((month, index) => {
    const total = Math.floor(Math.random() * 30) + 20
    const completed = Math.floor(total * 0.7)
    const cancelled = Math.floor(total * 0.1)
    const confirmed = total - completed - cancelled

    return {
      month,
      monthNumber: index + 1,
      totalReservations: total,
      completed,
      cancelled,
      confirmed,
    }
  })

  return NextResponse.json({
    year: new Date().getFullYear().toString(),
    months,
    summary: {
      totalReservations: months.reduce((sum, m) => sum + m.totalReservations, 0),
      avgPerMonth: months.reduce((sum, m) => sum + m.totalReservations, 0) / months.length,
    },
  })
}
