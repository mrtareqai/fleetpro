# Security Framework Documentation

## Overview

This document provides comprehensive documentation for the FleetPro security framework, including JWT Authentication, Password Hashing, and Rate Limiting.

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [JWT Authentication](#jwt-authentication)
3. [Password Hashing](#password-hashing)
4. [Rate Limiting](#rate-limiting)
5. [API Authentication](#api-authentication)
6. [Security Best Practices](#security-best-practices)
7. [Testing Guide](#testing-guide)
8. [Troubleshooting](#troubleshooting)

---

## Architecture Overview

### Security Layers

\`\`\`
┌─────────────────────────────────────────┐
│         Client Application              │
│  (Stores JWT tokens in localStorage)    │
└──────────────┬──────────────────────────┘
               │
               │ HTTP Request + JWT Token
               │
┌──────────────▼──────────────────────────┐
│         Rate Limiting Layer             │
│  (Prevents abuse & brute force)         │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│      JWT Verification Layer             │
│  (Validates token signature & expiry)   │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│    Permission Authorization Layer       │
│  (Checks user permissions)              │
└──────────────┬──────────────────────────┘
               │
┌──────────────▼──────────────────────────┐
│         API Route Handler               │
│  (Business logic)                       │
└─────────────────────────────────────────┘
\`\`\`

### Security Modules

| Module | Location | Purpose |
|--------|----------|---------|
| JWT | `lib/security/jwt.ts` | Token generation & verification |
| Password | `lib/security/password.ts` | Password hashing & validation |
| Rate Limit | `lib/security/rate-limit.ts` | Request throttling |
| API Auth | `lib/security/api-auth.ts` | Authentication middleware |

---

## JWT Authentication

### What is JWT?

JSON Web Token (JWT) is an industry-standard method for securely transmitting information between parties as a JSON object. It consists of three parts:

1. **Header**: Algorithm and token type
2. **Payload**: User data (claims)
3. **Signature**: Verification signature

### Why JWT?

**Advantages:**
- **Stateless**: No server-side session storage required
- **Scalable**: Works across multiple servers
- **Secure**: Cryptographically signed
- **Self-contained**: Contains all user information
- **Cross-domain**: Works with CORS

**vs. Session-based Auth:**
- Sessions require server-side storage (memory/database)
- Sessions don't scale well across multiple servers
- JWTs are self-contained and don't require lookups

### Token Structure

\`\`\`typescript
// Access Token Payload
{
  userId: "123",
  role: "admin",
  permissions: ["users.read", "users.write"],
  companyId: 1,
  iat: 1234567890,  // Issued at
  exp: 1234654290   // Expires at (7 days later)
}
\`\`\`

### Implementation

#### Generating Tokens

\`\`\`typescript
import { generateToken, generateRefreshToken } from '@/lib/security/jwt'

// Generate access token (expires in 7 days)
const accessToken = await generateToken({
  userId: user.id,
  role: user.role,
  permissions: ['users.read', 'users.write'],
  companyId: user.company_id
})

// Generate refresh token (expires in 30 days)
const refreshToken = await generateRefreshToken({
  userId: user.id,
  role: user.role,
  permissions: ['users.read'],
  companyId: user.company_id
})
\`\`\`

#### Verifying Tokens

\`\`\`typescript
import { verifyToken, extractTokenFromHeader } from '@/lib/security/jwt'

// Extract token from Authorization header
const authHeader = request.headers.get('Authorization')
const token = extractTokenFromHeader(authHeader) // "Bearer token123" -> "token123"

// Verify and decode token
try {
  const decoded = await verifyToken(token)
  console.log('User ID:', decoded.userId)
  console.log('Role:', decoded.role)
} catch (error) {
  // Token is invalid or expired
  console.error('Invalid token:', error.message)
}
\`\`\`

### Client-Side Usage

#### Storing Tokens

\`\`\`typescript
// After successful login
const response = await apiClient.login(username, password)

// Store tokens in localStorage
localStorage.setItem('auth_token', response.access_token)
localStorage.setItem('refresh_token', response.refresh_token)
localStorage.setItem('user', JSON.stringify(response.user))
\`\`\`

#### Sending Tokens

\`\`\`typescript
// Automatically included in API requests
const headers = {
  'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
  'Content-Type': 'application/json'
}

fetch('/api/users', { headers })
\`\`\`

#### Token Refresh

\`\`\`typescript
// When access token expires, use refresh token
async function refreshAccessToken() {
  const refreshToken = localStorage.getItem('refresh_token')
  
  const response = await fetch('/api/auth/refresh', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: refreshToken })
  })
  
  const data = await response.json()
  
  // Update stored tokens
  localStorage.setItem('auth_token', data.access_token)
  localStorage.setItem('refresh_token', data.refresh_token)
}
\`\`\`

### Environment Variables

\`\`\`bash
# .env.local
JWT_SECRET=your-super-secret-key-min-32-characters
JWT_EXPIRATION=7d
REFRESH_TOKEN_EXPIRATION=30d
\`\`\`

**Generating a secure secret:**
\`\`\`bash
openssl rand -base64 32
\`\`\`

---

## Password Hashing

### What is Password Hashing?

Password hashing is a one-way cryptographic function that converts a plain text password into a fixed-length string (hash). It's impossible to reverse the hash back to the original password.

### Why bcrypt?

**Advantages:**
- **Adaptive**: Can increase difficulty over time
- **Salt included**: Each hash has unique salt
- **Slow by design**: Prevents brute force attacks
- **Industry standard**: Widely tested and trusted

**vs. Other Methods:**
- **MD5/SHA1**: Too fast, vulnerable to rainbow tables
- **SHA256**: Fast, not designed for passwords
- **bcrypt**: Specifically designed for password hashing

### How It Works

\`\`\`
Plain Password → bcrypt → Hashed Password
"password123" → "$2a$12$R9h/cIPz0gi.URNNX3kh2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW"

Components:
$2a$    → bcrypt algorithm version
12$     → Cost factor (2^12 iterations)
R9h...  → Salt (22 characters)
...     → Hash (31 characters)
\`\`\`

### Implementation

#### Hashing Passwords

\`\`\`typescript
import { hashPassword } from '@/lib/security/password'

// Hash password during user registration
const plainPassword = 'MySecurePassword123!'
const hashedPassword = await hashPassword(plainPassword)

// Store hashedPassword in database
await sql`
  INSERT INTO users (username, password_hash)
  VALUES (${username}, ${hashedPassword})
`
\`\`\`

#### Verifying Passwords

\`\`\`typescript
import { verifyPassword } from '@/lib/security/password'

// During login
const plainPassword = request.body.password
const storedHash = user.password_hash

const isValid = await verifyPassword(plainPassword, storedHash)

if (isValid) {
  // Password is correct, proceed with login
} else {
  // Password is incorrect
}
\`\`\`

#### Password Strength Validation

\`\`\`typescript
import { validatePasswordStrength } from '@/lib/security/password'

const result = validatePasswordStrength('weak')

if (!result.isValid) {
  console.log(result.error)
  // "Password must be at least 8 characters long"
}
\`\`\`

### Password Requirements

**Minimum Requirements:**
- At least 8 characters
- One uppercase letter (A-Z)
- One lowercase letter (a-z)
- One number (0-9)
- One special character (!@#$%^&*...)

**Examples:**
- ✅ `SecurePass123!`
- ✅ `MyP@ssw0rd`
- ❌ `password` (no uppercase, number, special char)
- ❌ `Pass123` (too short, no special char)

### Security Considerations

**DO:**
- Always hash passwords before storing
- Use bcrypt with salt rounds ≥ 12
- Validate password strength
- Use HTTPS for password transmission
- Implement rate limiting on login

**DON'T:**
- Store plain text passwords
- Use weak hashing (MD5, SHA1)
- Reuse salts
- Log passwords
- Send passwords in URLs

---

## Rate Limiting

### What is Rate Limiting?

Rate limiting restricts the number of requests a client can make in a given time period. It prevents abuse, brute force attacks, and ensures fair resource usage.

### Why Rate Limiting?

**Protection Against:**
- **Brute Force**: Prevents password guessing
- **DDoS**: Limits impact of denial-of-service attacks
- **API Abuse**: Prevents excessive resource consumption
- **Scraping**: Limits automated data extraction

### Implementation

#### Pre-configured Limiters

\`\`\`typescript
import { 
  loginRateLimiter,      // 5 requests per 15 minutes
  apiRateLimiter,        // 100 requests per minute
  strictRateLimiter      // 3 requests per hour
} from '@/lib/security/rate-limit'

// Check rate limit
const result = await loginRateLimiter.check(clientIp)

if (!result.success) {
  return Response.json(
    { error: 'Too many requests', retryAfter: result.retryAfter },
    { status: 429 }
  )
}
\`\`\`

#### Custom Rate Limiter

\`\`\`typescript
import { createRateLimiter } from '@/lib/security/rate-limit'

// Create custom limiter
const customLimiter = createRateLimiter({
  maxRequests: 10,        // 10 requests
  windowMs: 60000,        // per minute
  message: 'Slow down!'
})

// Use it
const result = await customLimiter.check(identifier)
\`\`\`

#### Getting Client IP

\`\`\`typescript
import { getClientIp } from '@/lib/security/rate-limit'

const ip = getClientIp(request)
// Returns: "192.168.1.1" or "unknown"
\`\`\`

### Rate Limit Headers

When rate limit is applied, the following headers are returned:

\`\`\`
X-RateLimit-Limit: 5
X-RateLimit-Remaining: 2
X-RateLimit-Reset: 2025-01-15T10:30:00Z
Retry-After: 900
\`\`\`

### Configuration

| Limiter | Max Requests | Window | Use Case |
|---------|--------------|--------|----------|
| Login | 5 | 15 min | Login attempts |
| API | 100 | 1 min | General API calls |
| Strict | 3 | 1 hour | Sensitive operations |

### Production Considerations

**Current Implementation:**
- In-memory storage (single server)
- Automatic cleanup every 5 minutes
- IP-based identification

**For Production (Multiple Servers):**
- Use Redis (Upstash) for distributed storage
- Implement token bucket algorithm
- Add user-based limiting (in addition to IP)

**Recommended Setup:**
\`\`\`typescript
// Using Upstash Redis
import { Redis } from '@upstash/redis'

const redis = new Redis({
  url: process.env.KV_REST_API_URL,
  token: process.env.KV_REST_API_TOKEN
})

// Store rate limit data in Redis
await redis.incr(`rate_limit:${ip}:${endpoint}`)
await redis.expire(`rate_limit:${ip}:${endpoint}`, 900)
\`\`\`

---

## API Authentication

### Middleware Usage

#### Require Authentication

\`\`\`typescript
import { requireAuth } from '@/lib/security/api-auth'

export async function GET(request: NextRequest) {
  // Require authentication
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult
  
  const { userId, role, permissions } = authResult
  
  // Your API logic here
  return NextResponse.json({ data: 'Protected data' })
}
\`\`\`

#### Require Permission

\`\`\`typescript
import { requirePermission } from '@/lib/security/api-auth'

export async function POST(request: NextRequest) {
  // Require specific permission
  const authResult = await requirePermission(request, 'users.create')
  if (authResult instanceof Response) return authResult
  
  // User has 'users.create' permission
  // Proceed with user creation
}
\`\`\`

#### Require Any Permission

\`\`\`typescript
import { requireAnyPermission } from '@/lib/security/api-auth'

export async function GET(request: NextRequest) {
  // Require at least one of these permissions
  const authResult = await requireAnyPermission(request, [
    'users.read',
    'users.write'
  ])
  if (authResult instanceof Response) return authResult
  
  // User has at least one of the required permissions
}
\`\`\`

#### Require Role

\`\`\`typescript
import { requireRole } from '@/lib/security/api-auth'

export async function DELETE(request: NextRequest) {
  // Only admins can access
  const authResult = await requireRole(request, 'admin')
  if (authResult instanceof Response) return authResult
  
  // User is an admin
}
\`\`\`

### Disable Rate Limiting

\`\`\`typescript
// Disable rate limiting for specific endpoint
const authResult = await requireAuth(request, {
  checkRateLimit: false
})
\`\`\`

### Error Responses

#### 401 Unauthorized

\`\`\`json
{
  "error": "No authentication token provided"
}
\`\`\`

#### 403 Forbidden

\`\`\`json
{
  "error": "Forbidden",
  "message": "Missing required permission: users.write"
}
\`\`\`

#### 429 Too Many Requests

\`\`\`json
{
  "error": "Too many requests",
  "retryAfter": 900
}
\`\`\`

---

## Security Best Practices

### Token Management

**DO:**
- Store tokens in localStorage (or httpOnly cookies for SSR)
- Include tokens in Authorization header
- Refresh tokens before expiration
- Clear tokens on logout
- Use HTTPS in production

**DON'T:**
- Store tokens in URL parameters
- Share tokens between users
- Log tokens
- Use tokens after logout
- Expose JWT_SECRET

### Password Security

**DO:**
- Enforce strong password requirements
- Hash passwords with bcrypt (salt rounds ≥ 12)
- Implement rate limiting on login
- Use generic error messages (prevent user enumeration)
- Require password change after breach

**DON'T:**
- Store plain text passwords
- Log passwords
- Send passwords via email
- Reuse passwords across systems
- Use weak hashing algorithms

### API Security

**DO:**
- Validate all input data
- Use HTTPS in production
- Implement rate limiting
- Log security events
- Keep dependencies updated
- Use environment variables for secrets

**DON'T:**
- Trust client input
- Expose sensitive data in errors
- Use default secrets
- Disable security features
- Ignore security warnings

### OWASP Top 10 Protection

| Vulnerability | Protection |
|---------------|------------|
| Broken Authentication | JWT + bcrypt + rate limiting |
| Sensitive Data Exposure | HTTPS + password hashing |
| Injection | Input validation + parameterized queries |
| Broken Access Control | Permission-based authorization |
| Security Misconfiguration | Environment variables + secure defaults |

---

## Testing Guide

### Unit Tests

#### Testing Password Hashing

\`\`\`typescript
import { hashPassword, verifyPassword } from '@/lib/security/password'

describe('Password Hashing', () => {
  it('should hash password', async () => {
    const password = 'TestPassword123!'
    const hash = await hashPassword(password)
    
    expect(hash).toBeDefined()
    expect(hash).not.toBe(password)
    expect(hash).toMatch(/^\$2[aby]\$\d{2}\$/)
  })
  
  it('should verify correct password', async () => {
    const password = 'TestPassword123!'
    const hash = await hashPassword(password)
    const isValid = await verifyPassword(password, hash)
    
    expect(isValid).toBe(true)
  })
  
  it('should reject incorrect password', async () => {
    const password = 'TestPassword123!'
    const hash = await hashPassword(password)
    const isValid = await verifyPassword('WrongPassword', hash)
    
    expect(isValid).toBe(false)
  })
})
\`\`\`

#### Testing JWT

\`\`\`typescript
import { generateToken, verifyToken } from '@/lib/security/jwt'

describe('JWT', () => {
  it('should generate valid token', async () => {
    const payload = {
      userId: '123',
      role: 'admin',
      permissions: ['*']
    }
    
    const token = await generateToken(payload)
    expect(token).toBeDefined()
    expect(typeof token).toBe('string')
  })
  
  it('should verify valid token', async () => {
    const payload = {
      userId: '123',
      role: 'admin',
      permissions: ['*']
    }
    
    const token = await generateToken(payload)
    const decoded = await verifyToken(token)
    
    expect(decoded.userId).toBe('123')
    expect(decoded.role).toBe('admin')
  })
  
  it('should reject invalid token', async () => {
    await expect(verifyToken('invalid_token')).rejects.toThrow()
  })
})
\`\`\`

### Integration Tests

#### Testing Login API

\`\`\`typescript
describe('POST /api/auth/login', () => {
  it('should login with valid credentials', async () => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'admin',
        password: 'password123'
      })
    })
    
    expect(response.status).toBe(200)
    
    const data = await response.json()
    expect(data.access_token).toBeDefined()
    expect(data.user).toBeDefined()
  })
  
  it('should reject invalid credentials', async () => {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username: 'admin',
        password: 'wrong_password'
      })
    })
    
    expect(response.status).toBe(401)
  })
  
  it('should enforce rate limiting', async () => {
    // Make 6 requests (limit is 5)
    for (let i = 0; i < 6; i++) {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: 'admin',
          password: 'wrong'
        })
      })
      
      if (i < 5) {
        expect(response.status).toBe(401)
      } else {
        expect(response.status).toBe(429)
      }
    }
  })
})
\`\`\`

### Manual Testing

#### Test Login Flow

\`\`\`bash
# 1. Login
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password123"}'

# Response:
# {
#   "access_token": "eyJhbGc...",
#   "refresh_token": "eyJhbGc...",
#   "user": {...}
# }

# 2. Use token to access protected endpoint
curl http://localhost:3000/api/users \
  -H "Authorization: Bearer eyJhbGc..."

# 3. Refresh token
curl -X POST http://localhost:3000/api/auth/refresh \
  -H "Content-Type: application/json" \
  -d '{"refresh_token":"eyJhbGc..."}'
\`\`\`

---

## Troubleshooting

### Common Issues

#### "Invalid token" Error

**Cause:** Token is malformed, expired, or signed with wrong secret

**Solution:**
1. Check JWT_SECRET matches between token generation and verification
2. Verify token hasn't expired
3. Ensure token is properly formatted: `Bearer <token>`

\`\`\`typescript
// Debug token
import { decodeTokenUnsafe } from '@/lib/security/jwt'

const decoded = decodeTokenUnsafe(token)
console.log('Token payload:', decoded)
console.log('Expires at:', new Date(decoded.exp * 1000))
\`\`\`

#### "Too many requests" Error

**Cause:** Rate limit exceeded

**Solution:**
1. Wait for rate limit window to reset
2. Check Retry-After header
3. Reset rate limit for testing:

\`\`\`typescript
import { loginRateLimiter } from '@/lib/security/rate-limit'

// Reset rate limit for specific IP
loginRateLimiter.reset(clientIp)
\`\`\`

#### Password Verification Fails

**Cause:** Password not hashed or wrong hash algorithm

**Solution:**
1. Ensure password is hashed before storing
2. Verify bcrypt is used (not MD5/SHA)
3. Check salt rounds configuration

\`\`\`typescript
// Check if password is hashed
if (!password_hash.startsWith('$2a$') && !password_hash.startsWith('$2b$')) {
  console.error('Password is not bcrypt hashed!')
}
\`\`\`

#### CORS Errors

**Cause:** Missing CORS headers for cross-origin requests

**Solution:**
Add CORS headers to API responses:

\`\`\`typescript
return NextResponse.json(data, {
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type'
  }
})
\`\`\`

### Debug Mode

Enable debug logging:

\`\`\`typescript
// lib/security/jwt.ts
const DEBUG = process.env.NODE_ENV === 'development'

if (DEBUG) {
  console.log('[v0] Token payload:', payload)
  console.log('[v0] Token expires:', new Date(decoded.exp * 1000))
}
\`\`\`

### Security Checklist

Before deploying to production:

- [ ] JWT_SECRET is set to secure random string (min 32 chars)
- [ ] HTTPS is enabled
- [ ] Rate limiting is configured
- [ ] Password requirements are enforced
- [ ] Error messages don't leak sensitive info
- [ ] Tokens expire appropriately (7 days access, 30 days refresh)
- [ ] All API routes use authentication middleware
- [ ] Input validation is implemented
- [ ] Security headers are set
- [ ] Dependencies are up to date

---

## Migration Guide

### From Old System to New System

#### Step 1: Update Imports

\`\`\`typescript
// Old
import { requireAuth } from '@/lib/api-auth'

// New
import { requireAuth } from '@/lib/security/api-auth'
\`\`\`

#### Step 2: Update API Routes

\`\`\`typescript
// Old
export async function GET(request: NextRequest) {
  const userId = request.headers.get('x-user-id')
  // ...
}

// New
export async function GET(request: NextRequest) {
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult
  
  const { userId } = authResult
  // ...
}
\`\`\`

#### Step 3: Update Client Code

\`\`\`typescript
// Old
headers['x-user-id'] = user.id

// New
const token = localStorage.getItem('auth_token')
headers['Authorization'] = `Bearer ${token}`
\`\`\`

#### Step 4: Hash Existing Passwords

\`\`\`sql
-- Create migration script
-- scripts/migrate-passwords.ts

import { sql } from '@/lib/db'
import { hashPassword } from '@/lib/security/password'

async function migratePasswords() {
  const users = await sql`SELECT id, password FROM users`
  
  for (const user of users) {
    const hashedPassword = await hashPassword(user.password)
    await sql`
      UPDATE users 
      SET password_hash = ${hashedPassword}
      WHERE id = ${user.id}
    `
  }
}
\`\`\`

---

## Additional Resources

- [JWT.io](https://jwt.io/) - JWT debugger and documentation
- [OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
- [bcrypt Documentation](https://github.com/kelektiv/node.bcrypt.js)
- [Rate Limiting Best Practices](https://cloud.google.com/architecture/rate-limiting-strategies-techniques)

---

**Last Updated:** January 2025  
**Version:** 1.0.0  
**Maintainer:** FleetPro Development Team
\`\`\`

\`\`\`json file="" isHidden
