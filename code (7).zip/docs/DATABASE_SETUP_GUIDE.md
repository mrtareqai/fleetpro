# دليل إعداد قاعدة البيانات - FleetPro

## نظرة عامة

هذا الدليل يشرح كيفية إعداد قاعدة البيانات لنظام FleetPro بشكل صحيح.

## المشاكل التي تم حلها

### 1. مشكلة متغيرات البيئة
**المشكلة**: الكود كان يبحث عن `NEON_DATABASE_URL` بينما المتغيرات المتاحة تستخدم `NEON_DATABASE_URL`

**الحل**: تم تحديث `lib/db.ts` لاستخدام `NEON_DATABASE_URL`

### 2. قاعدة البيانات الفارغة
**المشكلة**: ملفات SQL موجودة لكن لم يتم تنفيذها

**الحل**: تم إنشاء سكريبت تهيئة تلقائي `scripts/00_initialize_database.ts`

### 3. ترتيب تنفيذ السكريبتات
**المشكلة**: بعض السكريبتات تحاول تعديل جداول غير موجودة

**الحل**: تم ترتيب السكريبتات بالشكل الصحيح:
1. إنشاء الجداول الأساسية
2. إنشاء نظام RBAC
3. إضافة نظام الشركات
4. تعديل الجداول
5. إضافة البيانات التجريبية

## هيكل قاعدة البيانات

### الجداول الأساسية
- **users**: المستخدمين والمصادقة
- **vehicles**: المركبات والأسطول
- **drivers**: السائقين
- **reservations**: الحجوزات
- **tickets**: التذاكر والصيانة
- **movements**: حركة المركبات
- **agency_supplies**: مستلزمات الوكالة

### نظام RBAC
- **roles**: الأدوار (Super Admin, Admin, Fleet Manager, إلخ)
- **permissions**: الصلاحيات التفصيلية
- **role_permissions**: ربط الأدوار بالصلاحيات
- **user_roles**: ربط المستخدمين بالأدوار

### نظام متعدد المستأجرين
- **companies**: الشركات
- جميع الجداول تحتوي على `company_id` للعزل بين الشركات

## العلاقات بين الجداول

### علاقات المفاتيح الخارجية (Foreign Keys)

\`\`\`
reservations
  ├─> vehicles (vehicle_id)
  └─> drivers (driver_id)

movements
  └─> vehicles (vehicle_id)

agency_supplies
  └─> vehicles (vehicle_id)

user_roles
  ├─> users (user_id)
  └─> roles (role_id)

role_permissions
  ├─> roles (role_id)
  └─> permissions (permission_id)

[جميع الجداول]
  └─> companies (company_id)
\`\`\`

### سياسات الحذف
- `ON DELETE CASCADE`: حذف السجلات المرتبطة تلقائياً (RBAC)
- `ON DELETE SET NULL`: تعيين NULL عند الحذف (العلاقات الاختيارية)

## كيفية تشغيل التهيئة

### الطريقة 1: من واجهة v0
1. افتح المشروع في v0
2. انتقل إلى قسم Scripts
3. شغّل `00_initialize_database.ts`

### الطريقة 2: من سطر الأوامر (محلياً)
\`\`\`bash
npm install
npx tsx scripts/00_initialize_database.ts
\`\`\`

## التحقق من نجاح التهيئة

بعد تشغيل السكريبت، يجب أن ترى:

\`\`\`
✅ Found 15 tables:
   - agency_supplies
   - companies
   - drivers
   - movements
   - permissions
   - reservations
   - role_permissions
   - roles
   - tickets
   - user_roles
   - users
   - vehicles

📈 Sample data counts:
   - Users: 3
   - Vehicles: 6
   - Drivers: 5
   - Roles: 6
\`\`\`

## بيانات تسجيل الدخول التجريبية

### Super Admin
- **Username**: admin
- **Password**: password123
- **الصلاحيات**: جميع الصلاحيات

### Fleet Manager
- **Username**: manager
- **Password**: password123
- **الصلاحيات**: إدارة المركبات والسائقين والحجوزات

### Viewer
- **Username**: user1
- **Password**: password123
- **الصلاحيات**: عرض فقط

## الفهارس (Indexes) للأداء

تم إنشاء فهارس على:
- حالة المركبات (status)
- أرقام اللوحات (plate_number)
- تواريخ الحجوزات
- حالة وأولوية التذاكر
- معرفات الشركات
- علاقات RBAC

## المحفزات (Triggers)

تم إنشاء محفزات `updated_at` لجميع الجداول لتحديث التاريخ تلقائياً عند التعديل.

## استكشاف الأخطاء

### خطأ: "NEON_DATABASE_URL is not set"
**الحل**: تأكد من إضافة متغير البيئة في إعدادات المشروع

### خطأ: "relation does not exist"
**الحل**: شغّل سكريبت التهيئة مرة أخرى

### خطأ: "duplicate key value"
**الحل**: السكريبتات تستخدم `ON CONFLICT DO NOTHING` - يمكن تشغيلها بأمان عدة مرات

## الخطوات التالية

بعد إعداد قاعدة البيانات:
1. اختبر تسجيل الدخول بالحسابات التجريبية
2. تحقق من عرض البيانات في الصفحات المختلفة
3. اختبر الصلاحيات المختلفة لكل دور
4. أضف بيانات حقيقية حسب الحاجة
