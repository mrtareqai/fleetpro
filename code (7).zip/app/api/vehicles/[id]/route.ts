import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { updateVehicleSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "vehicles.read")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const vehicleId = Number.parseInt(params.id)

    if (isNaN(vehicleId)) {
      return NextResponse.json({ error: "Invalid vehicle ID" }, { status: 400 })
    }

    logger.info("Fetching vehicle", { userId, vehicleId })

    const result = await sql`
      SELECT * FROM vehicles WHERE id = ${vehicleId}
    `

    if (result.length === 0) {
      logger.warn("Vehicle not found", { userId, vehicleId })
      return NextResponse.json({ error: "Vehicle not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Vehicle fetched successfully", { userId, vehicleId, duration })

    return NextResponse.json({ vehicle: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching vehicle", { error, vehicleId: params.id, duration })

    return NextResponse.json({ error: "Failed to fetch vehicle" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "vehicles.update")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const vehicleId = Number.parseInt(params.id)

    if (isNaN(vehicleId)) {
      return NextResponse.json({ error: "Invalid vehicle ID" }, { status: 400 })
    }

    const body = await request.json()
    const validatedData = await validateOrRespond(updateVehicleSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Updating vehicle", { userId, vehicleId })

    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1

    if (validatedData.model !== undefined) {
      updates.push(`model = $${paramIndex++}`)
      values.push(validatedData.model)
    }
    if (validatedData.manufacture_date !== undefined) {
      updates.push(`manufacture_date = $${paramIndex++}`)
      values.push(validatedData.manufacture_date)
    }
    if (validatedData.plate_number !== undefined) {
      updates.push(`plate_number = $${paramIndex++}`)
      values.push(validatedData.plate_number)
    }
    if (validatedData.base_number !== undefined) {
      updates.push(`base_number = $${paramIndex++}`)
      values.push(validatedData.base_number)
    }
    if (validatedData.card_number !== undefined) {
      updates.push(`card_number = $${paramIndex++}`)
      values.push(validatedData.card_number)
    }
    if (validatedData.issue_date !== undefined) {
      updates.push(`issue_date = $${paramIndex++}`)
      values.push(validatedData.issue_date)
    }
    if (validatedData.expiry_date !== undefined) {
      updates.push(`expiry_date = $${paramIndex++}`)
      values.push(validatedData.expiry_date)
    }
    if (validatedData.status !== undefined) {
      updates.push(`status = $${paramIndex++}`)
      values.push(validatedData.status)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(vehicleId)

    const query = `
      UPDATE vehicles 
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `

    const result = await sql(query, values)

    if (result.length === 0) {
      logger.warn("Vehicle not found for update", { userId, vehicleId })
      return NextResponse.json({ error: "Vehicle not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Vehicle updated successfully", { userId, vehicleId, duration })

    return NextResponse.json({ vehicle: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error updating vehicle", { error, vehicleId: params.id, duration })

    return NextResponse.json({ error: "Failed to update vehicle" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "vehicles.delete")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const vehicleId = Number.parseInt(params.id)

    if (isNaN(vehicleId)) {
      return NextResponse.json({ error: "Invalid vehicle ID" }, { status: 400 })
    }

    logger.info("Deleting vehicle", { userId, vehicleId })

    const result = await sql`
      DELETE FROM vehicles 
      WHERE id = ${vehicleId}
      RETURNING id
    `

    if (result.length === 0) {
      logger.warn("Vehicle not found for deletion", { userId, vehicleId })
      return NextResponse.json({ error: "Vehicle not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Vehicle deleted successfully", { userId, vehicleId, duration })

    return NextResponse.json({
      message: "Vehicle deleted successfully",
      id: vehicleId,
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error deleting vehicle", { error, vehicleId: params.id, duration })

    return NextResponse.json({ error: "Failed to delete vehicle" }, { status: 500 })
  }
}
