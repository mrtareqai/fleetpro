import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { mockStore } from "@/lib/mock-store"

// POST /api/admin/roles/create - Create new role
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, display_name, description, permission_ids } = body

    console.log("[v0] Creating role with data:", {
      name,
      display_name,
      description,
      permission_count: permission_ids?.length || 0,
    })

    if (!name || !display_name) {
      console.error("[v0] Missing required fields")
      return NextResponse.json(
        { error: "Missing required fields", details: "name and display_name are required" },
        { status: 400 },
      )
    }

    if (!sql) {
      const existingRoles = mockStore.getRoles()
      const duplicate = existingRoles.find((r) => r.name === name)
      if (duplicate) {
        console.error("[v0] Duplicate role name:", name)
        return NextResponse.json(
          { error: "Role already exists", details: `A role with name '${name}' already exists` },
          { status: 409 },
        )
      }

      const newRole = mockStore.addRole({
        name,
        display_name,
        description: description || "",
      })

      console.log("[v0] Role created with id:", newRole.id)

      // Add permissions to the role
      if (permission_ids && Array.isArray(permission_ids) && permission_ids.length > 0) {
        const success = mockStore.updateRolePermissions(newRole.id, permission_ids)
        console.log("[v0] Permissions updated:", success)
      }

      // Get the role with permissions to return
      const roleWithPermissions = mockStore.getRoleWithPermissions(newRole.id)

      if (!roleWithPermissions) {
        console.error("[v0] Failed to retrieve created role")
        return NextResponse.json({ error: "Failed to retrieve created role" }, { status: 500 })
      }

      console.log("[v0] Role created successfully with", roleWithPermissions.permissions.length, "permissions")

      return NextResponse.json({ role: roleWithPermissions }, { status: 201 })
    }

    // Create role
    const [role] = await sql`
      INSERT INTO roles (name, display_name, description, is_system)
      VALUES (${name}, ${display_name}, ${description}, false)
      RETURNING id, name, display_name, description
    `

    // Assign permissions
    if (permission_ids && permission_ids.length > 0) {
      for (const permission_id of permission_ids) {
        await sql`
          INSERT INTO role_permissions (role_id, permission_id)
          VALUES (${role.id}, ${permission_id})
          ON CONFLICT DO NOTHING
        `
      }
    }

    return NextResponse.json({ role }, { status: 201 })
  } catch (error) {
    console.error("[v0] Error creating role:", error)
    return NextResponse.json(
      { error: "Failed to create role", details: error instanceof Error ? error.message : String(error) },
      { status: 500 },
    )
  }
}
