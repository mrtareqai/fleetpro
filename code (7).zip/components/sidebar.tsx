"use client"

import {
  Settings,
  Home,
  Calendar,
  Ticket,
  Truck,
  Users,
  FileText,
  TrendingUp,
  Package,
  LogOut,
  X,
  Shield,
  Globe,
  DollarSign,
} from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { useRouter, usePathname } from "next/navigation"

interface SidebarProps {
  locale: "en" | "ar"
  activePage: string
  isOpen?: boolean
  onClose?: () => void
}

export default function Sidebar({ locale, activePage, isOpen = true, onClose }: SidebarProps) {
  const { hasAnyPermission } = useAuth()
  const router = useRouter()
  const pathname = usePathname()

  const t = {
    en: {
      title: "FleetPro",
      subtitle: "Management",
      dashboard: "Dashboard",
      reservations: "Reservations",
      tickets: "Tickets",
      fleet: "Fleet",
      drivers: "Drivers",
      reports: "Reports",
      movement: "Movement",
      supplies: "Agency Supplies",
      transactions: "Transactions",
      rbacGuide: "RBAC Guide",
      admin: "Administration",
      users: "User Management",
      roles: "Roles & Permissions",
      logout: "Logout",
      language: "Language",
    },
    ar: {
      title: "FleetPro",
      subtitle: "الإدارة",
      dashboard: "لوحة التحكم",
      reservations: "الحجوزات",
      tickets: "التذاكر",
      fleet: "الأسطول",
      drivers: "السائقون",
      reports: "التقارير",
      movement: "الحركة",
      supplies: "مستلزمات الوكالة",
      transactions: "المعاملات",
      rbacGuide: "دليل التحكم بالوصول",
      admin: "الإدارة",
      users: "إدارة المستخدمين",
      roles: "الأدوار والصلاحيات",
      logout: "تسجيل الخروج",
      language: "اللغة",
    },
  }

  const toggleLanguage = () => {
    const newLocale = locale === "en" ? "ar" : "en"
    router.push(`${pathname}?locale=${newLocale}`)
  }

  const menuItems = [
    { id: "dashboard", icon: Home, label: t[locale].dashboard, href: "/dashboard" },
    { id: "reservations", icon: Calendar, label: t[locale].reservations, href: "/reservations" },
    { id: "tickets", icon: Ticket, label: t[locale].tickets, href: "/tickets" },
    { id: "fleet", icon: Truck, label: t[locale].fleet, href: "/fleet" },
    { id: "drivers", icon: Users, label: t[locale].drivers, href: "/drivers" },
    { id: "reports", icon: TrendingUp, label: t[locale].reports, href: "/reports" },
    { id: "movement", icon: FileText, label: t[locale].movement, href: "/movement" },
    { id: "supplies", icon: Package, label: t[locale].supplies, href: "/supplies" },
    {
      id: "transactions",
      icon: DollarSign,
      label: t[locale].transactions,
      href: "/transactions",
      permission: "transactions.read",
    },
    {
      id: "rbac-guide",
      icon: Shield,
      label: t[locale].rbacGuide,
      href: "/rbac-guide",
    },
  ]

  const adminMenuItems = [
    { id: "users", icon: Users, label: t[locale].users, href: "/admin/users" },
    { id: "roles", icon: Shield, label: t[locale].roles, href: "/admin/roles" },
  ]

  const hasAdminAccess = hasAnyPermission(["users.read", "roles.read"])

  return (
    <>
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden touch-manipulation"
          onClick={onClose}
          aria-hidden="true"
        />
      )}

      <div
        className={`
        fixed lg:static inset-y-0 ${locale === "ar" ? "right-0" : "left-0"}
        w-72 bg-slate-700 min-h-screen text-white z-50
        transform transition-transform duration-300 ease-in-out
        ${isOpen ? "translate-x-0" : locale === "ar" ? "translate-x-full" : "-translate-x-full"}
        lg:translate-x-0 flex flex-col
      `}
      >
        <button
          onClick={onClose}
          className={`absolute top-4 ${locale === "ar" ? "left-4" : "right-4"} lg:hidden text-white hover:text-slate-300 p-2 hover:bg-slate-600 rounded-lg transition-colors touch-manipulation`}
          aria-label="Close menu"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="p-6 border-b border-slate-600 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="bg-white p-2 rounded-lg">
              <Settings className="w-6 h-6 text-slate-700" />
            </div>
            <div>
              <h1 className="text-lg font-bold">{t[locale].title}</h1>
              <p className="text-sm text-slate-300">{t[locale].subtitle}</p>
            </div>
          </div>
        </div>

        <nav className="p-4 space-y-2 flex-1 overflow-y-auto">
          {menuItems.map((item) => {
            if (item.permission && !hasAnyPermission([item.permission])) {
              return null
            }

            const Icon = item.icon
            const isActive = activePage === item.id
            return (
              <Link
                key={item.id}
                href={`${item.href}?locale=${locale}`}
                onClick={onClose}
                prefetch={true}
                aria-current={isActive ? "page" : undefined}
                className={`flex items-center gap-3 px-4 py-3.5 rounded-lg transition-colors touch-manipulation min-h-[48px] ${
                  isActive ? "bg-slate-600 text-white" : "text-slate-300 hover:bg-slate-600 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span className="text-base">{item.label}</span>
              </Link>
            )
          })}

          {hasAdminAccess && (
            <div className="pt-4 mt-4 border-t border-slate-600">
              <div className="px-4 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                {t[locale].admin}
              </div>
              {adminMenuItems.map((item) => {
                const Icon = item.icon
                const isActive = activePage === item.id
                return (
                  <Link
                    key={item.id}
                    href={`${item.href}?locale=${locale}`}
                    onClick={onClose}
                    prefetch={true}
                    aria-current={isActive ? "page" : undefined}
                    className={`flex items-center gap-3 px-4 py-3.5 rounded-lg transition-colors touch-manipulation min-h-[48px] ${
                      isActive ? "bg-slate-600 text-white" : "text-slate-300 hover:bg-slate-600 hover:text-white"
                    }`}
                  >
                    <Icon className="w-5 h-5 flex-shrink-0" />
                    <span className="text-base">{item.label}</span>
                  </Link>
                )
              })}
            </div>
          )}
        </nav>

        <div className="p-4 border-t border-slate-600 flex-shrink-0 space-y-2">
          <button
            onClick={toggleLanguage}
            className="w-full flex items-center gap-3 px-4 py-3.5 rounded-lg text-slate-300 hover:bg-slate-600 hover:text-white transition-colors touch-manipulation min-h-[48px]"
          >
            <Globe className="w-5 h-5 flex-shrink-0" />
            <span className="text-base">{locale === "en" ? "العربية" : "English"}</span>
          </button>

          <Link
            href="/login"
            className="flex items-center gap-3 px-4 py-3.5 rounded-lg text-slate-300 hover:bg-slate-600 hover:text-white transition-colors touch-manipulation min-h-[48px]"
          >
            <LogOut className="w-5 h-5 flex-shrink-0" />
            <span className="text-base">{t[locale].logout}</span>
          </Link>
        </div>
      </div>
    </>
  )
}
