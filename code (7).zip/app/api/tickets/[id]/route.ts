import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { updateTicketSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "tickets.read")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const ticketId = Number.parseInt(params.id)

    if (isNaN(ticketId)) {
      return NextResponse.json({ error: "Invalid ticket ID" }, { status: 400 })
    }

    logger.info("Fetching ticket", { userId: user.id, ticketId })

    const result = await sql`
      SELECT * FROM tickets WHERE id = ${ticketId}
    `

    if (result.length === 0) {
      logger.warn("Ticket not found", { userId: user.id, ticketId })
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Ticket fetched successfully", { userId: user.id, ticketId, duration })

    return NextResponse.json({ ticket: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching ticket", { error, ticketId: params.id, duration })

    return NextResponse.json({ error: "Failed to fetch ticket" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "tickets.update")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const ticketId = Number.parseInt(params.id)

    if (isNaN(ticketId)) {
      return NextResponse.json({ error: "Invalid ticket ID" }, { status: 400 })
    }

    // Validate request body
    const body = await request.json()
    const validatedData = await validateOrRespond(updateTicketSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Updating ticket", { userId: user.id, ticketId })

    // Build dynamic update query
    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1

    if (validatedData.passenger_name !== undefined) {
      updates.push(`passenger_name = $${paramIndex++}`)
      values.push(validatedData.passenger_name)
    }
    if (validatedData.trip_number !== undefined) {
      updates.push(`trip_number = $${paramIndex++}`)
      values.push(validatedData.trip_number)
    }
    if (validatedData.trip_name !== undefined) {
      updates.push(`trip_name = $${paramIndex++}`)
      values.push(validatedData.trip_name)
    }
    if (validatedData.trip_date !== undefined) {
      updates.push(`trip_date = $${paramIndex++}`)
      values.push(validatedData.trip_date)
    }
    if (validatedData.trip_time !== undefined) {
      updates.push(`trip_time = $${paramIndex++}`)
      values.push(validatedData.trip_time)
    }
    if (validatedData.seat_number !== undefined) {
      updates.push(`seat_number = $${paramIndex++}`)
      values.push(validatedData.seat_number)
    }
    if (validatedData.mobile_number !== undefined) {
      updates.push(`mobile_number = $${paramIndex++}`)
      values.push(validatedData.mobile_number)
    }
    if (validatedData.status !== undefined) {
      updates.push(`status = $${paramIndex++}`)
      values.push(validatedData.status)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(ticketId)

    const query = `
      UPDATE tickets 
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `

    const result = await sql(query, values)

    if (result.length === 0) {
      logger.warn("Ticket not found for update", { userId: user.id, ticketId })
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Ticket updated successfully", { userId: user.id, ticketId, duration })

    return NextResponse.json({ ticket: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error updating ticket", { error, ticketId: params.id, duration })

    return NextResponse.json({ error: "Failed to update ticket" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "tickets.delete")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const ticketId = Number.parseInt(params.id)

    if (isNaN(ticketId)) {
      return NextResponse.json({ error: "Invalid ticket ID" }, { status: 400 })
    }

    logger.info("Deleting ticket", { userId: user.id, ticketId })

    const result = await sql`
      DELETE FROM tickets 
      WHERE id = ${ticketId}
      RETURNING id
    `

    if (result.length === 0) {
      logger.warn("Ticket not found for deletion", { userId: user.id, ticketId })
      return NextResponse.json({ error: "Ticket not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Ticket deleted successfully", { userId: user.id, ticketId, duration })

    return NextResponse.json({
      message: "Ticket deleted successfully",
      id: ticketId,
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error deleting ticket", { error, ticketId: params.id, duration })

    return NextResponse.json({ error: "Failed to delete ticket" }, { status: 500 })
  }
}
