import DashboardLayout from "@/components/dashboard-layout"
import SuppliesTable from "@/components/supplies-table"

export default function SuppliesPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="supplies">
      <SuppliesTable locale={locale} />
    </DashboardLayout>
  )
}
