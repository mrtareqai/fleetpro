-- Add columns to tickets table for passenger ticket management
ALTER TABLE tickets 
ADD COLUMN IF NOT EXISTS passenger_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS trip_number VARCHAR(50),
ADD COLUMN IF NOT EXISTS trip_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS trip_date DATE,
ADD COLUMN IF NOT EXISTS trip_time TIME,
ADD COLUMN IF NOT EXISTS seat_number VARCHAR(10),
ADD COLUMN IF NOT EXISTS mobile_number VARCHAR(20),
ADD COLUMN IF NOT EXISTS issue_date DATE DEFAULT CURRENT_DATE,
ADD COLUMN IF NOT EXISTS issued_by VARCHAR(255),
ADD COLUMN IF NOT EXISTS branch VARCHAR(100);

-- Update ticket_number format if needed
UPDATE tickets 
SET ticket_number = 'TKT-' || LPAD(id::TEXT, 6, '0')
WHERE ticket_number IS NULL OR ticket_number = '';
