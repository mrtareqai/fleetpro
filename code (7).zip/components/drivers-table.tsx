"use client"

import type React from "react"

import { useState, useEffect, useMemo } from "react"
import { Plus, Edit, Trash2, X, Scan } from "lucide-react"
import { useSelection } from "@/lib/selection-context"
import { useAuth } from "@/lib/auth-context"
import { apiClient } from "@/lib/api-client"
import { sortData, filterData, exportToCSV, type SortConfig, type FilterConfig } from "@/lib/table-utils"
import { DataTableToolbar } from "@/components/data-table-toolbar"
import { SortableTableHead } from "@/components/sortable-table-head"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface DriversTableProps {
  locale: "en" | "ar"
}

interface Driver {
  id: number
  name: string
  license_number: string
  phone: string
  status: string
}

export default function DriversTable({ locale }: DriversTableProps) {
  const [drivers, setDrivers] = useState<Driver[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    license_number: "",
    phone: "",
    email: "",
    status: "active",
  })

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [deleteTargetId, setDeleteTargetId] = useState<number | null>(null)

  const [sortConfig, setSortConfig] = useState<SortConfig<Driver>>({
    key: null,
    direction: null,
  })
  const [filterConfig, setFilterConfig] = useState<FilterConfig>({
    searchQuery: "",
    statusFilter: "all",
  })

  const { isSelectionMode, toggleSelectionMode, selectedItems, toggleItem, selectAll, clearSelection, isSelected } =
    useSelection()
  const { hasPermission } = useAuth()

  const t = {
    en: {
      title: "Drivers Management",
      addDriver: "Add Driver",
      edit: "Edit",
      delete: "Delete",
      cancel: "Cancel",
      save: "Save",
      addDriverTitle: "Add New Driver",
      name: "Name",
      licenseNumber: "License Number",
      phone: "Phone",
      email: "Email",
      status: "Status",
      active: "Active",
      inactive: "Inactive",
      scan: "Scan",
      selectAll: "Select All",
      selected: "selected",
      deleteSelected: "Delete Selected",
      selectionModeActive: "Selection mode active - Select items to delete",
      loading: "Loading...",
      noDrivers: "No drivers found",
      exportSuccess: "Data exported successfully!",
      totalDrivers: "Total Drivers",
      showing: "Showing",
      of: "of",
      results: "results",
    },
    ar: {
      title: "إدارة السائقين",
      addDriver: "إضافة سائق",
      edit: "تعديل",
      delete: "حذف",
      cancel: "إلغاء",
      save: "حفظ",
      addDriverTitle: "إضافة سائق جديد",
      name: "الاسم",
      licenseNumber: "رقم الرخصة",
      phone: "الهاتف",
      email: "البريد الإلكتروني",
      status: "الحالة",
      active: "نشط",
      inactive: "غير نشط",
      scan: "مسح",
      selectAll: "تحديد الكل",
      selected: "محدد",
      deleteSelected: "حذف المحدد",
      selectionModeActive: "وضع التحديد نشط - حدد العناصر للحذف",
      loading: "جاري التحميل...",
      noDrivers: "لا يوجد سائقين",
      exportSuccess: "تم تصدير البيانات بنجاح!",
      totalDrivers: "إجمالي السائقين",
      showing: "عرض",
      of: "من",
      results: "نتيجة",
    },
  }

  useEffect(() => {
    fetchDrivers()
  }, [])

  const processedData = useMemo(() => {
    // First filter
    let filtered = filterData(drivers, filterConfig, ["name", "license_number", "phone"], "status")

    // Then sort
    filtered = sortData(filtered, sortConfig)

    return filtered
  }, [drivers, filterConfig, sortConfig])

  const handleSort = (key: keyof Driver) => {
    setSortConfig((prev) => {
      if (prev.key === key) {
        // Cycle through: asc -> desc -> null
        if (prev.direction === "asc") {
          return { key, direction: "desc" }
        } else if (prev.direction === "desc") {
          return { key: null, direction: null }
        }
      }
      return { key, direction: "asc" }
    })
  }

  const handleExport = () => {
    const columns = [
      { key: "id" as keyof Driver, label: "ID" },
      { key: "name" as keyof Driver, label: t[locale].name },
      { key: "license_number" as keyof Driver, label: t[locale].licenseNumber },
      { key: "phone" as keyof Driver, label: t[locale].phone },
      { key: "status" as keyof Driver, label: t[locale].status },
    ]

    const filename = `drivers_${new Date().toISOString().split("T")[0]}.csv`
    exportToCSV(processedData, columns, filename)
  }

  const handleClearFilters = () => {
    setFilterConfig({
      searchQuery: "",
      statusFilter: "all",
    })
    setSortConfig({
      key: null,
      direction: null,
    })
  }

  const activeFiltersCount = useMemo(() => {
    let count = 0
    if (filterConfig.searchQuery) count++
    if (filterConfig.statusFilter !== "all") count++
    if (sortConfig.key) count++
    return count
  }, [filterConfig, sortConfig])

  const fetchDrivers = async () => {
    try {
      setLoading(true)
      const data = await apiClient.getDrivers()
      setDrivers(data)
    } catch (err) {
      console.error("[v0] Error fetching drivers:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiClient.createDriver(formData)
      setShowAddModal(false)
      setFormData({
        name: "",
        license_number: "",
        phone: "",
        email: "",
        status: "active",
      })
      fetchDrivers()
    } catch (err) {
      alert(locale === "en" ? "Failed to add driver" : "فشل إضافة السائق")
      console.error("[v0] Error adding driver:", err)
    }
  }

  const handleEdit = () => {
    if (!selectedId) return
    const driver = drivers.find((d) => d.id === selectedId)
    if (driver) {
      setFormData({
        name: driver.name,
        license_number: driver.license_number,
        phone: driver.phone,
        email: "",
        status: driver.status,
      })
      setShowEditModal(true)
    }
  }

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!selectedId) return
    try {
      await apiClient.updateDriver(selectedId, formData)
      setShowEditModal(false)
      setFormData({
        name: "",
        license_number: "",
        phone: "",
        email: "",
        status: "active",
      })
      setSelectedId(null)
      fetchDrivers()
    } catch (err) {
      alert(locale === "en" ? "Failed to update driver" : "فشل تحديث السائق")
      console.error("[v0] Error updating driver:", err)
    }
  }

  const handleRowClick = (id: number) => {
    if (isSelectionMode) {
      toggleItem(id)
    } else {
      setSelectedId(id)
    }
  }

  const handleSelectAll = () => {
    selectAll(processedData.map((d) => d.id))
  }

  const handleDelete = async () => {
    if (!deleteTargetId) return

    try {
      await apiClient.deleteDriver(deleteTargetId)
      setShowDeleteConfirm(false)
      setDeleteTargetId(null)
      setSelectedId(null)
      fetchDrivers()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete driver" : "فشل حذف السائق")
      console.error("[v0] Error deleting driver:", err)
    }
  }

  const handleDeleteSelected = async () => {
    if (selectedItems.size === 0) return

    const confirmMessage =
      locale === "en"
        ? `Are you sure you want to delete ${selectedItems.size} driver(s)?`
        : `هل أنت متأكد من حذف ${selectedItems.size} سائق؟`

    if (!confirm(confirmMessage)) return

    try {
      const deletePromises = Array.from(selectedItems).map((id) => apiClient.deleteDriver(id))
      await Promise.all(deletePromises)
      clearSelection()
      toggleSelectionMode()
      fetchDrivers()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete drivers" : "فشل حذف السائقين")
      console.error("[v0] Error deleting drivers:", err)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>
        <div className="text-sm text-slate-600">
          {t[locale].showing} <span className="font-semibold">{processedData.length}</span> {t[locale].of}{" "}
          <span className="font-semibold">{drivers.length}</span> {t[locale].results}
        </div>
      </div>

      <DataTableToolbar
        searchQuery={filterConfig.searchQuery}
        onSearchChange={(query) => setFilterConfig((prev) => ({ ...prev, searchQuery: query }))}
        statusFilter={filterConfig.statusFilter}
        onStatusFilterChange={(status) => setFilterConfig((prev) => ({ ...prev, statusFilter: status }))}
        statusOptions={[
          { value: "active", label: t[locale].active },
          { value: "inactive", label: t[locale].inactive },
        ]}
        onExport={handleExport}
        locale={locale}
        activeFiltersCount={activeFiltersCount}
        onClearFilters={handleClearFilters}
      />

      <div className="flex flex-wrap gap-2 md:gap-3">
        {hasPermission("drivers.delete") && (
          <button
            onClick={toggleSelectionMode}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
              isSelectionMode
                ? "bg-purple-600 hover:bg-purple-700 text-white"
                : "bg-purple-500 hover:bg-purple-600 text-white"
            }`}
          >
            <Scan className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].scan}
          </button>
        )}

        {!isSelectionMode && (
          <>
            <button
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
            >
              <Plus className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].addDriver}
            </button>
            <button
              onClick={handleEdit}
              disabled={!selectedId}
              className="flex items-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Edit className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].edit}
            </button>
            <button
              onClick={() => {
                if (selectedId) {
                  setDeleteTargetId(selectedId)
                  setShowDeleteConfirm(true)
                }
              }}
              disabled={!selectedId}
              className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].delete}
            </button>
          </>
        )}
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden border border-slate-200">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-slate-100 border-b border-slate-200">
              <TableRow>
                {isSelectionMode && (
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedItems.size === processedData.length && processedData.length > 0}
                      onChange={handleSelectAll}
                      className="w-4 h-4 rounded border-slate-300"
                    />
                  </TableHead>
                )}
                <SortableTableHead
                  label={t[locale].name}
                  sortKey="name"
                  currentSortKey={sortConfig.key as string}
                  currentSortDirection={sortConfig.direction}
                  onSort={handleSort}
                />
                <SortableTableHead
                  label={t[locale].licenseNumber}
                  sortKey="license_number"
                  currentSortKey={sortConfig.key as string}
                  currentSortDirection={sortConfig.direction}
                  onSort={handleSort}
                />
                <SortableTableHead
                  label={t[locale].phone}
                  sortKey="phone"
                  currentSortKey={sortConfig.key as string}
                  currentSortDirection={sortConfig.direction}
                  onSort={handleSort}
                />
                <SortableTableHead
                  label={t[locale].status}
                  sortKey="status"
                  currentSortKey={sortConfig.key as string}
                  currentSortDirection={sortConfig.direction}
                  onSort={handleSort}
                />
              </TableRow>
            </TableHeader>
            <TableBody className="divide-y divide-slate-200">
              {processedData.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={isSelectionMode ? 5 : 4} className="px-4 py-8 text-center text-slate-500">
                    {t[locale].noDrivers}
                  </TableCell>
                </TableRow>
              ) : (
                processedData.map((driver) => (
                  <TableRow
                    key={driver.id}
                    onClick={() => handleRowClick(driver.id)}
                    className={`cursor-pointer transition-colors ${
                      isSelectionMode
                        ? isSelected(driver.id)
                          ? "bg-purple-50 border-l-4 border-purple-500"
                          : "hover:bg-slate-50"
                        : selectedId === driver.id
                          ? "bg-blue-50"
                          : "hover:bg-slate-50"
                    }`}
                  >
                    {isSelectionMode && (
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={isSelected(driver.id)}
                          onChange={() => toggleItem(driver.id)}
                          className="w-4 h-4 rounded border-slate-300"
                          onClick={(e) => e.stopPropagation()}
                        />
                      </TableCell>
                    )}
                    <TableCell className="text-sm text-slate-700 font-medium">{driver.name}</TableCell>
                    <TableCell className="text-sm text-slate-700">{driver.license_number}</TableCell>
                    <TableCell className="text-sm text-slate-700">{driver.phone}</TableCell>
                    <TableCell>
                      <span
                        className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          driver.status === "active" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"
                        }`}
                      >
                        {driver.status === "active" ? t[locale].active : t[locale].inactive}
                      </span>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        <div className="px-6 py-4 border-t border-slate-200">
          <p className="text-sm text-slate-500">© 2025 FleetPro System – All rights reserved</p>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <h2 className="text-xl font-bold text-slate-800">{t[locale].addDriverTitle}</h2>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].name}</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].licenseNumber}</label>
                <input
                  type="text"
                  required
                  value={formData.license_number}
                  onChange={(e) => setFormData({ ...formData, license_number: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].phone}</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].status}</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="active">{t[locale].active}</option>
                  <option value="inactive">{t[locale].inactive}</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  {t[locale].cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                >
                  {t[locale].save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && (
        <div
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={() => setShowEditModal(false)}
        >
          <div
            className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <h2 className="text-xl font-bold text-slate-800">{locale === "en" ? "Edit Driver" : "تعديل السائق"}</h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="text-slate-400 hover:text-slate-600"
                aria-label={locale === "en" ? "Close" : "إغلاق"}
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpdate} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].name}</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].licenseNumber}</label>
                <input
                  type="text"
                  required
                  value={formData.license_number}
                  onChange={(e) => setFormData({ ...formData, license_number: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].phone}</label>
                <input
                  type="tel"
                  required
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].status}</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="active">{t[locale].active}</option>
                  <option value="inactive">{t[locale].inactive}</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  {t[locale].cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                >
                  {t[locale].save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-lg font-bold text-slate-800 mb-4">
              {locale === "en" ? "Confirm Deletion" : "تأكيد الحذف"}
            </h3>
            <p className="text-slate-600 mb-6">
              {locale === "en"
                ? "Are you sure you want to delete this driver? This action cannot be undone."
                : "هل أنت متأكد من حذف هذا السائق؟ لا يمكن التراجع عن هذا الإجراء."}
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => {
                  setShowDeleteConfirm(false)
                  setDeleteTargetId(null)
                }}
                className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
              >
                {t[locale].cancel}
              </button>
              <button
                onClick={handleDelete}
                className="flex-1 px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
              >
                {t[locale].delete}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
