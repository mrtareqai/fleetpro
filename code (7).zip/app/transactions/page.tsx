"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import ProtectedRoute from "@/components/protected-route"
import PermissionGate from "@/components/permission-gate"
import { useAuth } from "@/lib/auth-context"
import { TRANSACTION_PERMISSIONS } from "@/lib/permissions"
import {
  Plus,
  Download,
  CheckCircle,
  XCircle,
  Clock,
  Edit,
  Trash2,
  FileText,
  User,
  DollarSign,
  AlertCircle,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface Transaction {
  id: string
  type: "fuel" | "maintenance" | "rental" | "fine" | "other"
  amount: number
  currency: string
  description: string
  status: "pending" | "approved" | "rejected" | "completed"
  vehicle_id?: string
  vehicle_name?: string
  driver_id?: string
  driver_name?: string
  created_by: string
  created_by_name: string
  created_at: string
  updated_by?: string
  updated_by_name?: string
  updated_at?: string
  approved_by?: string
  approved_by_name?: string
  approved_at?: string
  rejected_by?: string
  rejected_by_name?: string
  rejected_at?: string
  rejection_reason?: string
}

export default function TransactionsPage() {
  const searchParams = useSearchParams()
  const locale = (searchParams.get("locale") as "en" | "ar") || "en"
  const { user, hasPermission } = useAuth()

  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [isApproveModalOpen, setIsApproveModalOpen] = useState(false)
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false)
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)
  const [rejectionReason, setRejectionReason] = useState("")
  const [formData, setFormData] = useState({
    type: "fuel" as Transaction["type"],
    amount: "",
    currency: "USD",
    description: "",
    vehicle_id: "",
    driver_id: "",
  })

  const t = {
    en: {
      title: "Transaction Process Management",
      subtitle: "Manage financial transactions with role-based approval workflow",
      createTransaction: "Create Transaction",
      exportData: "Export Data",
      transactionId: "Transaction ID",
      type: "Type",
      amount: "Amount",
      description: "Description",
      status: "Status",
      createdBy: "Created By",
      createdAt: "Created At",
      approvedBy: "Approved By",
      rejectedBy: "Rejected By",
      actions: "Actions",
      edit: "Edit",
      delete: "Delete",
      approve: "Approve",
      reject: "Reject",
      cancel: "Cancel",
      save: "Save",
      confirm: "Confirm",
      pending: "Pending",
      approved: "Approved",
      rejected: "Rejected",
      completed: "Completed",
      fuel: "Fuel",
      maintenance: "Maintenance",
      rental: "Rental",
      fine: "Fine",
      other: "Other",
      vehicle: "Vehicle",
      driver: "Driver",
      rejectionReason: "Rejection Reason",
      confirmApprove: "Are you sure you want to approve this transaction?",
      confirmReject: "Please provide a reason for rejecting this transaction:",
      confirmDelete: "Are you sure you want to delete this transaction?",
      noPermission: "You don't have permission to perform this action",
      roleInfo: "Your Role Permissions",
      canCreate: "Can create transactions",
      canUpdate: "Can update pending transactions",
      canApprove: "Can approve transactions",
      canReject: "Can reject transactions",
      canDelete: "Can delete transactions",
      canExport: "Can export transaction reports",
      viewOnly: "View-only access",
    },
    ar: {
      title: "إدارة عمليات المعاملات",
      subtitle: "إدارة المعاملات المالية مع سير عمل الموافقة القائم على الأدوار",
      createTransaction: "إنشاء معاملة",
      exportData: "تصدير البيانات",
      transactionId: "رقم المعاملة",
      type: "النوع",
      amount: "المبلغ",
      description: "الوصف",
      status: "الحالة",
      createdBy: "أنشئ بواسطة",
      createdAt: "تاريخ الإنشاء",
      approvedBy: "وافق عليه",
      rejectedBy: "رفض بواسطة",
      actions: "الإجراءات",
      edit: "تعديل",
      delete: "حذف",
      approve: "موافقة",
      reject: "رفض",
      cancel: "إلغاء",
      save: "حفظ",
      confirm: "تأكيد",
      pending: "قيد الانتظار",
      approved: "موافق عليه",
      rejected: "مرفوض",
      completed: "مكتمل",
      fuel: "وقود",
      maintenance: "صيانة",
      rental: "إيجار",
      fine: "غرامة",
      other: "أخرى",
      vehicle: "المركبة",
      driver: "السائق",
      rejectionReason: "سبب الرفض",
      confirmApprove: "هل أنت متأكد من الموافقة على هذه المعاملة؟",
      confirmReject: "يرجى تقديم سبب لرفض هذه المعاملة:",
      confirmDelete: "هل أنت متأكد من حذف هذه المعاملة؟",
      noPermission: "ليس لديك إذن لتنفيذ هذا الإجراء",
      roleInfo: "صلاحيات دورك",
      canCreate: "يمكن إنشاء المعاملات",
      canUpdate: "يمكن تحديث المعاملات المعلقة",
      canApprove: "يمكن الموافقة على المعاملات",
      canReject: "يمكن رفض المعاملات",
      canDelete: "يمكن حذف المعاملات",
      canExport: "يمكن تصدير تقارير المعاملات",
      viewOnly: "وصول للقراءة فقط",
    },
  }

  useEffect(() => {
    fetchTransactions()
  }, [])

  const fetchTransactions = async () => {
    setLoading(true)
    // Mock data for demonstration
    setTimeout(() => {
      setTransactions([
        {
          id: "TXN-001",
          type: "fuel",
          amount: 150.5,
          currency: "USD",
          description: "Fuel refill for vehicle ABC-123",
          status: "pending",
          vehicle_id: "1",
          vehicle_name: "Toyota Camry - ABC-123",
          driver_id: "1",
          driver_name: "John Doe",
          created_by: "2",
          created_by_name: "Fleet Manager",
          created_at: new Date().toISOString(),
        },
        {
          id: "TXN-002",
          type: "maintenance",
          amount: 450.0,
          currency: "USD",
          description: "Oil change and tire rotation",
          status: "approved",
          vehicle_id: "2",
          vehicle_name: "Honda Accord - XYZ-789",
          created_by: "3",
          created_by_name: "Dispatcher",
          created_at: new Date(Date.now() - 86400000).toISOString(),
          approved_by: "1",
          approved_by_name: "Admin User",
          approved_at: new Date().toISOString(),
        },
        {
          id: "TXN-003",
          type: "fine",
          amount: 75.0,
          currency: "USD",
          description: "Parking violation",
          status: "rejected",
          vehicle_id: "1",
          vehicle_name: "Toyota Camry - ABC-123",
          driver_id: "2",
          driver_name: "Jane Smith",
          created_by: "4",
          created_by_name: "Maintenance Staff",
          created_at: new Date(Date.now() - 172800000).toISOString(),
          rejected_by: "1",
          rejected_by_name: "Admin User",
          rejected_at: new Date(Date.now() - 86400000).toISOString(),
          rejection_reason: "Insufficient documentation provided",
        },
      ])
      setLoading(false)
    }, 500)
  }

  const handleCreateTransaction = () => {
    console.log("[v0] Creating transaction:", formData)
    const newTransaction: Transaction = {
      id: `TXN-${String(transactions.length + 1).padStart(3, "0")}`,
      ...formData,
      amount: Number.parseFloat(formData.amount),
      status: "pending",
      created_by: user?.id || "unknown",
      created_by_name: user?.full_name || "Unknown User",
      created_at: new Date().toISOString(),
    }
    setTransactions([newTransaction, ...transactions])
    setIsCreateModalOpen(false)
    setFormData({ type: "fuel", amount: "", currency: "USD", description: "", vehicle_id: "", driver_id: "" })
  }

  const handleApproveTransaction = () => {
    if (!selectedTransaction) return
    console.log("[v0] Approving transaction:", selectedTransaction.id)
    setTransactions(
      transactions.map((t) =>
        t.id === selectedTransaction.id
          ? {
              ...t,
              status: "approved",
              approved_by: user?.id,
              approved_by_name: user?.full_name || "Unknown",
              approved_at: new Date().toISOString(),
            }
          : t,
      ),
    )
    setIsApproveModalOpen(false)
    setSelectedTransaction(null)
  }

  const handleRejectTransaction = () => {
    if (!selectedTransaction || !rejectionReason.trim()) return
    console.log("[v0] Rejecting transaction:", selectedTransaction.id, "Reason:", rejectionReason)
    setTransactions(
      transactions.map((t) =>
        t.id === selectedTransaction.id
          ? {
              ...t,
              status: "rejected",
              rejected_by: user?.id,
              rejected_by_name: user?.full_name || "Unknown",
              rejected_at: new Date().toISOString(),
              rejection_reason: rejectionReason,
            }
          : t,
      ),
    )
    setIsRejectModalOpen(false)
    setSelectedTransaction(null)
    setRejectionReason("")
  }

  const handleDeleteTransaction = (transactionId: string) => {
    if (!confirm(t[locale].confirmDelete)) return
    console.log("[v0] Deleting transaction:", transactionId)
    setTransactions(transactions.filter((t) => t.id !== transactionId))
  }

  const handleExportData = () => {
    console.log("[v0] Exporting transaction data")
    const csv = [
      ["ID", "Type", "Amount", "Status", "Created By", "Created At"].join(","),
      ...transactions.map((t) =>
        [t.id, t.type, t.amount, t.status, t.created_by_name, new Date(t.created_at).toLocaleDateString()].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `transactions-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
  }

  const getStatusBadge = (status: Transaction["status"]) => {
    const variants = {
      pending: { variant: "secondary" as const, icon: Clock, color: "text-yellow-600" },
      approved: { variant: "default" as const, icon: CheckCircle, color: "text-green-600" },
      rejected: { variant: "destructive" as const, icon: XCircle, color: "text-red-600" },
      completed: { variant: "default" as const, icon: CheckCircle, color: "text-blue-600" },
    }
    const { variant, icon: Icon, color } = variants[status]
    return (
      <Badge variant={variant} className="flex items-center gap-1">
        <Icon className={`w-3 h-3 ${color}`} />
        {t[locale][status]}
      </Badge>
    )
  }

  const getTypeIcon = (type: Transaction["type"]) => {
    const icons = {
      fuel: "⛽",
      maintenance: "🔧",
      rental: "🚗",
      fine: "⚠️",
      other: "📄",
    }
    return icons[type]
  }

  return (
    <ProtectedRoute requiredPermission={TRANSACTION_PERMISSIONS.READ}>
      <DashboardLayout locale={locale} activePage="transactions">
        <div className="p-6 space-y-6">
          {/* Header */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>
                <p className="text-slate-600 mt-1">{t[locale].subtitle}</p>
              </div>
              <div className="flex items-center gap-2">
                <PermissionGate permission={TRANSACTION_PERMISSIONS.EXPORT}>
                  <Button
                    variant="outline"
                    onClick={handleExportData}
                    className="flex items-center gap-2 bg-transparent"
                  >
                    <Download className="w-4 h-4" />
                    {t[locale].exportData}
                  </Button>
                </PermissionGate>
                <PermissionGate permission={TRANSACTION_PERMISSIONS.CREATE}>
                  <Button onClick={() => setIsCreateModalOpen(true)} className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    {t[locale].createTransaction}
                  </Button>
                </PermissionGate>
              </div>
            </div>
          </div>

          {/* Role Permissions Info */}
          <Alert>
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>
              <div className="font-semibold mb-2">{t[locale].roleInfo}</div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                {hasPermission(TRANSACTION_PERMISSIONS.CREATE) && (
                  <div className="flex items-center gap-1 text-green-700">
                    <CheckCircle className="w-3 h-3" />
                    {t[locale].canCreate}
                  </div>
                )}
                {hasPermission(TRANSACTION_PERMISSIONS.UPDATE) && (
                  <div className="flex items-center gap-1 text-green-700">
                    <CheckCircle className="w-3 h-3" />
                    {t[locale].canUpdate}
                  </div>
                )}
                {hasPermission(TRANSACTION_PERMISSIONS.APPROVE) && (
                  <div className="flex items-center gap-1 text-green-700">
                    <CheckCircle className="w-3 h-3" />
                    {t[locale].canApprove}
                  </div>
                )}
                {hasPermission(TRANSACTION_PERMISSIONS.REJECT) && (
                  <div className="flex items-center gap-1 text-green-700">
                    <CheckCircle className="w-3 h-3" />
                    {t[locale].canReject}
                  </div>
                )}
                {hasPermission(TRANSACTION_PERMISSIONS.DELETE) && (
                  <div className="flex items-center gap-1 text-green-700">
                    <CheckCircle className="w-3 h-3" />
                    {t[locale].canDelete}
                  </div>
                )}
                {hasPermission(TRANSACTION_PERMISSIONS.EXPORT) && (
                  <div className="flex items-center gap-1 text-green-700">
                    <CheckCircle className="w-3 h-3" />
                    {t[locale].canExport}
                  </div>
                )}
                {!hasPermission(TRANSACTION_PERMISSIONS.CREATE) &&
                  !hasPermission(TRANSACTION_PERMISSIONS.UPDATE) &&
                  !hasPermission(TRANSACTION_PERMISSIONS.APPROVE) && (
                    <div className="flex items-center gap-1 text-slate-600">
                      <AlertCircle className="w-3 h-3" />
                      {t[locale].viewOnly}
                    </div>
                  )}
              </div>
            </AlertDescription>
          </Alert>

          {/* Transactions Table */}
          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].transactionId}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].type}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].amount}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].description}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].status}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].createdBy}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].actions}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-200">
                    {transactions.map((transaction) => (
                      <tr key={transaction.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4 text-slate-400" />
                            <span className="text-sm font-medium text-slate-900">{transaction.id}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <span className="text-lg">{getTypeIcon(transaction.type)}</span>
                            <span className="text-sm text-slate-900">{t[locale][transaction.type]}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-1">
                            <DollarSign className="w-4 h-4 text-green-600" />
                            <span className="text-sm font-semibold text-slate-900">
                              {transaction.amount.toFixed(2)} {transaction.currency}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-slate-900 max-w-xs truncate">{transaction.description}</div>
                          {transaction.vehicle_name && (
                            <div className="text-xs text-slate-500 mt-1">{transaction.vehicle_name}</div>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">{getStatusBadge(transaction.status)}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-slate-400" />
                            <div>
                              <div className="text-sm text-slate-900">{transaction.created_by_name}</div>
                              <div className="text-xs text-slate-500">
                                {new Date(transaction.created_at).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            {transaction.status === "pending" && (
                              <>
                                <PermissionGate permission={TRANSACTION_PERMISSIONS.APPROVE}>
                                  <button
                                    onClick={() => {
                                      setSelectedTransaction(transaction)
                                      setIsApproveModalOpen(true)
                                    }}
                                    className="text-green-600 hover:text-green-800"
                                    title={t[locale].approve}
                                  >
                                    <CheckCircle className="w-5 h-5" />
                                  </button>
                                </PermissionGate>
                                <PermissionGate permission={TRANSACTION_PERMISSIONS.REJECT}>
                                  <button
                                    onClick={() => {
                                      setSelectedTransaction(transaction)
                                      setIsRejectModalOpen(true)
                                    }}
                                    className="text-red-600 hover:text-red-800"
                                    title={t[locale].reject}
                                  >
                                    <XCircle className="w-5 h-5" />
                                  </button>
                                </PermissionGate>
                                <PermissionGate permission={TRANSACTION_PERMISSIONS.UPDATE}>
                                  <button
                                    onClick={() => {
                                      setSelectedTransaction(transaction)
                                      setIsEditModalOpen(true)
                                    }}
                                    className="text-blue-600 hover:text-blue-800"
                                    title={t[locale].edit}
                                  >
                                    <Edit className="w-5 h-5" />
                                  </button>
                                </PermissionGate>
                              </>
                            )}
                            <PermissionGate permission={TRANSACTION_PERMISSIONS.DELETE}>
                              <button
                                onClick={() => handleDeleteTransaction(transaction.id)}
                                className="text-red-600 hover:text-red-800"
                                title={t[locale].delete}
                              >
                                <Trash2 className="w-5 h-5" />
                              </button>
                            </PermissionGate>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Create Transaction Modal */}
          <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>{t[locale].createTransaction}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="type">{t[locale].type}</Label>
                  <Select
                    value={formData.type}
                    onValueChange={(value: any) => setFormData({ ...formData, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fuel">{t[locale].fuel}</SelectItem>
                      <SelectItem value="maintenance">{t[locale].maintenance}</SelectItem>
                      <SelectItem value="rental">{t[locale].rental}</SelectItem>
                      <SelectItem value="fine">{t[locale].fine}</SelectItem>
                      <SelectItem value="other">{t[locale].other}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="amount">{t[locale].amount}</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">{t[locale].description}</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateModalOpen(false)}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleCreateTransaction}>{t[locale].save}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Approve Modal */}
          <Dialog open={isApproveModalOpen} onOpenChange={setIsApproveModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t[locale].approve}</DialogTitle>
              </DialogHeader>
              <p className="py-4">{t[locale].confirmApprove}</p>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsApproveModalOpen(false)}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleApproveTransaction}>{t[locale].confirm}</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Reject Modal */}
          <Dialog open={isRejectModalOpen} onOpenChange={setIsRejectModalOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{t[locale].reject}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <p>{t[locale].confirmReject}</p>
                <Textarea
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  placeholder={t[locale].rejectionReason}
                  rows={3}
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsRejectModalOpen(false)}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleRejectTransaction} disabled={!rejectionReason.trim()}>
                  {t[locale].confirm}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}
