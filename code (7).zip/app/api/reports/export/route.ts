import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import * as XLSX from "xlsx"
import { reportsRateLimiter, getClientIp } from "@/lib/security/rate-limit"

export async function POST(request: NextRequest) {
  const ip = getClientIp(request)
  const rateLimitResult = await reportsRateLimiter.check(ip)

  if (!rateLimitResult.success) {
    return NextResponse.json(
      {
        error: "Too many requests",
        retryAfter: rateLimitResult.retryAfter,
      },
      {
        status: 429,
        headers: {
          "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": "0",
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      },
    )
  }

  const authResult = await requirePermission(request, "reports.export")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Exporting report...")

    const body = await request.json()
    const { reportType, format, data } = body

    if (!reportType || !format || !data) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    if (format === "excel" || format === "xlsx") {
      const excelBuffer = generateExcel(data, reportType)

      return new NextResponse(excelBuffer, {
        headers: {
          "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "Content-Disposition": `attachment; filename="${reportType}-${Date.now()}.xlsx"`,
          "Content-Length": excelBuffer.length.toString(),
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      })
    } else if (format === "csv") {
      const csv = generateCSV(data, reportType)
      return new NextResponse(csv, {
        headers: {
          "Content-Type": "text/csv; charset=utf-8",
          "Content-Disposition": `attachment; filename="${reportType}-${Date.now()}.csv"`,
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      })
    } else if (format === "json") {
      return new NextResponse(JSON.stringify(data, null, 2), {
        headers: {
          "Content-Type": "application/json",
          "Content-Disposition": `attachment; filename="${reportType}-${Date.now()}.json"`,
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      })
    } else if (format === "pdf") {
      return NextResponse.json({
        message: "PDF generation is in progress",
        downloadUrl: `/api/reports/download/${reportType}-${Date.now()}.pdf`,
      })
    }

    return NextResponse.json({ error: "Unsupported format" }, { status: 400 })
  } catch (error) {
    console.error("[v0] Error exporting report:", error)
    return NextResponse.json({ error: "Failed to export report" }, { status: 500 })
  }
}

function generateExcel(data: any, reportType: string): Buffer {
  const workbook = XLSX.utils.book_new()

  // Add metadata sheet with Arabic support
  const metadataSheet = XLSX.utils.aoa_to_sheet([
    ["نوع التقرير / Report Type", reportType],
    ["تاريخ الإنشاء / Generated", new Date().toLocaleString("ar-SA")],
    [""],
  ])
  XLSX.utils.book_append_sheet(workbook, metadataSheet, "معلومات")

  // Process data based on structure
  if (Array.isArray(data)) {
    // Simple array of objects
    const worksheet = XLSX.utils.json_to_sheet(data)
    XLSX.utils.book_append_sheet(workbook, worksheet, "البيانات")
  } else if (typeof data === "object") {
    // Complex object with multiple sections
    if (data.summary) {
      // Add summary sheet
      const summaryData = Object.entries(data.summary).map(([key, value]) => ({
        "المقياس / Metric": key,
        "القيمة / Value": value,
      }))
      const summarySheet = XLSX.utils.json_to_sheet(summaryData)
      XLSX.utils.book_append_sheet(workbook, summarySheet, "الملخص")
    }

    if (data.data && Array.isArray(data.data)) {
      // Add main data sheet
      const dataSheet = XLSX.utils.json_to_sheet(data.data)
      XLSX.utils.book_append_sheet(workbook, dataSheet, "التفاصيل")
    }

    if (data.breakdown && Array.isArray(data.breakdown)) {
      // Add breakdown sheet
      const breakdownSheet = XLSX.utils.json_to_sheet(data.breakdown)
      XLSX.utils.book_append_sheet(workbook, breakdownSheet, "التفصيل")
    }

    if (data.drivers && Array.isArray(data.drivers)) {
      // Add drivers sheet
      const driversSheet = XLSX.utils.json_to_sheet(data.drivers)
      XLSX.utils.book_append_sheet(workbook, driversSheet, "السائقون")
    }

    if (data.months && Array.isArray(data.months)) {
      // Add monthly data sheet
      const monthsSheet = XLSX.utils.json_to_sheet(data.months)
      XLSX.utils.book_append_sheet(workbook, monthsSheet, "البيانات الشهرية")
    }

    // Add percentages or other nested data
    if (data.percentages) {
      const percentagesData = Object.entries(data.percentages).map(([key, value]) => ({
        "الحالة / Status": key,
        "النسبة / Percentage": `${value}%`,
      }))
      const percentagesSheet = XLSX.utils.json_to_sheet(percentagesData)
      XLSX.utils.book_append_sheet(workbook, percentagesSheet, "النسب المئوية")
    }
  }

  const excelData = XLSX.write(workbook, {
    type: "array",
    bookType: "xlsx",
    compression: true,
  })

  // Convert Uint8Array to Buffer
  return Buffer.from(excelData)
}

function generateCSV(data: any, reportType: string): string {
  const lines: string[] = []

  lines.push(`${reportType} Report`)
  lines.push(`Generated: ${new Date().toLocaleString()}`)
  lines.push("")

  if (Array.isArray(data)) {
    if (data.length > 0) {
      const headers = Object.keys(data[0])
      lines.push(headers.join(","))

      data.forEach((row) => {
        const values = headers.map((header) => {
          const value = row[header]
          if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
            return `"${value.replace(/"/g, '""')}"`
          }
          return value
        })
        lines.push(values.join(","))
      })
    }
  } else if (typeof data === "object") {
    Object.entries(data).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        lines.push(`\n${key}:`)
        lines.push(Object.keys(value[0] || {}).join(","))
        value.forEach((item) => {
          lines.push(Object.values(item).join(","))
        })
      } else {
        lines.push(`${key},${value}`)
      }
    })
  }

  return lines.join("\n")
}
