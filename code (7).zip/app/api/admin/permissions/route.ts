import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { mockStore } from "@/lib/mock-store"

// GET /api/admin/permissions - List all permissions
export async function GET(request: NextRequest) {
  try {
    if (!sql) {
      const permissions = mockStore.getPermissions()
      return NextResponse.json({ permissions })
    }

    const permissions = await sql`
      SELECT id, name, display_name, description, resource, action, created_at
      FROM permissions
      ORDER BY resource, action
    `

    return NextResponse.json({ permissions })
  } catch (error) {
    console.error("[v0] Error fetching permissions:", error)
    return NextResponse.json({ error: "Failed to fetch permissions" }, { status: 500 })
  }
}
