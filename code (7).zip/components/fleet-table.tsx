"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Plus, Edit, Trash2, Scan, X } from "lucide-react"
import { apiClient } from "@/lib/api-client"
import { useWebSocket } from "@/lib/websocket-client"
import { useSelection } from "@/lib/selection-context"
import { useAuth } from "@/lib/auth-context"

interface FleetTableProps {
  locale: "en" | "ar"
}

interface Vehicle {
  id: number
  model: string
  manufacture_date: string
  plate_number: string
  base_number: string
  card_number: string
  issue_date: string
  expiry_date: string
  status: "active" | "inactive" | "expired"
}

export default function FleetTable({ locale }: FleetTableProps) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedId, setSelectedId] = useState<number | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null)
  const [formData, setFormData] = useState({
    model: "",
    manufacture_date: "",
    plate_number: "",
    base_number: "",
    card_number: "",
    issue_date: "",
    expiry_date: "",
    status: "active" as "active" | "inactive" | "expired",
  })

  const { isSelectionMode, toggleSelectionMode, selectedItems, toggleItem, selectAll, clearSelection, isSelected } =
    useSelection()
  const { hasPermission } = useAuth()

  const t = {
    en: {
      title: "Fleet Management",
      add: "Add",
      edit: "Edit",
      delete: "Delete",
      number: "Number",
      model: "Model",
      manufactureDate: "Manufacturing Date",
      plateNumber: "License Plate",
      baseNumber: "Base Number",
      cardNumber: "Card Number",
      issueDate: "Issue Date",
      expiryDate: "Expiry Date",
      status: "Status",
      active: "Active",
      inactive: "Inactive",
      expired: "Expired",
      loading: "Loading...",
      error: "Error loading data",
      scan: "Scan",
      selectAll: "Select All",
      selected: "selected",
      deleteSelected: "Delete Selected",
      selectionModeActive: "Selection mode active - Select items to delete",
    },
    ar: {
      title: "إدارة الأسطول",
      add: "إضافة",
      edit: "تعديل",
      delete: "حذف",
      number: "الرقم",
      model: "الموديل",
      manufactureDate: "تاريخ الصنع",
      plateNumber: "اللوحة المعدنية",
      baseNumber: "رقم القاعدة",
      cardNumber: "رقم الكرت",
      issueDate: "تاريخ الإصدار",
      expiryDate: "تاريخ الانتهاء",
      status: "الحالة",
      active: "نشط",
      inactive: "غير نشط",
      expired: "منتهي",
      loading: "جاري التحميل...",
      error: "خطأ في تحميل البيانات",
      scan: "مسح",
      selectAll: "تحديد الكل",
      selected: "محدد",
      deleteSelected: "حذف المحدد",
      selectionModeActive: "وضع التحديد نشط - حدد العناصر للحذف",
    },
  }

  const modalRef = useRef<HTMLDivElement>(null)
  const previousFocusRef = useRef<HTMLElement | null>(null)
  const firstInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    fetchVehicles()
  }, [])

  useWebSocket((message) => {
    if (message.type === "vehicle_update") {
      fetchVehicles()
    }
  })

  const fetchVehicles = async () => {
    try {
      setLoading(true)
      const data = await apiClient.getVehicles()
      setVehicles(data)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch vehicles")
      console.error("[v0] Error fetching vehicles:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    const itemsToDelete = isSelectionMode ? Array.from(selectedItems) : selectedId ? [selectedId] : []

    if (itemsToDelete.length === 0) {
      alert(locale === "en" ? "Please select items to delete" : "الرجاء تحديد عناصر للحذف")
      return
    }

    if (!confirm(locale === "en" ? `Delete ${itemsToDelete.length} item(s)?` : `حذف ${itemsToDelete.length} عنصر؟`)) {
      return
    }

    try {
      for (const id of itemsToDelete) {
        await apiClient.deleteVehicle(id)
      }
      setSelectedId(null)
      clearSelection()
      fetchVehicles()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete items" : "فشل حذف العناصر")
      console.error("[v0] Error deleting vehicles:", err)
    }
  }

  const handleRowClick = (id: number) => {
    if (isSelectionMode) {
      toggleItem(id)
    } else {
      setSelectedId(id)
    }
  }

  const handleSelectAll = () => {
    selectAll(vehicles.map((v) => v.id))
  }

  const handleAddVehicle = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiClient.createVehicle(formData)
      setShowAddModal(false)
      setFormData({
        model: "",
        manufacture_date: "",
        plate_number: "",
        base_number: "",
        card_number: "",
        issue_date: "",
        expiry_date: "",
        status: "active",
      })
      fetchVehicles()
    } catch (err) {
      alert(locale === "en" ? "Failed to add vehicle" : "فشل إضافة المركبة")
      console.error("[v0] Error adding vehicle:", err)
    }
  }

  const handleEditClick = () => {
    if (!selectedId) return
    const vehicle = vehicles.find((v) => v.id === selectedId)
    if (vehicle) {
      setEditingVehicle(vehicle)
      setFormData({
        model: vehicle.model,
        manufacture_date: vehicle.manufacture_date,
        plate_number: vehicle.plate_number,
        base_number: vehicle.base_number,
        card_number: vehicle.card_number,
        issue_date: vehicle.issue_date,
        expiry_date: vehicle.expiry_date,
        status: vehicle.status,
      })
      setShowEditModal(true)
    }
  }

  const handleEditVehicle = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingVehicle) return

    try {
      await apiClient.updateVehicle(editingVehicle.id, formData)
      setShowEditModal(false)
      setEditingVehicle(null)
      setFormData({
        model: "",
        manufacture_date: "",
        plate_number: "",
        base_number: "",
        card_number: "",
        issue_date: "",
        expiry_date: "",
        status: "active",
      })
      fetchVehicles()
    } catch (err) {
      alert(locale === "en" ? "Failed to update vehicle" : "فشل تحديث المركبة")
      console.error("[v0] Error updating vehicle:", err)
    }
  }

  useEffect(() => {
    if (showAddModal || showEditModal) {
      previousFocusRef.current = document.activeElement as HTMLElement
      document.body.style.overflow = "hidden"
      setTimeout(() => {
        firstInputRef.current?.focus()
      }, 100)
    } else {
      document.body.style.overflow = ""
      previousFocusRef.current?.focus()
    }

    return () => {
      document.body.style.overflow = ""
    }
  }, [showAddModal, showEditModal])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (showAddModal) setShowAddModal(false)
        if (showEditModal) setShowEditModal(false)
      }
    }

    document.addEventListener("keydown", handleEscape)
    return () => document.removeEventListener("keydown", handleEscape)
  }, [showAddModal, showEditModal])

  const handleBackdropClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === e.currentTarget) {
      if (showAddModal) setShowAddModal(false)
      if (showEditModal) setShowEditModal(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-red-600">
          {t[locale].error}: {error}
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="flex flex-wrap gap-2 md:gap-3">
        {hasPermission("vehicles.delete") && (
          <button
            onClick={toggleSelectionMode}
            className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
              isSelectionMode
                ? "bg-purple-600 hover:bg-purple-700 text-white"
                : "bg-purple-500 hover:bg-purple-600 text-white"
            }`}
          >
            <Scan className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].scan}
          </button>
        )}

        {!isSelectionMode && (
          <>
            <button
              onClick={() => setShowAddModal(true)}
              aria-label={locale === "en" ? "Add new vehicle" : "إضافة مركبة جديدة"}
              className="flex items-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
            >
              <Plus className="w-4 h-4 md:w-5 md:h-5" aria-hidden="true" />
              <span>{t[locale].add}</span>
            </button>
            <button
              onClick={handleEditClick}
              disabled={!selectedId}
              aria-label={locale === "en" ? "Edit selected vehicle" : "تعديل المركبة المحددة"}
              className="flex items-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Edit className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].edit}
            </button>
            <button
              onClick={handleDelete}
              disabled={!selectedId}
              className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
            >
              <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].delete}
            </button>
          </>
        )}

        {isSelectionMode && selectedItems.size > 0 && (
          <button
            onClick={handleDelete}
            className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
          >
            <Trash2 className="w-4 h-4 md:w-5 md:h-5" />
            {t[locale].deleteSelected}
          </button>
        )}
      </div>

      {showAddModal && (
        <div
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={handleBackdropClick}
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
        >
          <div
            ref={modalRef}
            className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between z-10">
              <h2 id="modal-title" className="text-xl font-bold text-slate-800">
                {locale === "en" ? "Add New Vehicle" : "إضافة مركبة جديدة"}
              </h2>
              <button
                onClick={() => setShowAddModal(false)}
                aria-label={locale === "en" ? "Close dialog" : "إغلاق"}
                className="text-slate-400 hover:text-slate-600 focus:text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-500 rounded-lg p-1 transition-colors"
              >
                <X className="w-6 h-6" aria-hidden="true" />
              </button>
            </div>

            <form onSubmit={handleAddVehicle} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="model" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].model}
                  </label>
                  <input
                    id="model"
                    type="text"
                    required
                    ref={firstInputRef}
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="manufacture_date" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].manufactureDate}
                  </label>
                  <input
                    id="manufacture_date"
                    type="date"
                    required
                    value={formData.manufacture_date}
                    onChange={(e) => setFormData({ ...formData, manufacture_date: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="plate_number" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].plateNumber}
                  </label>
                  <input
                    id="plate_number"
                    type="text"
                    required
                    value={formData.plate_number}
                    onChange={(e) => setFormData({ ...formData, plate_number: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="base_number" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].baseNumber}
                  </label>
                  <input
                    id="base_number"
                    type="text"
                    required
                    value={formData.base_number}
                    onChange={(e) => setFormData({ ...formData, base_number: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="card_number" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].cardNumber}
                  </label>
                  <input
                    id="card_number"
                    type="text"
                    required
                    value={formData.card_number}
                    onChange={(e) => setFormData({ ...formData, card_number: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="issue_date" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].issueDate}
                  </label>
                  <input
                    id="issue_date"
                    type="date"
                    required
                    value={formData.issue_date}
                    onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="expiry_date" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].expiryDate}
                  </label>
                  <input
                    id="expiry_date"
                    type="date"
                    required
                    value={formData.expiry_date}
                    onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="status" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].status}
                  </label>
                  <select
                    id="status"
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as "active" | "inactive" | "expired" })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                  >
                    <option value="active">{t[locale].active}</option>
                    <option value="inactive">{t[locale].inactive}</option>
                    <option value="expired">{t[locale].expired}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-green-500 hover:bg-green-600 focus:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 text-white rounded-lg transition-colors font-medium min-h-[44px]"
                >
                  {locale === "en" ? "Add Vehicle" : "إضافة المركبة"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-3 bg-slate-200 hover:bg-slate-300 focus:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 text-slate-700 rounded-lg transition-colors font-medium min-h-[44px]"
                >
                  {locale === "en" ? "Cancel" : "إلغاء"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && editingVehicle && (
        <div
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={handleBackdropClick}
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-modal-title"
        >
          <div
            ref={modalRef}
            className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between z-10">
              <h2 id="edit-modal-title" className="text-xl font-bold text-slate-800">
                {locale === "en" ? "Edit Vehicle" : "تعديل المركبة"}
              </h2>
              <button
                onClick={() => setShowEditModal(false)}
                aria-label={locale === "en" ? "Close dialog" : "إغلاق"}
                className="text-slate-400 hover:text-slate-600 focus:text-slate-600 focus:outline-none focus:ring-2 focus:ring-slate-500 rounded-lg p-1 transition-colors"
              >
                <X className="w-6 h-6" aria-hidden="true" />
              </button>
            </div>

            <form onSubmit={handleEditVehicle} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="edit-model" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].model}
                  </label>
                  <input
                    id="edit-model"
                    type="text"
                    required
                    ref={firstInputRef}
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-manufacture_date" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].manufactureDate}
                  </label>
                  <input
                    id="edit-manufacture_date"
                    type="date"
                    required
                    value={formData.manufacture_date}
                    onChange={(e) => setFormData({ ...formData, manufacture_date: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-plate_number" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].plateNumber}
                  </label>
                  <input
                    id="edit-plate_number"
                    type="text"
                    required
                    value={formData.plate_number}
                    onChange={(e) => setFormData({ ...formData, plate_number: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-base_number" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].baseNumber}
                  </label>
                  <input
                    id="edit-base_number"
                    type="text"
                    required
                    value={formData.base_number}
                    onChange={(e) => setFormData({ ...formData, base_number: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-card_number" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].cardNumber}
                  </label>
                  <input
                    id="edit-card_number"
                    type="text"
                    required
                    value={formData.card_number}
                    onChange={(e) => setFormData({ ...formData, card_number: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-issue_date" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].issueDate}
                  </label>
                  <input
                    id="edit-issue_date"
                    type="date"
                    required
                    value={formData.issue_date}
                    onChange={(e) => setFormData({ ...formData, issue_date: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-expiry_date" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].expiryDate}
                  </label>
                  <input
                    id="edit-expiry_date"
                    type="date"
                    required
                    value={formData.expiry_date}
                    onChange={(e) => setFormData({ ...formData, expiry_date: e.target.value })}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                    aria-required="true"
                  />
                </div>

                <div>
                  <label htmlFor="edit-status" className="block text-sm font-medium text-slate-700 mb-2">
                    {t[locale].status}
                  </label>
                  <select
                    id="edit-status"
                    value={formData.status}
                    onChange={(e) =>
                      setFormData({ ...formData, status: e.target.value as "active" | "inactive" | "expired" })
                    }
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-shadow"
                  >
                    <option value="active">{t[locale].active}</option>
                    <option value="inactive">{t[locale].inactive}</option>
                    <option value="expired">{t[locale].expired}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="submit"
                  className="flex-1 px-4 py-3 bg-blue-500 hover:bg-blue-600 focus:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 text-white rounded-lg transition-colors font-medium min-h-[44px]"
                >
                  {locale === "en" ? "Update Vehicle" : "تحديث المركبة"}
                </button>
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-3 bg-slate-200 hover:bg-slate-300 focus:bg-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-500 focus:ring-offset-2 text-slate-700 rounded-lg transition-colors font-medium min-h-[44px]"
                >
                  {locale === "en" ? "Cancel" : "إلغاء"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1200px]">
            <thead className="bg-slate-100 border-b border-slate-200">
              <tr>
                {isSelectionMode && (
                  <th className="px-4 py-3 w-12">
                    <input
                      type="checkbox"
                      checked={selectedItems.size === vehicles.length && vehicles.length > 0}
                      onChange={handleSelectAll}
                      className="w-4 h-4 rounded border-slate-300"
                    />
                  </th>
                )}
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].number}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].model}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">
                  {t[locale].manufactureDate}
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].plateNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].baseNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].cardNumber}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].issueDate}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].expiryDate}</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700">{t[locale].status}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {vehicles.map((vehicle) => (
                <tr
                  key={vehicle.id}
                  onClick={() => handleRowClick(vehicle.id)}
                  className={`cursor-pointer transition-colors ${
                    isSelectionMode
                      ? isSelected(vehicle.id)
                        ? "bg-purple-50 border-l-4 border-purple-500"
                        : "hover:bg-slate-50"
                      : selectedId === vehicle.id
                        ? "bg-blue-50"
                        : "hover:bg-slate-50"
                  }`}
                >
                  {isSelectionMode && (
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={isSelected(vehicle.id)}
                        onChange={() => toggleItem(vehicle.id)}
                        className="w-4 h-4 rounded border-slate-300"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </td>
                  )}
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.id}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.model}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.manufacture_date}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.plate_number}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.base_number}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.card_number}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.issue_date}</td>
                  <td className="px-4 py-3 text-sm text-slate-700">{vehicle.expiry_date}</td>
                  <td className="px-4 py-3">
                    {vehicle.status === "active" && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                        {t[locale].active}
                      </span>
                    )}
                    {vehicle.status === "inactive" && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-700">
                        {t[locale].inactive}
                      </span>
                    )}
                    {vehicle.status === "expired" && (
                      <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                        {t[locale].expired}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-6 py-4 border-t border-slate-200">
          <p className="text-sm text-slate-500">© 2025 FleetPro System – All rights reserved</p>
        </div>
      </div>
    </div>
  )
}
