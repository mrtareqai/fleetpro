# دليل نظام Multi-Tenant - FleetPro Management

## نظرة عامة

تم تطوير نظام FleetPro ليدعم نموذج Multi-Tenant (متعدد الشركات)، حيث يمكن لكل شركة أن يكون لها:
- رابط URL فريد خاص بها
- قاعدة بيانات منفصلة (اختياري)
- مستخدمين وبيانات معزولة تماماً
- إعدادات وتخصيصات مستقلة

## البنية المعمارية

### 1. هيكل الروابط (URL Structure)

\`\`\`
https://yourdomain.com/[company_code]/...
\`\`\`

**أمثلة:**
- `https://fleetpro.com/demo/dashboard` - لوحة تحكم شركة Demo
- `https://fleetpro.com/acme/login` - صفحة تسجيل دخول شركة ACME
- `https://fleetpro.com/master-admin` - لوحة تحكم المدير العام (topowner)

### 2. لوحة تحكم المدير العام (Top Owner Dashboard)

**الوصول:**
- الرابط: `/master-admin`
- اسم المستخدم: `topowner`
- كلمة المرور: `mrtareq2008`

**الصلاحيات:**
- إضافة شركات جديدة
- تعديل معلومات الشركات
- تفعيل/تعطيل الشركات
- حذف الشركات
- عرض جميع الشركات المسجلة

### 3. إضافة شركة جديدة

عند إضافة شركة جديدة من لوحة تحكم topowner، يتم إدخال:

**معلومات أساسية:**
- `name`: اسم الشركة
- `url_code`: الرمز الفريد للشركة (يستخدم في الرابط)
- `owner_name`: اسم مالك الشركة
- `contact_number`: رقم الاتصال
- `email`: البريد الإلكتروني

**معلومات تقنية:**
- `neon_url`: رابط قاعدة بيانات Neon المخصصة للشركة (اختياري)
- `github_api_key`: مفتاح GitHub API (اختياري)
- `admin_username`: اسم مستخدم المدير الأول للشركة
- `admin_password`: كلمة مرور المدير الأول

**مثال:**
\`\`\`json
{
  "name": "شركة النقل السريع",
  "url_code": "fast-transport",
  "owner_name": "أحمد محمد",
  "contact_number": "+966501234567",
  "email": "info@fasttransport.com",
  "neon_url": "postgresql://user:pass@ep-xxx.neon.tech/fasttransport",
  "admin_username": "admin",
  "admin_password": "secure_password_123"
}
\`\`\`

### 4. تسجيل الدخول للشركة

بعد إنشاء الشركة، يمكن للمستخدمين الوصول إليها عبر:

\`\`\`
https://yourdomain.com/[url_code]/login
\`\`\`

**مثال:**
\`\`\`
https://fleetpro.com/fast-transport/login
\`\`\`

سيتم عرض:
- اسم الشركة
- نموذج تسجيل دخول مخصص
- رمز الشركة

### 5. عزل البيانات (Data Isolation)

#### الطريقة الأولى: قاعدة بيانات مشتركة مع company_id
- جميع الجداول تحتوي على حقل `company_id`
- يتم فلترة البيانات تلقائياً حسب الشركة
- أسهل في الإدارة والصيانة

#### الطريقة الثانية: قواعد بيانات منفصلة
- كل شركة لها قاعدة بيانات Neon مستقلة
- عزل كامل للبيانات
- أمان أعلى
- يتطلب إدارة أكثر تعقيداً

### 6. الملفات الرئيسية

#### Middleware
\`\`\`typescript
// middleware.ts
// يستخرج company_code من الرابط ويضيفه للـ headers
\`\`\`

#### Company Context
\`\`\`typescript
// lib/company-context.tsx
// يوفر معلومات الشركة الحالية لجميع المكونات
\`\`\`

#### Database Connection Manager
\`\`\`typescript
// lib/db-connection-manager.ts
// يدير الاتصالات بقواعد البيانات المختلفة
\`\`\`

#### Company Login Page
\`\`\`typescript
// app/[company]/login/page.tsx
// صفحة تسجيل دخول مخصصة لكل شركة
\`\`\`

### 7. استخدام Company Context في المكونات

\`\`\`typescript
import { useCompany } from "@/lib/company-context"

function MyComponent() {
  const { company, companyCode, loading } = useCompany()
  
  if (loading) return <div>Loading...</div>
  
  return (
    <div>
      <h1>{company?.name}</h1>
      <p>Company Code: {companyCode}</p>
    </div>
  )
}
\`\`\`

### 8. API Routes مع Multi-Tenant

\`\`\`typescript
// في API routes
import { getCompanySQL } from "@/lib/db-connection-manager"

export async function GET(request: NextRequest) {
  const companyCode = request.headers.get("x-company-code")
  const sql = getCompanySQL(companyCode)
  
  // استخدام sql للاستعلامات
  const data = await sql`SELECT * FROM vehicles WHERE company_id = ${companyId}`
  
  return NextResponse.json(data)
}
\`\`\`

### 9. الأمان (Security)

**التحقق من الشركة:**
- يتم التحقق من أن الشركة نشطة (`is_active = true`)
- يتم التحقق من صلاحيات المستخدم للوصول للشركة
- عزل كامل بين بيانات الشركات المختلفة

**JWT Tokens:**
- يحتوي التوكن على `companyId` و `companyCode`
- يتم التحقق من التوكن في كل طلب API
- لا يمكن للمستخدم الوصول لبيانات شركة أخرى

### 10. سيناريو كامل

**1. المدير العام يضيف شركة جديدة:**
\`\`\`
1. يسجل دخول على /master-admin
2. يضغط "Add Company"
3. يدخل معلومات الشركة
4. يحفظ - يتم إنشاء الشركة في قاعدة البيانات
\`\`\`

**2. مدير الشركة يسجل دخول:**
\`\`\`
1. يذهب إلى /fast-transport/login
2. يدخل admin_username و admin_password
3. يتم توجيهه إلى /fast-transport/dashboard
4. يرى فقط بيانات شركته
\`\`\`

**3. إضافة مستخدمين جدد:**
\`\`\`
1. المدير يذهب إلى /fast-transport/admin/users
2. يضيف مستخدمين جدد
3. يتم ربطهم تلقائياً بـ company_id الخاص بالشركة
\`\`\`

### 11. قاعدة البيانات

**جدول companies:**
\`\`\`sql
CREATE TABLE companies (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  url_code VARCHAR(100) UNIQUE NOT NULL,
  owner_name VARCHAR(255) NOT NULL,
  contact_number VARCHAR(50),
  email VARCHAR(255) NOT NULL,
  neon_url TEXT,
  github_api_key TEXT,
  admin_username VARCHAR(100) NOT NULL,
  admin_password VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);
\`\`\`

**الجداول الأخرى:**
\`\`\`sql
-- جميع الجداول تحتوي على company_id
ALTER TABLE users ADD COLUMN company_id INTEGER REFERENCES companies(id);
ALTER TABLE vehicles ADD COLUMN company_id INTEGER REFERENCES companies(id);
ALTER TABLE drivers ADD COLUMN company_id INTEGER REFERENCES companies(id);
-- ... إلخ
\`\`\`

### 12. الخطوات التالية للتطوير

**مطلوب للإنتاج:**
1. ✅ إنشاء جدول companies في قاعدة البيانات
2. ✅ إضافة company_id لجميع الجداول
3. ✅ تحديث جميع API routes لدعم company_id
4. ✅ إنشاء صفحات تسجيل دخول مخصصة
5. ⚠️ إضافة نظام إنشاء قواعد بيانات تلقائياً (إذا كنت تستخدم قواعد منفصلة)
6. ⚠️ إضافة نظام نسخ احتياطي لكل شركة
7. ⚠️ إضافة تقارير استخدام لكل شركة

**تحسينات مستقبلية:**
- نظام فواتير لكل شركة
- تخصيص الألوان والشعار لكل شركة
- نظام إشعارات مخصص
- تقارير متقدمة لكل شركة
- API خارجي لكل شركة

## الخلاصة

النظام الآن يدعم Multi-Tenant بشكل كامل مع:
- ✅ لوحة تحكم topowner
- ✅ إضافة وإدارة الشركات
- ✅ روابط فريدة لكل شركة
- ✅ عزل البيانات
- ✅ تسجيل دخول مخصص
- ✅ دعم قواعد بيانات منفصلة (اختياري)

للبدء، قم بتسجيل الدخول على `/master-admin` باستخدام:
- Username: `topowner`
- Password: `mrtareq2008`
