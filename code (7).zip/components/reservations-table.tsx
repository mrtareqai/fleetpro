"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Plus, Edit, Trash2, ArrowUpDown, X, Scan } from "lucide-react"
import { apiClient } from "@/lib/api-client"
import { useWebSocket } from "@/lib/websocket-client"
import PermissionGate from "@/components/permission-gate"
import { useSelection } from "@/lib/selection-context"
import { useAuth } from "@/lib/auth-context"

interface ReservationsTableProps {
  locale: "en" | "ar"
}

interface Reservation {
  id: number
  vehicle_id: number
  driver_id: number
  customer_name: string
  pickup_date: string
  return_date: string
  destination: string
  status: string
}

export default function ReservationsTable({ locale }: ReservationsTableProps) {
  const [reservations, setReservations] = useState<Reservation[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedIds, setSelectedIds] = useState<number[]>([])
  const [error, setError] = useState<string | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingReservation, setEditingReservation] = useState<Reservation | null>(null)
  const [formData, setFormData] = useState({
    vehicle_id: "",
    driver_id: "",
    customer_name: "",
    pickup_date: "",
    return_date: "",
    destination: "",
    status: "pending",
  })

  const { isSelectionMode, toggleSelectionMode, selectedItems, toggleItem, selectAll, clearSelection } = useSelection()
  const { hasPermission } = useAuth()

  const t = {
    en: {
      title: "Reservations Management Screen",
      addReservation: "Add Reservation",
      edit: "Edit",
      delete: "Delete",
      id: "ID",
      vehicle: "Vehicle",
      driver: "Driver",
      customer: "Customer",
      pickupDate: "Pickup Date",
      returnDate: "Return Date",
      destination: "Destination",
      status: "Status",
      confirmed: "Confirmed",
      pending: "Pending",
      cancelled: "Cancelled",
      loading: "Loading...",
      error: "Error loading data",
      addNewReservation: "Add New Reservation",
      cancel: "Cancel",
      save: "Save",
      vehicleId: "Vehicle ID",
      driverId: "Driver ID",
      scan: "Scan",
      selectAll: "Select All",
      selected: "selected",
      deleteSelected: "Delete Selected",
      selectionModeActive: "Selection mode active - Select items to delete",
    },
    ar: {
      title: "شاشة إدارة الحجوزات",
      addReservation: "إضافة حجز",
      edit: "تعديل",
      delete: "حذف",
      id: "المعرف",
      vehicle: "المركبة",
      driver: "السائق",
      customer: "العميل",
      pickupDate: "تاريخ الاستلام",
      returnDate: "تاريخ الإرجاع",
      destination: "الوجهة",
      status: "الحالة",
      confirmed: "مؤكد",
      pending: "قيد الانتظار",
      cancelled: "ملغى",
      loading: "جاري التحميل...",
      error: "خطأ في تحميل البيانات",
      addNewReservation: "إضافة حجز جديد",
      cancel: "إلغاء",
      save: "حفظ",
      vehicleId: "رقم المركبة",
      driverId: "رقم السائق",
      scan: "مسح",
      selectAll: "تحديد الكل",
      selected: "محدد",
      deleteSelected: "حذف المحدد",
      selectionModeActive: "وضع التحديد نشط - حدد العناصر للحذف",
    },
  }

  useEffect(() => {
    fetchReservations()
  }, [])

  useWebSocket((message) => {
    if (message.type === "reservation_update") {
      fetchReservations()
    }
  })

  const fetchReservations = async () => {
    try {
      setLoading(true)
      const data = await apiClient.getReservations()
      setReservations(data)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch reservations")
      console.error("[v0] Error fetching reservations:", err)
    } finally {
      setLoading(false)
    }
  }

  const localToggleSelection = (id: number) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((selectedId) => selectedId !== id) : [...prev, id]))
  }

  const handleDelete = async () => {
    const itemsToDelete = isSelectionMode ? Array.from(selectedItems) : selectedIds

    if (itemsToDelete.length === 0) {
      alert(locale === "en" ? "Please select items to delete" : "الرجاء تحديد عناصر للحذف")
      return
    }

    if (!confirm(locale === "en" ? `Delete ${itemsToDelete.length} item(s)?` : `حذف ${itemsToDelete.length} عنصر؟`)) {
      return
    }

    try {
      for (const id of itemsToDelete) {
        await apiClient.updateReservation(id, { status: "cancelled" })
      }
      setSelectedIds([])
      clearSelection()
      fetchReservations()
    } catch (err) {
      alert(locale === "en" ? "Failed to delete items" : "فشل حذف العناصر")
      console.error("[v0] Error deleting reservations:", err)
    }
  }

  const handleRowClick = (id: number) => {
    if (isSelectionMode) {
      toggleItem(id)
    } else {
      localToggleSelection(id)
    }
  }

  const handleSelectAll = () => {
    if (isSelectionMode) {
      selectAll(reservations.map((r) => r.id))
    } else {
      // Toggle: if all selected, clear; otherwise select all
      if (selectedIds.length === reservations.length) {
        setSelectedIds([])
      } else {
        setSelectedIds(reservations.map((r) => r.id))
      }
    }
  }

  const handleAddReservation = async (e: React.FormEvent) => {
    e.preventDefault()
    try {
      await apiClient.createReservation({
        vehicle_id: Number.parseInt(formData.vehicle_id),
        driver_id: Number.parseInt(formData.driver_id),
        customer_name: formData.customer_name,
        pickup_date: formData.pickup_date,
        return_date: formData.return_date,
        destination: formData.destination,
        status: formData.status,
      })
      setShowAddModal(false)
      setFormData({
        vehicle_id: "",
        driver_id: "",
        customer_name: "",
        pickup_date: "",
        return_date: "",
        destination: "",
        status: "pending",
      })
      fetchReservations()
    } catch (err) {
      alert(locale === "en" ? "Failed to add reservation" : "فشل إضافة الحجز")
      console.error("[v0] Error adding reservation:", err)
    }
  }

  const handleEdit = () => {
    if (selectedIds.length !== 1) return

    const reservation = reservations.find((r) => r.id === selectedIds[0])
    if (!reservation) return

    setEditingReservation(reservation)

    // Convert all values to strings, handling null/undefined cases
    const pickupDate = reservation.pickup_date
      ? reservation.pickup_date.includes("T")
        ? reservation.pickup_date.split("T")[0]
        : reservation.pickup_date
      : ""

    const returnDate = reservation.return_date
      ? reservation.return_date.includes("T")
        ? reservation.return_date.split("T")[0]
        : reservation.return_date
      : ""

    setFormData({
      vehicle_id: String(reservation.vehicle_id || ""),
      driver_id: String(reservation.driver_id || ""),
      customer_name: reservation.customer_name || "",
      pickup_date: pickupDate,
      return_date: returnDate,
      destination: reservation.destination || "",
      status: reservation.status || "pending",
    })
    setShowEditModal(true)
  }

  const handleUpdateReservation = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!editingReservation) return

    try {
      await apiClient.updateReservation(editingReservation.id, {
        vehicle_id: Number.parseInt(formData.vehicle_id),
        driver_id: Number.parseInt(formData.driver_id),
        customer_name: formData.customer_name,
        pickup_date: formData.pickup_date,
        return_date: formData.return_date,
        destination: formData.destination,
        status: formData.status,
      })
      setShowEditModal(false)
      setEditingReservation(null)
      setSelectedIds([])
      fetchReservations()
    } catch (err) {
      alert(locale === "en" ? "Failed to update reservation" : "فشل تحديث الحجز")
      console.error("[v0] Error updating reservation:", err)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-slate-600">{t[locale].loading}</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-lg text-red-600">
          {t[locale].error}: {error}
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-4 md:space-y-6">
      <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>

      <div className="sticky top-0 lg:top-auto z-20 bg-slate-100 -mx-4 px-4 py-3 md:mx-0 md:px-0 md:py-0 md:bg-transparent">
        <div className="flex flex-wrap gap-2 md:gap-3">
          <PermissionGate permission="reservations.delete">
            <button
              onClick={toggleSelectionMode}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px] ${
                isSelectionMode
                  ? "bg-purple-600 hover:bg-purple-700 text-white"
                  : "bg-purple-500 hover:bg-purple-600 text-white"
              }`}
            >
              <Scan className="w-4 h-4 md:w-5 md:h-5" />
              {t[locale].scan}
            </button>
          </PermissionGate>

          {!isSelectionMode && (
            <>
              <PermissionGate permission="reservations.create">
                <button
                  onClick={() => setShowAddModal(true)}
                  className="flex items-center gap-2 px-4 py-3 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
                >
                  <Plus className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  <span className="hidden sm:inline">{t[locale].addReservation}</span>
                  <span className="sm:hidden">Add</span>
                </button>
              </PermissionGate>
              <PermissionGate permission="reservations.update">
                <button
                  onClick={handleEdit}
                  disabled={selectedIds.length !== 1}
                  className="flex items-center gap-2 px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
                >
                  <Edit className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  {t[locale].edit}
                </button>
              </PermissionGate>
              <PermissionGate permission="reservations.delete">
                <button
                  onClick={handleDelete}
                  disabled={selectedIds.length === 0}
                  className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm disabled:opacity-50 disabled:cursor-not-allowed min-h-[44px]"
                >
                  <Trash2 className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                  {t[locale].delete}
                </button>
              </PermissionGate>
            </>
          )}

          {isSelectionMode && selectedItems.size > 0 && (
            <PermissionGate permission="reservations.delete">
              <button
                onClick={handleDelete}
                className="flex items-center gap-2 px-4 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors text-sm md:text-base font-medium shadow-sm min-h-[44px]"
              >
                <Trash2 className="w-4 h-4 md:w-5 md:h-5 flex-shrink-0" />
                {t[locale].deleteSelected}
              </button>
            </PermissionGate>
          )}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm overflow-hidden -mx-4 md:mx-0">
        <div className="overflow-x-auto overscroll-x-contain">
          <table className="w-full min-w-[640px]">
            <thead className="bg-slate-100 border-b border-slate-200">
              <tr>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left">
                  <input
                    type="checkbox"
                    checked={
                      isSelectionMode
                        ? selectedItems.size === reservations.length && reservations.length > 0
                        : selectedIds.length === reservations.length && reservations.length > 0
                    }
                    onChange={handleSelectAll}
                    className="rounded"
                  />
                </th>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold text-slate-700">
                  <div className="flex items-center gap-2">
                    {t[locale].id}
                    <ArrowUpDown className="w-3 h-3 md:w-4 md:h-4" />
                  </div>
                </th>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold text-slate-700">
                  {t[locale].customer}
                </th>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold text-slate-700">
                  <div className="flex items-center gap-2">
                    {t[locale].pickupDate}
                    <ArrowUpDown className="w-3 h-3 md:w-4 md:h-4" />
                  </div>
                </th>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold text-slate-700">
                  <div className="flex items-center gap-2">
                    {t[locale].returnDate}
                    <ArrowUpDown className="w-3 h-3 md:w-4 md:h-4" />
                  </div>
                </th>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold text-slate-700">
                  {t[locale].destination}
                </th>
                <th className="px-3 md:px-6 py-3 md:py-4 text-left text-xs md:text-sm font-semibold text-slate-700">
                  {t[locale].status}
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {reservations.map((reservation) => (
                <tr
                  key={reservation.id}
                  onClick={() => handleRowClick(reservation.id)}
                  className={`cursor-pointer transition-colors ${
                    isSelectionMode
                      ? selectedItems.has(reservation.id)
                        ? "bg-purple-50 border-l-4 border-purple-500"
                        : "hover:bg-slate-50"
                      : "hover:bg-slate-50"
                  }`}
                >
                  <td className="px-3 md:px-6 py-3 md:py-4">
                    <input
                      type="checkbox"
                      checked={
                        isSelectionMode ? selectedItems.has(reservation.id) : selectedIds.includes(reservation.id)
                      }
                      onChange={() =>
                        isSelectionMode ? toggleItem(reservation.id) : localToggleSelection(reservation.id)
                      }
                      className="rounded"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </td>
                  <td className="px-3 md:px-6 py-3 md:py-4 text-xs md:text-sm text-slate-700">{reservation.id}</td>
                  <td className="px-3 md:px-6 py-3 md:py-4 text-xs md:text-sm text-slate-700">
                    {reservation.customer_name}
                  </td>
                  <td className="px-3 md:px-6 py-3 md:py-4 text-xs md:text-sm text-slate-700">
                    {new Date(reservation.pickup_date).toLocaleDateString()}
                  </td>
                  <td className="px-3 md:px-6 py-3 md:py-4 text-xs md:text-sm text-slate-700">
                    {new Date(reservation.return_date).toLocaleDateString()}
                  </td>
                  <td className="px-3 md:px-6 py-3 md:py-4 text-xs md:text-sm text-slate-700">
                    {reservation.destination}
                  </td>
                  <td className="px-3 md:px-6 py-3 md:py-4">
                    {reservation.status === "confirmed" && (
                      <span className="inline-flex items-center px-2 md:px-3 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-700">
                        ✓ {t[locale].confirmed}
                      </span>
                    )}
                    {reservation.status === "pending" && (
                      <span className="inline-flex items-center px-2 md:px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                        ✓ {t[locale].pending}
                      </span>
                    )}
                    {reservation.status === "cancelled" && (
                      <span className="inline-flex items-center px-2 md:px-3 py-1 rounded-full text-xs font-medium bg-red-100 text-red-700">
                        ✕ {t[locale].cancelled}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 md:px-6 py-3 md:py-4 border-t border-slate-200">
          <p className="text-xs md:text-sm text-slate-500">© 2025 FleetPro System – All rights reserved</p>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-4 md:p-6 border-b border-slate-200">
              <h2 className="text-xl md:text-2xl font-bold text-slate-800">{t[locale].addNewReservation}</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddReservation} className="p-4 md:p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].vehicleId}</label>
                  <input
                    type="number"
                    required
                    value={formData.vehicle_id}
                    onChange={(e) => setFormData({ ...formData, vehicle_id: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].driverId}</label>
                  <input
                    type="number"
                    required
                    value={formData.driver_id}
                    onChange={(e) => setFormData({ ...formData, driver_id: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].customer}</label>
                <input
                  type="text"
                  required
                  value={formData.customer_name}
                  onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].pickupDate}</label>
                  <input
                    type="date"
                    required
                    value={formData.pickup_date}
                    onChange={(e) => setFormData({ ...formData, pickup_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].returnDate}</label>
                  <input
                    type="date"
                    required
                    value={formData.return_date}
                    onChange={(e) => setFormData({ ...formData, return_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].destination}</label>
                <input
                  type="text"
                  required
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  {t[locale].cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded-lg transition-colors"
                >
                  {t[locale].save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {showEditModal && editingReservation && (
        <div
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={() => setShowEditModal(false)}
        >
          <div
            className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between p-4 md:p-6 border-b border-slate-200">
              <h2 className="text-xl md:text-2xl font-bold text-slate-800">
                {locale === "en" ? "Edit Reservation" : "تعديل الحجز"}
              </h2>
              <button
                onClick={() => setShowEditModal(false)}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleUpdateReservation} className="p-4 md:p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].vehicleId}</label>
                  <input
                    type="number"
                    required
                    value={formData.vehicle_id}
                    onChange={(e) => setFormData({ ...formData, vehicle_id: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].driverId}</label>
                  <input
                    type="number"
                    required
                    value={formData.driver_id}
                    onChange={(e) => setFormData({ ...formData, driver_id: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].customer}</label>
                <input
                  type="text"
                  required
                  value={formData.customer_name}
                  onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].pickupDate}</label>
                  <input
                    type="date"
                    required
                    value={formData.pickup_date}
                    onChange={(e) => setFormData({ ...formData, pickup_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].returnDate}</label>
                  <input
                    type="date"
                    required
                    value={formData.return_date}
                    onChange={(e) => setFormData({ ...formData, return_date: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].destination}</label>
                <input
                  type="text"
                  required
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">{t[locale].status}</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="pending">{t[locale].pending}</option>
                  <option value="confirmed">{t[locale].confirmed}</option>
                  <option value="cancelled">{t[locale].cancelled}</option>
                </select>
              </div>
              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => setShowEditModal(false)}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  {t[locale].cancel}
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-colors"
                >
                  {t[locale].save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
