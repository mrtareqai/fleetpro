/**
 * Error Logging System
 *
 * Comprehensive logging system for tracking errors, warnings, and info messages
 *
 * Features:
 * - Multiple log levels (ERROR, WARN, INFO, DEBUG)
 * - Structured logging with context
 * - Error tracking with stack traces
 * - Request/response logging
 * - Performance monitoring
 * - Log persistence (console, file, external service)
 *
 * Usage:
 * ```typescript
 * logger.error('Database connection failed', { error, userId: '123' })
 * logger.info('User logged in', { userId: '123', ip: '192.168.1.1' })
 * ```
 */

/**
 * Log levels
 */
export enum LogLevel {
  ERROR = "ERROR",
  WARN = "WARN",
  INFO = "INFO",
  DEBUG = "DEBUG",
}

/**
 * Log entry interface
 */
export interface LogEntry {
  level: LogLevel
  message: string
  timestamp: string
  context?: Record<string, any>
  error?: {
    name: string
    message: string
    stack?: string
  }
  request?: {
    method: string
    url: string
    headers?: Record<string, string>
    body?: any
  }
  response?: {
    status: number
    duration?: number
  }
  user?: {
    id: string
    role: string
  }
}

/**
 * Logger configuration
 */
interface LoggerConfig {
  minLevel: LogLevel
  enableConsole: boolean
  enableFile: boolean
  enableExternal: boolean
  externalEndpoint?: string
}

/**
 * Default logger configuration
 */
const defaultConfig: LoggerConfig = {
  minLevel: process.env.NODE_ENV === "production" ? LogLevel.INFO : LogLevel.DEBUG,
  enableConsole: true,
  enableFile: false,
  enableExternal: false,
}

/**
 * Logger class
 */
class Logger {
  private config: LoggerConfig
  private logs: LogEntry[] = []
  private maxLogsInMemory = 1000

  constructor(config: Partial<LoggerConfig> = {}) {
    this.config = { ...defaultConfig, ...config }
  }

  /**
   * Check if log level should be logged
   */
  private shouldLog(level: LogLevel): boolean {
    const levels = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR]
    const minLevelIndex = levels.indexOf(this.config.minLevel)
    const currentLevelIndex = levels.indexOf(level)
    return currentLevelIndex >= minLevelIndex
  }

  /**
   * Create log entry
   */
  private createLogEntry(level: LogLevel, message: string, context?: Record<string, any>): LogEntry {
    const entry: LogEntry = {
      level,
      message,
      timestamp: new Date().toISOString(),
      context,
    }

    // Extract error information if present
    if (context?.error instanceof Error) {
      entry.error = {
        name: context.error.name,
        message: context.error.message,
        stack: context.error.stack,
      }
      delete context.error
    }

    return entry
  }

  /**
   * Format log entry for console output
   */
  private formatForConsole(entry: LogEntry): string {
    const emoji = {
      [LogLevel.ERROR]: "🔴",
      [LogLevel.WARN]: "🟡",
      [LogLevel.INFO]: "🔵",
      [LogLevel.DEBUG]: "⚪",
    }

    let output = `${emoji[entry.level]} [${entry.level}] ${entry.timestamp} - ${entry.message}`

    if (entry.context && Object.keys(entry.context).length > 0) {
      output += `\n  Context: ${JSON.stringify(entry.context, null, 2)}`
    }

    if (entry.error) {
      output += `\n  Error: ${entry.error.name}: ${entry.error.message}`
      if (entry.error.stack) {
        output += `\n  Stack: ${entry.error.stack}`
      }
    }

    if (entry.request) {
      output += `\n  Request: ${entry.request.method} ${entry.request.url}`
    }

    if (entry.response) {
      output += `\n  Response: ${entry.response.status} (${entry.response.duration}ms)`
    }

    return output
  }

  /**
   * Write log entry
   */
  private async writeLog(entry: LogEntry): Promise<void> {
    // Add to in-memory logs
    this.logs.push(entry)
    if (this.logs.length > this.maxLogsInMemory) {
      this.logs.shift()
    }

    // Console logging
    if (this.config.enableConsole) {
      const formatted = this.formatForConsole(entry)
      switch (entry.level) {
        case LogLevel.ERROR:
          console.error(formatted)
          break
        case LogLevel.WARN:
          console.warn(formatted)
          break
        case LogLevel.INFO:
          console.info(formatted)
          break
        case LogLevel.DEBUG:
          console.debug(formatted)
          break
      }
    }

    // File logging (if enabled)
    if (this.config.enableFile && typeof window === "undefined") {
      // Server-side only
      try {
        const fs = await import("fs/promises")
        const path = await import("path")
        const logDir = path.join(process.cwd(), "logs")
        const logFile = path.join(logDir, `${new Date().toISOString().split("T")[0]}.log`)

        await fs.mkdir(logDir, { recursive: true })
        await fs.appendFile(logFile, JSON.stringify(entry) + "\n")
      } catch (error) {
        console.error("Failed to write log to file:", error)
      }
    }

    // External logging service (if enabled)
    if (this.config.enableExternal && this.config.externalEndpoint) {
      try {
        await fetch(this.config.externalEndpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(entry),
        })
      } catch (error) {
        console.error("Failed to send log to external service:", error)
      }
    }
  }

  /**
   * Log error message
   */
  error(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.ERROR)) return
    const entry = this.createLogEntry(LogLevel.ERROR, message, context)
    this.writeLog(entry)
  }

  /**
   * Log warning message
   */
  warn(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.WARN)) return
    const entry = this.createLogEntry(LogLevel.WARN, message, context)
    this.writeLog(entry)
  }

  /**
   * Log info message
   */
  info(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.INFO)) return
    const entry = this.createLogEntry(LogLevel.INFO, message, context)
    this.writeLog(entry)
  }

  /**
   * Log debug message
   */
  debug(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.DEBUG)) return
    const entry = this.createLogEntry(LogLevel.DEBUG, message, context)
    this.writeLog(entry)
  }

  /**
   * Log API request
   */
  logRequest(request: Request, context?: Record<string, any>): void {
    const entry = this.createLogEntry(LogLevel.INFO, "API Request", {
      ...context,
      request: {
        method: request.method,
        url: request.url,
        headers: Object.fromEntries(request.headers.entries()),
      },
    })
    this.writeLog(entry)
  }

  /**
   * Log API response
   */
  logResponse(request: Request, response: Response, duration: number, context?: Record<string, any>): void {
    const level = response.status >= 500 ? LogLevel.ERROR : response.status >= 400 ? LogLevel.WARN : LogLevel.INFO

    const entry = this.createLogEntry(level, "API Response", {
      ...context,
      request: {
        method: request.method,
        url: request.url,
      },
      response: {
        status: response.status,
        duration,
      },
    })
    this.writeLog(entry)
  }

  /**
   * Get recent logs
   */
  getRecentLogs(count = 100): LogEntry[] {
    return this.logs.slice(-count)
  }

  /**
   * Get logs by level
   */
  getLogsByLevel(level: LogLevel): LogEntry[] {
    return this.logs.filter((log) => log.level === level)
  }

  /**
   * Clear logs from memory
   */
  clearLogs(): void {
    this.logs = []
  }
}

/**
 * Global logger instance
 */
export const logger = new Logger()

/**
 * Create request logger middleware
 */
export function createRequestLogger() {
  return async (request: Request, handler: () => Promise<Response>): Promise<Response> => {
    const startTime = Date.now()

    logger.logRequest(request)

    try {
      const response = await handler()
      const duration = Date.now() - startTime

      logger.logResponse(request, response, duration)

      return response
    } catch (error) {
      const duration = Date.now() - startTime

      logger.error("Request handler error", {
        error,
        request: {
          method: request.method,
          url: request.url,
        },
        duration,
      })

      throw error
    }
  }
}
