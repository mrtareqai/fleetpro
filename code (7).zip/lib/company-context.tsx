"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"
import { usePathname } from "next/navigation"

interface Company {
  id: number
  name: string
  url_code: string
  owner_name: string
  email: string
  neon_url?: string
  is_active: boolean
}

interface CompanyContextType {
  company: Company | null
  companyCode: string | null
  loading: boolean
  setCompany: (company: Company | null) => void
}

const CompanyContext = createContext<CompanyContextType>({
  company: null,
  companyCode: null,
  loading: true,
  setCompany: () => {},
})

export function CompanyProvider({ children }: { children: React.ReactNode }) {
  const [company, setCompany] = useState<Company | null>(null)
  const [companyCode, setCompanyCode] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const pathname = usePathname()

  useEffect(() => {
    const pathParts = pathname.split("/").filter(Boolean)

    if (pathParts.length > 0 && !["login", "master-admin"].includes(pathParts[0])) {
      const code = pathParts[0]
      setCompanyCode(code)

      // Load company info from API or localStorage
      const loadCompany = async () => {
        try {
          // In a real implementation, this would fetch from API
          // For now, we'll use localStorage or mock data
          const storedCompany = localStorage.getItem(`company_${code}`)
          if (storedCompany) {
            setCompany(JSON.parse(storedCompany))
          }
        } catch (error) {
          console.error("Failed to load company:", error)
        } finally {
          setLoading(false)
        }
      }

      loadCompany()
    } else {
      setCompanyCode(null)
      setCompany(null)
      setLoading(false)
    }
  }, [pathname])

  return (
    <CompanyContext.Provider value={{ company, companyCode, loading, setCompany }}>{children}</CompanyContext.Provider>
  )
}

export function useCompany() {
  const context = useContext(CompanyContext)
  if (!context) {
    throw new Error("useCompany must be used within CompanyProvider")
  }
  return context
}
