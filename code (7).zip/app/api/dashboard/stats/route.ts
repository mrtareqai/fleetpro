import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"
import { dashboardRateLimiter, getClientIp } from "@/lib/security/rate-limit"

export async function GET(request: NextRequest) {
  const ip = getClientIp(request)
  const rateLimitResult = await dashboardRateLimiter.check(ip)

  if (!rateLimitResult.success) {
    return NextResponse.json(
      {
        error: "Too many requests",
        retryAfter: rateLimitResult.retryAfter,
      },
      {
        status: 429,
        headers: {
          "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": "0",
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      },
    )
  }

  const authResult = await requirePermission(request, "dashboard.view")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Fetching dashboard stats...")

    if (!sql) {
      return getMockDashboardStats()
    }

    const [vehiclesResult, reservationsResult, driversResult, suppliesResult] = await Promise.all([
      sql`SELECT COUNT(*) as total, 
                 COUNT(*) FILTER (WHERE status = 'active') as active,
                 COUNT(*) FILTER (WHERE status = 'maintenance') as maintenance,
                 COUNT(*) FILTER (WHERE status = 'inactive') as inactive
          FROM vehicles`,

      sql`SELECT COUNT(*) as total,
                 COUNT(*) FILTER (WHERE status = 'confirmed' AND start_date <= CURRENT_DATE AND end_date >= CURRENT_DATE) as active,
                 COUNT(*) FILTER (WHERE status = 'confirmed' AND start_date > CURRENT_DATE) as upcoming,
                 COUNT(*) FILTER (WHERE status = 'pending') as pending
          FROM reservations`,

      sql`SELECT COUNT(*) as total,
                 COUNT(*) FILTER (WHERE status = 'active') as active,
                 COUNT(*) FILTER (WHERE status = 'on_leave') as on_leave
          FROM drivers`,

      sql`SELECT COUNT(*) as total,
                 COUNT(*) FILTER (WHERE priority = 'urgent' AND status = 'pending') as urgent
          FROM supplies`,
    ])

    const stats = {
      vehicles: {
        total: Number(vehiclesResult[0]?.total || 0),
        active: Number(vehiclesResult[0]?.active || 0),
        maintenance: Number(vehiclesResult[0]?.maintenance || 0),
        inactive: Number(vehiclesResult[0]?.inactive || 0),
      },
      reservations: {
        total: Number(reservationsResult[0]?.total || 0),
        active: Number(reservationsResult[0]?.active || 0),
        upcoming: Number(reservationsResult[0]?.upcoming || 0),
        pending: Number(reservationsResult[0]?.pending || 0),
      },
      drivers: {
        total: Number(driversResult[0]?.total || 0),
        active: Number(driversResult[0]?.active || 0),
        on_leave: Number(driversResult[0]?.on_leave || 0),
      },
      supplies: {
        total: Number(suppliesResult[0]?.total || 0),
        urgent: Number(suppliesResult[0]?.urgent || 0),
      },
      total_vehicles: Number(vehiclesResult[0]?.total || 0),
      active_reservations: Number(reservationsResult[0]?.active || 0),
      upcoming_reservations: Number(reservationsResult[0]?.upcoming || 0),
    }

    console.log("[v0] Dashboard stats fetched successfully")

    const response = NextResponse.json(stats, {
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
      },
    })

    response.headers.set("X-RateLimit-Limit", rateLimitResult.limit.toString())
    response.headers.set("X-RateLimit-Remaining", rateLimitResult.remaining.toString())
    response.headers.set("X-RateLimit-Reset", new Date(rateLimitResult.reset).toISOString())

    return response
  } catch (error) {
    console.error("[v0] Error fetching dashboard stats:", error)
    return NextResponse.json({ error: "Failed to fetch dashboard stats" }, { status: 500 })
  }
}

function getMockDashboardStats() {
  console.log("[v0] Using mock dashboard stats")

  const stats = {
    vehicles: {
      total: 90,
      active: 45,
      maintenance: 20,
      inactive: 25,
    },
    reservations: {
      total: 150,
      active: 35,
      upcoming: 28,
      pending: 12,
    },
    drivers: {
      total: 65,
      active: 52,
      on_leave: 13,
    },
    supplies: {
      total: 45,
      urgent: 8,
    },
    // Legacy fields
    total_vehicles: 90,
    active_reservations: 35,
    upcoming_reservations: 28,
  }

  return NextResponse.json(stats, {
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-cache, no-store, must-revalidate",
    },
  })
}
