/**
 * Enhanced Error Handling Utility
 *
 * Provides consistent error handling, logging, and response formatting
 * for all API routes with improved performance and reliability.
 */

import { NextResponse } from "next/server"
import { logger } from "@/lib/logging/logger"
import { ZodError } from "zod"

export interface ApiError {
  message: string
  code?: string
  details?: unknown
  statusCode: number
}

export class AppError extends Error {
  constructor(
    message: string,
    public statusCode = 500,
    public code?: string,
    public details?: unknown,
  ) {
    super(message)
    this.name = "AppError"
  }
}

/**
 * Handle database constraint violations
 */
function handleDatabaseError(error: any): ApiError {
  // Unique constraint violation
  if (error.code === "23505") {
    const match = error.message.match(/Key $$(.*?)$$=/)
    const field = match ? match[1] : "field"
    return {
      message: `A record with this ${field} already exists`,
      code: "DUPLICATE_ENTRY",
      statusCode: 409,
    }
  }

  // Foreign key violation
  if (error.code === "23503") {
    return {
      message: "Referenced record does not exist",
      code: "FOREIGN_KEY_VIOLATION",
      statusCode: 400,
    }
  }

  // Not null violation
  if (error.code === "23502") {
    const match = error.message.match(/column "(.*?)"/)
    const field = match ? match[1] : "field"
    return {
      message: `${field} is required`,
      code: "MISSING_REQUIRED_FIELD",
      statusCode: 400,
    }
  }

  return {
    message: "Database operation failed",
    code: "DATABASE_ERROR",
    details: process.env.NODE_ENV === "development" ? error.message : undefined,
    statusCode: 500,
  }
}

/**
 * Centralized error handler for API routes
 */
export function handleApiError(
  error: unknown,
  context: {
    operation: string
    userId?: number
    duration?: number
  },
): NextResponse {
  // Handle AppError
  if (error instanceof AppError) {
    logger.error(`${context.operation} failed`, {
      ...context,
      error: error.message,
      code: error.code,
    })

    return NextResponse.json(
      {
        error: error.message,
        code: error.code,
        details: error.details,
      },
      { status: error.statusCode },
    )
  }

  // Handle Zod validation errors
  if (error instanceof ZodError) {
    logger.warn(`${context.operation} validation failed`, {
      ...context,
      errors: error.errors,
    })

    return NextResponse.json(
      {
        error: "Validation failed",
        code: "VALIDATION_ERROR",
        details: error.errors.map((err) => ({
          field: err.path.join("."),
          message: err.message,
        })),
      },
      { status: 400 },
    )
  }

  // Handle database errors
  if (error && typeof error === "object" && "code" in error) {
    const dbError = handleDatabaseError(error)
    logger.error(`${context.operation} database error`, {
      ...context,
      error: dbError,
    })

    return NextResponse.json(
      {
        error: dbError.message,
        code: dbError.code,
        details: dbError.details,
      },
      { status: dbError.statusCode },
    )
  }

  // Handle generic errors
  logger.error(`${context.operation} unexpected error`, {
    ...context,
    error: error instanceof Error ? error.message : String(error),
    stack: error instanceof Error ? error.stack : undefined,
  })

  return NextResponse.json(
    {
      error: "An unexpected error occurred",
      code: "INTERNAL_ERROR",
      details: process.env.NODE_ENV === "development" && error instanceof Error ? error.message : undefined,
    },
    { status: 500 },
  )
}

/**
 * Async error wrapper for API handlers
 */
export function withErrorHandler<T extends any[], R>(handler: (...args: T) => Promise<R>, operation: string) {
  return async (...args: T): Promise<R | NextResponse> => {
    const startTime = Date.now()
    try {
      return await handler(...args)
    } catch (error) {
      const duration = Date.now() - startTime
      return handleApiError(error, { operation, duration })
    }
  }
}
