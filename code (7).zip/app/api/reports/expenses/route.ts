import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "reports.read")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Generating expenses report...")

    const { searchParams } = new URL(request.url)
    const year = searchParams.get("year") || new Date().getFullYear().toString()
    const month = searchParams.get("month")

    if (!sql) {
      return getMockExpenses()
    }

    let expensesQuery
    if (month) {
      expensesQuery = sql`
        SELECT 
          category,
          SUM(quantity) as total_quantity,
          COUNT(*) as total_requests
        FROM supplies
        WHERE EXTRACT(YEAR FROM date) = ${year}
          AND EXTRACT(MONTH FROM date) = ${month}
        GROUP BY category
      `
    } else {
      expensesQuery = sql`
        SELECT 
          category,
          SUM(quantity) as total_quantity,
          COUNT(*) as total_requests
        FROM supplies
        WHERE EXTRACT(YEAR FROM date) = ${year}
        GROUP BY category
      `
    }

    const expenses = await expensesQuery

    const report = {
      period: month ? `${year}-${month}` : year,
      breakdown: expenses.map((row) => ({
        category: row.category,
        totalQuantity: Number(row.total_quantity),
        totalRequests: Number(row.total_requests),
      })),
      total: expenses.reduce((sum, row) => sum + Number(row.total_quantity), 0),
    }

    console.log("[v0] Expenses report generated")

    return NextResponse.json(report, {
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("[v0] Error generating expenses report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

function getMockExpenses() {
  console.log("[v0] Using mock expenses data")

  return NextResponse.json({
    period: new Date().getFullYear().toString(),
    breakdown: [
      { category: "Fuel", totalQuantity: 5000, totalRequests: 120, percentage: 60 },
      { category: "Maintenance", totalQuantity: 2000, totalRequests: 45, percentage: 25 },
      { category: "Parts", totalQuantity: 800, totalRequests: 30, percentage: 10 },
      { category: "Other", totalQuantity: 400, totalRequests: 15, percentage: 5 },
    ],
    total: 8200,
  })
}
