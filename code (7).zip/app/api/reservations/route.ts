import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/api-auth"
import { createReservationSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"
import { handleApiError, AppError } from "@/lib/api/error-handler"
import { executeQuery } from "@/lib/api/db-utils"
import { neon } from "@neondatabase/serverless"
import { apiRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import {
  getPaginationParams,
  getSearchParams,
  createPaginatedResponse,
  validatePaginationParams,
  generatePaginationCacheKey,
} from "@/lib/api/pagination-utils"
import { getCachedData, setCachedData } from "@/lib/api/cache-utils"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "reservations.read")
    if (authResult instanceof Response) return authResult

    const { userId, role } = authResult

    const { page, limit, offset, sort, order } = getPaginationParams(request)
    const { search, status, startDate, endDate } = getSearchParams(request)

    const validation = validatePaginationParams(page, limit)
    if (!validation.valid) {
      return NextResponse.json({ error: validation.error }, { status: 400 })
    }

    logger.info("Fetching reservations", { userId, role, page, limit, search, status })

    const cacheKey = generatePaginationCacheKey("reservations", {
      page,
      limit,
      search,
      status,
      startDate,
      endDate,
      sort,
      order,
    })

    const cached = await getCachedData(cacheKey)
    if (cached) {
      logger.info("Reservations fetched from cache", { userId, cacheKey })
      return NextResponse.json(cached, {
        headers: {
          "X-Cache": "HIT",
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      })
    }

    let query = `
      SELECT 
        r.id,
        r.vehicle_id,
        r.driver_id,
        r.pickup_date as start_date,
        r.return_date as end_date,
        r.destination as purpose,
        r.customer_name,
        r.status,
        r.company_id,
        r.created_at,
        r.updated_at,
        v.model as vehicle_model,
        v.plate_number as vehicle_plate,
        d.name as driver_name
      FROM reservations r
      LEFT JOIN vehicles v ON r.vehicle_id = v.id
      LEFT JOIN drivers d ON r.driver_id = d.id
      WHERE 1=1
    `

    const params: any[] = []
    let paramIndex = 1

    // Apply search filter
    if (search) {
      query += ` AND (r.customer_name ILIKE $${paramIndex} OR r.destination ILIKE $${paramIndex + 1})`
      params.push(`%${search}%`, `%${search}%`)
      paramIndex += 2
    }

    // Apply status filter
    if (status) {
      query += ` AND r.status = $${paramIndex}`
      params.push(status)
      paramIndex++
    }

    // Apply date range filter
    if (startDate) {
      query += ` AND r.pickup_date >= $${paramIndex}`
      params.push(startDate)
      paramIndex++
    }

    if (endDate) {
      query += ` AND r.return_date <= $${paramIndex}`
      params.push(endDate)
      paramIndex++
    }

    // Apply sorting
    const sortField = sort === "customer_name" ? "r.customer_name" : "r.pickup_date"
    query += ` ORDER BY ${sortField} ${order === "asc" ? "ASC" : "DESC"}`

    // Apply pagination
    query += ` LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`
    params.push(limit, offset)

    const reservations = await sql(query, params)

    let countQuery = `SELECT COUNT(*) as count FROM reservations r WHERE 1=1`
    const countParams: any[] = []
    let countParamIndex = 1

    if (search) {
      countQuery += ` AND (r.customer_name ILIKE $${countParamIndex} OR r.destination ILIKE $${countParamIndex + 1})`
      countParams.push(`%${search}%`, `%${search}%`)
      countParamIndex += 2
    }

    if (status) {
      countQuery += ` AND r.status = $${countParamIndex}`
      countParams.push(status)
      countParamIndex++
    }

    if (startDate) {
      countQuery += ` AND r.pickup_date >= $${countParamIndex}`
      countParams.push(startDate)
      countParamIndex++
    }

    if (endDate) {
      countQuery += ` AND r.return_date <= $${countParamIndex}`
      countParams.push(endDate)
      countParamIndex++
    }

    const totalResult = await sql(countQuery, countParams)
    const total = Number(totalResult[0]?.count || 0)

    const response = createPaginatedResponse(reservations, page, limit, total)

    await setCachedData(cacheKey, response, 300)

    const duration = Date.now() - startTime
    logger.info("Reservations fetched successfully", {
      userId,
      count: reservations.length,
      total,
      page,
      duration,
    })

    return NextResponse.json(response, {
      headers: {
        "X-Cache": "MISS",
        "X-RateLimit-Limit": rateLimitResult.limit.toString(),
        "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
        "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
      },
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching reservations", { error, duration })

    return NextResponse.json({ error: "Failed to fetch reservations" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "reservations.create")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult

    let body
    try {
      body = await request.json()
    } catch {
      throw new AppError("Invalid JSON in request body", 400, "INVALID_JSON")
    }

    const validatedData = await validateOrRespond(createReservationSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Creating new reservation", {
      userId,
      vehicleId: validatedData.vehicle_id,
      driverId: validatedData.driver_id,
    })

    const [vehicleExists, driverExists] = await Promise.all([
      executeQuery(async (sql) => {
        const result = await sql`SELECT EXISTS(SELECT 1 FROM vehicles WHERE id = ${validatedData.vehicle_id}) as exists`
        return result[0]?.exists
      }),
      executeQuery(async (sql) => {
        const result = await sql`SELECT EXISTS(SELECT 1 FROM drivers WHERE id = ${validatedData.driver_id}) as exists`
        return result[0]?.exists
      }),
    ])

    if (!vehicleExists) {
      throw new AppError("Vehicle not found", 404, "VEHICLE_NOT_FOUND")
    }

    if (!driverExists) {
      throw new AppError("Driver not found", 404, "DRIVER_NOT_FOUND")
    }

    const hasOverlap = await executeQuery(async (sql) => {
      const result = await sql`
        SELECT EXISTS(
          SELECT 1 FROM reservations
          WHERE vehicle_id = ${validatedData.vehicle_id}
            AND status NOT IN ('cancelled', 'completed')
            AND (
              (pickup_date <= ${validatedData.end_date} AND return_date >= ${validatedData.start_date})
            )
        ) as exists
      `
      return result[0]?.exists
    })

    if (hasOverlap) {
      throw new AppError("Vehicle is already reserved for the selected dates", 409, "RESERVATION_CONFLICT")
    }

    const reservation = await executeQuery(async (sql) => {
      const result = await sql`
        INSERT INTO reservations (
          vehicle_id,
          driver_id,
          pickup_date,
          return_date,
          destination,
          status,
          company_id,
          created_at,
          updated_at
        ) VALUES (
          ${validatedData.vehicle_id},
          ${validatedData.driver_id},
          ${validatedData.start_date},
          ${validatedData.end_date},
          ${validatedData.purpose},
          ${validatedData.status},
          ${validatedData.company_id || null},
          NOW(),
          NOW()
        )
        RETURNING *
      `
      return result[0]
    })

    const duration = Date.now() - startTime

    logger.info("Reservation created successfully", {
      userId,
      reservationId: reservation.id,
      duration,
    })

    const response = NextResponse.json(
      {
        reservation,
        message: "Reservation created successfully",
      },
      {
        status: 201,
        headers: {
          Location: `/api/reservations/${reservation.id}`,
        },
      },
    )

    response.headers.set("X-RateLimit-Limit", rateLimitResult.limit.toString())
    response.headers.set("X-RateLimit-Remaining", rateLimitResult.remaining.toString())
    response.headers.set("X-RateLimit-Reset", new Date(rateLimitResult.reset).toISOString())

    return response
  } catch (error) {
    const duration = Date.now() - startTime
    return handleApiError(error, { operation: "Create reservation", duration })
  }
}
