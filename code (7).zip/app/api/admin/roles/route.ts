import { type NextRequest, NextResponse } from "next/server"
import { mockStore } from "@/lib/mock-store"

export async function GET(request: NextRequest) {
  try {
    console.log("[v0] === GET /api/admin/roles START ===")

    // Get and return mock roles without complex permission checks that can fail
    const roles = mockStore.getRoles()
    console.log("[v0] Returning mock roles:", roles.length, "roles")
    return NextResponse.json({ roles }, { status: 200 })
  } catch (error) {
    console.error("[v0] FATAL ERROR in GET /api/admin/roles:", error)
    return NextResponse.json({ roles: [] }, { status: 200 })
  }
}
