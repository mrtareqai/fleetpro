import { Redis } from "@upstash/redis"

let redis: Redis | null = null

/**
 * Get Redis client instance
 */
function getRedisClient(): Redis | null {
  if (typeof window !== "undefined") {
    return null // Redis only works on server
  }

  if (!redis && process.env.KV_REST_API_URL && process.env.KV_REST_API_TOKEN) {
    redis = new Redis({
      url: process.env.KV_REST_API_URL,
      token: process.env.KV_REST_API_TOKEN,
    })
  }

  return redis
}

/**
 * Cache configuration
 */
export const CACHE_TTL = {
  SHORT: 60, // 1 minute
  MEDIUM: 300, // 5 minutes
  LONG: 900, // 15 minutes
  HOUR: 3600, // 1 hour
  DAY: 86400, // 24 hours
}

/**
 * Get data from cache
 */
export async function getFromCache<T>(key: string): Promise<T | null> {
  try {
    const client = getRedisClient()
    if (!client) return null

    const cached = await client.get<T>(key)
    return cached
  } catch (error) {
    console.error("[Cache] Error getting from cache:", error)
    return null
  }
}

/**
 * Set data in cache with TTL
 */
export async function setInCache<T>(key: string, value: T, ttl: number = CACHE_TTL.MEDIUM): Promise<boolean> {
  try {
    const client = getRedisClient()
    if (!client) return false

    await client.setex(key, ttl, value)
    return true
  } catch (error) {
    console.error("[Cache] Error setting in cache:", error)
    return false
  }
}

/**
 * Invalidate cache by key
 */
export async function invalidateCache(key: string): Promise<boolean> {
  try {
    const client = getRedisClient()
    if (!client) return false

    await client.del(key)
    return true
  } catch (error) {
    console.error("[Cache] Error invalidating cache:", error)
    return false
  }
}

/**
 * Invalidate cache by pattern
 */
export async function invalidateCachePattern(pattern: string): Promise<boolean> {
  try {
    const client = getRedisClient()
    if (!client) return false

    const keys = await client.keys(pattern)
    if (keys.length > 0) {
      await client.del(...keys)
    }
    return true
  } catch (error) {
    console.error("[Cache] Error invalidating cache pattern:", error)
    return false
  }
}

/**
 * Cache wrapper for async functions
 */
export async function withCache<T>(key: string, fetcher: () => Promise<T>, ttl: number = CACHE_TTL.MEDIUM): Promise<T> {
  // Try to get from cache first
  const cached = await getFromCache<T>(key)
  if (cached !== null) {
    return cached
  }

  // Fetch fresh data
  const data = await fetcher()

  // Store in cache
  await setInCache(key, data, ttl)

  return data
}

/**
 * Alias for getFromCache - for backward compatibility
 */
export const getCachedData = getFromCache

/**
 * Alias for setInCache - for backward compatibility
 */
export const setCachedData = setInCache
