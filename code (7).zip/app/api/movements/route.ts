import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { createMovementSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"
import { apiRateLimiter, getClientIp } from "@/lib/security/rate-limit"
import {
  getPaginationParams,
  getSearchParams,
  createPaginatedResponse,
  validatePaginationParams,
  generatePaginationCacheKey,
} from "@/lib/api/pagination-utils"
import { getCachedData, setCachedData } from "@/lib/api/cache-utils"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "movements.read")
    if (authResult instanceof Response) return authResult

    const { userId, role } = authResult

    const { page, limit, offset, sort, order } = getPaginationParams(request)
    const { search, status, startDate, endDate } = getSearchParams(request)

    const validation = validatePaginationParams(page, limit)
    if (!validation.valid) {
      return NextResponse.json({ error: validation.error }, { status: 400 })
    }

    logger.info("Fetching movements", { userId, role, page, limit, search, status })

    const cacheKey = generatePaginationCacheKey("movements", {
      page,
      limit,
      search,
      status,
      startDate,
      endDate,
      sort,
      order,
    })

    const cached = await getCachedData(cacheKey)
    if (cached) {
      logger.info("Movements fetched from cache", { userId, cacheKey })
      return NextResponse.json(cached, {
        headers: {
          "X-Cache": "HIT",
          "X-RateLimit-Limit": rateLimitResult.limit.toString(),
          "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
          "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
        },
      })
    }

    let query = `
      SELECT 
        id,
        driver_name,
        assistant_name,
        bus_number,
        trip_name,
        trip_date,
        trip_time,
        seats,
        pending_seats,
        status,
        created_at
      FROM movements
      WHERE 1=1
    `

    const params: any[] = []
    let paramIndex = 1

    // Apply search filter
    if (search) {
      query += ` AND (driver_name ILIKE $${paramIndex} OR trip_name ILIKE $${paramIndex + 1} OR bus_number ILIKE $${paramIndex + 2})`
      params.push(`%${search}%`, `%${search}%`, `%${search}%`)
      paramIndex += 3
    }

    // Apply status filter
    if (status) {
      query += ` AND status = $${paramIndex}`
      params.push(status)
      paramIndex++
    }

    // Apply date range filter
    if (startDate) {
      query += ` AND trip_date >= $${paramIndex}`
      params.push(startDate)
      paramIndex++
    }

    if (endDate) {
      query += ` AND trip_date <= $${paramIndex}`
      params.push(endDate)
      paramIndex++
    }

    // Apply sorting
    const sortField = sort === "driver_name" ? "driver_name" : "trip_date"
    query += ` ORDER BY ${sortField} ${order === "asc" ? "ASC" : "DESC"}, trip_time ${order === "asc" ? "ASC" : "DESC"}`

    // Apply pagination
    query += ` LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`
    params.push(limit, offset)

    const movements = await sql(query, params)

    let countQuery = `SELECT COUNT(*) as count FROM movements WHERE 1=1`
    const countParams: any[] = []
    let countParamIndex = 1

    if (search) {
      countQuery += ` AND (driver_name ILIKE $${countParamIndex} OR trip_name ILIKE $${countParamIndex + 1} OR bus_number ILIKE $${countParamIndex + 2})`
      countParams.push(`%${search}%`, `%${search}%`, `%${search}%`)
      countParamIndex += 3
    }

    if (status) {
      countQuery += ` AND status = $${countParamIndex}`
      countParams.push(status)
      countParamIndex++
    }

    if (startDate) {
      countQuery += ` AND trip_date >= $${countParamIndex}`
      countParams.push(startDate)
      countParamIndex++
    }

    if (endDate) {
      countQuery += ` AND trip_date <= $${countParamIndex}`
      countParams.push(endDate)
      countParamIndex++
    }

    const totalResult = await sql(countQuery, countParams)
    const total = Number(totalResult[0]?.count || 0)

    const response = createPaginatedResponse(movements, page, limit, total)

    await setCachedData(cacheKey, response, 300)

    const duration = Date.now() - startTime
    logger.info("Movements fetched successfully", {
      userId,
      count: movements.length,
      total,
      page,
      duration,
    })

    return NextResponse.json(response, {
      headers: {
        "X-Cache": "MISS",
        "X-RateLimit-Limit": rateLimitResult.limit.toString(),
        "X-RateLimit-Remaining": rateLimitResult.remaining.toString(),
        "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
      },
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching movements", { error, duration })

    return NextResponse.json({ error: "Failed to fetch movements" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const startTime = Date.now()

  try {
    const ip = getClientIp(request)
    const rateLimitResult = await apiRateLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        {
          error: "Too many requests",
          retryAfter: rateLimitResult.retryAfter,
        },
        {
          status: 429,
          headers: {
            "Retry-After": rateLimitResult.retryAfter?.toString() || "60",
            "X-RateLimit-Limit": rateLimitResult.limit.toString(),
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": new Date(rateLimitResult.reset).toISOString(),
          },
        },
      )
    }

    const authResult = await requirePermission(request, "movements.create")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult

    // Validate request body
    const body = await request.json()
    const validatedData = await validateOrRespond(createMovementSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Creating new movement", {
      userId,
      tripName: validatedData.trip_name,
    })

    const result = await sql`
      INSERT INTO movements (
        driver_name,
        assistant_name,
        bus_number,
        trip_name,
        trip_date,
        trip_time,
        seats,
        pending_seats,
        status,
        movement_type,
        category,
        priority
      ) VALUES (
        ${validatedData.driver_name},
        ${validatedData.assistant_name || null},
        ${validatedData.bus_number},
        ${validatedData.trip_name},
        ${validatedData.trip_date},
        ${validatedData.trip_time},
        ${validatedData.seats},
        ${validatedData.pending_seats},
        ${validatedData.status},
        'trip',
        'intercity',
        'medium'
      )
      RETURNING *
    `

    const movement = result[0]
    const duration = Date.now() - startTime

    logger.info("Movement created successfully", {
      userId,
      movementId: movement.id,
      duration,
    })

    const response = NextResponse.json({ movement }, { status: 201 })

    response.headers.set("X-RateLimit-Limit", rateLimitResult.limit.toString())
    response.headers.set("X-RateLimit-Remaining", rateLimitResult.remaining.toString())
    response.headers.set("X-RateLimit-Reset", new Date(rateLimitResult.reset).toISOString())

    return response
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error creating movement", { error, duration })

    return NextResponse.json({ error: "Failed to create movement" }, { status: 500 })
  }
}
