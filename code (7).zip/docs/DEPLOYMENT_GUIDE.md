# Security Framework Deployment Guide

## Pre-Deployment Checklist

### Environment Variables

Ensure all required environment variables are set:

\`\`\`bash
# Required for JWT
JWT_SECRET=your-super-secret-key-min-32-characters-long
JWT_EXPIRATION=7d
REFRESH_TOKEN_EXPIRATION=30d

# Database (already configured)
DATABASE_URL=your-neon-database-url

# Optional: For production monitoring
NODE_ENV=production
\`\`\`

### Generate Secure JWT Secret

\`\`\`bash
# Generate a secure random string
openssl rand -base64 32

# Or use Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
\`\`\`

### Security Checklist

- [ ] JWT_SECRET is set to a secure random string (min 32 characters)
- [ ] HTTPS is enabled in production
- [ ] Rate limiting is configured appropriately
- [ ] Password requirements are enforced
- [ ] All API routes use authentication middleware
- [ ] Error messages don't leak sensitive information
- [ ] Dependencies are up to date (`npm audit`)
- [ ] Security headers are configured
- [ ] CORS is properly configured
- [ ] Database uses SSL connections

---

## Deployment Steps

### Step 1: Install Dependencies

\`\`\`bash
npm install
\`\`\`

### Step 2: Set Environment Variables

#### Vercel Deployment

\`\`\`bash
# Add environment variables via Vercel CLI
vercel env add JWT_SECRET production
vercel env add JWT_EXPIRATION production
vercel env add REFRESH_TOKEN_EXPIRATION production
\`\`\`

Or via Vercel Dashboard:
1. Go to Project Settings
2. Navigate to Environment Variables
3. Add each variable with appropriate scope (Production/Preview/Development)

### Step 3: Database Migration

If you have existing users with plain text passwords, run migration:

\`\`\`bash
# Create migration script
npm run migrate:passwords
\`\`\`

### Step 4: Build and Deploy

\`\`\`bash
# Build the project
npm run build

# Deploy to Vercel
vercel --prod
\`\`\`

### Step 5: Verify Deployment

\`\`\`bash
# Test login endpoint
curl -X POST https://your-domain.com/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username":"admin","password":"password123"}'

# Should return JWT tokens
\`\`\`

---

## Post-Deployment

### Monitor Security Events

Set up logging and monitoring for:
- Failed login attempts
- Rate limit violations
- Invalid token attempts
- Permission violations

### Regular Maintenance

- Update dependencies monthly: `npm update`
- Run security audits: `npm audit`
- Review access logs weekly
- Rotate JWT_SECRET every 6 months

---

## Rollback Plan

If issues occur after deployment:

1. Revert to previous deployment via Vercel dashboard
2. Check error logs for specific issues
3. Verify environment variables are correct
4. Test authentication flow in staging first

---

**Last Updated:** January 2025
