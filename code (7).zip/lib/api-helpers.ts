export function getAuthToken(): string | null {
  if (typeof window === "undefined") return null
  return localStorage.getItem("token")
}

export async function authenticatedFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getAuthToken()

  console.log("[v0] Making authenticated request to:", url)
  console.log("[v0] Token present:", !!token)

  const headers = new Headers(options.headers)
  if (token) {
    headers.set("Authorization", `Bearer ${token}`)
  } else {
    console.warn("[v0] No authentication token found in localStorage")
  }

  return fetch(url, {
    ...options,
    headers,
  })
}

export async function handleApiResponse<T>(response: Response): Promise<T> {
  console.log("[v0] API Response status:", response.status, response.statusText)

  if (!response.ok) {
    let errorMessage = "An error occurred"
    try {
      const clonedResponse = response.clone()
      const errorData = await clonedResponse.json()
      errorMessage = errorData.error || errorData.message || errorMessage
      console.error("[v0] API Error:", errorMessage)
    } catch {
      try {
        errorMessage = await response.text()
        console.error("[v0] API Error (text):", errorMessage)
      } catch {
        errorMessage = `HTTP ${response.status}: ${response.statusText}`
        console.error("[v0] API Error (status):", errorMessage)
      }
    }
    throw new Error(errorMessage)
  }

  return response.json()
}
