import DashboardLayout from "@/components/dashboard-layout"
import MovementTable from "@/components/movement-table"

export default function MovementPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="movement">
      <MovementTable locale={locale} />
    </DashboardLayout>
  )
}
