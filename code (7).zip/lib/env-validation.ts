/**
 * Environment Variables Validation
 *
 * This module validates required environment variables at application startup.
 * It ensures all critical configuration is present before the app runs.
 */

interface EnvConfig {
  // Database
  DATABASE_URL: string

  // JWT Authentication
  JWT_SECRET?: string
  JWT_EXPIRATION?: string
  REFRESH_TOKEN_EXPIRATION?: string

  // Application
  NODE_ENV: string
  NEXT_PUBLIC_APP_URL?: string
}

/**
 * Validate required environment variables
 * Removed production check for JWT_SECRET - moved to runtime validation
 * This allows builds to complete even if JWT_SECRET is not set during build time.
 * Tokens throws an error when actually trying to generate/verify tokens at runtime.
 */
export function validateEnv(): EnvConfig {
  const errors: string[] = []

  // Required in all environments
  if (!process.env.DATABASE_URL) {
    errors.push("DATABASE_URL is required")
  }

  // This prevents build failures when deploying to platforms that inject
  // environment variables after the build completes

  if (errors.length > 0) {
    throw new Error(`Environment validation failed:\n${errors.join("\n")}`)
  }

  return {
    DATABASE_URL: process.env.DATABASE_URL!,
    JWT_SECRET: process.env.JWT_SECRET,
    JWT_EXPIRATION: process.env.JWT_EXPIRATION,
    REFRESH_TOKEN_EXPIRATION: process.env.REFRESH_TOKEN_EXPIRATION,
    NODE_ENV: process.env.NODE_ENV || "development",
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  }
}

/**
 * Get validated environment configuration
 * Safe to use after validateEnv() has been called
 */
export function getEnv(): EnvConfig {
  return {
    DATABASE_URL: process.env.DATABASE_URL!,
    JWT_SECRET: process.env.JWT_SECRET,
    JWT_EXPIRATION: process.env.JWT_EXPIRATION,
    REFRESH_TOKEN_EXPIRATION: process.env.REFRESH_TOKEN_EXPIRATION,
    NODE_ENV: process.env.NODE_ENV || "development",
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
  }
}
