import * as XLSX from "xlsx"

export interface ExportData {
  summary?: Record<string, any>
  data?: any[]
  breakdown?: any[]
  [key: string]: any
}

const getColumnHeaders = (reportType: string) => {
  const headers: Record<string, Record<string, string>> = {
    "fleet-utilization": {
      date: "التاريخ / Date",
      vehiclesUsed: "المركبات المستخدمة / Vehicles Used",
      totalVehicles: "إجمالي المركبات / Total Vehicles",
      utilizationRate: "معدل الاستخدام % / Utilization Rate %",
    },
    expenses: {
      category: "الفئة / Category",
      amount: "المبلغ / Amount",
      percentage: "النسبة % / Percentage %",
      totalQuantity: "الكمية الإجمالية / Total Quantity",
    },
    "driver-performance": {
      rank: "الترتيب / Rank",
      name: "الاسم / Name",
      score: "النقاط / Score",
      trips: "الرحلات / Trips",
    },
    "monthly-reservations": {
      month: "الشهر / Month",
      year: "السنة / Year",
      count: "العدد / Count",
      revenue: "الإيرادات / Revenue",
    },
  }
  return headers[reportType] || {}
}

export function exportToExcel(reportType: string, data: ExportData, filename?: string) {
  try {
    console.log("[v0] Exporting to Excel:", { reportType, data })

    // Create a new workbook
    const wb = XLSX.utils.book_new()

    if (data.data && Array.isArray(data.data) && data.data.length > 0) {
      console.log("[v0] Adding data sheet:", data.data.length, "rows")

      // Get column headers for this report type
      const headerMap = getColumnHeaders(reportType)

      // Transform data with translated headers
      const transformedData = data.data.map((row: any) => {
        const newRow: any = {}
        Object.keys(row).forEach((key) => {
          const translatedKey = headerMap[key] || key
          newRow[translatedKey] = row[key]
        })
        return newRow
      })

      const dataSheet = XLSX.utils.json_to_sheet(transformedData)

      const columnWidths = Object.keys(transformedData[0] || {}).map(() => ({ wch: 20 }))
      dataSheet["!cols"] = columnWidths

      XLSX.utils.book_append_sheet(wb, dataSheet, "البيانات التفصيلية")
    } else {
      console.log("[v0] No data array found or empty")
    }

    if (data.breakdown && Array.isArray(data.breakdown) && data.breakdown.length > 0) {
      console.log("[v0] Adding breakdown sheet:", data.breakdown.length, "rows")

      const headerMap = getColumnHeaders(reportType)
      const transformedBreakdown = data.breakdown.map((row: any) => {
        const newRow: any = {}
        Object.keys(row).forEach((key) => {
          const translatedKey = headerMap[key] || key
          newRow[translatedKey] = row[key]
        })
        return newRow
      })

      const breakdownSheet = XLSX.utils.json_to_sheet(transformedBreakdown)
      const columnWidths = Object.keys(transformedBreakdown[0] || {}).map(() => ({ wch: 20 }))
      breakdownSheet["!cols"] = columnWidths

      XLSX.utils.book_append_sheet(wb, breakdownSheet, "التفصيل")
    }

    if (data.drivers && Array.isArray(data.drivers) && data.drivers.length > 0) {
      console.log("[v0] Adding drivers sheet:", data.drivers.length, "rows")

      const headerMap = getColumnHeaders("driver-performance")
      const transformedDrivers = data.drivers.map((row: any) => {
        const newRow: any = {}
        Object.keys(row).forEach((key) => {
          const translatedKey = headerMap[key] || key
          newRow[translatedKey] = row[key]
        })
        return newRow
      })

      const driversSheet = XLSX.utils.json_to_sheet(transformedDrivers)
      const columnWidths = Object.keys(transformedDrivers[0] || {}).map(() => ({ wch: 20 }))
      driversSheet["!cols"] = columnWidths

      XLSX.utils.book_append_sheet(wb, driversSheet, "السائقون")
    }

    if (data.months && Array.isArray(data.months) && data.months.length > 0) {
      console.log("[v0] Adding months sheet:", data.months.length, "rows")

      const headerMap = getColumnHeaders("monthly-reservations")
      const transformedMonths = data.months.map((row: any) => {
        const newRow: any = {}
        Object.keys(row).forEach((key) => {
          const translatedKey = headerMap[key] || key
          newRow[translatedKey] = row[key]
        })
        return newRow
      })

      const monthsSheet = XLSX.utils.json_to_sheet(transformedMonths)
      const columnWidths = Object.keys(transformedMonths[0] || {}).map(() => ({ wch: 20 }))
      monthsSheet["!cols"] = columnWidths

      XLSX.utils.book_append_sheet(wb, monthsSheet, "الأشهر")
    }

    // Add summary sheet if available
    if (data.summary) {
      console.log("[v0] Adding summary sheet:", data.summary)
      const summaryData = Object.entries(data.summary).map(([key, value]) => [key, value])
      const summarySheet = XLSX.utils.aoa_to_sheet([["Field", "Value"], ...summaryData])
      summarySheet["!cols"] = [{ wch: 25 }, { wch: 20 }]
      XLSX.utils.book_append_sheet(wb, summarySheet, "الملخص")
    }

    // Add metadata sheet LAST
    const metaData = [
      ["Report Type", reportType],
      ["Generated Date", new Date().toLocaleString("ar-SA")],
      ["Generated By", "FleetPro Management System"],
    ]
    const metaSheet = XLSX.utils.aoa_to_sheet(metaData)
    metaSheet["!cols"] = [{ wch: 20 }, { wch: 30 }]
    XLSX.utils.book_append_sheet(wb, metaSheet, "معلومات التقرير")

    console.log("[v0] Total sheets created:", wb.SheetNames.length)

    // Generate Excel file
    const excelBuffer = XLSX.write(wb, { bookType: "xlsx", type: "array" })
    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    })

    // Download file
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = filename || `${reportType}-${Date.now()}.xlsx`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    console.log("[v0] Excel file downloaded successfully")
    return true
  } catch (error) {
    console.error("[v0] Error exporting to Excel:", error)
    return false
  }
}

export function exportToCSV(reportType: string, data: any[], filename?: string) {
  try {
    if (!data || !Array.isArray(data) || data.length === 0) {
      throw new Error("No data to export")
    }

    // Convert data to CSV
    const headers = Object.keys(data[0])
    const csvContent = [
      headers.join(","),
      ...data.map((row) => headers.map((header) => JSON.stringify(row[header] || "")).join(",")),
    ].join("\n")

    // Create blob and download
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = filename || `${reportType}-${Date.now()}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    return true
  } catch (error) {
    console.error("[v0] Error exporting to CSV:", error)
    return false
  }
}

export function exportToJSON(reportType: string, data: ExportData, filename?: string) {
  try {
    const jsonContent = JSON.stringify(data, null, 2)
    const blob = new Blob([jsonContent], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = filename || `${reportType}-${Date.now()}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)

    return true
  } catch (error) {
    console.error("[v0] Error exporting to JSON:", error)
    return false
  }
}
