import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { updateReservationSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "reservations.read")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "Invalid reservation ID" }, { status: 400 })
    }

    logger.info("Fetching reservation", { userId: user.id, reservationId })

    const result = await sql`
      SELECT 
        r.*,
        v.model as vehicle_model,
        v.plate_number as vehicle_plate,
        d.name as driver_name
      FROM reservations r
      LEFT JOIN vehicles v ON r.vehicle_id = v.id
      LEFT JOIN drivers d ON r.driver_id = d.id
      WHERE r.id = ${reservationId}
    `

    if (result.length === 0) {
      logger.warn("Reservation not found", { userId: user.id, reservationId })
      return NextResponse.json({ error: "Reservation not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Reservation fetched successfully", { userId: user.id, reservationId, duration })

    return NextResponse.json({ reservation: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching reservation", { error, reservationId: params.id, duration })

    return NextResponse.json({ error: "Failed to fetch reservation" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "reservations.update")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "Invalid reservation ID" }, { status: 400 })
    }

    // Validate request body
    const body = await request.json()
    const validatedData = await validateOrRespond(updateReservationSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Updating reservation", { userId: user.id, reservationId })

    // Build dynamic update query
    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1

    if (validatedData.vehicle_id !== undefined) {
      updates.push(`vehicle_id = $${paramIndex++}`)
      values.push(validatedData.vehicle_id)
    }
    if (validatedData.driver_id !== undefined) {
      updates.push(`driver_id = $${paramIndex++}`)
      values.push(validatedData.driver_id)
    }
    if (validatedData.start_date !== undefined) {
      updates.push(`pickup_date = $${paramIndex++}`)
      values.push(validatedData.start_date)
    }
    if (validatedData.end_date !== undefined) {
      updates.push(`return_date = $${paramIndex++}`)
      values.push(validatedData.end_date)
    }
    if (validatedData.purpose !== undefined) {
      updates.push(`destination = $${paramIndex++}`)
      values.push(validatedData.purpose)
    }
    if (validatedData.status !== undefined) {
      updates.push(`status = $${paramIndex++}`)
      values.push(validatedData.status)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(reservationId)

    const query = `
      UPDATE reservations 
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `

    const result = await sql(query, values)

    if (result.length === 0) {
      logger.warn("Reservation not found for update", { userId: user.id, reservationId })
      return NextResponse.json({ error: "Reservation not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Reservation updated successfully", { userId: user.id, reservationId, duration })

    return NextResponse.json({ reservation: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error updating reservation", { error, reservationId: params.id, duration })

    return NextResponse.json({ error: "Failed to update reservation" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "reservations.delete")
    if (authResult instanceof Response) return authResult

    const { user } = authResult
    const reservationId = Number.parseInt(params.id)

    if (isNaN(reservationId)) {
      return NextResponse.json({ error: "Invalid reservation ID" }, { status: 400 })
    }

    logger.info("Deleting reservation", { userId: user.id, reservationId })

    const result = await sql`
      DELETE FROM reservations 
      WHERE id = ${reservationId}
      RETURNING id
    `

    if (result.length === 0) {
      logger.warn("Reservation not found for deletion", { userId: user.id, reservationId })
      return NextResponse.json({ error: "Reservation not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Reservation deleted successfully", { userId: user.id, reservationId, duration })

    return NextResponse.json({
      message: "Reservation deleted successfully",
      id: reservationId,
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error deleting reservation", { error, reservationId: params.id, duration })

    return NextResponse.json({ error: "Failed to delete reservation" }, { status: 500 })
  }
}
