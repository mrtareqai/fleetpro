"use client"

import { createContext, useContext, useState, type ReactNode } from "react"

interface SelectionContextType {
  isSelectionMode: boolean
  selectedItems: Set<number>
  toggleSelectionMode: () => void
  selectItem: (id: number) => void
  deselectItem: (id: number) => void
  toggleItem: (id: number) => void
  selectAll: (ids: number[]) => void
  clearSelection: () => void
  isSelected: (id: number) => boolean
}

const SelectionContext = createContext<SelectionContextType | undefined>(undefined)

export function SelectionProvider({ children }: { children: ReactNode }) {
  const [isSelectionMode, setIsSelectionMode] = useState(false)
  const [selectedItems, setSelectedItems] = useState<Set<number>>(new Set())

  const toggleSelectionMode = () => {
    setIsSelectionMode((prev) => !prev)
    if (isSelectionMode) {
      // Clear selection when exiting selection mode
      setSelectedItems(new Set())
    }
  }

  const selectItem = (id: number) => {
    setSelectedItems((prev) => new Set(prev).add(id))
  }

  const deselectItem = (id: number) => {
    setSelectedItems((prev) => {
      const newSet = new Set(prev)
      newSet.delete(id)
      return newSet
    })
  }

  const toggleItem = (id: number) => {
    setSelectedItems((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(id)) {
        newSet.delete(id)
      } else {
        newSet.add(id)
      }
      return newSet
    })
  }

  const selectAll = (ids: number[]) => {
    setSelectedItems(new Set(ids))
  }

  const clearSelection = () => {
    setSelectedItems(new Set())
  }

  const isSelected = (id: number) => {
    return selectedItems.has(id)
  }

  return (
    <SelectionContext.Provider
      value={{
        isSelectionMode,
        selectedItems,
        toggleSelectionMode,
        selectItem,
        deselectItem,
        toggleItem,
        selectAll,
        clearSelection,
        isSelected,
      }}
    >
      {children}
    </SelectionContext.Provider>
  )
}

export function useSelection() {
  const context = useContext(SelectionContext)
  if (context === undefined) {
    throw new Error("useSelection must be used within a SelectionProvider")
  }
  return {
    ...context,
    selectedItems: context.selectedItems,
    selectedItemsArray: Array.from(context.selectedItems),
  }
}
