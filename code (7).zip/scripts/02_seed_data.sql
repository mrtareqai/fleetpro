-- Seed data for FleetPro Management System

-- Insert sample users (password is 'password123' hashed with bcrypt)
INSERT INTO users (username, email, password_hash, full_name, role) VALUES
('admin', 'admin@fleetpro.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYIeWU7u3oi', 'Admin User', 'admin'),
('manager', 'manager@fleetpro.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYIeWU7u3oi', 'Fleet Manager', 'manager'),
('user1', 'user1@fleetpro.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYIeWU7u3oi', 'John Doe', 'user')
ON CONFLICT (username) DO NOTHING;

-- Assign roles to users
INSERT INTO user_roles (user_id, role_id)
SELECT u.id, r.id
FROM users u
CROSS JOIN roles r
WHERE (u.username = 'admin' AND r.name = 'super_admin')
   OR (u.username = 'manager' AND r.name = 'fleet_manager')
   OR (u.username = 'user1' AND r.name = 'viewer')
ON CONFLICT DO NOTHING;

-- Insert sample vehicles
INSERT INTO vehicles (manufacture_date, model, plate_number, base_number, card_number, expiry_date, status, country) VALUES
('2020-01-15', 'Mercedes Sprinter', 'ABC-1234', 'BS-123', 'CRD-890', '2025-03-10', 'active', 'Germany'),
('2019-06-20', 'Ford Transit', 'XYZ-5678', 'BS-567', 'CRD-891', '2025-06-20', 'active', 'USA'),
('2021-03-10', 'Toyota Hiace', 'DEF-9012', 'BS-126', 'CRD-892', '2025-03-10', 'active', 'Japan'),
('2018-11-05', 'Volkswagen Crafter', 'GHI-3456', 'BS-890', 'CRD-893', '2024-06-15', 'maintenance', 'Germany'),
('2022-05-20', 'Nissan NV350', 'JKL-7890', 'BS-234', 'CRD-894', '2026-01-20', 'active', 'Japan'),
('2020-08-15', 'Renault Master', 'MNO-2345', 'BS-456', 'CRD-895', '2025-08-15', 'active', 'France')
ON CONFLICT (plate_number) DO NOTHING;

-- Insert sample drivers
INSERT INTO drivers (name, license_number, phone, email, status) VALUES
('Ahmed Ali', 'DL-2024001', '+971-50-1234567', 'ahmed.ali@fleetpro.com', 'active'),
('Fatima Khan', 'DL-2024002', '+971-50-2345678', 'fatima.khan@fleetpro.com', 'active'),
('Mohammed Hassan', 'DL-2024003', '+971-50-3456789', 'mohammed.hassan@fleetpro.com', 'active'),
('Sara Ahmed', 'DL-2024004', '+971-50-4567890', 'sara.ahmed@fleetpro.com', 'inactive'),
('Omar Ibrahim', 'DL-2024005', '+971-50-5678901', 'omar.ibrahim@fleetpro.com', 'active')
ON CONFLICT (license_number) DO NOTHING;

-- Insert sample reservations
INSERT INTO reservations (vehicle_id, driver_id, customer_name, pickup_date, return_date, destination, status) VALUES
(1, 1, 'Customer A', '2025-01-20', '2025-01-25', 'Dubai', 'confirmed'),
(2, 2, 'Customer B', '2025-01-22', '2025-01-24', 'Abu Dhabi', 'confirmed'),
(3, 3, 'Customer C', '2025-01-25', '2025-01-28', 'Sharjah', 'pending'),
(4, NULL, 'Customer D', '2025-01-30', '2025-02-02', 'Ajman', 'pending'),
(5, NULL, 'Customer E', '2025-02-05', '2025-02-10', 'Ras Al Khaimah', 'pending');

-- Insert sample tickets
INSERT INTO tickets (ticket_number, subject, category, assigned_to, priority, status, date_created) VALUES
('#2024001', 'Tire Replacement Required', 'Maintenance', 'Ahmed Ali', 'high', 'open', '2024-12-15'),
('#2024002', 'Engine Oil Change', 'Maintenance', 'Fatima Khan', 'medium', 'in_progress', '2024-12-20'),
('#2024003', 'Brake System Check', 'Safety', 'Mohammed Hassan', 'high', 'open', '2025-01-05'),
('#2024004', 'AC Not Working', 'Repair', 'Ahmed Ali', 'medium', 'open', '2025-01-10'),
('#2024005', 'Battery Replacement', 'Maintenance', 'Sara Ahmed', 'low', 'resolved', '2025-01-12')
ON CONFLICT (ticket_number) DO NOTHING;

-- Insert sample movements
INSERT INTO movements (vehicle_id, movement_type, subject, category, date, priority, status) VALUES
(1, 'Delivery', 'Package Delivery to Dubai Mall', 'Logistics', '2025-01-15', 'high', 'completed'),
(2, 'Pickup', 'Cargo Pickup from Port', 'Logistics', '2025-01-16', 'high', 'in_progress'),
(3, 'Transfer', 'Vehicle Transfer to Branch', 'Internal', '2025-01-17', 'medium', 'pending'),
(4, 'Maintenance', 'Scheduled Maintenance Visit', 'Service', '2025-01-18', 'medium', 'pending'),
(5, 'Emergency', 'Emergency Medical Transport', 'Emergency', '2025-01-19', 'critical', 'completed');

-- Insert sample agency supplies
INSERT INTO agency_supplies (vehicle_id, supply_type, subject, category, date, priority, status, quantity) VALUES
(1, 'Fuel', 'Diesel Refill', 'Fuel', '2025-01-15', 'high', 'delivered', 100),
(2, 'Parts', 'Brake Pads', 'Maintenance', '2025-01-16', 'high', 'ordered', 4),
(3, 'Tires', 'All-Season Tires', 'Maintenance', '2025-01-17', 'medium', 'pending', 4),
(4, 'Oil', 'Engine Oil 5W-30', 'Maintenance', '2025-01-18', 'medium', 'delivered', 20),
(5, 'Emergency Kit', 'First Aid Kit', 'Safety', '2025-01-19', 'low', 'delivered', 1);
