"use client"

import type React from "react"

import { Search, Download, Filter, X } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"

interface DataTableToolbarProps {
  searchQuery: string
  onSearchChange: (query: string) => void
  statusFilter?: string
  onStatusFilterChange?: (status: string) => void
  statusOptions?: { value: string; label: string }[]
  onExport?: () => void
  locale: "en" | "ar"
  showFilters?: boolean
  activeFiltersCount?: number
  onClearFilters?: () => void
  customFilters?: React.ReactNode
}

export function DataTableToolbar({
  searchQuery,
  onSearchChange,
  statusFilter,
  onStatusFilterChange,
  statusOptions,
  onExport,
  locale,
  showFilters = true,
  activeFiltersCount = 0,
  onClearFilters,
  customFilters,
}: DataTableToolbarProps) {
  const t = {
    en: {
      search: "Search...",
      export: "Export CSV",
      filter: "Filter",
      status: "Status",
      all: "All",
      clearFilters: "Clear filters",
      activeFilters: "active filter(s)",
    },
    ar: {
      search: "بحث...",
      export: "تصدير CSV",
      filter: "تصفية",
      status: "الحالة",
      all: "الكل",
      clearFilters: "مسح التصفية",
      activeFilters: "تصفية نشطة",
    },
  }

  return (
    <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between bg-white p-4 rounded-lg shadow-sm border border-slate-200">
      <div className="flex flex-1 flex-col sm:flex-row gap-3 w-full sm:w-auto">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <Input
            type="text"
            placeholder={t[locale].search}
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-9 pr-4"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Status Filter */}
        {showFilters && statusOptions && onStatusFilterChange && (
          <Select value={statusFilter} onValueChange={onStatusFilterChange}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <div className="flex items-center gap-2">
                <Filter className="w-4 h-4" />
                <SelectValue placeholder={t[locale].status} />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t[locale].all}</SelectItem>
              {statusOptions.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {/* Custom Filters */}
        {customFilters}

        {/* Active Filters Badge */}
        {activeFiltersCount > 0 && onClearFilters && (
          <Button
            variant="outline"
            size="sm"
            onClick={onClearFilters}
            className="flex items-center gap-2 bg-transparent"
          >
            <Badge variant="secondary" className="rounded-full">
              {activeFiltersCount}
            </Badge>
            <span className="text-sm">{t[locale].clearFilters}</span>
            <X className="w-3 h-3" />
          </Button>
        )}
      </div>

      {/* Export Button */}
      {onExport && (
        <Button
          onClick={onExport}
          variant="outline"
          className="flex items-center gap-2 w-full sm:w-auto bg-transparent"
        >
          <Download className="w-4 h-4" />
          {t[locale].export}
        </Button>
      )}
    </div>
  )
}
