# Testing and Validation Guide

Complete guide for testing and data validation in the FleetPro Management System.

## Table of Contents

1. [Overview](#overview)
2. [Testing Framework](#testing-framework)
3. [Unit Tests](#unit-tests)
4. [Integration Tests](#integration-tests)
5. [Data Validation](#data-validation)
6. [Error Logging](#error-logging)
7. [Best Practices](#best-practices)
8. [Running Tests](#running-tests)

---

## Overview

The FleetPro system implements comprehensive testing and validation:

- **Unit Tests**: Test individual functions and modules
- **Integration Tests**: Test API endpoints and workflows
- **Data Validation**: Zod schemas for runtime type safety
- **Error Logging**: Structured logging system for debugging

### Technology Stack

- **Jest**: Testing framework
- **Testing Library**: React component testing
- **Zod**: Schema validation
- **Custom Logger**: Error tracking and monitoring

---

## Testing Framework

### Setup

The project uses Jest with Next.js integration:

\`\`\`bash
# Run all tests
npm test

# Run tests in watch mode
npm run test:watch

# Run tests with coverage
npm run test:coverage
\`\`\`

### Configuration

**jest.config.js**:
\`\`\`javascript
const nextJest = require('next/jest')

const createJestConfig = nextJest({
  dir: './',
})

const customJestConfig = {
  setupFilesAfterEnv: ['<rootDir>/jest.setup.js'],
  testEnvironment: 'jest-environment-jsdom',
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/$1',
  },
  coverageThreshold: {
    global: {
      branches: 70,
      functions: 70,
      lines: 70,
      statements: 70,
    },
  },
}

module.exports = createJestConfig(customJestConfig)
\`\`\`

---

## Unit Tests

### Password Hashing Tests

**Location**: `__tests__/lib/security/password.test.ts`

\`\`\`typescript
import { hashPassword, verifyPassword, validatePasswordStrength } from '@/lib/security/password'

describe('Password Hashing', () => {
  it('should hash password successfully', async () => {
    const password = 'TestPassword123!'
    const hash = await hashPassword(password)
    
    expect(hash).toBeDefined()
    expect(hash).not.toBe(password)
  })

  it('should verify correct password', async () => {
    const password = 'TestPassword123!'
    const hash = await hashPassword(password)
    const isValid = await verifyPassword(password, hash)
    
    expect(isValid).toBe(true)
  })
})
\`\`\`

### JWT Authentication Tests

**Location**: `__tests__/lib/security/jwt.test.ts`

\`\`\`typescript
import { generateToken, verifyToken } from '@/lib/security/jwt'

describe('JWT Authentication', () => {
  it('should generate valid token', async () => {
    const payload = {
      userId: '123',
      role: 'admin',
      permissions: ['users.read'],
    }
    
    const token = await generateToken(payload)
    expect(token).toBeDefined()
    expect(token.split('.')).toHaveLength(3)
  })

  it('should verify valid token', async () => {
    const payload = { userId: '123', role: 'admin', permissions: [] }
    const token = await generateToken(payload)
    const decoded = await verifyToken(token)
    
    expect(decoded.userId).toBe('123')
  })
})
\`\`\`

### Validation Schema Tests

**Location**: `__tests__/lib/validation/schemas.test.ts`

\`\`\`typescript
import { createUserSchema } from '@/lib/validation/schemas'

describe('User Validation', () => {
  it('should validate correct user data', () => {
    const validUser = {
      username: 'testuser',
      email: 'test@example.com',
      password: 'StrongPass123!',
      full_name: 'Test User',
      role: 'admin',
    }
    
    const result = createUserSchema.safeParse(validUser)
    expect(result.success).toBe(true)
  })

  it('should reject invalid email', () => {
    const invalidUser = {
      username: 'testuser',
      email: 'invalid-email',
      password: 'StrongPass123!',
      full_name: 'Test User',
      role: 'admin',
    }
    
    const result = createUserSchema.safeParse(invalidUser)
    expect(result.success).toBe(false)
  })
})
\`\`\`

---

## Integration Tests

### API Endpoint Testing

**Example**: Testing the login endpoint

\`\`\`typescript
import { POST } from '@/app/api/auth/login/route'

describe('POST /api/auth/login', () => {
  it('should login with valid credentials', async () => {
    const request = new Request('http://localhost:3000/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: 'admin',
        password: 'password123',
      }),
    })

    const response = await POST(request)
    const data = await response.json()

    expect(response.status).toBe(200)
    expect(data.token).toBeDefined()
    expect(data.user).toBeDefined()
  })

  it('should reject invalid credentials', async () => {
    const request = new Request('http://localhost:3000/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: 'admin',
        password: 'wrongpassword',
      }),
    })

    const response = await POST(request)
    expect(response.status).toBe(401)
  })
})
\`\`\`

### Rate Limiting Tests

**Location**: `__tests__/lib/security/rate-limit-integration.test.ts`

Tests rate limiting functionality across multiple requests.

---

## Data Validation

### Using Zod Schemas

All API endpoints should validate input data using Zod schemas:

\`\`\`typescript
import { createDriverSchema } from '@/lib/validation/schemas'
import { validateOrRespond } from '@/lib/validation/validator'

export async function POST(request: Request) {
  // Validate request body
  const body = await validateOrRespond(createDriverSchema, await request.json())
  if (body instanceof NextResponse) return body

  // body is now typed and validated
  const driver = await createDriver(body)
  
  return NextResponse.json(driver)
}
\`\`\`

### Available Schemas

- `createUserSchema` / `updateUserSchema`
- `createDriverSchema` / `updateDriverSchema`
- `createVehicleSchema` / `updateVehicleSchema`
- `createMovementSchema` / `updateMovementSchema`
- `createReservationSchema` / `updateReservationSchema`
- `createTicketSchema` / `updateTicketSchema`
- `loginSchema`
- `paginationSchema`

### Custom Validation

\`\`\`typescript
import { z } from 'zod'

const customSchema = z.object({
  email: z.string().email(),
  age: z.number().min(18).max(100),
}).refine((data) => {
  // Custom validation logic
  return data.age >= 21 || data.email.endsWith('@company.com')
}, {
  message: "Must be 21+ or have company email",
})
\`\`\`

---

## Error Logging

### Using the Logger

\`\`\`typescript
import { logger } from '@/lib/logging/logger'

// Log error
logger.error('Database connection failed', {
  error: dbError,
  userId: '123',
  action: 'fetch_users',
})

// Log warning
logger.warn('Rate limit approaching', {
  ip: '192.168.1.1',
  requests: 95,
  limit: 100,
})

// Log info
logger.info('User logged in', {
  userId: '123',
  ip: '192.168.1.1',
})

// Log debug
logger.debug('Cache hit', {
  key: 'users:123',
  ttl: 3600,
})
\`\`\`

### Log Levels

- **ERROR**: Critical errors that need immediate attention
- **WARN**: Warning conditions that should be reviewed
- **INFO**: Informational messages about normal operations
- **DEBUG**: Detailed debugging information

### Viewing Logs

\`\`\`typescript
// Get recent logs
const recentLogs = logger.getRecentLogs(100)

// Get logs by level
const errorLogs = logger.getLogsByLevel(LogLevel.ERROR)

// Clear logs
logger.clearLogs()
\`\`\`

### Request/Response Logging

\`\`\`typescript
import { createRequestLogger } from '@/lib/logging/logger'

const requestLogger = createRequestLogger()

export async function GET(request: Request) {
  return requestLogger(request, async () => {
    // Your handler logic
    return NextResponse.json({ data: 'response' })
  })
}
\`\`\`

---

## Best Practices

### Testing Best Practices

1. **Write Tests First**: Follow TDD when possible
2. **Test Edge Cases**: Don't just test happy paths
3. **Mock External Dependencies**: Use Jest mocks for APIs, databases
4. **Keep Tests Isolated**: Each test should be independent
5. **Use Descriptive Names**: Test names should explain what they test
6. **Maintain Coverage**: Aim for 70%+ code coverage

### Validation Best Practices

1. **Validate Early**: Validate at API boundaries
2. **Provide Clear Errors**: Use descriptive error messages
3. **Use Type Inference**: Let Zod infer TypeScript types
4. **Reuse Schemas**: Don't duplicate validation logic
5. **Document Constraints**: Comment complex validation rules

### Logging Best Practices

1. **Log Appropriately**: Use correct log levels
2. **Include Context**: Add relevant metadata to logs
3. **Protect Sensitive Data**: Never log passwords or tokens
4. **Structure Logs**: Use consistent log formats
5. **Monitor Logs**: Set up alerts for errors

---

## Running Tests

### Run All Tests

\`\`\`bash
npm test
\`\`\`

### Run Specific Test File

\`\`\`bash
npm test password.test.ts
\`\`\`

### Run Tests in Watch Mode

\`\`\`bash
npm run test:watch
\`\`\`

### Run Tests with Coverage

\`\`\`bash
npm run test:coverage
\`\`\`

### View Coverage Report

After running coverage, open `coverage/lcov-report/index.html` in your browser.

---

## Continuous Integration

### GitHub Actions Example

\`\`\`yaml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '18'
      
      - run: npm install
      - run: npm test
      - run: npm run test:coverage
      
      - name: Upload coverage
        uses: codecov/codecov-action@v2
\`\`\`

---

## Troubleshooting

### Common Issues

**Issue**: Tests timeout
**Solution**: Increase Jest timeout in test file:
\`\`\`typescript
jest.setTimeout(10000) // 10 seconds
\`\`\`

**Issue**: Module not found errors
**Solution**: Check `moduleNameMapper` in jest.config.js

**Issue**: Validation fails unexpectedly
**Solution**: Use `.safeParse()` and inspect error details:
\`\`\`typescript
const result = schema.safeParse(data)
if (!result.success) {
  console.log(result.error.errors)
}
\`\`\`

---

## Next Steps

1. Write tests for all new features
2. Maintain test coverage above 70%
3. Add integration tests for critical workflows
4. Set up CI/CD pipeline with automated testing
5. Monitor error logs in production
6. Review and update validation schemas regularly

For more information, see:
- [Jest Documentation](https://jestjs.io/)
- [Zod Documentation](https://zod.dev/)
- [Testing Library](https://testing-library.com/)
