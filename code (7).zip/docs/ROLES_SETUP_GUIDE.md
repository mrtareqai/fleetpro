# دليل إعداد الأدوار والصلاحيات
# Roles and Permissions Setup Guide

## نظرة عامة | Overview

يحتوي نظام FleetPro على 6 أدوار أساسية مُعرّفة مسبقاً:

The FleetPro system includes 6 predefined core roles:

### الأدوار الافتراضية | Default Roles

1. **Super Administrator** (مدير النظام الأعلى)
   - الاسم التقني: `super_admin`
   - الوصف: Full system access (وصول كامل للنظام)
   - الصلاحيات: جميع الصلاحيات (*)

2. **Administrator** (المدير)
   - الاسم التقني: `admin`
   - الوصف: Administrative access (وصول إداري)
   - الصلاحيات: معظم الصلاحيات الإدارية

3. **Fleet Manager** (مدير الأسطول)
   - الاسم التقني: `fleet_manager`
   - الوصف: Manage fleet operations (إدارة عمليات الأسطول)
   - الصلاحيات: إدارة المركبات والسائقين

4. **Dispatcher** (المرسل)
   - الاسم التقني: `dispatcher`
   - الوصف: Manage reservations (إدارة الحجوزات)
   - الصلاحيات: إدارة الحجوزات والرحلات

5. **Maintenance Staff** (طاقم الصيانة)
   - الاسم التقني: `maintenance_staff`
   - الوصف: Manage maintenance (إدارة الصيانة)
   - الصلاحيات: إدارة الصيانة والإمدادات

6. **Viewer** (المشاهد)
   - الاسم التقني: `viewer`
   - الوصف: Read-only access (وصول للقراءة فقط)
   - الصلاحيات: عرض البيانات فقط

## إعداد قاعدة البيانات | Database Setup

### الخطوة 1: تشغيل سكريبت إنشاء الأدوار
### Step 1: Run the roles creation script

\`\`\`bash
# إذا كنت تستخدم Neon أو PostgreSQL
# If using Neon or PostgreSQL
psql -d your_database -f scripts/01_seed_default_roles.sql
\`\`\`

أو استخدم واجهة Neon SQL Editor:
Or use the Neon SQL Editor interface:

1. افتح لوحة تحكم Neon | Open Neon Dashboard
2. اذهب إلى SQL Editor | Go to SQL Editor
3. انسخ محتوى `scripts/01_seed_default_roles.sql` | Copy content from `scripts/01_seed_default_roles.sql`
4. شغّل السكريبت | Execute the script

### الخطوة 2: التحقق من الأدوار
### Step 2: Verify roles

\`\`\`sql
SELECT id, name, display_name, description, is_system 
FROM roles 
ORDER BY id;
\`\`\`

يجب أن ترى 6 أدوار:
You should see 6 roles:

| ID | Name | Display Name | Description |
|----|------|--------------|-------------|
| 1 | super_admin | Super Administrator | Full system access |
| 2 | admin | Administrator | Administrative access |
| 3 | fleet_manager | Fleet Manager | Manage fleet operations |
| 4 | dispatcher | Dispatcher | Manage reservations |
| 5 | maintenance_staff | Maintenance Staff | Manage maintenance |
| 6 | viewer | Viewer | Read-only access |

## استخدام صفحة إدارة الأدوار | Using the Roles Management Page

### الوصول إلى الصفحة | Accessing the Page

انتقل إلى: `/admin/roles?locale=ar` (للعربية) أو `/admin/roles?locale=en` (للإنجليزية)

Navigate to: `/admin/roles?locale=ar` (for Arabic) or `/admin/roles?locale=en` (for English)

### الميزات المتاحة | Available Features

#### 1. عرض الأدوار | View Roles
- جميع الأدوار الستة معروضة في بطاقات
- All six roles displayed in cards
- عرض عدد الصلاحيات لكل دور
- Display permission count for each role

#### 2. إضافة دور جديد | Add New Role
- انقر على زر "إضافة دور" | Click "Add Role" button
- املأ النموذج: | Fill the form:
  - اسم الدور (مثل: custom_manager) | Role Name (e.g., custom_manager)
  - الاسم المعروض (مثل: Custom Manager) | Display Name (e.g., Custom Manager)
  - الوصف | Description
  - اختر الصلاحيات | Select Permissions

#### 3. تعديل دور | Edit Role
- انقر على زر "تعديل" في بطاقة الدور | Click "Edit" button on role card
- عدّل الاسم المعروض والوصف والصلاحيات | Modify display name, description, and permissions
- الأدوار الأساسية محمية من الحذف | System roles are protected from deletion

#### 4. حذف دور | Delete Role
- انقر على زر "حذف" | Click "Delete" button
- ملاحظة: لا يمكن حذف الأدوار الأساسية (is_system = true)
- Note: System roles cannot be deleted (is_system = true)

## الصلاحيات المطلوبة | Required Permissions

للوصول إلى صفحة إدارة الأدوار، تحتاج إلى:
To access the roles management page, you need:

- `roles.read` - لعرض الأدوار | To view roles
- `roles.create` - لإضافة أدوار جديدة | To add new roles
- `roles.update` - لتعديل الأدوار | To edit roles
- `roles.delete` - لحذف الأدوار | To delete roles

## استكشاف الأخطاء | Troubleshooting

### المشكلة: الأدوار لا تظهر
### Issue: Roles not showing

**الحل | Solution:**
1. تحقق من اتصال قاعدة البيانات | Check database connection
2. تأكد من تشغيل سكريبت الأدوار | Ensure roles script was executed
3. تحقق من متغيرات البيئة | Verify environment variables
4. النظام يستخدم بيانات تجريبية تلقائياً عند فشل الاتصال
   The system automatically uses mock data when connection fails

### المشكلة: لا يمكن إضافة أو تعديل الأدوار
### Issue: Cannot add or edit roles

**الحل | Solution:**
1. تحقق من صلاحيات المستخدم | Check user permissions
2. تأكد من وجود جدول `roles` في قاعدة البيانات
   Ensure `roles` table exists in database
3. راجع سجلات الأخطاء في Console | Check error logs in Console

### المشكلة: الأدوار الأساسية لا تظهر كمحمية
### Issue: System roles not showing as protected

**الحل | Solution:**
- تأكد من أن حقل `is_system` في قاعدة البيانات مضبوط على `true`
  Ensure `is_system` field in database is set to `true`

## البيانات التجريبية | Mock Data

عند عدم توفر قاعدة البيانات، يستخدم النظام بيانات تجريبية من:
When database is unavailable, the system uses mock data from:

- `lib/mock-store.ts` - يحتوي على الأدوار الستة الافتراضية
  Contains the six default roles
- `app/admin/roles/page.tsx` - دالة `getMockRoles()` للبيانات الاحتياطية
  `getMockRoles()` function for fallback data

## كيفية تشغيل السكريبت من v0 | How to Run Script from v0

لا تحتاج إلى مغادرة v0 لتشغيل سكريبت SQL:
You don't need to leave v0 to run the SQL script:

1. السكريبت موجود في: `scripts/01_seed_default_roles.sql`
   The script is located at: `scripts/01_seed_default_roles.sql`

2. يمكنك تشغيله مباشرة من v0 إذا كانت قاعدة البيانات متصلة
   You can run it directly from v0 if database is connected

3. أو انسخ المحتوى والصقه في Neon SQL Editor
   Or copy the content and paste it in Neon SQL Editor

## الخلاصة | Summary

نظام الأدوار في FleetPro مصمم ليكون:
The FleetPro roles system is designed to be:

- ✅ مرن - يمكن إضافة أدوار مخصصة | Flexible - custom roles can be added
- ✅ آمن - الأدوار الأساسية محمية | Secure - system roles are protected
- ✅ قابل للتوسع - يدعم صلاحيات متعددة | Scalable - supports multiple permissions
- ✅ موثوق - يعمل مع أو بدون قاعدة بيانات | Reliable - works with or without database

## الحالة الحالية | Current Status

✅ صفحة إدارة الأدوار تعمل بشكل كامل
✅ Roles management page is fully functional

✅ الأدوار الستة معروضة بشكل صحيح
✅ All six roles are displayed correctly

✅ يمكن إضافة وتعديل وحذف الأدوار المخصصة
✅ Custom roles can be added, edited, and deleted

✅ الأدوار الأساسية محمية من الحذف
✅ System roles are protected from deletion

✅ النظام يعمل مع أو بدون قاعدة بيانات
✅ System works with or without database connection
