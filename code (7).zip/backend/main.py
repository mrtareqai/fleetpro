"""
FleetPro Management System - FastAPI Backend
Main application entry point
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio
from typing import List
import json

from .database import engine, Base
from .routers import auth, vehicles, drivers, reservations, tickets, movements, supplies, dashboard
from .websocket_manager import ConnectionManager

# WebSocket connection manager
manager = ConnectionManager()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup: Create database tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # Shutdown: Close connections
    await engine.dispose()

# Initialize FastAPI app
app = FastAPI(
    title="FleetPro Management API",
    description="Backend API for FleetPro Management System",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(vehicles.router, prefix="/api/vehicles", tags=["Vehicles"])
app.include_router(drivers.router, prefix="/api/drivers", tags=["Drivers"])
app.include_router(reservations.router, prefix="/api/reservations", tags=["Reservations"])
app.include_router(tickets.router, prefix="/api/tickets", tags=["Tickets"])
app.include_router(movements.router, prefix="/api/movements", tags=["Movements"])
app.include_router(supplies.router, prefix="/api/supplies", tags=["Agency Supplies"])
app.include_router(dashboard.router, prefix="/api/dashboard", tags=["Dashboard"])

@app.get("/")
async def root():
    return {
        "message": "FleetPro Management API",
        "version": "1.0.0",
        "docs": "/docs"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

# WebSocket endpoint for real-time updates
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await manager.connect(websocket, client_id)
    try:
        while True:
            data = await websocket.receive_text()
            # Echo back or process the message
            await manager.send_personal_message(f"Message received: {data}", client_id)
    except WebSocketDisconnect:
        manager.disconnect(client_id)
        await manager.broadcast(f"Client {client_id} disconnected")

# Broadcast function for real-time updates
async def broadcast_update(event_type: str, data: dict):
    """Broadcast updates to all connected clients"""
    message = json.dumps({
        "type": event_type,
        "data": data,
        "timestamp": asyncio.get_event_loop().time()
    })
    await manager.broadcast(message)
