import type { NextRequest } from "next/server"

export interface PaginationParams {
  page: number
  limit: number
  offset: number
  sort?: string
  order: "asc" | "desc"
}

export interface CursorPaginationParams {
  cursor?: string
  limit: number
  sort?: string
  order: "asc" | "desc"
}

export interface PaginationMeta {
  page: number
  limit: number
  total: number
  totalPages: number
  hasNext: boolean
  hasPrev: boolean
}

export interface CursorPaginationMeta {
  limit: number
  hasNext: boolean
  hasPrev: boolean
  nextCursor?: string
  prevCursor?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  pagination: PaginationMeta
}

export interface CursorPaginatedResponse<T> {
  data: T[]
  pagination: CursorPaginationMeta
}

/**
 * Extract pagination parameters from request (Offset-based)
 *
 * Offset-based pagination is simple and intuitive:
 * - Easy to implement and understand
 * - Supports jumping to any page
 * - Good for small to medium datasets
 *
 * Limitations:
 * - Performance degrades with large offsets
 * - Inconsistent results if data changes between requests
 * - Not suitable for real-time data
 */
export function getPaginationParams(request: NextRequest): PaginationParams {
  const { searchParams } = new URL(request.url)

  const page = Math.max(1, Number.parseInt(searchParams.get("page") || "1", 10))
  const limit = Math.min(100, Math.max(1, Number.parseInt(searchParams.get("limit") || "20", 10)))
  const offset = (page - 1) * limit
  const sort = searchParams.get("sort") || undefined
  const order = (searchParams.get("order") || "desc") as "asc" | "desc"

  return { page, limit, offset, sort, order }
}

/**
 * Extract cursor pagination parameters from request (Cursor-based)
 *
 * Cursor-based pagination is more efficient for large datasets:
 * - Consistent performance regardless of dataset size
 * - Handles data changes gracefully
 * - Perfect for infinite scroll and real-time data
 *
 * Limitations:
 * - Cannot jump to arbitrary pages
 * - More complex to implement
 * - Requires indexed cursor field
 */
export function getCursorPaginationParams(request: NextRequest): CursorPaginationParams {
  const { searchParams } = new URL(request.url)

  const cursor = searchParams.get("cursor") || undefined
  const limit = Math.min(100, Math.max(1, Number.parseInt(searchParams.get("limit") || "20", 10)))
  const sort = searchParams.get("sort") || "created_at"
  const order = (searchParams.get("order") || "desc") as "asc" | "desc"

  return { cursor, limit, sort, order }
}

/**
 * Create pagination metadata
 */
export function createPaginationMeta(page: number, limit: number, total: number): PaginationMeta {
  const totalPages = Math.ceil(total / limit)

  return {
    page,
    limit,
    total,
    totalPages,
    hasNext: page < totalPages,
    hasPrev: page > 1,
  }
}

/**
 * Create cursor pagination metadata
 */
export function createCursorPaginationMeta(data: any[], limit: number, cursorField = "id"): CursorPaginationMeta {
  const hasNext = data.length === limit
  const hasPrev = data.length > 0

  return {
    limit,
    hasNext,
    hasPrev,
    nextCursor: hasNext && data.length > 0 ? encodeCursor(data[data.length - 1][cursorField]) : undefined,
    prevCursor: hasPrev && data.length > 0 ? encodeCursor(data[0][cursorField]) : undefined,
  }
}

/**
 * Create paginated response
 */
export function createPaginatedResponse<T>(
  data: T[],
  page: number,
  limit: number,
  total: number,
): PaginatedResponse<T> {
  return {
    data,
    pagination: createPaginationMeta(page, limit, total),
  }
}

/**
 * Create cursor paginated response
 */
export function createCursorPaginatedResponse<T>(
  data: T[],
  limit: number,
  cursorField = "id",
): CursorPaginatedResponse<T> {
  return {
    data,
    pagination: createCursorPaginationMeta(data, limit, cursorField),
  }
}

/**
 * Extract search parameters from request
 */
export function getSearchParams(request: NextRequest): {
  search?: string
  status?: string
  startDate?: string
  endDate?: string
} {
  const { searchParams } = new URL(request.url)

  return {
    search: searchParams.get("search") || undefined,
    status: searchParams.get("status") || undefined,
    startDate: searchParams.get("start_date") || undefined,
    endDate: searchParams.get("end_date") || undefined,
  }
}

/**
 * Encode cursor for pagination
 * Uses base64 encoding to hide internal IDs
 */
export function encodeCursor(value: string | number): string {
  return Buffer.from(String(value)).toString("base64")
}

/**
 * Decode cursor for pagination
 */
export function decodeCursor(cursor: string): string {
  try {
    return Buffer.from(cursor, "base64").toString("utf-8")
  } catch {
    throw new Error("Invalid cursor format")
  }
}

/**
 * Build SQL ORDER BY clause from pagination params
 */
export function buildOrderByClause(sort?: string, order: "asc" | "desc" = "desc"): string {
  const validSortFields = ["id", "created_at", "updated_at", "name", "status", "date", "trip_date", "pickup_date"]

  const sortField = sort && validSortFields.includes(sort) ? sort : "created_at"
  const sortOrder = order === "asc" ? "ASC" : "DESC"

  return `ORDER BY ${sortField} ${sortOrder}`
}

/**
 * Calculate optimal page size based on data characteristics
 *
 * Strategy:
 * - Small records (< 1KB): 50-100 items
 * - Medium records (1-10KB): 20-50 items
 * - Large records (> 10KB): 10-20 items
 */
export function calculateOptimalPageSize(avgRecordSize: number): number {
  if (avgRecordSize < 1024) {
    return 100 // Small records
  } else if (avgRecordSize < 10240) {
    return 50 // Medium records
  } else {
    return 20 // Large records
  }
}

/**
 * Generate cache key for paginated data
 *
 * Includes all parameters that affect the result:
 * - Resource type
 * - Pagination params
 * - Filters
 * - Sort order
 */
export function generatePaginationCacheKey(
  resource: string,
  params: {
    page?: number
    limit?: number
    cursor?: string
    search?: string
    status?: string
    sort?: string
    order?: string
    [key: string]: any
  },
): string {
  const sortedParams = Object.keys(params)
    .sort()
    .map((key) => `${key}:${params[key] || "all"}`)
    .join(":")

  return `${resource}:${sortedParams}`
}

/**
 * Validate pagination parameters
 */
export function validatePaginationParams(page: number, limit: number): { valid: boolean; error?: string } {
  if (page < 1) {
    return { valid: false, error: "Page must be greater than 0" }
  }

  if (limit < 1 || limit > 100) {
    return { valid: false, error: "Limit must be between 1 and 100" }
  }

  // Prevent extremely large offsets that could cause performance issues
  const offset = (page - 1) * limit
  if (offset > 10000) {
    return {
      valid: false,
      error: "Offset too large. Please use cursor-based pagination for large datasets",
    }
  }

  return { valid: true }
}
