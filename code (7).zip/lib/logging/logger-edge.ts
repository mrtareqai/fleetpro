/**
 * Edge Runtime Compatible Logger
 *
 * Simplified logger for use in middleware and edge functions
 * Does not include file system operations or Node.js-specific APIs
 */

export enum LogLevel {
  ERROR = "ERROR",
  WARN = "WARN",
  INFO = "INFO",
  DEBUG = "DEBUG",
}

export interface LogEntry {
  level: LogLevel
  message: string
  timestamp: string
  context?: Record<string, any>
}

class EdgeLogger {
  private minLevel: LogLevel

  constructor() {
    this.minLevel = process.env.NODE_ENV === "production" ? LogLevel.INFO : LogLevel.DEBUG
  }

  private shouldLog(level: LogLevel): boolean {
    const levels = [LogLevel.DEBUG, LogLevel.INFO, LogLevel.WARN, LogLevel.ERROR]
    const minLevelIndex = levels.indexOf(this.minLevel)
    const currentLevelIndex = levels.indexOf(level)
    return currentLevelIndex >= minLevelIndex
  }

  private formatMessage(level: LogLevel, message: string, context?: Record<string, any>): string {
    const timestamp = new Date().toISOString()
    const emoji = {
      [LogLevel.ERROR]: "🔴",
      [LogLevel.WARN]: "🟡",
      [LogLevel.INFO]: "🔵",
      [LogLevel.DEBUG]: "⚪",
    }

    let output = `${emoji[level]} [${level}] ${timestamp} - ${message}`

    if (context && Object.keys(context).length > 0) {
      output += ` ${JSON.stringify(context)}`
    }

    return output
  }

  error(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.ERROR)) return
    console.error(this.formatMessage(LogLevel.ERROR, message, context))
  }

  warn(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.WARN)) return
    console.warn(this.formatMessage(LogLevel.WARN, message, context))
  }

  info(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.INFO)) return
    console.info(this.formatMessage(LogLevel.INFO, message, context))
  }

  debug(message: string, context?: Record<string, any>): void {
    if (!this.shouldLog(LogLevel.DEBUG)) return
    console.debug(this.formatMessage(LogLevel.DEBUG, message, context))
  }
}

export const logger = new EdgeLogger()
