/**
 * Mock Data Cache System
 * Improves performance by caching mock responses
 */

import { mockConfig } from "./mock-config"

interface CacheEntry<T> {
  data: T
  timestamp: number
  expiresAt: number
}

class MockCache {
  private cache: Map<string, CacheEntry<any>> = new Map()

  set<T>(key: string, data: T, duration?: number): void {
    if (!mockConfig.cacheEnabled) return

    const now = Date.now()
    const expiresAt = now + (duration || mockConfig.cacheDuration)

    this.cache.set(key, {
      data,
      timestamp: now,
      expiresAt,
    })
  }

  get<T>(key: string): T | null {
    if (!mockConfig.cacheEnabled) return null

    const entry = this.cache.get(key)
    if (!entry) return null

    const now = Date.now()
    if (now > entry.expiresAt) {
      this.cache.delete(key)
      return null
    }

    return entry.data as T
  }

  invalidate(key: string): void {
    this.cache.delete(key)
  }

  invalidatePattern(pattern: string): void {
    const regex = new RegExp(pattern)
    for (const key of this.cache.keys()) {
      if (regex.test(key)) {
        this.cache.delete(key)
      }
    }
  }

  clear(): void {
    this.cache.clear()
  }

  getStats() {
    return {
      size: this.cache.size,
      entries: Array.from(this.cache.keys()),
    }
  }
}

export const mockCache = new MockCache()
