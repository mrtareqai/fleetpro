/**
 * JWT Authentication Unit Tests
 */

import { describe, it, expect } from "@jest/globals"
import {
  generateToken,
  generateRefreshToken,
  verifyToken,
  extractTokenFromHeader,
  decodeTokenUnsafe,
  type JWTPayload,
} from "@/lib/security/jwt"

describe("JWT Authentication", () => {
  const mockPayload: JWTPayload = {
    userId: "123",
    role: "admin",
    permissions: ["users.read", "users.write"],
    companyId: 1,
  }

  describe("generateToken", () => {
    it("should generate a valid JWT token", async () => {
      const token = await generateToken(mockPayload)

      expect(token).toBeDefined()
      expect(typeof token).toBe("string")
      expect(token.split(".")).toHaveLength(3)
    })

    it("should include payload data in token", async () => {
      const token = await generateToken(mockPayload)
      const decoded = decodeTokenUnsafe(token)

      expect(decoded).toBeDefined()
      expect(decoded?.userId).toBe(mockPayload.userId)
      expect(decoded?.role).toBe(mockPayload.role)
      expect(decoded?.permissions).toEqual(mockPayload.permissions)
      expect(decoded?.companyId).toBe(mockPayload.companyId)
    })

    it("should include expiration time", async () => {
      const token = await generateToken(mockPayload)
      const decoded = decodeTokenUnsafe(token)

      expect(decoded?.exp).toBeDefined()
      expect(decoded?.iat).toBeDefined()
      expect(decoded!.exp).toBeGreaterThan(decoded!.iat)
    })
  })

  describe("generateRefreshToken", () => {
    it("should generate a refresh token", async () => {
      const refreshToken = await generateRefreshToken(mockPayload)

      expect(refreshToken).toBeDefined()
      expect(typeof refreshToken).toBe("string")
      expect(refreshToken.split(".")).toHaveLength(3)
    })

    it("should have longer expiration than access token", async () => {
      const accessToken = await generateToken(mockPayload)
      const refreshToken = await generateRefreshToken(mockPayload)

      const accessDecoded = decodeTokenUnsafe(accessToken)
      const refreshDecoded = decodeTokenUnsafe(refreshToken)

      expect(refreshDecoded!.exp).toBeGreaterThan(accessDecoded!.exp)
    })
  })

  describe("verifyToken", () => {
    it("should verify valid token", async () => {
      const token = await generateToken(mockPayload)
      const decoded = await verifyToken(token)

      expect(decoded).toBeDefined()
      expect(decoded.userId).toBe(mockPayload.userId)
      expect(decoded.role).toBe(mockPayload.role)
    })

    it("should reject invalid token", async () => {
      const invalidToken = "invalid.token.here"

      await expect(verifyToken(invalidToken)).rejects.toThrow("Invalid token")
    })

    it("should reject malformed token", async () => {
      const malformedToken = "not-a-jwt-token"

      await expect(verifyToken(malformedToken)).rejects.toThrow()
    })

    it("should reject empty token", async () => {
      await expect(verifyToken("")).rejects.toThrow()
    })
  })

  describe("extractTokenFromHeader", () => {
    it("should extract token from valid Bearer header", () => {
      const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test.token"
      const header = `Bearer ${token}`
      const extracted = extractTokenFromHeader(header)

      expect(extracted).toBe(token)
    })

    it("should return null for missing header", () => {
      const extracted = extractTokenFromHeader(null)
      expect(extracted).toBeNull()
    })

    it("should return null for invalid format", () => {
      const extracted = extractTokenFromHeader("InvalidFormat token")
      expect(extracted).toBeNull()
    })

    it("should return null for missing Bearer prefix", () => {
      const extracted = extractTokenFromHeader("token-without-bearer")
      expect(extracted).toBeNull()
    })

    it("should return null for empty string", () => {
      const extracted = extractTokenFromHeader("")
      expect(extracted).toBeNull()
    })
  })

  describe("decodeTokenUnsafe", () => {
    it("should decode valid token without verification", async () => {
      const token = await generateToken(mockPayload)
      const decoded = decodeTokenUnsafe(token)

      expect(decoded).toBeDefined()
      expect(decoded?.userId).toBe(mockPayload.userId)
    })

    it("should return null for invalid token", () => {
      const decoded = decodeTokenUnsafe("invalid-token")
      expect(decoded).toBeNull()
    })
  })
})
