-- Companies table for multi-tenant system
DROP TABLE IF EXISTS companies CASCADE;

CREATE TABLE companies (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    owner_name VARCHAR(255) NOT NULL,
    contact_number VARCHAR(50),
    email VARCHAR(255) UNIQUE NOT NULL,
    neon_url TEXT NOT NULL,
    github_api_key TEXT,
    admin_username VARCHAR(100) NOT NULL,
    admin_password VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Add company_id to users table if not exists
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'users' AND column_name = 'company_id'
    ) THEN
        ALTER TABLE users ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL;
    END IF;
END $$;

-- Add company_id to other tables for multi-tenancy
DO $$ 
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'vehicles' AND column_name = 'company_id'
    ) THEN
        ALTER TABLE vehicles ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL;
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'drivers' AND column_name = 'company_id'
    ) THEN
        ALTER TABLE drivers ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL;
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'reservations' AND column_name = 'company_id'
    ) THEN
        ALTER TABLE reservations ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL;
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'tickets' AND column_name = 'company_id'
    ) THEN
        ALTER TABLE tickets ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL;
    END IF;
    
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_name = 'movements' AND column_name = 'company_id'
    ) THEN
        ALTER TABLE movements ADD COLUMN company_id INTEGER REFERENCES companies(id) ON DELETE SET NULL;
    END IF;
END $$;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_companies_email ON companies(email);
CREATE INDEX IF NOT EXISTS idx_companies_active ON companies(is_active);
CREATE INDEX IF NOT EXISTS idx_users_company ON users(company_id);
CREATE INDEX IF NOT EXISTS idx_vehicles_company ON vehicles(company_id);

-- Create trigger for companies updated_at
DROP TRIGGER IF EXISTS update_companies_updated_at ON companies;
CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Insert demo company
INSERT INTO companies (name, owner_name, contact_number, email, neon_url, admin_username, admin_password, is_active)
VALUES ('Demo Company', 'Demo Owner', '+966501234567', 'demo@fleetpro.com', '', 'admin', 'password123', true)
ON CONFLICT (email) DO NOTHING;
