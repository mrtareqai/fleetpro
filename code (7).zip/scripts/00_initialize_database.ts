// Database Initialization Script
// Runs all SQL migrations in the correct order to set up the FleetPro database

import { neon } from "@neondatabase/serverless"
import { readFileSync } from "fs"
import { join } from "path"

const dbUrl = process.env.NEON_DATABASE_URL

if (!dbUrl) {
  console.error("❌ NEON_DATABASE_URL environment variable is not set")
  process.exit(1)
}

const sql = neon(dbUrl)

// SQL scripts to run in order
const scripts = [
  "01_create_tables.sql",
  "03_rbac_schema.sql",
  "09_create_companies_table.sql",
  "04_update_movements_schema.sql",
  "06_update_tickets_schema.sql",
  "08_update_vehicles_schema.sql",
  "02_seed_data.sql",
  "05_seed_movements_data.sql",
  "07_seed_tickets_data.sql",
]

async function initializeDatabase() {
  console.log("🚀 Starting database initialization...")
  console.log("=".repeat(60))

  for (const scriptName of scripts) {
    try {
      console.log(`\n📄 Running: ${scriptName}`)

      const scriptPath = join(process.cwd(), "scripts", scriptName)
      const scriptContent = readFileSync(scriptPath, "utf-8")

      // Split by semicolon and filter out empty statements
      const statements = scriptContent
        .split(";")
        .map((s) => s.trim())
        .filter((s) => s.length > 0 && !s.startsWith("--"))

      for (const statement of statements) {
        if (statement) {
          await sql(statement)
        }
      }

      console.log(`✅ Completed: ${scriptName}`)
    } catch (error) {
      console.error(`❌ Error in ${scriptName}:`, error)
      // Continue with other scripts even if one fails
    }
  }

  console.log("\n" + "=".repeat(60))
  console.log("🎉 Database initialization completed!")
  console.log("\n📊 Verifying database structure...")

  try {
    // Verify tables were created
    const tables = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public' 
      ORDER BY table_name
    `

    console.log(`\n✅ Found ${tables.length} tables:`)
    tables.forEach((table: any) => {
      console.log(`   - ${table.table_name}`)
    })

    // Count records in key tables
    const userCount = await sql`SELECT COUNT(*) as count FROM users`
    const vehicleCount = await sql`SELECT COUNT(*) as count FROM vehicles`
    const driverCount = await sql`SELECT COUNT(*) as count FROM drivers`
    const roleCount = await sql`SELECT COUNT(*) as count FROM roles`

    console.log("\n📈 Sample data counts:")
    console.log(`   - Users: ${userCount[0].count}`)
    console.log(`   - Vehicles: ${vehicleCount[0].count}`)
    console.log(`   - Drivers: ${driverCount[0].count}`)
    console.log(`   - Roles: ${roleCount[0].count}`)

    console.log("\n✨ Database is ready to use!")
  } catch (error) {
    console.error("❌ Error verifying database:", error)
  }
}

// Run initialization
initializeDatabase().catch(console.error)
