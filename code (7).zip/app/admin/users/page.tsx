"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import DashboardLayout from "@/components/dashboard-layout"
import { Plus, Edit, Trash2, Shield, CheckCircle2, Search, Calendar, User, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import ProtectedRoute from "@/components/protected-route"
import PermissionGate from "@/components/permission-gate"
import { authenticatedFetch, handleApiResponse } from "@/lib/api-helpers"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

interface UserInterface {
  id: string
  username: string
  email: string
  full_name: string
  roles: Array<{ id: number; name: string; display_name: string }>
  created_at: string
  created_by?: string
  updated_at?: string
  updated_by?: string
  last_login?: string
  is_active?: boolean
}

interface Role {
  id: number
  name: string
  display_name: string
  description: string
}

export default function UsersManagementPage() {
  const searchParams = useSearchParams()
  const locale = (searchParams.get("locale") as "en" | "ar") || "en"

  const [users, setUsers] = useState<UserInterface[]>([])
  const [roles, setRoles] = useState<Role[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [successMessage, setSuccessMessage] = useState("")
  const [isAddModalOpen, setIsAddModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<UserInterface | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [userToDelete, setUserToDelete] = useState<UserInterface | null>(null)
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    password: "",
    full_name: "",
    role_ids: [] as number[],
    is_active: true,
  })

  const t = {
    en: {
      title: "User Management",
      addUser: "Add User",
      username: "Username",
      email: "Email",
      fullName: "Full Name",
      roles: "Roles",
      actions: "Actions",
      edit: "Edit",
      delete: "Delete",
      cancel: "Cancel",
      save: "Save",
      password: "Password",
      selectRoles: "Select Roles",
      confirmDelete: "Are you sure you want to delete this user?",
      createdAt: "Created At",
      search: "Search users...",
      noResults: "No users found",
      createdBy: "Created by",
      updatedAt: "Last updated",
      updatedBy: "Updated by",
      lastLogin: "Last login",
      active: "Active",
      inactive: "Inactive",
      status: "Status",
      deleteConfirmTitle: "Delete User",
      deleteConfirmDescription:
        "This action cannot be undone. This will permanently delete the user account and remove all associated data.",
      userDetails: "User Details",
      never: "Never",
      statusDescription: "Enable or disable user account access",
    },
    ar: {
      title: "إدارة المستخدمين",
      addUser: "إضافة مستخدم",
      username: "اسم المستخدم",
      email: "البريد الإلكتروني",
      fullName: "الاسم الكامل",
      roles: "الأدوار",
      actions: "الإجراءات",
      edit: "تعديل",
      delete: "حذف",
      cancel: "إلغاء",
      save: "حفظ",
      password: "كلمة المرور",
      selectRoles: "اختر الأدوار",
      confirmDelete: "هل أنت متأكد من حذف هذا المستخدم؟",
      createdAt: "تاريخ الإنشاء",
      search: "البحث عن المستخدمين...",
      noResults: "لم يتم العثور على مستخدمين",
      createdBy: "أنشئ بواسطة",
      updatedAt: "آخر تحديث",
      updatedBy: "حدث بواسطة",
      lastLogin: "آخر تسجيل دخول",
      active: "نشط",
      inactive: "معطل",
      status: "الحالة",
      deleteConfirmTitle: "حذف المستخدم",
      deleteConfirmDescription:
        "لا يمكن التراجع عن هذا الإجراء. سيتم حذف حساب المستخدم نهائياً وإزالة جميع البيانات المرتبطة.",
      userDetails: "تفاصيل المستخدم",
      never: "أبداً",
      statusDescription: "تفعيل أو تعطيل وصول المستخدم للحساب",
    },
  }

  useEffect(() => {
    fetchUsers()
    fetchRoles()
  }, [])

  const fetchUsers = async () => {
    try {
      const response = await authenticatedFetch("/api/admin/users")
      const data = await handleApiResponse<{ users: UserInterface[] }>(response)
      setUsers(data.users || [])
    } catch (error) {
      console.error("[v0] Error fetching users:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchRoles = async () => {
    try {
      const response = await authenticatedFetch("/api/admin/roles")
      const data = await handleApiResponse<{ roles: Role[] }>(response)
      setRoles(data.roles || [])
    } catch (error) {
      console.error("[v0] Error fetching roles:", error)
    }
  }

  const handleAddUser = async () => {
    if (!formData.username || !formData.email || !formData.password || !formData.full_name) {
      alert(locale === "en" ? "Please fill in all required fields" : "يرجى ملء جميع الحقول المطلوبة")
      return
    }

    if (formData.role_ids.length === 0) {
      alert(locale === "en" ? "Please select at least one role" : "يرجى اختيار دور واحد على الأقل")
      return
    }

    setSaving(true)
    console.log("[v0] handleAddUser called with formData:", formData)

    try {
      const response = await authenticatedFetch("/api/admin/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      console.log("[v0] Add user response status:", response.status)
      const result = await handleApiResponse(response)

      console.log("[v0] Add user successful, closing modal and refreshing")

      if (result && result.user) {
        setUsers((prev) => [...prev, result.user])
      }

      setIsAddModalOpen(false)
      setFormData({ username: "", email: "", password: "", full_name: "", role_ids: [], is_active: true })

      setSuccessMessage(locale === "en" ? "User added successfully!" : "تمت إضافة المستخدم بنجاح!")
      setTimeout(() => setSuccessMessage(""), 3000)

      await fetchUsers()
    } catch (error) {
      console.error("[v0] Error adding user:", error)
      alert(
        locale === "en" ? "Failed to add user. Please try again." : "فشل في إضافة المستخدم. يرجى المحاولة مرة أخرى.",
      )
    } finally {
      setSaving(false)
    }
  }

  const handleEditUser = async () => {
    if (!selectedUser) return

    if (!formData.username || !formData.email || !formData.full_name) {
      alert(locale === "en" ? "Please fill in all required fields" : "يرجى ملء جميع الحقول المطلوبة")
      return
    }

    setSaving(true)
    console.log("[v0] handleEditUser called with formData:", formData)

    try {
      const response = await authenticatedFetch(`/api/admin/users/${selectedUser.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      console.log("[v0] Edit user response status:", response.status)
      const result = await handleApiResponse(response)

      console.log("[v0] Edit user successful, closing modal and refreshing")

      if (result && result.user) {
        setUsers((prev) => prev.map((u) => (u.id === selectedUser.id ? result.user : u)))
      }

      setIsEditModalOpen(false)
      setSelectedUser(null)
      setFormData({ username: "", email: "", password: "", full_name: "", role_ids: [], is_active: true })

      setSuccessMessage(locale === "en" ? "User updated successfully!" : "تم تحديث المستخدم بنجاح!")
      setTimeout(() => setSuccessMessage(""), 3000)

      await fetchUsers()
    } catch (error) {
      console.error("[v0] Error updating user:", error)
      alert(
        locale === "en" ? "Failed to update user. Please try again." : "فشل في تحديث المستخدم. يرجى المحاولة مرة أخرى.",
      )
    } finally {
      setSaving(false)
    }
  }

  const handleDeleteUser = async (userId: string) => {
    try {
      const response = await authenticatedFetch(`/api/admin/users/${userId}`, {
        method: "DELETE",
      })

      await handleApiResponse(response)
      setUserToDelete(null)
      setSuccessMessage(locale === "en" ? "User deleted successfully!" : "تم حذف المستخدم بنجاح!")
      setTimeout(() => setSuccessMessage(""), 3000)
      fetchUsers()
    } catch (error) {
      console.error("[v0] Error deleting user:", error)
      alert(locale === "en" ? "Failed to delete user" : "فشل في حذف المستخدم")
    }
  }

  const openEditModal = (user: UserInterface) => {
    setSelectedUser(user)
    setFormData({
      username: user.username,
      email: user.email,
      password: "",
      full_name: user.full_name,
      role_ids: user.roles.map((r) => r.id),
      is_active: user.is_active !== false,
    })
    setIsEditModalOpen(true)
  }

  const toggleRole = (roleId: number) => {
    setFormData((prev) => ({
      ...prev,
      role_ids: prev.role_ids.includes(roleId)
        ? prev.role_ids.filter((id) => id !== roleId)
        : [...prev.role_ids, roleId],
    }))
  }

  const filteredUsers = users.filter(
    (user) =>
      user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.full_name.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const formatDate = (dateString?: string) => {
    if (!dateString) return t[locale].never
    const date = new Date(dateString)
    return date.toLocaleDateString(locale === "ar" ? "ar-SA" : "en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <ProtectedRoute requiredPermission="users.read">
      <DashboardLayout locale={locale} activePage="users">
        <div className="p-6 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <h1 className="text-2xl md:text-3xl font-bold text-slate-800">{t[locale].title}</h1>
            <PermissionGate permission="users.create">
              <Button onClick={() => setIsAddModalOpen(true)} className="flex items-center gap-2">
                <Plus className="w-4 h-4" />
                {t[locale].addUser}
              </Button>
            </PermissionGate>
          </div>

          {successMessage && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              <p className="text-green-800 font-medium">{successMessage}</p>
            </div>
          )}

          <div className="bg-white rounded-lg shadow p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <Input
                type="text"
                placeholder={t[locale].search}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-12 text-center">
              <User className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">{t[locale].noResults}</p>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].username}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].email}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].fullName}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].roles}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].status}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].createdAt}
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">
                        {t[locale].actions}
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-slate-200">
                    {filteredUsers.map((user) => (
                      <tr key={user.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                              <User className="w-4 h-4 text-blue-600" />
                            </div>
                            <span className="text-sm font-medium text-slate-900">{user.username}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{user.email}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{user.full_name}</td>
                        <td className="px-6 py-4 text-sm text-slate-500">
                          <div className="flex flex-wrap gap-1">
                            {user.roles?.map((role) => (
                              <span
                                key={role.id}
                                className="inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                              >
                                <Shield className="w-3 h-3" />
                                {role.display_name}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              user.is_active !== false ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"
                            }`}
                          >
                            {user.is_active !== false ? t[locale].active : t[locale].inactive}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4 text-slate-400" />
                            <span>{formatDate(user.created_at)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          <div className="flex items-center gap-2">
                            <PermissionGate permission="users.update">
                              <button
                                onClick={() => openEditModal(user)}
                                className="text-blue-600 hover:text-blue-900 p-1 hover:bg-blue-50 rounded transition-colors"
                                title={t[locale].edit}
                              >
                                <Edit className="w-4 h-4" />
                              </button>
                            </PermissionGate>
                            <PermissionGate permission="users.delete">
                              <button
                                onClick={() => setUserToDelete(user)}
                                className="text-red-600 hover:text-red-900 p-1 hover:bg-red-50 rounded transition-colors"
                                title={t[locale].delete}
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </PermissionGate>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          <AlertDialog open={!!userToDelete} onOpenChange={() => setUserToDelete(null)}>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>{t[locale].deleteConfirmTitle}</AlertDialogTitle>
                <AlertDialogDescription>
                  {t[locale].deleteConfirmDescription}
                  {userToDelete && (
                    <div className="mt-4 p-3 bg-slate-50 rounded-lg">
                      <p className="font-medium text-slate-900">
                        {userToDelete.full_name} ({userToDelete.username})
                      </p>
                      <p className="text-sm text-slate-600">{userToDelete.email}</p>
                    </div>
                  )}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>{t[locale].cancel}</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => userToDelete && handleDeleteUser(userToDelete.id)}
                  className="bg-red-600 hover:bg-red-700"
                >
                  {t[locale].delete}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          {/* Add User Modal */}
          <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>{t[locale].addUser}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="username">{t[locale].username}</Label>
                  <Input
                    id="username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">{t[locale].email}</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">{t[locale].password}</Label>
                  <Input
                    id="password"
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="full_name">{t[locale].fullName}</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="status">{t[locale].status}</Label>
                      <p className="text-sm text-slate-500">{t[locale].statusDescription}</p>
                    </div>
                    <Switch
                      id="status"
                      checked={formData.is_active}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>{t[locale].selectRoles}</Label>
                  <div className="space-y-2 max-h-48 overflow-y-auto border rounded-md p-3">
                    {roles.map((role) => (
                      <label key={role.id} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.role_ids.includes(role.id)}
                          onChange={() => toggleRole(role.id)}
                          className="rounded border-slate-300"
                        />
                        <span className="text-sm">
                          {role.display_name}
                          <span className="text-slate-500 text-xs ml-2">({role.description})</span>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsAddModalOpen(false)} disabled={saving}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleAddUser} disabled={saving}>
                  {saving ? (locale === "en" ? "Saving..." : "جاري الحفظ...") : t[locale].save}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Edit User Modal */}
          <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
            <DialogContent className="sm:max-w-[500px]">
              <DialogHeader>
                <DialogTitle>
                  {t[locale].edit} {selectedUser?.username}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                {selectedUser && (
                  <div className="bg-slate-50 rounded-lg p-3 space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-slate-600">
                      <Calendar className="w-4 h-4" />
                      <span>
                        {t[locale].createdAt}: {formatDate(selectedUser.created_at)}
                      </span>
                    </div>
                    {selectedUser.updated_at && (
                      <div className="flex items-center gap-2 text-slate-600">
                        <Clock className="w-4 h-4" />
                        <span>
                          {t[locale].updatedAt}: {formatDate(selectedUser.updated_at)}
                        </span>
                      </div>
                    )}
                    {selectedUser.last_login && (
                      <div className="flex items-center gap-2 text-slate-600">
                        <User className="w-4 h-4" />
                        <span>
                          {t[locale].lastLogin}: {formatDate(selectedUser.last_login)}
                        </span>
                      </div>
                    )}
                  </div>
                )}
                <div className="space-y-2">
                  <Label htmlFor="edit-username">{t[locale].username}</Label>
                  <Input
                    id="edit-username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-email">{t[locale].email}</Label>
                  <Input
                    id="edit-email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-full_name">{t[locale].fullName}</Label>
                  <Input
                    id="edit-full_name"
                    value={formData.full_name}
                    onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="edit-status">{t[locale].status}</Label>
                      <p className="text-sm text-slate-500">{t[locale].statusDescription}</p>
                    </div>
                    <Switch
                      id="edit-status"
                      checked={formData.is_active}
                      onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>{t[locale].selectRoles}</Label>
                  <div className="space-y-2 max-h-48 overflow-y-auto border rounded-md p-3">
                    {roles.map((role) => (
                      <label key={role.id} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={formData.role_ids.includes(role.id)}
                          onChange={() => toggleRole(role.id)}
                          className="rounded border-slate-300"
                        />
                        <span className="text-sm">
                          {role.display_name}
                          <span className="text-slate-500 text-xs ml-2">({role.description})</span>
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsEditModalOpen(false)} disabled={saving}>
                  {t[locale].cancel}
                </Button>
                <Button onClick={handleEditUser} disabled={saving}>
                  {saving ? (locale === "en" ? "Saving..." : "جاري الحفظ...") : t[locale].save}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </DashboardLayout>
    </ProtectedRoute>
  )
}
