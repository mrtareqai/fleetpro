/**
 * Logger Unit Tests
 */

import { describe, it, expect, beforeEach, jest } from "@jest/globals"
import { logger, LogLevel } from "@/lib/logging/logger"

describe("Logger", () => {
  beforeEach(() => {
    logger.clearLogs()
    jest.spyOn(console, "error").mockImplementation()
    jest.spyOn(console, "warn").mockImplementation()
    jest.spyOn(console, "info").mockImplementation()
    jest.spyOn(console, "debug").mockImplementation()
  })

  describe("error", () => {
    it("should log error message", () => {
      logger.error("Test error message")
      const logs = logger.getRecentLogs()

      expect(logs).toHaveLength(1)
      expect(logs[0].level).toBe(LogLevel.ERROR)
      expect(logs[0].message).toBe("Test error message")
    })

    it("should log error with context", () => {
      logger.error("Test error", { userId: "123", action: "login" })
      const logs = logger.getRecentLogs()

      expect(logs[0].context).toEqual({ userId: "123", action: "login" })
    })

    it("should extract error object", () => {
      const error = new Error("Test error")
      logger.error("Error occurred", { error })
      const logs = logger.getRecentLogs()

      expect(logs[0].error).toBeDefined()
      expect(logs[0].error?.message).toBe("Test error")
      expect(logs[0].error?.name).toBe("Error")
    })
  })

  describe("warn", () => {
    it("should log warning message", () => {
      logger.warn("Test warning")
      const logs = logger.getRecentLogs()

      expect(logs).toHaveLength(1)
      expect(logs[0].level).toBe(LogLevel.WARN)
    })
  })

  describe("info", () => {
    it("should log info message", () => {
      logger.info("Test info")
      const logs = logger.getRecentLogs()

      expect(logs).toHaveLength(1)
      expect(logs[0].level).toBe(LogLevel.INFO)
    })
  })

  describe("debug", () => {
    it("should log debug message", () => {
      logger.debug("Test debug")
      const logs = logger.getRecentLogs()

      expect(logs).toHaveLength(1)
      expect(logs[0].level).toBe(LogLevel.DEBUG)
    })
  })

  describe("getLogsByLevel", () => {
    it("should filter logs by level", () => {
      logger.error("Error 1")
      logger.warn("Warning 1")
      logger.error("Error 2")
      logger.info("Info 1")

      const errorLogs = logger.getLogsByLevel(LogLevel.ERROR)
      expect(errorLogs).toHaveLength(2)
      expect(errorLogs.every((log) => log.level === LogLevel.ERROR)).toBe(true)
    })
  })

  describe("clearLogs", () => {
    it("should clear all logs", () => {
      logger.error("Error")
      logger.warn("Warning")
      expect(logger.getRecentLogs()).toHaveLength(2)

      logger.clearLogs()
      expect(logger.getRecentLogs()).toHaveLength(0)
    })
  })
})
