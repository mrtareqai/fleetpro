/**
 * Rate Limiting Utilities
 *
 * This module provides rate limiting to prevent abuse and brute force attacks.
 *
 * Features:
 * - In-memory rate limiting (suitable for single-server deployments)
 * - Configurable limits per endpoint
 * - Automatic cleanup of expired entries
 * - IP-based and user-based limiting
 *
 * For production with multiple servers, consider using:
 * - Redis-based rate limiting (Upstash)
 * - Vercel Edge Config
 * - Third-party services (Cloudflare, etc.)
 *
 * Usage:
 * \`\`\`typescript
 * const limiter = createRateLimiter({ maxRequests: 5, windowMs: 60000 })
 * const result = await limiter.check(identifier)
 * if (!result.success) {
 *   return Response.json({ error: 'Too many requests' }, { status: 429 })
 * }
 * \`\`\`
 */

interface RateLimitConfig {
  /**
   * Maximum number of requests allowed in the time window
   */
  maxRequests: number

  /**
   * Time window in milliseconds
   */
  windowMs: number

  /**
   * Optional message to return when rate limit is exceeded
   */
  message?: string
}

interface RateLimitEntry {
  count: number
  resetTime: number
}

interface RateLimitResult {
  success: boolean
  limit: number
  remaining: number
  reset: number
  retryAfter?: number
}

/**
 * In-memory store for rate limit data
 * Key: identifier (IP address or user ID)
 * Value: { count, resetTime }
 */
const rateLimitStore = new Map<string, RateLimitEntry>()

/**
 * Cleanup interval for expired entries (5 minutes)
 */
const CLEANUP_INTERVAL = 5 * 60 * 1000

/**
 * Start cleanup interval
 */
let cleanupInterval: NodeJS.Timeout | null = null

function startCleanup() {
  if (cleanupInterval) return

  cleanupInterval = setInterval(() => {
    const now = Date.now()
    for (const [key, entry] of rateLimitStore.entries()) {
      if (entry.resetTime < now) {
        rateLimitStore.delete(key)
      }
    }
  }, CLEANUP_INTERVAL)
}

/**
 * Create a rate limiter with specified configuration
 *
 * @param config - Rate limit configuration
 * @returns Rate limiter object with check method
 *
 * @example
 * // Allow 5 requests per minute
 * const loginLimiter = createRateLimiter({
 *   maxRequests: 5,
 *   windowMs: 60000,
 *   message: 'Too many login attempts'
 * })
 */
export function createRateLimiter(config: RateLimitConfig) {
  startCleanup()

  return {
    /**
     * Check if request is allowed
     *
     * @param identifier - Unique identifier (IP address or user ID)
     * @returns Rate limit result
     */
    async check(identifier: string): Promise<RateLimitResult> {
      const now = Date.now()
      const entry = rateLimitStore.get(identifier)

      // No entry or expired entry - create new
      if (!entry || entry.resetTime < now) {
        rateLimitStore.set(identifier, {
          count: 1,
          resetTime: now + config.windowMs,
        })

        return {
          success: true,
          limit: config.maxRequests,
          remaining: config.maxRequests - 1,
          reset: now + config.windowMs,
        }
      }

      // Entry exists and not expired
      if (entry.count >= config.maxRequests) {
        return {
          success: false,
          limit: config.maxRequests,
          remaining: 0,
          reset: entry.resetTime,
          retryAfter: Math.ceil((entry.resetTime - now) / 1000),
        }
      }

      // Increment count
      entry.count++
      rateLimitStore.set(identifier, entry)

      return {
        success: true,
        limit: config.maxRequests,
        remaining: config.maxRequests - entry.count,
        reset: entry.resetTime,
      }
    },

    /**
     * Reset rate limit for identifier
     *
     * @param identifier - Unique identifier to reset
     */
    reset(identifier: string): void {
      rateLimitStore.delete(identifier)
    },
  }
}

/**
 * Pre-configured rate limiters for common use cases
 */

/**
 * Login rate limiter
 * Allows 5 login attempts per 15 minutes per IP
 */
export const loginRateLimiter = createRateLimiter({
  maxRequests: 5,
  windowMs: 15 * 60 * 1000, // 15 minutes
  message: "Too many login attempts. Please try again later.",
})

/**
 * API rate limiter
 * Allows 100 requests per minute per user
 */
export const apiRateLimiter = createRateLimiter({
  maxRequests: 100,
  windowMs: 60 * 1000, // 1 minute
  message: "Too many requests. Please slow down.",
})

/**
 * Strict rate limiter for sensitive operations
 * Allows 3 requests per hour per user
 */
export const strictRateLimiter = createRateLimiter({
  maxRequests: 3,
  windowMs: 60 * 60 * 1000, // 1 hour
  message: "Rate limit exceeded for this operation.",
})

/**
 * Admin API rate limiter
 * Allows 20 requests per minute for admin operations
 */
export const adminRateLimiter = createRateLimiter({
  maxRequests: 20,
  windowMs: 60 * 1000, // 1 minute
  message: "Too many admin requests. Please slow down.",
})

/**
 * Reports rate limiter
 * Allows 10 requests per minute for report generation
 */
export const reportsRateLimiter = createRateLimiter({
  maxRequests: 10,
  windowMs: 60 * 1000, // 1 minute
  message: "Too many report requests. Please slow down.",
})

/**
 * Dashboard rate limiter
 * Allows 30 requests per minute for dashboard stats
 */
export const dashboardRateLimiter = createRateLimiter({
  maxRequests: 30,
  windowMs: 60 * 1000, // 1 minute
  message: "Too many dashboard requests. Please slow down.",
})

/**
 * Get client IP address from request
 *
 * @param request - Next.js request object
 * @returns IP address or 'unknown'
 */
export function getClientIp(request: Request): string {
  // Try various headers (in order of preference)
  const headers = [
    "x-real-ip",
    "x-forwarded-for",
    "cf-connecting-ip", // Cloudflare
    "x-vercel-forwarded-for", // Vercel
  ]

  for (const header of headers) {
    const value = request.headers.get(header)
    if (value) {
      // x-forwarded-for can contain multiple IPs, take the first one
      return value.split(",")[0].trim()
    }
  }

  return "unknown"
}

/**
 * Apply rate limiting and return appropriate response
 *
 * @param request - Next.js request object
 * @param limiter - Rate limiter to use
 * @param identifier - Unique identifier (IP or user ID)
 * @returns null if allowed, Response if rate limited
 */
export async function applyRateLimit(
  request: Request,
  limiter: ReturnType<typeof createRateLimiter>,
  identifier?: string,
): Promise<Response | null> {
  const id = identifier || getClientIp(request)
  const result = await limiter.check(id)

  if (!result.success) {
    return new Response(
      JSON.stringify({
        error: "Too many requests",
        message: "You have exceeded the rate limit. Please try again later.",
        retryAfter: result.retryAfter,
      }),
      {
        status: 429,
        headers: {
          "Content-Type": "application/json",
          "X-RateLimit-Limit": result.limit.toString(),
          "X-RateLimit-Remaining": "0",
          "X-RateLimit-Reset": new Date(result.reset).toISOString(),
          "Retry-After": result.retryAfter?.toString() || "60",
        },
      },
    )
  }

  return null
}

/**
 * Add rate limit headers to response
 *
 * @param response - Response to add headers to
 * @param result - Rate limit result
 */
export function addRateLimitHeaders(response: Response, result: RateLimitResult): void {
  response.headers.set("X-RateLimit-Limit", result.limit.toString())
  response.headers.set("X-RateLimit-Remaining", result.remaining.toString())
  response.headers.set("X-RateLimit-Reset", new Date(result.reset).toISOString())
}
