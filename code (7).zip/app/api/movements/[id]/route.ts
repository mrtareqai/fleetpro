import { type NextRequest, NextResponse } from "next/server"
import { neon } from "@neondatabase/serverless"
import { requirePermission } from "@/lib/api-auth"
import { updateMovementSchema } from "@/lib/validation/schemas"
import { validateOrRespond } from "@/lib/validation/validator"
import { logger } from "@/lib/logging/logger"

const sql = neon(process.env.DATABASE_URL!)

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "movements.read")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const movementId = Number.parseInt(params.id)

    if (isNaN(movementId)) {
      return NextResponse.json({ error: "Invalid movement ID" }, { status: 400 })
    }

    logger.info("Fetching movement", { userId, movementId })

    const result = await sql`
      SELECT * FROM movements WHERE id = ${movementId}
    `

    if (result.length === 0) {
      logger.warn("Movement not found", { userId, movementId })
      return NextResponse.json({ error: "Movement not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Movement fetched successfully", { userId, movementId, duration })

    return NextResponse.json({ movement: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error fetching movement", { error, movementId: params.id, duration })

    return NextResponse.json({ error: "Failed to fetch movement" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "movements.update")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const movementId = Number.parseInt(params.id)

    if (isNaN(movementId)) {
      return NextResponse.json({ error: "Invalid movement ID" }, { status: 400 })
    }

    const body = await request.json()
    const validatedData = await validateOrRespond(updateMovementSchema, body)
    if (validatedData instanceof NextResponse) return validatedData

    logger.info("Updating movement", { userId, movementId })

    const updates: string[] = []
    const values: any[] = []
    let paramIndex = 1

    if (validatedData.driver_name !== undefined) {
      updates.push(`driver_name = $${paramIndex++}`)
      values.push(validatedData.driver_name)
    }
    if (validatedData.assistant_name !== undefined) {
      updates.push(`assistant_name = $${paramIndex++}`)
      values.push(validatedData.assistant_name)
    }
    if (validatedData.bus_number !== undefined) {
      updates.push(`bus_number = $${paramIndex++}`)
      values.push(validatedData.bus_number)
    }
    if (validatedData.trip_name !== undefined) {
      updates.push(`trip_name = $${paramIndex++}`)
      values.push(validatedData.trip_name)
    }
    if (validatedData.trip_date !== undefined) {
      updates.push(`trip_date = $${paramIndex++}`)
      values.push(validatedData.trip_date)
    }
    if (validatedData.trip_time !== undefined) {
      updates.push(`trip_time = $${paramIndex++}`)
      values.push(validatedData.trip_time)
    }
    if (validatedData.seats !== undefined) {
      updates.push(`seats = $${paramIndex++}`)
      values.push(validatedData.seats)
    }
    if (validatedData.pending_seats !== undefined) {
      updates.push(`pending_seats = $${paramIndex++}`)
      values.push(validatedData.pending_seats)
    }
    if (validatedData.status !== undefined) {
      updates.push(`status = $${paramIndex++}`)
      values.push(validatedData.status)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)
    values.push(movementId)

    const query = `
      UPDATE movements 
      SET ${updates.join(", ")}
      WHERE id = $${paramIndex}
      RETURNING *
    `

    const result = await sql(query, values)

    if (result.length === 0) {
      logger.warn("Movement not found for update", { userId, movementId })
      return NextResponse.json({ error: "Movement not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Movement updated successfully", { userId, movementId, duration })

    return NextResponse.json({ movement: result[0] })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error updating movement", { error, movementId: params.id, duration })

    return NextResponse.json({ error: "Failed to update movement" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  const startTime = Date.now()

  try {
    const authResult = await requirePermission(request, "movements.delete")
    if (authResult instanceof Response) return authResult

    const { userId } = authResult
    const movementId = Number.parseInt(params.id)

    if (isNaN(movementId)) {
      return NextResponse.json({ error: "Invalid movement ID" }, { status: 400 })
    }

    logger.info("Deleting movement", { userId, movementId })

    const result = await sql`
      DELETE FROM movements 
      WHERE id = ${movementId}
      RETURNING id
    `

    if (result.length === 0) {
      logger.warn("Movement not found for deletion", { userId, movementId })
      return NextResponse.json({ error: "Movement not found" }, { status: 404 })
    }

    const duration = Date.now() - startTime
    logger.info("Movement deleted successfully", { userId, movementId, duration })

    return NextResponse.json({
      message: "Movement deleted successfully",
      id: movementId,
    })
  } catch (error) {
    const duration = Date.now() - startTime
    logger.error("Error deleting movement", { error, movementId: params.id, duration })

    return NextResponse.json({ error: "Failed to delete movement" }, { status: 500 })
  }
}
