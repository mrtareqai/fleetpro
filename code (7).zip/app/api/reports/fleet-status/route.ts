import { type NextRequest, NextResponse } from "next/server"
import { requirePermission } from "@/lib/security/api-auth"
import { sql } from "@/lib/db"

export async function GET(request: NextRequest) {
  const authResult = await requirePermission(request, "reports.read")
  if (authResult instanceof Response) return authResult

  try {
    console.log("[v0] Generating fleet status report...")

    if (!sql) {
      return getMockFleetStatus()
    }

    const statusData = await sql`
      SELECT 
        status,
        COUNT(*) as count,
        ROUND((COUNT(*)::numeric / (SELECT COUNT(*) FROM vehicles)) * 100, 2) as percentage
      FROM vehicles
      GROUP BY status
      ORDER BY count DESC
    `

    const maintenanceDetails = await sql`
      SELECT 
        v.id,
        v.model,
        v.plate_number,
        v.status,
        s.priority,
        s.subject,
        s.date as last_maintenance_date
      FROM vehicles v
      LEFT JOIN supplies s ON s.vehicle_id = v.id AND s.category = 'Maintenance'
      WHERE v.status = 'maintenance'
      ORDER BY s.date DESC
    `

    const report = {
      statusDistribution: statusData.map((row) => ({
        status: row.status,
        count: Number(row.count),
        percentage: Number(row.percentage),
      })),
      maintenanceVehicles: maintenanceDetails.map((row) => ({
        id: row.id,
        model: row.model,
        plateNumber: row.plate_number,
        status: row.status,
        priority: row.priority,
        issue: row.subject,
        lastMaintenanceDate: row.last_maintenance_date,
      })),
      summary: {
        totalVehicles: statusData.reduce((sum, row) => sum + Number(row.count), 0),
        activePercentage: Number(statusData.find((row) => row.status === "active")?.percentage || 0),
        maintenanceCount: Number(statusData.find((row) => row.status === "maintenance")?.count || 0),
      },
    }

    console.log("[v0] Fleet status report generated")

    return NextResponse.json(report, {
      headers: {
        "Content-Type": "application/json",
      },
    })
  } catch (error) {
    console.error("[v0] Error generating fleet status report:", error)
    return NextResponse.json({ error: "Failed to generate report" }, { status: 500 })
  }
}

function getMockFleetStatus() {
  console.log("[v0] Using mock fleet status data")

  return NextResponse.json({
    statusDistribution: [
      { status: "active", count: 45, percentage: 50 },
      { status: "inactive", count: 25, percentage: 27.78 },
      { status: "maintenance", count: 20, percentage: 22.22 },
    ],
    maintenanceVehicles: [
      {
        id: 1,
        model: "Toyota Hiace",
        plateNumber: "ABC-1234",
        status: "maintenance",
        priority: "high",
        issue: "Engine repair",
        lastMaintenanceDate: "2024-01-20",
      },
      {
        id: 2,
        model: "Mercedes Sprinter",
        plateNumber: "XYZ-5678",
        status: "maintenance",
        priority: "medium",
        issue: "Brake system check",
        lastMaintenanceDate: "2024-01-18",
      },
    ],
    summary: {
      totalVehicles: 90,
      activePercentage: 50,
      maintenanceCount: 20,
    },
  })
}
