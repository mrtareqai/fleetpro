"use client"

import type React from "react"
import { useState } from "react"
import { Settings, User, Lock, Globe } from "lucide-react"
import { useRouter } from "next/navigation"
import { apiClient } from "@/lib/api-client"
import { useAuth } from "@/lib/auth-context"

export default function LoginForm() {
  const router = useRouter()
  const { login } = useAuth()
  const [locale, setLocale] = useState<"en" | "ar">("en")
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const t = {
    en: {
      title: "Secure Login",
      username: "Username",
      password: "Password",
      login: "Log In",
      forgot: "Forgot Password?",
      create: "Create Account",
      footer: "© 2025 FleetPro System - All rights reserved",
      error: "Invalid username or password",
      loading: "Logging in...",
      demoMode: "Demo Mode - Use: admin / password123",
    },
    ar: {
      title: "تسجيل دخول آمن",
      username: "اسم المستخدم",
      password: "كلمة المرور",
      login: "تسجيل الدخول",
      forgot: "نسيت كلمة المرور؟",
      create: "إنشاء حساب",
      footer: "© 2025 نظام FleetPro - جميع الحقوق محفوظة",
      error: "اسم المستخدم أو كلمة المرور غير صحيحة",
      loading: "جاري تسجيل الدخول...",
      demoMode: "وضع التجريبي - استخدم: admin / password123",
    },
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    try {
      const trimmedUsername = username.trim()
      const trimmedPassword = password.trim()

      console.log("[v0] Attempting login with username:", trimmedUsername)

      const response = await apiClient.login({
        username: trimmedUsername,
        password: trimmedPassword,
      })

      console.log("[v0] Login successful:", response.user)

      if (response.access_token) {
        localStorage.setItem("token", response.access_token)
        login(response.user)

        if (response.user.role === "superadmin") {
          console.log("[v0] Redirecting to /master-admin")
          router.push("/master-admin")
        } else {
          console.log("[v0] Redirecting to /dashboard")
          router.push(`/dashboard?locale=${locale}`)
        }
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error"
      setError(t[locale].error)
      console.error("[v0] Login error:", errorMessage)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div dir={locale === "ar" ? "rtl" : "ltr"} className="w-full max-w-md">
      <div className="bg-white rounded-2xl shadow-2xl p-8">
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-3">
            <div className="bg-slate-700 p-2 rounded-lg">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-800">FleetPro</h1>
              <p className="text-sm text-slate-600">Management</p>
            </div>
          </div>
          <button
            onClick={() => setLocale(locale === "en" ? "ar" : "en")}
            className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white font-medium rounded-lg transition-colors shadow-md"
          >
            <Globe className="w-4 h-4" />
            <span>{locale === "en" ? "العربية" : "English"}</span>
          </button>
        </div>

        <h2 className="text-2xl font-bold text-center mb-8 text-slate-800">{t[locale].title}</h2>

        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 text-blue-700 rounded-lg text-sm text-center">
          {t[locale].demoMode}
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-100 border border-red-300 text-red-700 rounded-lg text-sm">{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="relative">
            <input
              type="text"
              placeholder={t[locale].username}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              className="w-full px-4 py-3 border-2 border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 transition-colors pr-12"
            />
            <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          </div>

          <div className="relative">
            <input
              type="password"
              placeholder={t[locale].password}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-4 py-3 border-2 border-slate-200 rounded-lg focus:outline-none focus:border-blue-500 transition-colors pr-12"
            />
            <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? t[locale].loading : t[locale].login}
          </button>
        </form>

        <div className="flex justify-between mt-6 text-sm">
          <a href="#" className="text-blue-500 hover:text-blue-600">
            {t[locale].forgot}
          </a>
        </div>

        <p className="text-center text-xs text-slate-500 mt-8">{t[locale].footer}</p>
      </div>
    </div>
  )
}
