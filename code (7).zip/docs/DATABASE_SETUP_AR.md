# دليل إعداد قاعدة البيانات - Database Setup Guide

## 📋 نظرة عامة

هذا الدليل يشرح كيفية إعداد قاعدة بيانات Neon PostgreSQL لمشروع FleetPro Management System.

## ✅ المتطلبات الأساسية

- [x] تكامل Neon متصل في v0
- [x] متغير البيئة `NEON_NEON_DATABASE_URL` متوفر
- [ ] تشغيل سكريبتات SQL
- [ ] التحقق من الاتصال

## 🔧 الخطوة 1: التحقق من الاتصال

### سلسلة الاتصال الخاصة بك

تم توفير سلسلة الاتصال التالية لقاعدة البيانات:

\`\`\`bash
postgresql://neondb_owner:npg_yrGIk2Awoab8@ep-icy-cloud-adpafx3r-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
\`\`\`

### كيفية إضافتها في Vercel

#### الطريقة 1: من خلال v0 Interface (الأسرع)

1. افتح **In-chat sidebar** (الشريط الجانبي في المحادثة)
2. اضغط على **Vars** (المتغيرات)
3. أضف متغير جديد:
   - **Key**: `NEON_DATABASE_URL`
   - **Value**: `postgresql://neondb_owner:npg_yrGIk2Awoab8@ep-icy-cloud-adpafx3r-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require`
4. احفظ التغييرات

#### الطريقة 2: من خلال Vercel Dashboard

1. افتح [Vercel Dashboard](https://vercel.com/dashboard)
2. اختر مشروعك
3. اذهب إلى **Settings** → **Environment Variables**
4. أضف متغير جديد:
   - **Key**: `NEON_DATABASE_URL`
   - **Value**: السلسلة أعلاه
   - **Environment**: اختر `Production`, `Preview`, `Development`
5. اضغط **Save**
6. أعد نشر المشروع

#### الطريقة 3: من خلال Vercel CLI

\`\`\`bash
# تسجيل الدخول
vercel login

# ربط المشروع
vercel link

# إضافة المتغير
vercel env add NEON_DATABASE_URL production

# عند الطلب، الصق السلسلة:
# postgresql://neondb_owner:npg_yrGIk2Awoab8@ep-icy-cloud-adpafx3r-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require
\`\`\`

### اختبار الاتصال

بعد إضافة المتغير، اختبر الاتصال:

\`\`\`bash
# من خلال psql
psql 'postgresql://neondb_owner:npg_yrGIk2Awoab8@ep-icy-cloud-adpafx3r-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require'

# يجب أن ترى:
# psql (XX.X)
# SSL connection (protocol: TLSv1.3, cipher: TLS_AES_256_GCM_SHA384, bits: 256, compression: off)
# Type "help" for help.
# neondb=>
\`\`\`

### تم الإصلاح ✅

تم إصلاح خطأ في `lib/db.ts`:

**قبل الإصلاح:**
\`\`\`typescript
export const sql = process.env.NEON_NEON_DATABASE_URL ? neon(process.env.NEON_DATABASE_URL) : null
//                              ^^^^^ كان خطأ إملائي، تم إصلاحه
\`\`\`

**بعد الإصلاح:**
\`\`\`typescript
export const sql = process.env.NEON_DATABASE_URL ? neon(process.env.NEON_DATABASE_URL) : null
//                              ✅ صحيح الآن
\`\`\`

## 🗄️ الخطوة 2: تشغيل سكريبتات SQL

### السكريبتات المتوفرة

المشروع يحتوي على 13 سكريبت SQL في مجلد `scripts/`:

1. **01_create_tables.sql** - إنشاء الجداول الأساسية
2. **02_seed_demo_data.sql** - إضافة بيانات تجريبية
3. **03_add_rbac_tables.sql** - إضافة جداول نظام الصلاحيات
4. **04_seed_rbac_data.sql** - إضافة بيانات الصلاحيات
5. **05_add_indexes.sql** - إضافة فهارس للأداء
6. **06_add_audit_log.sql** - إضافة سجل التدقيق
7. **07_add_notifications.sql** - إضافة نظام الإشعارات
8. **08_add_settings.sql** - إضافة جدول الإعدادات
9. **09_add_companies.sql** - إضافة جدول الشركات
10. **10_add_maintenance.sql** - إضافة جدول الصيانة
11. **11_add_fuel_logs.sql** - إضافة سجل الوقود
12. **12_add_documents.sql** - إضافة جدول المستندات
13. **13_add_reports.sql** - إضافة جدول التقارير

### كيفية تشغيل السكريبتات

#### الطريقة 1: من خلال v0 (موصى بها)

السكريبتات موجودة في مجلد `scripts/` ويمكن تشغيلها مباشرة من v0:

1. افتح v0 Chat
2. اطلب من v0 تشغيل السكريبتات:
   \`\`\`
   قم بتشغيل جميع سكريبتات SQL في مجلد scripts/
   \`\`\`

#### الطريقة 2: من خلال Neon Console

1. افتح [Neon Console](https://console.neon.tech)
2. اختر مشروعك
3. اذهب إلى **SQL Editor**
4. انسخ محتوى كل سكريبت والصقه
5. اضغط **Run** لكل سكريبت بالترتيب

#### الطريقة 3: من خلال psql CLI

\`\`\`bash
# الاتصال بقاعدة البيانات
psql $NEON_DATABASE_URL

# تشغيل السكريبتات بالترتيب
\i scripts/01_create_tables.sql
\i scripts/02_seed_demo_data.sql
\i scripts/03_add_rbac_tables.sql
# ... وهكذا
\`\`\`

#### الطريقة 4: من خلال Node.js Script

\`\`\`bash
# إنشاء سكريبت تشغيل
node scripts/run-migrations.js
\`\`\`

## 🔍 الخطوة 3: التحقق من الإعداد

### 1. التحقق من الجداول

\`\`\`sql
-- عرض جميع الجداول
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public'
ORDER BY table_name;
\`\`\`

يجب أن ترى:
- users
- vehicles
- drivers
- reservations
- tickets
- movements
- agency_supplies
- roles
- permissions
- role_permissions
- user_roles
- audit_logs
- notifications
- settings
- companies
- maintenance_records
- fuel_logs
- documents
- reports

### 2. التحقق من البيانات

\`\`\`sql
-- عدد المستخدمين
SELECT COUNT(*) FROM users;

-- عدد المركبات
SELECT COUNT(*) FROM vehicles;

-- عدد الأدوار
SELECT COUNT(*) FROM roles;
\`\`\`

### 3. اختبار الاتصال من التطبيق

قم بإنشاء ملف اختبار:

\`\`\`typescript
// test-db-connection.ts
import { sql } from './lib/db'

async function testConnection() {
  try {
    if (!sql) {
      console.error('❌ Database connection not available')
      return
    }

    const result = await sql`SELECT NOW() as current_time`
    console.log('✅ Database connected successfully!')
    console.log('Current time:', result[0].current_time)

    // اختبار عدد الجداول
    const tables = await sql`
      SELECT COUNT(*) as table_count
      FROM information_schema.tables 
      WHERE table_schema = 'public'
    `
    console.log('📊 Tables count:', tables[0].table_count)

  } catch (error) {
    console.error('❌ Database connection failed:', error)
  }
}

testConnection()
\`\`\`

## 📊 بنية قاعدة البيانات

### الجداول الأساسية

#### 1. users (المستخدمون)
- إدارة حسابات المستخدمين
- المصادقة والتفويض
- الأدوار والصلاحيات

#### 2. vehicles (المركبات)
- معلومات الأسطول
- حالة المركبات
- تواريخ الصلاحية

#### 3. drivers (السائقون)
- معلومات السائقين
- رخص القيادة
- حالة التوظيف

#### 4. reservations (الحجوزات)
- حجوزات المركبات
- تواريخ الاستلام والإرجاع
- حالة الحجز

#### 5. tickets (التذاكر)
- نظام التذاكر
- الأولويات والفئات
- حالة المعالجة

#### 6. movements (الحركات)
- حركات المركبات
- أنواع الحركات
- التتبع والمراقبة

#### 7. agency_supplies (مستلزمات الوكالة)
- إدارة المستلزمات
- الكميات والأنواع
- حالة الطلبات

### جداول RBAC (نظام الصلاحيات)

#### 8. roles (الأدوار)
- تعريف الأدوار
- الأوصاف والأولويات

#### 9. permissions (الصلاحيات)
- صلاحيات النظام
- الموارد والإجراءات

#### 10. role_permissions (صلاحيات الأدوار)
- ربط الأدوار بالصلاحيات

#### 11. user_roles (أدوار المستخدمين)
- ربط المستخدمين بالأدوار

### جداول إضافية

#### 12. audit_logs (سجل التدقيق)
- تتبع جميع العمليات
- من قام بماذا ومتى

#### 13. notifications (الإشعارات)
- إشعارات النظام
- حالة القراءة

#### 14. settings (الإعدادات)
- إعدادات النظام
- التخصيص

#### 15. companies (الشركات)
- إدارة الشركات
- معلومات الاتصال

#### 16-19. جداول إضافية
- maintenance_records (سجلات الصيانة)
- fuel_logs (سجل الوقود)
- documents (المستندات)
- reports (التقارير)

## 🔐 الأمان

### Row Level Security (RLS)

بعض الجداول تستخدم RLS لحماية البيانات:

\`\`\`sql
-- مثال: حماية جدول المستخدمين
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_select_policy ON users
  FOR SELECT
  USING (auth.uid() = id OR auth.role() = 'admin');
\`\`\`

### الفهارس (Indexes)

تم إضافة فهارس لتحسين الأداء:

\`\`\`sql
-- فهارس البحث السريع
CREATE INDEX idx_vehicles_plate ON vehicles(plate_number);
CREATE INDEX idx_drivers_license ON drivers(license_number);
CREATE INDEX idx_tickets_status ON tickets(status);
\`\`\`

## 🚀 الخطوات التالية

بعد إعداد قاعدة البيانات:

1. ✅ تشغيل التطبيق محلياً
2. ✅ اختبار تسجيل الدخول
3. ✅ التحقق من جميع الصفحات
4. ✅ اختبار العمليات CRUD
5. ✅ نشر التطبيق على Vercel

## 🐛 استكشاف الأخطاء

### المشكلة: "relation does not exist"

**السبب**: الجداول لم يتم إنشاؤها

**الحل**: قم بتشغيل `01_create_tables.sql`

### المشكلة: "permission denied"

**السبب**: المستخدم لا يملك صلاحيات كافية

**الحل**: تحقق من صلاحيات المستخدم في Neon Console

### المشكلة: "connection timeout"

**السبب**: مشكلة في الاتصال بالشبكة

**الحل**: 
1. تحقق من اتصال الإنترنت
2. تحقق من أن قاعدة البيانات نشطة
3. تحقق من صحة `NEON_DATABASE_URL`

## 📞 الدعم

إذا واجهت أي مشاكل:

1. راجع [Neon Documentation](https://neon.tech/docs)
2. تحقق من [Neon Status](https://status.neon.tech)
3. افتح تذكرة دعم في Neon Console
