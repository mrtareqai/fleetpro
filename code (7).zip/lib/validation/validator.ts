/**
 * Validation Utility Functions
 *
 * Helper functions for validating data using Zod schemas
 */

import type { z } from "zod"
import { NextResponse } from "next/server"

/**
 * Validation result interface
 */
export interface ValidationResult<T> {
  success: boolean
  data?: T
  errors?: Array<{
    field: string
    message: string
  }>
}

/**
 * Validate data against a Zod schema
 *
 * @param schema - Zod schema to validate against
 * @param data - Data to validate
 * @returns Validation result with data or errors
 *
 * @example
 * const result = validate(createUserSchema, userData)
 * if (!result.success) {
 *   return NextResponse.json({ errors: result.errors }, { status: 400 })
 * }
 */
export function validate<T>(schema: z.ZodSchema<T>, data: unknown): ValidationResult<T> {
  const result = schema.safeParse(data)

  if (result.success) {
    return {
      success: true,
      data: result.data,
    }
  }

  return {
    success: false,
    errors: result.error.errors.map((err) => ({
      field: err.path.join("."),
      message: err.message,
    })),
  }
}

/**
 * Validate request body and return error response if invalid
 *
 * @param schema - Zod schema to validate against
 * @param data - Data to validate
 * @returns Validated data or NextResponse with errors
 *
 * @example
 * const userData = await validateOrRespond(createUserSchema, await request.json())
 * if (userData instanceof NextResponse) return userData
 * // userData is now typed and validated
 */
export async function validateOrRespond<T>(schema: z.ZodSchema<T>, data: unknown): Promise<T | NextResponse> {
  const result = validate(schema, data)

  if (!result.success) {
    return NextResponse.json(
      {
        error: "Validation failed",
        details: result.errors,
      },
      { status: 400 },
    )
  }

  return result.data!
}

/**
 * Validate query parameters from URL
 *
 * @param schema - Zod schema to validate against
 * @param searchParams - URLSearchParams from request
 * @returns Validation result
 *
 * @example
 * const params = validateQueryParams(paginationSchema, request.nextUrl.searchParams)
 * if (!params.success) {
 *   return NextResponse.json({ errors: params.errors }, { status: 400 })
 * }
 */
export function validateQueryParams<T>(schema: z.ZodSchema<T>, searchParams: URLSearchParams): ValidationResult<T> {
  const params: Record<string, string | string[]> = {}

  searchParams.forEach((value, key) => {
    if (params[key]) {
      if (Array.isArray(params[key])) {
        ;(params[key] as string[]).push(value)
      } else {
        params[key] = [params[key] as string, value]
      }
    } else {
      params[key] = value
    }
  })

  return validate(schema, params)
}

/**
 * Create a validation middleware for API routes
 *
 * @param schema - Zod schema to validate against
 * @returns Middleware function
 *
 * @example
 * const validateUser = createValidationMiddleware(createUserSchema)
 * const userData = await validateUser(request)
 * if (userData instanceof NextResponse) return userData
 */
export function createValidationMiddleware<T>(schema: z.ZodSchema<T>) {
  return async (request: Request): Promise<T | NextResponse> => {
    try {
      const body = await request.json()
      return validateOrRespond(schema, body)
    } catch (error) {
      return NextResponse.json({ error: "Invalid JSON in request body" }, { status: 400 })
    }
  }
}
