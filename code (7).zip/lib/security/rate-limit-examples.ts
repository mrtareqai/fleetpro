/**
 * Rate Limiting Examples
 *
 * This file contains practical examples of implementing rate limiting
 * in various scenarios throughout the FleetPro application.
 */

import { type NextRequest, NextResponse } from "next/server"
import { createRateLimiter, loginRateLimiter, apiRateLimiter, strictRateLimiter, getClientIp } from "./rate-limit"
import { requireAuth } from "./api-auth"

// ============================================================================
// Example 1: Basic Rate Limiting
// ============================================================================

/**
 * Simple rate limiting for a public endpoint
 */
export async function exampleBasicRateLimit(request: NextRequest) {
  // Create a rate limiter
  const limiter = createRateLimiter({
    maxRequests: 10,
    windowMs: 60000, // 1 minute
  })

  // Get client identifier
  const ip = getClientIp(request)

  // Check rate limit
  const result = await limiter.check(ip)

  if (!result.success) {
    return NextResponse.json(
      {
        error: "Too many requests",
        retryAfter: result.retryAfter,
      },
      {
        status: 429,
        headers: {
          "X-RateLimit-Limit": result.limit.toString(),
          "X-RateLimit-Remaining": result.remaining.toString(),
          "X-RateLimit-Reset": new Date(result.reset).toISOString(),
          "Retry-After": result.retryAfter?.toString() || "60",
        },
      },
    )
  }

  // Process request
  return NextResponse.json({ message: "Success" })
}

// ============================================================================
// Example 2: Rate Limiting with Authentication
// ============================================================================

/**
 * Rate limiting for authenticated endpoints
 * Uses user ID instead of IP for more accurate tracking
 */
export async function exampleAuthenticatedRateLimit(request: NextRequest) {
  // Authenticate first
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  // Create rate limiter
  const limiter = apiRateLimiter

  // Use user ID as identifier
  const identifier = `user:${authResult.userId}`

  // Check rate limit
  const result = await limiter.check(identifier)

  if (!result.success) {
    return NextResponse.json(
      {
        error: "Too many requests",
        message: "You have exceeded your request quota",
        retryAfter: result.retryAfter,
      },
      { status: 429 },
    )
  }

  // Process request
  return NextResponse.json({ data: "Protected data" })
}

// ============================================================================
// Example 3: Different Limits for Different Operations
// ============================================================================

/**
 * Apply different rate limits based on operation type
 */
export async function exampleOperationBasedRateLimit(request: NextRequest) {
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  // Choose limiter based on operation
  const operation = request.nextUrl.searchParams.get("operation")
  let limiter

  switch (operation) {
    case "read":
      // Generous limit for reads
      limiter = createRateLimiter({
        maxRequests: 200,
        windowMs: 60000,
      })
      break

    case "write":
      // Stricter limit for writes
      limiter = createRateLimiter({
        maxRequests: 30,
        windowMs: 60000,
      })
      break

    case "delete":
      // Very strict limit for deletes
      limiter = strictRateLimiter
      break

    default:
      limiter = apiRateLimiter
  }

  const identifier = `user:${authResult.userId}`
  const result = await limiter.check(identifier)

  if (!result.success) {
    return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 })
  }

  return NextResponse.json({ message: "Operation successful" })
}

// ============================================================================
// Example 4: Combined IP and User Rate Limiting
// ============================================================================

/**
 * Apply rate limiting to both IP and user
 * Useful for preventing abuse from both authenticated and unauthenticated users
 */
export async function exampleCombinedRateLimit(request: NextRequest) {
  const limiter = apiRateLimiter

  // Check IP-based limit first
  const ip = getClientIp(request)
  const ipResult = await limiter.check(`ip:${ip}`)

  if (!ipResult.success) {
    return NextResponse.json({ error: "IP rate limit exceeded" }, { status: 429 })
  }

  // Then check user-based limit if authenticated
  const authResult = await requireAuth(request, { checkRateLimit: false })
  if (!(authResult instanceof Response)) {
    const userResult = await limiter.check(`user:${authResult.userId}`)

    if (!userResult.success) {
      return NextResponse.json({ error: "User rate limit exceeded" }, { status: 429 })
    }
  }

  return NextResponse.json({ message: "Success" })
}

// ============================================================================
// Example 5: Endpoint-Specific Rate Limiting
// ============================================================================

/**
 * Different rate limits for different endpoints
 */

// Search endpoint - higher limit (read-heavy)
export async function exampleSearchEndpoint(request: NextRequest) {
  const searchLimiter = createRateLimiter({
    maxRequests: 200,
    windowMs: 60000,
  })

  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  const result = await searchLimiter.check(`user:${authResult.userId}`)
  if (!result.success) {
    return NextResponse.json({ error: "Search rate limit exceeded" }, { status: 429 })
  }

  // Perform search
  return NextResponse.json({ results: [] })
}

// Export endpoint - lower limit (resource-intensive)
export async function exampleExportEndpoint(request: NextRequest) {
  const exportLimiter = createRateLimiter({
    maxRequests: 5,
    windowMs: 60000,
  })

  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  const result = await exportLimiter.check(`user:${authResult.userId}`)
  if (!result.success) {
    return NextResponse.json(
      {
        error: "Export rate limit exceeded",
        message: "You can only export 5 times per minute",
      },
      { status: 429 },
    )
  }

  // Perform export
  return NextResponse.json({ exportUrl: "/exports/data.csv" })
}

// ============================================================================
// Example 6: Graceful Degradation
// ============================================================================

/**
 * Provide degraded service instead of complete rejection
 */
export async function exampleGracefulDegradation(request: NextRequest) {
  const limiter = apiRateLimiter
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  const result = await limiter.check(`user:${authResult.userId}`)

  if (!result.success) {
    // Instead of rejecting, return cached/limited data
    return NextResponse.json({
      data: [], // Empty or cached data
      cached: true,
      message: "Rate limit exceeded. Showing cached data.",
      retryAfter: result.retryAfter,
    })
  }

  // Return fresh data
  return NextResponse.json({
    data: [
      /* fresh data */
    ],
    cached: false,
  })
}

// ============================================================================
// Example 7: Progressive Rate Limiting
// ============================================================================

/**
 * Warn users before hitting the limit
 */
export async function exampleProgressiveRateLimit(request: NextRequest) {
  const limiter = apiRateLimiter
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  const result = await limiter.check(`user:${authResult.userId}`)

  // Calculate percentage used
  const percentUsed = ((result.limit - result.remaining) / result.limit) * 100

  // Warn at 80%
  if (percentUsed >= 80 && result.success) {
    return NextResponse.json({
      data: [
        /* data */
      ],
      warning: {
        message: "You are approaching your rate limit",
        remaining: result.remaining,
        limit: result.limit,
        resetAt: new Date(result.reset).toISOString(),
      },
    })
  }

  // Block at 100%
  if (!result.success) {
    return NextResponse.json(
      {
        error: "Rate limit exceeded",
        retryAfter: result.retryAfter,
      },
      { status: 429 },
    )
  }

  // Normal response
  return NextResponse.json({
    data: [
      /* data */
    ],
  })
}

// ============================================================================
// Example 8: Admin Override
// ============================================================================

/**
 * Allow admins to bypass rate limits
 */
export async function exampleAdminOverride(request: NextRequest) {
  const authResult = await requireAuth(request)
  if (authResult instanceof Response) return authResult

  // Admins bypass rate limiting
  if (authResult.role === "admin" || authResult.role === "superadmin") {
    return NextResponse.json({
      data: [
        /* data */
      ],
      rateLimitBypassed: true,
    })
  }

  // Apply rate limiting for non-admins
  const limiter = apiRateLimiter
  const result = await limiter.check(`user:${authResult.userId}`)

  if (!result.success) {
    return NextResponse.json({ error: "Rate limit exceeded" }, { status: 429 })
  }

  return NextResponse.json({
    data: [
      /* data */
    ],
  })
}

// ============================================================================
// Example 9: Custom Error Messages
// ============================================================================

/**
 * Provide helpful error messages based on context
 */
export async function exampleCustomErrorMessages(request: NextRequest) {
  const limiter = loginRateLimiter
  const ip = getClientIp(request)
  const result = await limiter.check(ip)

  if (!result.success) {
    const minutesUntilReset = Math.ceil((result.reset - Date.now()) / 60000)

    return NextResponse.json(
      {
        error: "Too many login attempts",
        message: `For security reasons, you have been temporarily blocked after multiple failed login attempts. Please try again in ${minutesUntilReset} minutes.`,
        details: {
          attemptsAllowed: result.limit,
          resetAt: new Date(result.reset).toISOString(),
          retryAfter: result.retryAfter,
        },
        helpText: "If you forgot your password, use the 'Forgot Password' link below.",
      },
      { status: 429 },
    )
  }

  // Process login
  return NextResponse.json({ message: "Login successful" })
}

// ============================================================================
// Example 10: Rate Limiting with Middleware
// ============================================================================

/**
 * Apply rate limiting at middleware level
 * This is useful for protecting multiple routes at once
 */

// middleware.ts
export async function rateLimitMiddleware(request: NextRequest) {
  // Skip rate limiting for static files
  if (request.nextUrl.pathname.startsWith("/_next") || request.nextUrl.pathname.startsWith("/static")) {
    return NextResponse.next()
  }

  // Apply different limits based on path
  let limiter
  if (request.nextUrl.pathname.startsWith("/api/auth")) {
    limiter = loginRateLimiter
  } else if (request.nextUrl.pathname.startsWith("/api/admin")) {
    limiter = createRateLimiter({
      maxRequests: 50,
      windowMs: 60000,
    })
  } else {
    limiter = apiRateLimiter
  }

  const ip = getClientIp(request)
  const result = await limiter.check(ip)

  if (!result.success) {
    return NextResponse.json(
      { error: "Rate limit exceeded" },
      {
        status: 429,
        headers: {
          "X-RateLimit-Limit": result.limit.toString(),
          "X-RateLimit-Remaining": result.remaining.toString(),
          "X-RateLimit-Reset": new Date(result.reset).toISOString(),
          "Retry-After": result.retryAfter?.toString() || "60",
        },
      },
    )
  }

  // Add rate limit headers to response
  const response = NextResponse.next()
  response.headers.set("X-RateLimit-Limit", result.limit.toString())
  response.headers.set("X-RateLimit-Remaining", result.remaining.toString())
  response.headers.set("X-RateLimit-Reset", new Date(result.reset).toISOString())

  return response
}
