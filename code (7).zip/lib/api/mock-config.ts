/**
 * Mock Data Configuration
 * Centralized configuration for mock data behavior
 */

export interface MockConfig {
  enabled: boolean
  networkDelay: {
    min: number
    max: number
  }
  errorRate: number // Percentage of requests that should fail (0-100)
  cacheEnabled: boolean
  cacheDuration: number // milliseconds
  logging: boolean
}

export const mockConfig: MockConfig = {
  get enabled() {
    if (typeof window !== "undefined") {
      return true // Default to enabled on client
    }
    return !process.env.NEON_DATABASE_URL
  },
  networkDelay: {
    min: 100,
    max: 500,
  },
  errorRate: 0, // Set to 5 for 5% error rate in testing
  cacheEnabled: true,
  cacheDuration: 5 * 60 * 1000, // 5 minutes
  get logging() {
    if (typeof window !== "undefined") {
      return false // Disable logging on client
    }
    return process.env.NODE_ENV === "development"
  },
}

// Simulate realistic network delay
export const simulateNetworkDelay = async (): Promise<void> => {
  const delay =
    Math.random() * (mockConfig.networkDelay.max - mockConfig.networkDelay.min) + mockConfig.networkDelay.min
  await new Promise((resolve) => setTimeout(resolve, delay))
}

// Simulate random errors for testing
export const shouldSimulateError = (): boolean => {
  return Math.random() * 100 < mockConfig.errorRate
}

// Mock error responses
export const mockErrors = {
  networkError: new Error("Network request failed"),
  unauthorized: new Error("Unauthorized access"),
  notFound: new Error("Resource not found"),
  validationError: new Error("Validation failed"),
  serverError: new Error("Internal server error"),
}

// Log mock operations
export const logMockOperation = (operation: string, details?: any) => {
  if (mockConfig.logging) {
    console.log(`[v0 Mock] ${operation}`, details || "")
  }
}
