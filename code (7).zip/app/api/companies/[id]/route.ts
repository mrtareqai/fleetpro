import { type NextRequest, NextResponse } from "next/server"
import { sql } from "@/lib/db"
import { requirePermission } from "@/lib/security/api-auth"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requirePermission(request, "companies.read")
    if (authResult instanceof Response) return authResult

    if (!sql) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const id = Number.parseInt(params.id)

    const { role, companyId } = authResult
    if (role !== "admin" && role !== "super_admin" && companyId !== id) {
      return NextResponse.json({ error: "You can only view your own company" }, { status: 403 })
    }

    const companies = await sql`
      SELECT * FROM companies WHERE id = ${id}
    `

    if (companies.length === 0) {
      return NextResponse.json({ error: "Company not found" }, { status: 404 })
    }

    return NextResponse.json(companies[0])
  } catch (error) {
    console.error("[v0] Error fetching company:", error)
    return NextResponse.json({ error: "Failed to fetch company" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requirePermission(request, "companies.update")
    if (authResult instanceof Response) return authResult

    if (!sql) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const id = Number.parseInt(params.id)

    const { role, companyId } = authResult
    if (role !== "admin" && role !== "super_admin" && companyId !== id) {
      return NextResponse.json({ error: "You can only update your own company" }, { status: 403 })
    }

    const body = await request.json()

    // Build update query dynamically
    const updates: string[] = []
    const values: any[] = []

    if (body.name !== undefined) {
      updates.push(`name = $${updates.length + 1}`)
      values.push(body.name)
    }
    if (body.owner_name !== undefined) {
      updates.push(`owner_name = $${updates.length + 1}`)
      values.push(body.owner_name)
    }
    if (body.contact_number !== undefined) {
      updates.push(`contact_number = $${updates.length + 1}`)
      values.push(body.contact_number)
    }
    if (body.email !== undefined) {
      updates.push(`email = $${updates.length + 1}`)
      values.push(body.email)
    }
    if (body.neon_url !== undefined) {
      updates.push(`neon_url = $${updates.length + 1}`)
      values.push(body.neon_url)
    }
    if (body.github_api_key !== undefined) {
      updates.push(`github_api_key = $${updates.length + 1}`)
      values.push(body.github_api_key)
    }
    if (body.is_active !== undefined) {
      updates.push(`is_active = $${updates.length + 1}`)
      values.push(body.is_active)
    }

    if (updates.length === 0) {
      return NextResponse.json({ error: "No fields to update" }, { status: 400 })
    }

    updates.push(`updated_at = NOW()`)

    const result = await sql`
      UPDATE companies
      SET ${sql(updates.join(", "))}
      WHERE id = ${id}
      RETURNING *
    `

    if (result.length === 0) {
      return NextResponse.json({ error: "Company not found" }, { status: 404 })
    }

    return NextResponse.json(result[0])
  } catch (error) {
    console.error("[v0] Error updating company:", error)
    return NextResponse.json({ error: "Failed to update company" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const authResult = await requirePermission(request, "companies.delete")
    if (authResult instanceof Response) return authResult

    if (authResult.role !== "super_admin") {
      return NextResponse.json({ error: "Only super administrators can delete companies" }, { status: 403 })
    }

    if (!sql) {
      return NextResponse.json({ error: "Database not configured" }, { status: 500 })
    }

    const id = Number.parseInt(params.id)

    const result = await sql`
      DELETE FROM companies WHERE id = ${id}
      RETURNING id
    `

    if (result.length === 0) {
      return NextResponse.json({ error: "Company not found" }, { status: 404 })
    }

    return NextResponse.json({ success: true, id: result[0].id })
  } catch (error) {
    console.error("[v0] Error deleting company:", error)
    return NextResponse.json({ error: "Failed to delete company" }, { status: 500 })
  }
}
