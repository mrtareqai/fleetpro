import DashboardLayout from "@/components/dashboard-layout"
import DriversTable from "@/components/drivers-table"

export default function DriversPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="drivers">
      <DriversTable locale={locale} />
    </DashboardLayout>
  )
}
