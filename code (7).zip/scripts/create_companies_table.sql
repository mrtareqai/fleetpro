-- Create companies table for multi-tenant support
CREATE TABLE IF NOT EXISTS companies (
  id SERIAL PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  url_code VARCHAR(100) UNIQUE NOT NULL,
  owner_name VARCHAR(255) NOT NULL,
  contact_number VARCHAR(50),
  email VARCHAR(255) NOT NULL,
  neon_url TEXT,
  github_api_key TEXT,
  admin_username VARCHAR(100) NOT NULL,
  admin_password VARCHAR(255) NOT NULL,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Create index on url_code for faster lookups
CREATE INDEX IF NOT EXISTS idx_companies_url_code ON companies(url_code);
CREATE INDEX IF NOT EXISTS idx_companies_is_active ON companies(is_active);

-- Add company_id to existing tables if not exists
DO $$ 
BEGIN
  -- Users table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='users' AND column_name='company_id') THEN
    ALTER TABLE users ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_users_company_id ON users(company_id);
  END IF;

  -- Vehicles table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='vehicles' AND column_name='company_id') THEN
    ALTER TABLE vehicles ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_vehicles_company_id ON vehicles(company_id);
  END IF;

  -- Drivers table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='drivers' AND column_name='company_id') THEN
    ALTER TABLE drivers ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_drivers_company_id ON drivers(company_id);
  END IF;

  -- Reservations table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='reservations' AND column_name='company_id') THEN
    ALTER TABLE reservations ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_reservations_company_id ON reservations(company_id);
  END IF;

  -- Tickets table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='tickets' AND column_name='company_id') THEN
    ALTER TABLE tickets ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_tickets_company_id ON tickets(company_id);
  END IF;

  -- Movements table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='movements' AND column_name='company_id') THEN
    ALTER TABLE movements ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_movements_company_id ON movements(company_id);
  END IF;

  -- Supplies table
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                 WHERE table_name='supplies' AND column_name='company_id') THEN
    ALTER TABLE supplies ADD COLUMN company_id INTEGER REFERENCES companies(id);
    CREATE INDEX idx_supplies_company_id ON supplies(company_id);
  END IF;
END $$;

-- Insert demo company
INSERT INTO companies (
  name, 
  url_code, 
  owner_name, 
  contact_number, 
  email, 
  admin_username, 
  admin_password,
  is_active
) VALUES (
  'Demo Company',
  'demo',
  'Demo Owner',
  '+1-555-0000',
  'demo@fleetpro.com',
  'admin',
  'password123',
  true
) ON CONFLICT (url_code) DO NOTHING;

-- Create superadmin user for topowner
INSERT INTO users (
  username,
  email,
  password_hash,
  full_name,
  role,
  company_id,
  is_active
) VALUES (
  'topowner',
  'topowner@fleetpro.com',
  '$2a$10$YourHashedPasswordHere', -- Replace with actual bcrypt hash of 'mrtareq2008'
  'Top Owner',
  'superadmin',
  NULL,
  true
) ON CONFLICT (username) DO NOTHING;

COMMENT ON TABLE companies IS 'Stores company information for multi-tenant support';
COMMENT ON COLUMN companies.url_code IS 'Unique URL identifier for the company (e.g., "demo" for /demo/login)';
COMMENT ON COLUMN companies.neon_url IS 'Optional separate Neon database URL for complete data isolation';
COMMENT ON COLUMN companies.is_active IS 'Whether the company account is active and can be accessed';
