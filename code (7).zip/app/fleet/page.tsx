import DashboardLayout from "@/components/dashboard-layout"
import FleetTable from "@/components/fleet-table"

export default function FleetPage({
  searchParams,
}: {
  searchParams: { locale?: string }
}) {
  const locale = (searchParams.locale || "en") as "en" | "ar"

  return (
    <DashboardLayout locale={locale} activePage="fleet">
      <FleetTable locale={locale} />
    </DashboardLayout>
  )
}
